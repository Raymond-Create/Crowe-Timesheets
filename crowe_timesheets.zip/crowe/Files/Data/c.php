<?php

GAT001 Gateway Construction (Private) Limited
GHS001 Girls High School
HCH001 High Court Housing Corporative
KIM001 Kimberworth Investments (Private) Limited
LMP001 Lovemore Madhuku Legal Practitioners
MAK001 Makomo Primary School
MVA001 MicroVentures Africa Limited
MIN001 Mine Roof (Private) Limited
RDC001 National Employment Council for the Rural District Councils
NKL001 Nyika Kanengoni Legal Practitioners
ORI001 Original Technology (Private) Limited
POL001 Police Heights Corporative
PRA001 Practical Action
PRA002 Practical Action - Projects
PES001 Prince Edward School
RHC001 Ranche House College
PPE001 Select PPE (Zambia) Limited
SHA001 Shawash Agric (Private) Limited
TRA001 Transmedia Corporation (Private) Limited
TYN0001 Tynwald Group of Schools
VAS001 Vast Resources (Private) Limited
VSO001 Voluntary Services Organisation (VSO)
WIZ001 Wiz Ear Trust
WIZ002 Wiz Ear Trust - Projects 
ZIM001 Zimbabwe Small Organic Farmers Forum
ZIM002 Zimbabwe Small Organic Farmers Forum - LVC