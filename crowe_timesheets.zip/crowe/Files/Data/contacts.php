<?php

return [
    [["Contact","Base"],[
        "name"=>"Council for Estate Administrators",
        "code"=>"CEA001",
        "type"=>[
            ["ContactType","Base"],
            [
                "name"=>"CLIENTS","type"=>"customer"
            ]
        ]
    ]],
    [["Contact","Base"],[
        "name"=>"CSI Electrical (Zambia) Limited",
        "code"=>"CSI001",
        "type"=>[
            ["ContactType","Base"],
            [
                "name"=>"CLIENTS","type"=>"customer"
            ]
        ]
    ]],
    [["Contact","Base"],[
        "name"=>"Domboramwari High School",
        "code"=>"DOM001",
        "type"=>[
            ["ContactType","Base"],
            [
                "name"=>"CLIENTS","type"=>"customer"
            ]
        ]
    ]],
    [["Contact","Base"],[
        "name"=>"Ephtha Energy (Private) Limited",
        "code"=>"EPH001",
        "type"=>[
            ["ContactType","Base"],
            [
                "name"=>"CLIENTS","type"=>"customer"
            ]
        ]
    ]],
    [["Contact","Base"],[
        "name"=>"Epworth Local Board",
        "code"=>"ELB001",
        "type"=>[
            ["ContactType","Base"],
            [
                "name"=>"CLIENTS","type"=>"customer"
            ]
        ]
    ]]
];
