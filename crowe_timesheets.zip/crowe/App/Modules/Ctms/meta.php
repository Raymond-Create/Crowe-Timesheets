<?php

return [
	'path'=>'Ctms',
	'version'=>'1.0',
	'publication'=>'2023-02-15',
	'restriction'=>'Licensed',
	'notes'=>'Module-for time management in a consulting environment',
	'icon'=>"mdi mdi-account-group-outline",
	'name'=>'Ctms',
	'flag'=>1
 ];