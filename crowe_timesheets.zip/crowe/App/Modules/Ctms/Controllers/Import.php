<?php

namespace Mod\Ctms\Controllers;

use  Core\Base\Library\Controller;

use Mod\Ctms\Library\TasksView as Ev;

class Import extends Controller{

    public function contacts()
    {
        $file=FILES .DS. "Data" .DS. "contacts.csv";
        $data=file_get_contents($file);
        $ex=explode("\n",$data);
        foreach($ex as $line){
            $yo=explode(",",$line);//x($yo,9);
            $mod=\Lib\TableFixer::init("Contact","Base");
            $usr=$this->userId(trim($yo[9]));
            $mod->fetch([
                "where"=>[
                    "code"=>"CL00".trim($yo[0]),
                    "name"=>trim($yo[1]),
                    "sector"=>trim($yo[2]),
                    "contact_person"=>trim($yo[3]),
                    "position"=>trim($yo[4]),
                    //"email"=>trim($yo[5]),
                    "phone"=>trim($yo[6]),
                    "user"=>$usr,
                    "type"=>1
                ]
            ]);
            $mod->code="CL00".trim($yo[0]);
            $mod->name=trim($yo[1]);
            $mod->sector=trim($yo[2]);
            $mod->contact_person=trim($yo[3]);
            $mod->position=trim($yo[4]);
            if(preg_match(EMAIL_RGX, trim($yo[5])))
            {
                $mod->email=trim($yo[5]);
            }
            $mod->phone=trim($yo[6]);
            $mod->user=$usr;
            $mod->type=1;
            //x($mod->data(),9);
            $mod->save();
        }
        $this->json("done");
    }
     
    private function userId($name)
    {
        $usr=\Lib\TableFixer::init("User","Authentication");
        $auth= \Lib\Factory::init()->get_model("Authentication","Authentication");
        $nm=explode(" ",$name);//x($nm,9);
        $auth->fetch([
            "where"=>["name"=>$nm[0],"surname"=>$nm[1]]
        ]);
        if(!$auth->id){
            $auth->id=$this->missingUser($nm[0],$nm[1]);
        }
        $usr->fetch([
            "where"=>["user_id"=>$auth->id]
        ]);
        $usr->name=$name;
        $usr->user_id=$auth->id;
        $usr->role=3;
        $id=$usr->save();
        return $usr->id?:$id;
    }
    
    private function missingUser($name,$surname)
    {
        $auth= \Lib\Factory::init()->get_model("Authentication","Authentication");
        $email=strtolower($name).'.'.strtolower($surname)."@crowe.co.zw";//x($nm,9);
        $auth->fetch([
            "where"=>[
                "email"=>$email
            ]
        ]);
        $auth->name=$surname;
        $auth->email=$email;
        $auth->code=0;
        $auth->moblie=0;
        $auth->ehash=rand(0,100000000);
        $auth->mhash=rand(0,100000000);
        $auth->password='$2y$11$pifh3UFlt6Uiu7F8kdBXbeXp9lLoKQF09qmQIy6iwc29Vw8U2xV5K';
        $id=$auth->save();
        return $auth->id?:$id;
    }
    
    public function sheet($name)
    {
        $file=FILES .DS. "Data" .DS. "$name.csv";
        $data=file_get_contents($file);
        $ex=explode("\n",$data);
        foreach($ex as $line){
            $yo=explode(",",$line);
            $mod= \Lib\Factory::app("TimeSheet","Ctms");
            $employee=$this->employee(trim($yo[0]));
            $start=str_replace(" PM","",str_replace(" AM","",trim($yo[2])));
            $finish=str_replace(" PM","",str_replace(" AM","",trim($yo[3])));
            $task=$this->task($yo);
            $mod->fetch([
                "where"=>[
                    "employee"=>$employee,
                    "date"=>trim($yo[1]),
                    "start"=>$start,
                    "finish"=>$finish,
                    "task"=>$task->id
                ]
            ]);//x($task,8);
            $mod->employee=$employee;
            $mod->date=trim($yo[1]);
            $mod->start=$start;
            $mod->finish=$finish;
            $mod->billable=$task->billable;
            $mod->task=$task->id;
            $mod->stage='Approval';
            $desc=trim($yo[5]);
            if(!empty($desc))
            {
                $mod->description=$desc;
            }
            if(!empty($yo[6]) && preg_match("/[a-zA-z0-9]+/",$yo[6]))
            {//x($yo[6]);x(strlen($yo[6]),9);
                $mod->client=$this->client($yo[6]);
            }
            $mod->save();
        }
        $this->json("done");
    }
    private function client($data)
    {  
        $mod=\Lib\Factory::app("Contact","Base");
        $a=$mod->fetch([
            "where"=>[
                "name"=>trim(strtoupper($data))
            ]
        ]);//x(qd());x($a);x($mod->data(),6);
        if($mod->id)
        {
            return $mod->id;
        }
        x($data,9);
    }
    private function task($data)
    {
        $mod= \Lib\Factory::app("Task","Ctms");
        $mod->fetch([
            "where"=>[
                "code"=>trim($data[4])
            ]
        ]);
        if($mod->id)
        {
            return $mod;
        }x(qd());x($mod->data(),6);
        x($data[4],9);
    }
    private function employee($name)
    {
        $mod= \Lib\Factory::app("User","Authentication");
        $mod->fetch([
            "where"=>[
                "name"=>$name
            ]
        ]);
        if($mod->id)
        {
            return $mod->id;
        }
        $auth=$this->auth($name);
        $mod->fetch([
            "where"=>[
                "user_id"=>$auth
            ]
        ]);
        $mod->name=$name;
        $mod->user_id=$auth;
        $mod->role=5;
        return $mod->save();
    }
    private function auth($name)
    {
        $mod= \Lib\Factory::init()->get_model("Authentication","Authentication");
        $nm=explode(" ",$name);
        $email=strtolower($nm[0]).'.'.strtolower($nm[1])."@crowe.co.zw";//x($nm,9);
        $mod->fetch([
            "where"=>[
                "email"=>$email
            ]
        ]);
        if($mod->id)
        {
            return $mod->id;
        }
        //$auth=$this->auth($name);
        x($name);
    }
    
    public function tasks()
    {
        $file=FILES .DS. "Data" .DS. "Book1.csv";
        $data=file_get_contents($file);
        $ex=explode("\n",$data);
        foreach($ex as $line){
            $yo=explode(",",$line);
            $mod= \Lib\Factory::app("Task","Ctms");
            $type=$this->department(trim($yo[0]));
            $mod->fetch([
                "where"=>[
                    "name"=>trim($yo[2]),
                    "code"=>trim($yo[1]),
                    "type"=>$type->id
                ]
            ]);
            $mod->type=$type->id;
            $mod->name=trim($yo[2]);
            $mod->code=trim($yo[1]);
            $mod->flag=$type->flag?:0;
            $mod->price=0;
            $mod->save();
        }
        $this->json("done");
    }
    
	public function users()
    {
        $file=FILES .DS. "Data" .DS. "users.txt";
        $data=file_get_contents($file);
        $ex=explode("\n",$data);
            $md= \Lib\Factory::app("Task","Ctms");
            try{
                $md->begin();
                foreach($ex as $line){
                    $yo=explode(",",$line);
                    $mod= \Lib\Factory::init()->get_model("Authentication","Authentication");
                    $org= \Lib\Factory::init()->get_model("Org","Authentication");
                    $db= \Lib\Factory::init()->get_model("Org","Authentication");
                    $org->fetch([
                            "where"=>["name"=>"CROWE"]
                    ]);
                    $mod->fetch([ "where"=>["email"=>trim($yo[2]) ]]);
                    $mod->name=trim($yo[0]);
                    $mod->surname=trim($yo[1]);
                    $mod->email=trim($yo[2]);
                    $mod->code=0;
                    $mod->mobile=0;
                    $mod->ehash=rand(0,1000000000);
                    $mod->mhash=rand(0,1000000000);
                    $mod->password='Password-Default';
                    x($mod->data(),9);
                    $mod->save();
                }
                $md->commit();
                $this->json("done");
            }catch(\Exception $exc){
                $md->rollback();
                x($exc,8);
            }
        
    }
	
    private function department($name)
    {
        $mod= \Lib\Factory::app("Department","Ctms");
        $mod->fetch([
            "where"=>["name"=>$name]
        ]);
        $mod->name=$name;
        $x=$mod->save();
        if(!$mod->id)
        {
            $mod->id=$x;
        }
        return $mod;
    }
}