<?php

namespace Mod\Ctms\Controllers;

use  Core\Base\Library\Controller;

use Mod\Ctms\Library\TimesheetsView as Ev;
use Core\Authentication\Library\User;

class Details extends Controller{
		
    use \Core\Base\Library\Index;

    public 
        //$show_form=1,
        $_lib=["TimeSheet","Ctms"],
        $_model=["TimeSheet","Ctms"];

        public function __table($rows,$page):\Huchi\Classes\Tag
	{
	    if(User::is("STAFF"))
            {
                $this->table["filter"]=[
                    "where"=>[
                        "employee"=>User::id()
                    ]
                ];
                //$stage="Approva"
            }else{
                $this->table["script"]="ts-support";
                $this->table["action"]=[
                    ["icon"=>"fa fa-eye mr-2","text"=>"View","act"=>"btn-view"],
                    ["icon"=>"mdi mdi-account-check-outline mr-2","text"=>"Authorize","act"=>"btn-auth"],
                    ["icon"=>"fa fa-edit mr-2","text"=>"Edit","act"=>"btn-edit"],
                    ["icon"=>"fa far fa-trash-alt mr-2","text"=>"Delete","act"=>"btn-delete"]
                ];
            }
            $this->table["filter"]["where"]=["stage"=>"Assingment"];
            $this->table["search_forms"]=[
	        "employee","task","date"
	    ];
            $this->table["widths"]=[
                "finish"=>"80px","start"=>"80px","date"=>"70px",
                "billable"=>"60px","num"=>"60px","stage"=>"60px"
            ];
            $table=parent::__table($rows, $page);
	    return Ev::init($table)->html();
	}
        
        public function authorise($id)
        {
            $form=new \Mod\Ctms\Library\Authorisation($id);
            $this->ajax($form->html());
        }
}