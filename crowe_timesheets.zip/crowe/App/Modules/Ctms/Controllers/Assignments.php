<?php

namespace Mod\Ctms\Controllers;

use  Core\Base\Library\Controller;

use Mod\Ctms\Library\AssignmentsView as Ev;
use Core\Authentication\Library\User;

class Assignments extends Controller{
		
    use \Core\Base\Library\Index;

    public 
        //$show_form=1,
        $_lib=["TimeSheet","Ctms"],
        $_model=["TimeSheet","Ctms"];

        public function __table($rows,$page):\Huchi\Classes\Tag
	{
	    if(User::is("STAFF"))
            {
                $this->table["filter"]=[
                    "where"=>[
                        "employee"=>User::id()
                    ]
                ];
                //$stage="Approva"
            }else{
                $this->table["script"]="ts-support";
                $this->table["action"]=[
                    ["icon"=>"fa fa-eye mr-2","text"=>"View","act"=>"btn-view"],
                    ["icon"=>"fa fa-edit mr-2","text"=>"Edit","act"=>"btn-edit"],
                    ["icon"=>"fa far fa-trash-alt mr-2","text"=>"Delete","act"=>"btn-delete"]
                ];
            }
            $this->table["filter"]["where"]["stage"]="Assignment";
            $this->table["search_forms"]=[
	        "employee","task","date"
	    ];
            $this->table["widths"]=[
                "finish"=>"80px","start"=>"80px","date"=>"70px",
                "billable"=>"60px","num"=>"60px","stage"=>"60px"
            ];//x($this->table["filter"],8);
            $table=parent::__table($rows, $page);
	    return Ev::init($table)->html();
	}
        
    public function assign($id)
    {
        $form=new \Mod\Ctms\Library\Assignment();
        $form->set_budget_line($id);
        if($this->post())
        {
            return $this->_put(null);
        }
        $this->ajax($form->html());
    }
}