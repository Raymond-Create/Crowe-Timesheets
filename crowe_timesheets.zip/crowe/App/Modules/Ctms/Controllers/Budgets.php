<?php

namespace Mod\Ctms\Controllers;

use Core\Base\Controllers\Records as Controller;

use Mod\Ctms\Library\EstimatesView as Ev;

class Budgets extends Controller{
		
    use \Core\Base\Library\Index;

    
        
        public function __table($rows,$page):\Huchi\Classes\Tag
    {
        $this->table["script"]="budget-support";
        $this->table["action"]=[
            ["icon"=>"fa fa-eye mr-2","text"=>"View","act"=>"btn-view"],
            ["icon"=>"fa fa-file-pdf mr-2","text"=>"View PDF","act"=>"btn-open"],
            ["icon"=>"mdi mdi-account-arrow-right-outline mr-2","text"=>"Assign","act"=>"btn-assign"],
            ["icon"=>"fa fa-edit mr-2","text"=>"Edit","act"=>"btn-edit"],
            ["icon"=>"fa far fa-trash-alt mr-2","text"=>"Delete","act"=>"btn-delete"]
        ];
        $this->table["widths"]=[
            "type"=>"70px","date"=>"70px","due"=>"70px",
            "currency"=>"70px","ref"=>"72px",
            "amount"=>"70px","comment"=>"100px",
            "prefix"=>"70px","number"=>"70px","paid"=>"70px"
        ];
        $this->table["search_forms"]=["date","contact","number","ref"];
        $table=parent::__table($rows, $page);
        return Ev::init($table)->html();
    }

    public
       $_lib=["Estimate",'Ctms'],
       $_model=["Record",'Ctms'];

}