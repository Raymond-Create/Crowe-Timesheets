<?php

namespace Mod\Ctms\Controllers;

use  Core\Base\Library\Controller;

use Mod\Ctms\Library\DepartmentsView as Ev;

class Departments extends Controller{
		
    use \Core\Base\Library\Index;

    public 
        $show_form=1,
        $_model=["Department","Ctms"];

        public function __table($rows,$page):\Huchi\Classes\Tag
	{
	    $this->table["search_forms"]=[
	        "name","flag"
	    ];
            $table=parent::__table($rows, $page);
	    return Ev::init($table)->html();
	}

}