<?php

namespace Mod\Ctms\Controllers;

use  Core\Base\Library\Controller;

use Mod\Ctms\Library\NotificationsView as Ev;
use Core\Authentication\Library\User;

class Notifications extends Controller{
		
    use \Core\Base\Library\Index;

    public 
        //$show_form=1,
        //$_lib=["TimeSheet","Ctms"],
        $_model=["Notification","Ctms"];

        public function __table($rows,$page):\Huchi\Classes\Tag
	{
            $this->table["filter"]=[
                "where"=>[
                    "user_id"=>User::id(),'dismissed'=>0
                ]
            ];
            $this->table["action"]=[
                    ["icon"=>"fa fa-eye mr-2","text"=>"Dismis","act"=>"btn-dismis"]
                ];
            $this->table["search_forms"]=[
	        "type","user_id","title"
	    ];
            $this->table["widths"]=[
                "title"=>"80px","type"=>"70px","created"=>"100px",
                "billable"=>"60px","num"=>"60px","stage"=>"60px"
            ];//x($this->table["filter"],8);
            $table=parent::__table($rows, $page);
	    return Ev::init($table)->html();
	}
        
    
}