<?php

namespace Mod\Ctms\Controllers;

use  Core\Base\Library\Controller;

use Mod\Ctms\Library\StaffView as Ev;

class Staff extends Controller{
		
    use \Core\Base\Library\Index;

    public 
        //$show_form=1,
        $_lib=["Employee","Ctms"],
        $_model=["Employee","Ctms"];

        public function __table($rows,$page):\Huchi\Classes\Tag
	{
	    $this->table["filter"]=[
	        "where"=>[
                    "user"=>\Core\Authentication\Library\User::id()
                ]
	    ];
            $this->table["search_forms"]=[
	       // "name","surname","identity_type","department"
	    ];
            $table=parent::__table($rows, $page);
	    return Ev::init($table)->html();
	}

}