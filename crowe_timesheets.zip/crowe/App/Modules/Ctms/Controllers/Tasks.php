<?php

namespace Mod\Ctms\Controllers;

use  Core\Base\Library\Controller;

use Mod\Ctms\Library\TasksView as Ev;

class Tasks extends Controller{
		
    use \Core\Base\Library\Index;

    public 
        $show_form=1,
        $_model=["Task","Ctms"];

        public function __table($rows,$page):\Huchi\Classes\Tag
	{
	    $this->table["search_forms"]=[
	        "type","code","name","flag"
	    ];
            $this->table["widths"]=[
                "flag"=>"70px","price"=>"70px","code"=>"70px",
                "type"=>"70px","name"=>"200px"
            ];
            $table=parent::__table($rows, $page);
	    return Ev::init($table)->html();
	}

}