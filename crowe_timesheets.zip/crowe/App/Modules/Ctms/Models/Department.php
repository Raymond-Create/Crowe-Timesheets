<?php

namespace Mod\Ctms\Models;


class Department extends \Lib\Model
{
    
    public $_rep_=['name'];
    
    public $_group_=['flag'];
    
    public function _setup()
    {
        return [
            'hod'=>_foreign([
                'model'=>['User','Authentication'],'null'=>1
            ]),
            'name'=>_char(["unique"=>1,"index"=>1]),
            'billable'=>_integer([
                'default'=>0,
                'options'=>["No","Yes"]
            ]),
            'Shared'=>_integer([
                'default'=>0,
                'options'=>["No","Yes"]
            ]),
            'flag'=>_integer([
                'default'=>0,'hide'=>0,
                'options'=>["No","Yes"]
            ])
        ];
    }//ALTER TABLE `departments` ADD `hod` INT NULL FIRST; 
    
    public function setName($name)
    {
        return strtoupper($name);
    }
    
}