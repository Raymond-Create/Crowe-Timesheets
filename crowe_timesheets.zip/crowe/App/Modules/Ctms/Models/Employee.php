<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Mod\Ctms\Models;

/**
 * Description of Wage
 *
 * @author Hp
 */
use Core\Base\Library\Number;
use Core\Base\Library\Prefix;

class Employee  extends \Lib\Model{

    public $_prefix="STF";
    
    public $_flag=1;
    
        public function _setup(){    
    	return [
            'contact'=>_foreign([
               "model"=>["Contact","Base"],"null"=>1,"hide"=>1
            ]),
            'prefix'=>_char(['null'=>1,'hide'=>1]),
            'number'=> _integer(['null'=>1,'disabled'=>1]),
            'title'=>_char(['null'=>1,'hide'=>1]),
            'name'=>_char(),
            'surname'=>_char(),
            'date_first'=>_date(['null'=>1,'hide'=>1]),
            'dob'=>_date(["null"=>1,'hide'=>1]),
            'user'=>_foreign([
               "model"=>["User","Authentication"],'null'=>1,
                'disabled'=>1,"hide"=>1
            ]),
            'identity_type'=>_char([
                "choices"=>[
                    "Passport","ID","Licence","Other"
                ],"default"=>"Licence"
            ]),
            'identity'=>_char(),
            'user'=>_foreign([
               "model"=>["User","Authentication"],'null'=>1,
                'disabled'=>1,"hide"=>1
            ]),
    	    'supervisor'=> _integer([
                'null'=>1,'hide'=>1,
                //'model'=>["Employee","Ctms"]
            ]),
    	    'designation'=> _integer(['null'=>1,'hide'=>1]),
    	    'department'=> _foreign(['null'=>1,'model'=>["Department","Ctms"]]),
    	    'rate'=> _decimal(['default'=>0.00]),
    	    'cluster'=>_char(['index'=>1,'hide'=>1]),
    	    'flag'=> _integer(['null'=>1,'hide'=>1]),
    	    'flag2'=> _integer(['null'=>1,'hide'=>1])
        ];
    }
	
    public function insert(array $crit,$table=false)
    {
        $num=new Number($this);
        $prefix=Prefix::init($this,$crit);
        $num->field="number";
        $num->date="date_first";
        $num->init=$prefix->get_initial();
        $crit["prefix"]=$prefix->get_prefix();
        $crit['number']=$num->getNext();
        $crit['flag2']=0;
        $crit['cluster']="Ctms.Employee";//x($crit,9);
        $crit['user']=\Core\Authentication\Library\User::id();
        return parent::insert($crit,$table);
    }
}