<?php

namespace Mod\Ctms\Models;


class Task extends \Lib\Model
{
    
    public $_rep_=['code','name'];
    
    public $_group_=['type'];
    
    public function _setup()
    {
        return [
            'type'=>_foreign([
                'model'=>['Department','Ctms'],
                'null'=>1,"verbose"=>"Department"
            ]),
            'code'=>_char(["null"=>1,"index"=>1,"pattern"=>"/[a-zA-Z0-9\/\- ]+/"]),
            'name'=>_char(["unique"=>1,"index"=>1,"pattern"=>"/[a-zA-Z0-9\/\-\(\) ]+/"]),
            'billable'=>_integer([
                'default'=>0,'options'=>["No","Yes"],"hide"=>1
            ]),
            'flag'=>_integer([
                "hide"=>1,'default'=>0,
                'options'=>["No","Yes"]
            ]),
            'flag2'=>_integer([
                'default'=>0,'hide'=>1,
                'options'=>["No","Yes"]
            ])
        ];
    }
    
    public function setName($name)
    {
        return strtoupper($name);
    }
    
    public function insert(array $data, $table = false) {
        $mod= \Lib\Factory::app("Department","Ctms");
        $mod->get($data["flag"]);
        if($mod->flag){
            $data["flag"]=$mod->flag;
        }
        return parent::insert($data, $table);
    }
    
}