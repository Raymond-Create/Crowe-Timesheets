<?php

namespace Mod\Ctms\Models;


class Record extends \Core\Base\Models\Record
{
    
    public function _setup()
    {
        return [
            'date'=>_date(),
            'due'=>_date(["null"=>1]),
            'location'=>_foreign([
                'model'=>['Location','Base'],
                'null'=>1,"hide"=>1
            ]),
            'business'=>_foreign([
                'model'=>['Location','Base'],
                'null'=>1,"hide"=>1
            ]),
            'doc_type'=>_foreign([
                'model'=>['DocType','Base'],"hide"=>1
            ]),
            'category'=>_foreign([
                'model'=>['Category','Base'],"hide"=>1,
                "null"=>1
            ]),
            'prefix'=>_char(["null"=>1]),
            'number'=>_integer([
                'null'=>1,'index'=>1
            ]),
            'contact'=>_foreign([
                'model'=>['Contact','Base'],'null'=>1
            ]),
            'debit'=>_foreign([
                'model'=>['Account','Base'],'null'=>1,"hide"=>1
            ]),
            'credit'=>_foreign([
                'model'=>['Account','Base'],'null'=>1,"hide"=>1
            ]),
            'journalised'=>_integer([
                'default'=>1,'hide'=>1,
                'options'=>["Never","No","Yes"]
            ]),
            'accrual'=>_integer([
                'options'=>["No","Yes"],"default"=>1,"hide"=>1
            ]),
            'comment'=>_char([
                'null'=>1,"pattern"=>"/^[a-zA-Z0-9\/\-\,\(\)\+\.\:\$ ]+$/","hide"=>1
            ]),
            'ref'=>_char([
                'null'=>1,'index'=>1
            ]),
            'type'=>_char([
                'choices'=>['Receipt','Payment'],"null"=>1,"hide"=>1
            ]),
            'currency'=>_foreign([
                'model'=>['Currency','Base']
            ]),
            'rate'=>_foreign([
                'model'=>['Rate','Base'],"hide"=>1
            ]),
            'authorisation'=>_datetime([
            	"null"=>1,"hide"=>1
            ]),
            'creation'=>_datetime([
            	"null"=>1,"hide"=>1
            ]),
            'method'=>_foreign([
                'model'=>['CashAccount','Base'],
                'null'=>1,"hide"=>1
            ]),
            'cluster'=>_char(["null"=>1,"hide"=>1]),
            'creator'=>_foreign([
                'model'=>['User','Authentication'],"hide"=>1
            ]),
            'authoriser'=>_foreign([
                'model'=>['User','Authentication'],
                'null'=>1,"hide"=>1
            ]),
            'subtotal'=>_decimal(["pattern"=>'/^-?[0-9]\d*(\.\d+)?$/',"hide"=>1]),
            'amount'=>_decimal(["pattern"=>'/^-?[0-9]\d*(\.\d+)?$/']),
            'tax'=>_decimal(['null'=>1,"hide"=>1]),
            'paid'=>_decimal(['default'=>0,"hide"=>1]),
            'int_1'=>_integer(['null'=>1,'hide'=>1]),
            'int_2'=>_integer(['null'=>1,'hide'=>1]),
            'int_3'=>_integer(['null'=>1,'hide'=>1]),
            'dec_1'=>_decimal(['null'=>1,'hide'=>1]),
            'dec_2'=>_decimal(['null'=>1,'hide'=>1]),
            'dec_3'=>_decimal(['null'=>1,'hide'=>1]),
            'nt1'=>_integer(['null'=>1,'hide'=>1]),
            'nt2'=>_integer(['null'=>1,'hide'=>1]),
            'nt3'=>_integer(['null'=>1,'hide'=>1]),
            'dec1'=>_decimal(['null'=>1,'hide'=>1]),
            'dec2'=>_decimal(['null'=>1,'hide'=>1]),
            'dec3'=>_decimal(['null'=>1,'hide'=>1]),
            'cha1'=>_char(['null'=>1,'hide'=>1]),
            'cha2'=>_char(['null'=>1,'hide'=>1]),
            'cha3'=>_char(['null'=>1,'hide'=>1]),
            'txt1'=>_text(['null'=>1,'hide'=>1]),
            'txt2'=>_text(['null'=>1,'hide'=>1]),
            'txt3'=>_text(['null'=>1,'hide'=>1]),
            'dat1'=>_date(['null'=>1,'hide'=>1]),
            'dat2'=>_date(['null'=>1,'hide'=>1]),
            'dat3'=>_date(['null'=>1,'hide'=>1]),
            'dtt1'=>_datetime(['null'=>1,'hide'=>1]),
            'dtt2'=>_datetime(['null'=>1,'hide'=>1]),
            'dtt3'=>_datetime(['null'=>1,'hide'=>1]),
            'active'=>_integer([
                'default'=>1,'hide'=>1,
                'options'=>["No","Yes"]
            ])
        ];
    }
    
    public function insert(array $crit, $table = false) 
    {//x($data,9);
        if(!isset($crit['cluster']))
        {
            $crit['cluster']=$this->_cluster;
        }
        $num=new Number($this);
        $prefix=Prefix::init($this,$crit);
        $num->date="date";
        $num->field="number";
        $num->group="doc_type";
        $crit['creator']=User::id();
        $num->value=$crit["doc_type"];
        $num->init=$prefix->get_initial();
        $crit['creation']=date('Y-m-d H:i:s');
        if(!isset($crit['prefix']))
        {
            $crit["prefix"]=$prefix->get_prefix();
        }
        $crit['number']=$num->getNext();
        return parent::insert($crit, $table);
    }
    
    public function setCluster($val){
        if(!$val){
            $val=$this->_cluster;
        }
        return $val;
    }
    /*public function update(array $data=[], $cr=[], $table=false)
    {
        if($this->isLocked($data)){
            return false;
        }
        return parent::update($data, $cr, $table);
    }
    
    public function isLocked($data){
        return $this->locked($data)&&$this->isNotEntry($data);
    }
    
   
    
    
    
    public function isNotEntry($data){
        $mod=Lf::app("Source","Doc");
        $data=$mod->read([
            "where"=>[
                "model"=>["in"=>["Depreciation","Entry"]],
                "id"=>$data["source"]
            ]
        ]);
        //empty data mean source is not entry or deprecition
        return empty($data);
    }
    
    public function setAmount($amnt)
    {
        return currency($amnt);
    }
    
    public function setPaid($amnt)
    {
        return currency($amnt);
    }
    */
}

//ALTER TABLE `records` ADD `subtotal` DECIMAL(16,2) NOT NULL DEFAULT '0' AFTER `authoriser`; 