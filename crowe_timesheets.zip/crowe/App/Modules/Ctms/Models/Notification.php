<?php

namespace Mod\Ctms\Models;


class Notification extends \Lib\Model
{
    
    public $_rep_=['title'];
    
    public $_group_=['type'];
    
    public function _setup()
    {
        return [
            'created'=> _datetime(),
            'type'=>_char([
                'choices'=>['Error','Warning',"Success","Info"],
                'default'=>"Success"
            ]),
            'title'=>_char(["index"=>1,"pattern"=>"/[a-zA-Z0-9\/\- ]+/"]),
            'body'=>_text(["pattern"=>"/[a-zA-Z0-9\/\-\(\)\<\>\=\"\'\: ]+/"]),
            'resource'=>_char(["null"=>1,"hide"=>1]),
            'resource_id'=>_integer(["hide"=>1,'null'=>1]),
            'dismissed'=>_integer([
                'default'=>0,'hide'=>1,
                'options'=>["No","Yes"]
            ]),
            'user_id'=>_foreign([
                'model'=>['User','Authentication'],'null'=>1,"hide"=>1
            ]),
            'frequency'=>_integer(['default'=>1]),
            'flag'=>_integer([
                'default'=>0,'hide'=>1,
                'options'=>["No","Yes"]
            ])
        ];
    }
    
    public function setTitle($name)
    {
        return strtoupper($name);
    }
    
    public function insert(array $data, $table = false) {
        $data["created"]=date("Y-m-d H:i:s");
        return parent::insert($data, $table);
    }
    
}