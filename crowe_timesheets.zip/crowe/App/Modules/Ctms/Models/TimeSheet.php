<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Mod\Ctms\Models;

/**
 * Description of Wage
 *
 * @author Hp
 */
use Core\Authentication\Library\User;
use Mod\Ctms\Library\Notifications;

class TimeSheet  extends \Lib\Model{

    public $_prefix="DRV";
    
    public $_flag=1;
    
        public function _setup(){    
    	return [
            'date'=>_date(['null'=>1]),
            'num'=>_integer(),
            'start'=>_char(['null'=>1,"pattern"=>"/^\d{2}\:\d{2}\:\d{2}$/"]),
            'finish'=>_char(['null'=>1,"pattern"=>"/^\d{2}\:\d{2}\:\d{2}$/"]),
            'client'=>_foreign([
               "model"=>["Contact","Base"],"null"=>1
            ]),
            'employee'=>_foreign([
               "model"=>["User","Authentication"]
            ]),
            'task'=>_foreign([
               "model"=>["Task","Ctms"]
            ]),
            'billable'=> _integer([
               "option"=>["Billable","Non Billable"]
            ]),
            'rate'=>_decimal(['default'=>'0.00','hide'=>1]),
            'expected_duration'=>_decimal(['default'=>'0.00','hide'=>1]),
            'actual_duration'=>_decimal(['default'=>'0.00','hide'=>1]),
            'description'=>_text(['null'=>1]),
            'cluster'=>_char(['index'=>1,'hide'=>1,'null'=>1]),
    	    'start_h'=> _integer(['null'=>1,'hide'=>1,"pattern"=>'/^\d\d$/']),
    	    'start_m'=> _integer(['null'=>1,'hide'=>1,"pattern"=>'/^\d\d$/']),
    	    'finish_h'=> _integer(['null'=>1,'hide'=>1,"pattern"=>'/^\d\d$/']),
    	    'finish_m'=> _integer(['null'=>1,'hide'=>1,"pattern"=>'/^\d\d$/']),
    	    'created'=>_datetime(['null'=>1,'hide'=>1]),
            'assignment'=>_datetime(['null'=>1,'hide'=>1]),
            'authorised'=>_datetime(['null'=>1,'hide'=>1]),
            'stage'=>_char([
                "choices"=>["Assignment","Approval","TimeSheet"]
            ]),
            "action"=>_char(['hide'=>1,'null'=>1]),
            "comment"=>_text(['hide'=>1,'null'=>1]),
            'line'=> _foreign([
               "model"=>["SourceLine","Base"],"null"=>1,"hide"=>1
            ]),
            'authoriser'=>_foreign([
               "model"=>["User","Authentication"],"null"=>1
            ]),
            'flag'=> _integer(['null'=>1,'hide'=>1]),
    	    'flag2'=> _integer(['null'=>1,'hide'=>1])
        ];
    }
	
    public function insert(array $crit,$table=false)
    {
        if(isset($crit['start'])&&$crit['start']){
            $time1 = strtotime($crit['start']);
            $time2 = strtotime($crit['finish']);
            $crit["actual_duration"]=round(abs($time2 - $time1) / 3600,2);
        }
        $crit['created']=date("Y-m-d H:i:s");
        if(!isset($crit['employee'])||!$crit['employee']){
            $crit['employee']=User::id();
        }
        $crit['num']=$this->serial();
        $id=parent::insert($crit,$table);
        $not=Notifications::init($id);
        if($crit["stage"]=="Assignment")
        {
            $not->assignment();
        }
        else{
            $not->timesheet();
        }
        return $id;
    }
    
    public function modify(array $data = [], $cr = [], $table = false) {
        if(isset($data['start'])&&$data['start']){
            $time1 = strtotime($data['start']);
            $time2 = strtotime($data['finish']);
            $data["actual_duration"]=round(abs($time2 - $time1) / 3600,2);
        }
        $id=parent::modify($data, $cr, $table);
        if(isset($cr["where"])&&isset($cr["where"][$this->pK()]))
        {
            Notifications::init($cr["where"][$this->pK()])->timesheet();
        }
        return $id;
    }
    
    private function serial()
    {
        $ser=\Lib\Factory::app("TimeSheet","Ctms");
        $dt=$ser->read(["select"=>["max(num) as num"]]);
        if(empty($dt)){
            return 1;
        }
        if($dt[0]["num"]>0){
            return $dt[0]["num"]+1;
        }
        return 1; 
    }

}
/*
ALTER TABLE `timesheets` CHANGE `finish` `finish` VARCHAR(8) NOT NULL; 
ALTER TABLE `timesheets` CHANGE `start` `start` VARCHAR(8) NOT NULL; 
*/