CORE.add("assignment",x=>{
    let task,billable,line,rate,expected_duration;
    let  lineChList=e=>{
        if(nM(x.me(e).val())){
            X("base/sourcelines/read",o=>{
                if(o.status){
                    if(o.message&&o.message[0]&&o.message[0].quantity)
                        expected_duration.val(parseFloat(o.message[0].quantity).toFixed(2));
                    if(o.message&&o.message[0]&&o.message[0].price)
                        rate.val(parseFloat(o.message[0].price).toFixed(2));
                }
            },{filter:tS({
                where:{id:x.me(e).val()}
            })});
        }
    };
    let  taskChList=e=>{
        if(nM(x.me(e).val())){
            X("ctms/tasks/read",o=>{
                if(o.message&&o.message[0]){
                    var  ob=o.message[0];
                    billable.val(ob.flag);
                }
            },{filter:tS({
                    where:{id:x.me(e).val()}
                })}
            );
        }
    };
    
    let start=()=>{
        rate=x.named("rate");
        line=x.named("line");
        task=x.named("task");
        expected_duration=x.named("expected_duration");
        billable=x.named("billable");
        task.bind().change(taskChList);
        line.bind().change(lineChList);
    };
    let stop=()=>{
        line.unbind().change(lineChList);
        task.unbind().change(taskChList);
        rate=null;
        line=null;
        task=null;
        billable=null;
        expected_duration=null;
    };
    return{init:start,dump:stop};
});