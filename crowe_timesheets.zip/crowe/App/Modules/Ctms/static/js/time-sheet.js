CORE.add("time-sheet",x=>{
    let client,record,task,billable;
    let  clientChList=e=>{
        if(nM(x.me(e).val())){
            X("gs/landing/combo_data/Base/Record",o=>{
                PopCombo.init(record,o.message).populate(); 
            },{filter:tS({
                    where:{id:x.me(e).val()}
                })}
            );
        }
    };
    let  taskChList=e=>{
        if(nM(x.me(e).val())){
            X("ctms/tasks/read",o=>{
                if(o.message&&o.message[0]){
                    var  ob=o.message[0];
                    billable.val(ob.flag);
                }
            },{filter:tS({
                    where:{id:x.me(e).val()}
                })}
            );
        }
    };
    
    let start=()=>{
        client=x.named("client");
        record=x.named("record");
        task=x.named("task");
        billable=x.named("billable");
        client.bind().change(clientChList);
        task.bind().change(taskChList);
    };
    let stop=()=>{
        client.unbind().change(clientChList);
        task.unbind().change(taskChList);
        client=null;
        record=null;
        task=null;
        billable=null;
    };
    return{init:start,dump:stop};
});