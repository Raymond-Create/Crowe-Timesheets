CORE.add("auth",x=>{
    let id,authorised,authoriser,btn,line;
    let btnList=(e)=>{
        x.stop(e);
        X("ctms/timesheets/put/"+id.val(),o=>{
            if(o.status)
            {
                x.notify({type:"success",data:"Time sheet authorised"},"notify");
                x.notify({type:"redraw",data:null},"data-grid-module");
                line.hide();
                btn.hide();
            }
        },{
            authorised:authorised.val(),
            authoriser:authoriser.val(),
            stage:"TimeSheet"
        });
    };
    let start=()=>{
        id=x.named("id");
        authoriser=x.named("authoriser");
        authorised=x.named("authorised");
        btn=x.pick(".btn-save");
        line=x.pick("HR");
        btn.bind().click(btnList);
        //console.log(id.n);
    };
    let stop=()=>{
        btn.unbind().click(btnList);
        id=null;
        authorised=null;
        authoriser=null;
        btn=null;
        line=null;
    };
    return {init:start,dump:stop};
});