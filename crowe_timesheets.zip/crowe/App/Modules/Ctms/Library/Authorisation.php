<?php

namespace Mod\Ctms\Library;

use \Core\Authentication\Library\User;

class Authorisation{
    
    public $id;
    
    public function __construct($id) {
        $this->id=$id;
    }
    
    public function html()
    {
        $mod=\Lib\Factory::app("TimeSheet","Ctms");
        $mod->get($this->id);
        $card=div("card")
            ->attr("data-x-mod","auth")
            ->add(div("card-header")
                ->add(h3()->add("Time Sheet Authorization"))
            );
        $body=div("card-body");
        $body->add(div(ROW)
            ->add(div(C121212)
                ->add(label()->add("Supervisor"))
                ->add(\Lib\Combo::init()
                    ->set_model(["User","Authentication"])   
                    ->set_default($mod->authoriser?:User::id())
                    ->set_pattern("/\d+/")
                    ->set_name("authoriser")
                    ->set_meta(["disabled"=>"disabled"])
                    ->html()
                )
            )
        );//x($this->id,8);
        $body->add(div(ROW . " mt-2")
            ->add(div(C121212)
                ->add(label()->add("Authorisation Time"))
                ->add(input(NPS)
                    ->attr([
                        "name"=>"authorised","data-pattern"=>DATETIME_RGX,
                        "value"=>$mod->authorised?:date("Y-m-d H:i:s"),
                        "disabled"=>"disabled"
                    ])
                )
                ->add(input()->attr([
                    "name"=>"id","value"=>$this->id,"type"=>"hidden"
                ]))
            )
        );
        if(!$mod->authoriser){
            $body->add(div(ROW)
                ->add(div(C121212)
                    ->add(hr())
                    
                )
            );
            $body->add(div(ROW)
                ->add(div(C121212)
                    ->add(button("btn btn-primary btn-sm btn-block btn-save")
                            ->add("Save")
                    )
                )
            );
        }
        return $card->add($body);
    }
}
