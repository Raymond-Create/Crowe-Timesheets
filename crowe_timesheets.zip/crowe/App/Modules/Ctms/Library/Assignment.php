<?php

namespace Mod\Ctms\Library;
use Lib\Factory as Lf;

class Assignment extends \Core\Base\Library\Editor
{
    
    public
    $script="assignment",
    $title="Assignment Editor",
    $model=["TimeSheet","Ctms"],
    $main_script="_editor";
    
    private $bl;
    
    public function set_budget_line($budget_line){
        $this->bl=$budget_line;
        $this->url="ctms/assignments/assign/".$budget_line;
    }
    
    public function rows(){
        $div=div();
        $div->add($this->row1());
        $div->add($this->row2());
        $div->add($this->row3());
        return $div;
    }
    public function row1(){
        $div=div("row");
        
        $div->add(div("col-lg-6 col-xs-12")
            ->add($this->label("Budget","Buget from which tash originates"))
            ->add(\Lib\Combo::init()  
                ->set_model(["Record","Base"])
                ->set_default($this->bl)
                ->set_name("budget")
                ->set_meta([
                    $this->attr=>$this->attr,
                    "disabled"=>"disabled"
                    //"data-type"=>"input"
                ])
                //->required()
                ->html()
            )
        );//Auto populate
        $div->add(div("col-lg-6 col-xs-12")
            ->add($this->label("Line","Budget Line"))
            ->add(\Lib\Combo::init()  
                ->set_model(["SourceLine","Base"])
                ->set_default($this->val("line"))
                ->set_filter([
                    "where"=>["record"=> $this->bl]
                ])
                ->set_name("line")
                ->set_meta([
                    $this->attr=>$this->attr,
                    "data-type"=>"input",
                ])
                ->required()
                ->html()
            )
        );
        return $div;
    }
	
    public function row2(){
        $div=div("row mt-2");
        $div->add(div("col-lg-6 col-xs-12")
            ->add($this->label("Employee","Employee to which task is allocated"))
            ->add(\Lib\Combo::init()  
                ->set_default($this->val("employee"))
                ->set_model(["User","Authentication"])
                ->set_pattern("/^\d+$/")
                ->set_name("employee")
                ->set_meta([
                    $this->attr=>$this->attr,
                    "data-type"=>"input"
                ])
                ->required()
                ->html()
            )
        );
        $div->add(div("col-lg-6 col-xs-12")
            ->add($this->label("Task","Task to be done"))
            ->add(\Lib\Combo::init()  
                ->set_model(["Task","Ctms"])
                ->set_default($this->val("task"))
                ->set_name("task")
                ->set_meta([
                    $this->attr=>$this->attr,
                    "data-type"=>"input"
                ])
                ->required()
                ->html()
            )
        );
        return $div;
    }
    
    
    public function row3(){
        $div=div("row mt-2");
        $div->add(div("col-lg-6 col-xs-12")
            ->add($this->label("Expected Duration","Time in hrs to complete task as per budget"))
            ->add(input("form-control form-control-sm")
                ->attr([
                    "name"=>"expected_duration",
                    "data-pattern"=>CHAR_RGX,
                    "value"=>$this->val("expected_duration"),
                    "data-type"=>"input",
                    "placeholder"=>"Budgeted duration of task (in Hrs)",
                    $this->attr=>$this->attr,"required"=>"required"
                ])
            )
        );
        $div->add(div("col-lg-6 col-xs-12")
            ->add($this->label("Rate","Rate as budgeted"))
            ->add(input("form-control form-control-sm")
                ->attr([
                    "name"=>"rate",
                    "data-pattern"=>CHAR_RGX,
                    "value"=>$this->val("rate"),
                    "data-type"=>"input",
                    "placeholder"=>"Rate per hour for given employee",
                    $this->attr=>$this->attr,"required"=>"required"
                ])
            )
            ->add(input()
                ->attr([
                    "name"=>"stage","value"=>"Assignment",
                    "data-type"=>"input","type"=>"hidden",
                    "data-pattern"=>"/Assignment/"
                ])
            )
            ->add(input()
                ->attr([
                    "name"=>"billable","value"=>$this->val("billable"),
                    "data-type"=>"input","type"=>"hidden",
                    "data-pattern"=>"/(0|1)/"
                ])
            )
            ->add(input()
                ->attr([
                    "name"=>"client","value"=>$this->client(),
                    "data-type"=>"input","type"=>"hidden",
                    "data-pattern"=>"/\d+/"
                ])
            )
        );
        return $div;
    }
    
    private function client()
    {
        $mod= Lf::app("Record","Base");
        $mod->fetch([
            "where"=>["id"=>$this->bl]
        ]);
        return $mod->contact;
    }
}