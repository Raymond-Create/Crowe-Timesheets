<?php
namespace Mod\Ctms\Library;

class UserView extends MyAccountView
{
    use \Lib\Init;
    
    public function form() {
        return;// new Employee;
    }
    
    public
        $_title="User Details",
        $url="ctms/employees/create",
        $types="User Details",
        $type="User Information";
}