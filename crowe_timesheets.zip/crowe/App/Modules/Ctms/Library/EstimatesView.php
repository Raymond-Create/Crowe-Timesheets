<?php
namespace Mod\Ctms\Library;

class EstimatesView extends TimesheetsView
{
    use \Lib\Init;
    
    public function form() {
        return new Estimate;
    }
    
    public
        $_title="Budgets",
        $url="ctms/budgets/create",
        $types="Budgets",
        $type="Budget";
}