<?php
namespace Mod\Ctms\Library;

use Lib\TableFixer as Tf;
use Core\Base\Library\Editor;

class Employee extends Editor
{
    
    public
    $id,
    $status,
    $message,
    $attr,
    $mode="edit",
    $script=false,
    $title="Employee Editor",
    $pattern="/\d+/",
    $model=["Employee","Ctms"];
    
    public function rows()
    {
        $b=div("col-lg-12 col-md-12");
        $b->add($this->row0());
        $b->add($this->row1());
        $b->add($this->row2());
        $b->add($this->row3());
        $b->add($this->row4());
        return $b;
    }
    
    public function row0()
    {
        return div(ROW)
            ->add(div(C333)
                ->add(label(LB)->add("Title"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"title","data-pattern"=>CHAR_RGX,
                        "value"=>$this->val("title"),"data-type"=>"input",
                        "required"=>"required",$this->attr=>$this->attr
                    ])
                )
            )
            ->add(div(C333)
                ->add(label(LB)->add("Name"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"name","data-pattern"=>CHAR_RGX,
                        "value"=>$this->val("name"),"data-type"=>"input",
                        "required"=>"required",$this->attr=>$this->attr
                    ])
                )
            )
            ->add(div(C333)
                ->add(label(LB)->add("Surname"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"surname","data-pattern"=>CHAR_RGX,
                        "value"=>$this->val("surname"),"data-type"=>"input",
                        "required"=>"required",$this->attr=>$this->attr
                    ])
                )
            )
            ->add(div(C333)
                ->add(label(LB)->add("D.O.B"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"dob","data-pattern"=>DATE_RGX,
                        "required"=>"required","data-addon"=>"datepicker",
                        "value"=>$this->val("dob"),$this->attr=>$this->attr,
                        "data-type"=>"input"
                    ])
                )
            );
    }
    
    public function row1()
    {
        return div(ROW ." mt-2")
            ->add(div(C444)
                ->add(label(LB)->add("Date First"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"date_first","data-pattern"=>DATE_RGX,
                        "value"=>$this->val("date_first"),
                        "required"=>"required","data-addon"=>"datepicker",
                        $this->attr=>$this->attr,"data-type"=>"input"
                    ])
                )
            )
            ->add(div(C444)
                ->add(label(LB)->add("ID Type"))
                ->add(\Lib\Combo::init()
                    ->set_data([
                        "Passport"=>"Passport","ID"=>"ID",
                        "Licence"=>"Licence","Other"=>"Other"
                    ])
                    ->set_default($this->val("identity_type"))
                    ->set_pattern("/Passport|ID|Licence|Other/")
                    ->set_meta([$this->attr=>$this->attr,"data-type"=>"input"])
                    ->set_name("identity_type")
                    ->required()
                    ->html()
                )
            )
            ->add(div(C444)
                ->add(label(LB)->add("Identity"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"identity","data-pattern"=>CHAR_RGX,
                        "value"=>$this->val("identity"),"data-type"=>"input",
                        "required"=>"required",$this->attr=>$this->attr
                    ])
                )
            );
    }
    
    
    public function row2()
    {
        return div(ROW ." mt-2")
            ->add(div(C444)
                ->add(label(LB)->add("Code"))
                ->add($this->code($this->con("code")?:263)
                )
            )
            ->add(div(C444)
                ->add(label(LB)->add("Phone"))
                ->add(input(NPS)
                    ->attr([
                        "name"=>"phone","value"=>$this->val("phone"),
                        "data-pattern"=>"/^\d+$/","required"=>"required",
                        $this->attr=>$this->attr,"data-type"=>"input"
                    ])
                )
            )
            ->add(div(C444)
                ->add(label(LB)->add("Email"))
                ->add(input(NPS)
                    ->attr([
                        "name"=>"email","value"=>$this->val("email"),
                        "data-pattern"=>EMAIL_RGX,"required"=>"required",
                        $this->attr=>$this->attr,"data-type"=>"input"
                    ])
                )
            );
    }
    
    public function row3()
    {
        return "";div(ROW ." mt-2")
            ->add(div(C444)
                ->add(label(LB)->add("Department"))
                ->add(\Lib\Combo::init()
                    ->set_placeholder("Select Department")
                    ->set_meta([
                        $this->attr=>$this->attr,
                        "data-type"=>"input"
                    ])
                    ->set_default($this->ass("flag5"))
                    ->set_model(["Department","Hr"])
                    ->set_pattern("/^\d+$/")
                    ->set_name("flag5")
                    ->set_filter([
                        "where"=>[
                            "cluster"=>"Hr.Department"
                        ]
                    ])
                    ->html()
                )
            )
            ->add(div(C444)
                ->add(label(LB)->add("Designation"))
                ->add(\Lib\Combo::init()
                    ->set_placeholder("Select Designation")
                    ->set_default($this->ass("flag4"))
                    ->set_model(["Designation","Hr"])
                    ->set_pattern("/^\d+$/")
                    ->set_name("flag4")
                    ->set_filter([
                        "where"=>[
                            "cluster"=>"Hr.Designation"
                        ]
                    ])
                    ->set_meta([
                        $this->attr=>$this->attr,
                        "data-type"=>"input"
                    ])
                    ->html()
                )
            )
            ->add(div(C444)
                ->add(label(LB)->add("Grade"))
                ->add(\Lib\Combo::init()
                    ->set_placeholder("Select Grade")
                    ->set_default($this->ass("link"))
                    ->set_model(["PayGrade","Hr"])
                    ->set_pattern("/^\d+$/")
                    ->set_name("link")
                    ->set_filter([
                        "where"=>[
                            "cluster"=>"Hr.PayGrade"
                        ]
                    ])
                    ->set_meta([
                        $this->attr=>$this->attr,
                        "data-type"=>"input"
                    ])
                    ->html()
                )
            );
    }
    
    public function row4()
    {
        $div=div(ROW ." mt-2")
            ->add(div(C444)
                ->add(label(LB)->add("Address"))
                ->add(textarea(NPS)
                    ->attr([
                        $this->attr=>$this->attr,"name"=>"address",
                        "data-type"=>"input","value"=>$this->con("address"),
                        "data-pattern"=>"/[a-zA-Z0-9\r\n\'\-\,\.\\ ]+/"
                    ])
                )
            )
            ->add(div(C444)
                ->add(label(LB)->add("Supervisor"))
                ->add(\Lib\Combo::init()
                    ->set_model(["Employee","Ctms"])
                    ->set_default($this->val("supervisor"))
                    ->set_pattern("/\d+/")
                    ->set_meta([$this->attr=>$this->attr,"data-type"=>"input"])
                    ->set_name("supervisor")
                    ->set_filter([
                        
                    ])
                    ->html()
                )
            )
            ->add(div(C444)
                ->add(label(LB)->add("Department"))
                ->add(\Lib\Combo::init()
                    ->set_model(["Department","Ctms"])
                    ->set_default($this->val("department"))
                    ->set_pattern("/\d+/")
                    ->set_meta([$this->attr=>$this->attr,"data-type"=>"input"])
                    ->set_name("department")
                    ->set_filter([
                        
                    ])
                    ->html()
                )
            );
        return $div;
    }
    public function code($default=null)
    {
        $select=select("form-control form-control-sm");
        $select->attr([
            "data-pattern"=>"/\d+/",
            "name"=>"code","required"=>"required",
            $this->attr,$this->attr,"data-type"=>"input"
        ]);
        foreach(config("country-codes") as $rw)
        {
            $opt=option();
            $opt->attr([
                "data-countryCode"=>$rw[0],"value"=>$rw[1]
            ]);
            if($rw[1]==$default)
            {
                $opt->attr("selected","selected");
            }
            $select->add($opt->add($rw[2]));
        }
        return $select->attr([
            $this->attr=>$this->attr
        ]);
    }
    
    public function con($field)
    {
        $mod=\Lib\Factory::app("Contact","Base");
        $mod->get($this->val("contact"));
        return $mod->$field;
    }
    
    public function ass($field)
    {
        $mod=\Lib\Factory::app("Assignment","Hr");
        $mod->fetch([
            "where"=>["flag3"=>$this->val("id")]
        ]);
        return $mod->$field;
    }
    
    public function save($post) {
        $loc=\Lib\Factory::app("Base","Base");//x($loc,8);
        try{
            $loc->begin();
            $employee=$this->_employee($post);//x($employee,8);
            if(!$employee->id){
                throw new \Exception("Employee not created");
            }
            $contact=$this->_contact($post,$employee->contact);
            if(!$employee->contact&&$contact->id)
            {
                $employee->contact=$contact->id;
                $employee->save();
            }
            $loc->commit();
            return $employee->id;
        } catch (\Exception $exp){
            x($exp,9);
        }
        //x($this->id);
        
        
    }
    
    private function _employee($post)
    {
        $model=Tf::init("Employee","Hr");//x($model,9);
        $data=[
            "dob"=>$post["dob"]??null,
            "name"=>$post["name"]??null,
            "title"=>$post["title"]??null,
            "surname"=>$post["surname"]??null,
            "identity"=>$post["identity"]??null,
            "date_first"=>$post["date_first"]??null,
            "identity_type"=>$post["identity_type"]??null,
        ];
        return $this->save_data($data,$model,$this->id);
    }
    
    private function _contact($post,$id=null)
    {
        $model=Tf::init("Contact","Base");//x($model,9);
        $ct=$this->save_data([
            "type"=>"Other","name"=>"EMPLOYEES"
        ],Tf::init("ContactType","Base"));
        $data=[
            "type"=>$ct->id,
            "organisation"=>0,
            "cluster"=>"Hr.Employee",
            "name"=>isset($post["name"])&&isset($post["surname"])?
            $post["name"]." ".$post["surname"]:null,
            "email"=>$post["email"]??null,
            "code"=>$post["code"]??null,
            "phone"=>$post["phone"]??null,
            "address"=>$post["address"]??null,
        ];
        return $this->save_data($data,$model,$id);
    }
    
    private function save_data($data,$model,$id=null)
    {
        
        if($id){
            $model->get($id);
        }else{
            $model->fetch(["where"=>$data]);
        }
        foreach($data as $field=>$value)
        {
            $model->$field=$value;
        }
        $xid=$model->save();
        if($xid&&!$model->id)
        {
            $model->id=$xid;
        }
        return $model;
    }
}