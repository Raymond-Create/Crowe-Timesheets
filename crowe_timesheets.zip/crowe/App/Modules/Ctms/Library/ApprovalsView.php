<?php
namespace Mod\Ctms\Library;

use Core\Base\Library\AbView;


class ApprovalsView extends AbView
{
    use \Lib\Init;
    
    public function form() {
        return new TimeSheet;
    }
    
    public
        $_title="Approvals",
        $url="ctms/approvals/create",
        $types="Approvals",
        $type="Approval",
        $drop=[
            "Budgets"=>"ctms/budgets/index",
            "Assignments"=>"ctms/assignments/index",
            "Approvals"=>"ctms/approvals/index",
            "Time Sheets"=>"ctms/timesheets/index",
            "Tasks"=>"ctms/tasks/index",
            "Departments"=>"ctms/departments/index",
            "Employees"=>"ctms/employees/index",
            "Notifications"=>"ctms/notifications/index"
        ];
            
   
}