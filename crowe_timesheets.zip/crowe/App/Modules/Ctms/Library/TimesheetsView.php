<?php
namespace Mod\Ctms\Library;


class TimesheetsView extends ApprovalsView
{
    use \Lib\Init;
    
    public function form() {
        return;
    }
    
    public
        $_title="Time Sheets",
        $url="ctms/timesheets/create",
        $types="Time Sheets",
        $type="Time Sheet";
}