<?php

namespace Mod\Ctms\Library;

class AssignmentsView extends ApprovalsView
{
    use \Lib\Init;
    
    public function form() {
        return new TimeSheet;
    }
    
    public
        $_title="Assignments",
        $url="ctms/assignments/create",
        $types="Assignments",
        $type="Assignment";
}