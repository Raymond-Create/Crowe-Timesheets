<?php

namespace Mod\Ctms\Library;
use Lib\Factory as Lf;

class Notifications 
{
    use \Lib\Init;
    
    private $ts,$id,$mod,$data=[];
    
    public function __construct($id)
    {
        $this->mod=Lf::app("Notification","Ctms");
        $this->ts=Lf::app("TimeSheet","Ctms");
        $this->ts->get($id);
        $this->id=$id;
    }
    
    public function assignment(){
        if(!$this->ts->id)
        {
            return;
        }
        $mod=Lf::app("Record","Base");
        $mod->fetch([
            "join"=>[
                "join"=>[
                    ["sourcelines s","records.id","s.record"]
                ]
            ],
            "select"=>["records.*"],
            "where"=>["s.id"=>$this->ts->line]
        ]);
        $t=[
            "type"=>"Info",
            "title"=>"Task Assignment",
            "body"=>"A new task has been assigned to you from a budget on ".$mod->rep(),
            "user_id"=>$this->ts->employee,
            "resource"=>"timesheets",
            "resource_id"=>$this->id
        ];
        $this->save($t);
    }
    
    public function timesheet(){
        if(!$this->ts->id)
        {
            return;
        }
        $mod=Lf::app("Contact","Base");
        $dep=Lf::app("Department","Ctms");
        $usr=Lf::app("User","Authentication");
        $mod->fetch([
            "where"=>[
                "id"=>$this->ts->client
            ]
        ]);
        $dep->fetch([
            "where"=>[
                "t.id"=>$this->ts->task
            ],
            "join"=>[
                "join"=>[
                    ["tasks t","departments.id","t.type"]
                ]
            ],
            "select"=>["departments.*"]
        ]);
        $usr->fetch([
            "where"=>[
                "users.id"=>[">","2"],
                "r.name"=>"ADMINISTRATION"
            ],
            "join"=>[
                "join"=>[
                    ["roles r","users.role","r.id"]
                ]
            ],
            "select"=>["users.*"]
        ]);
        //No one found to authorise
        $err1=[
            "type"=>"Error",
            "title"=>"Task not approvable",
            "body"=>"No one was found who can authorise the timesheet ".$this->ts->created,
            "user_id"=>$usr->id,
            "resource"=>"timesheets",
            "resource_id"=>$this->id
        ];
        //department has no hod
        $err2=[
            "type"=>"Error",
            "title"=>"Department hod missing",
            "body"=>"Department ".$dep->name." has no hod ",
            "user_id"=>$usr->id,
            "resource"=>"timesheets",
            "resource_id"=>$this->id
        ];
        //Contact has no superviser
        $err3=[
            "type"=>"Error",
            "title"=>"Client supervisor missing",
            "body"=>"Supervisor for client ".$mod->name." not found",
            "user_id"=>$usr->id,
            "resource"=>"timesheets",
            "resource_id"=>$this->id
        ];
        $bool=$dep->hod&&$mod->user;
        if(!$bool){
            $this->save($err1);
        }
        if(!$dep->hod){
            $this->save($err2);
        }
        if(!$mod->user){
            $this->save($err3);
        }
        if($bool){
            $t=[
                "type"=>"Success",
                "title"=>"Task has been approved",
                "body"=>"A task has been approved identified by ".$this->ts->num,
                "user_id"=> $this->ts->employee,
                "resource"=>"timesheets",
                "resource_id"=>$this->id
            ];
            $this->save($t);
        }
    }
    
    private function save($param) {
        $this->mod->fetch([
            "where"=>$param
        ]);
        if($this->mod->id){
            $this->mod->frequency++;
        }else{
            foreach ($param as $key => $value) {
                $this->mod->$key=$value;
            }
        }
        return $this->mod->save();
    }
}