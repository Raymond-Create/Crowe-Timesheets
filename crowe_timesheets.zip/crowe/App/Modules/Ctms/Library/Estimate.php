<?php

namespace Mod\Ctms\Library;

use Core\Base\Library\Record as AD;
use Core\Base\Library\Config;
use Lib\BootSelect as Bs;
use Lib\Factory as Lf;
use Lib\Combo;

class Estimate extends AD
{
    public 
        $rows="inventory/invoices",
        $linesController="base/sourcelines",
           
    $internal_comment="Estimate",
    $multiple_doc=false,
    $map=[
        "order_no"=>"txt3",
        "record_for"=>"nt1",
        "title_1"=>"cha1",
        "title_2"=>"cha2",
        "attention"=>"cha3",
        "note_1"=>"txt1",
        "note_2"=>"txt2"
    ],
    $prefix="BUDG",
    $prefixKey="BUDGETPREFIX",
    $title="Budget",
    $doc_type=[
        ["DocType","Base"],
        [
            "name"=>"BUDGET",
            "doc"=>[
                ["Doc","Base"],
                [
                    "name"=>"SALES"
                ]
            ],
            "postable"=>1,
            "type"=>"Other",
            "postable"=>0,
                "debit_notes"=>"null_acc",
                "debit_core"=>[
                    ["CoreAccount","Base"],
                    [
                        "type"=>"Equity",
                        "side"=>"credit",
                        "name"=>"SUSPENSE"
                    ]
                ],
                "credit_notes"=>"null_acc",
                "credit_core"=>[
                    ["CoreAccount","Base"],
                    [
                        "type"=>"Equity",
                        "side"=>"credit",
                        "name"=>"SUSPENSE"
                    ]
                ]
        ]
    ];
    
    public function notes(){
        
    }
    
    public function method(){
        
    }
    
     public function row5()
    {
        return div("row  mb-2")

            ->add(div("col-lg-6 col-md-6 x-x")
                ->add(label("control-label")->add("First Optional Note"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"cha1","data-pattern"=>CHAR_RGX,
                        "data-for"=>"input",$this->attr=>$this->attr,
                        "placeholder"=>"First Note Title (NOT Required)",
                        "value"=>$this->val("cha1")?:(config("title_1")?:"")
                    ])
                )
                ->add(textarea("form-control form-control-sm mt-2")
                    ->attr([
                        "name"=>"txt1","data-pattern"=>"/^[0-9A-Za-z'\_\,\.\s\r\% ]+$/",
                        "data-for"=>"input",$this->attr=>$this->attr,
                        "placeholder"=>"First Note Body (NOT Required)",
                        "value"=>$this->val("txt1")?:(config("note_1")?:"")
                    ])
                )
            )   
            ->add(div("col-lg-6 col-md-6 x-x")
                ->add(label("control-label")->add("Second Optional Note"))
                    ->add(input("form-control form-control-sm")
                        ->attr([
                            "name"=>"cha2","data-pattern"=>CHAR_RGX,
                            "data-for"=>"input","value"=>$this->val("cha2"),
                            "placeholder"=>"Second Note Title (NOT Required)",
                            $this->attr=>$this->attr
                        ])
                    )
                    ->add(textarea("form-control form-control-sm mt-2")
                        ->attr([
                            "name"=>"txt2","data-pattern"=>CHAR_RGX,
                            "data-for"=>"input","value"=>$this->val("txt2"),
                            "placeholder"=>"Second Note Body (NOT Required)",
                            $this->attr=>$this->attr
                        ])
                )
            );
}
    
    public function row4()
    {
        return div("row")
            ->add(div("col-lg-6 col-md-6 x-x")
                ->add(label("control-label")->add("Order #"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"txt3","data-pattern"=>CHAR_RGX,
                        "data-for"=>"source","value"=>$this->src("txt3"),
                        "placeholder"=>"Order No (NOT Required)",
                        $this->attr=>$this->attr
                    ])
                )
            )
            ->add(div("col-lg-6 col-md-6 x-x")
                ->add(label("control-label")->add("Attention"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"cha3","data-pattern"=>CHAR_RGX,
                        "data-for"=>"source","value"=>$this->src("cha3"),
                        "placeholder"=>"Attention (NOT Required)",
                        $this->attr=>$this->attr
                    ])
                )
            );
    }
    
   
    public function row6()
    {
        return div("row")
            ->add(div("col-lg-4 col-md-4 x-x")
                ->add($this->label("Asset Involved"))
                ->add(Combo::init()
                    ->set_model(["Record","Base"])
                    ->set_placeholder("Linked Asset (Not Required)")
                    ->set_filter([
                        //"where"=>["doc_type"=>$this->idOf($this->asset_doc)]
                    ])
                    ->set_default($this->val("nt1"))
                    ->set_meta([
                        "data-for"=>"source",
                        $this->attr=>$this->attr,
                        "disabled"=>"disabled"
                    ])
                    ->set_pattern("/\d+/")
                    ->set_name("nt1")
                    ->html()
                )
            )
            ->add(div("col-lg-4 col-md-4 x-x")
                ->add($this->label("Debit"))
                ->add(Bs::init()
                    ->set_model(["Account","Base"])
                    ->set_placeholder("Debit Account (Not Required)")
                    ->set_filter([
                        "select"=>["accounts.*"],
                        "join"=>[
                            "join"=>[
                                ["coreaccounts c","c.id","accounts.core"]
                            ]
                        ],
                        "where"=>["c.side"=>"debit"]
                    ])
                    ->set_default($this->val("debit"))
                    ->set_meta([
                        "data-type"=>"input",
                        $this->attr=>$this->attr,
                        "disabled"=>"disabled"
                    ])
                    ->set_pattern("/\d+/")
                    ->set_name("debit")
                    ->html()
                )
            )
            ->add(div("col-lg-4 col-md-4 x-x")
                ->add($this->label("Credit"))
                ->add(Bs::init()
                    ->set_model(["Account","Base"])
                    ->set_placeholder("Credit Account (Not Required)")
                    ->set_filter([
                        "select"=>["accounts.*"],
                        "join"=>[
                            "join"=>[
                                ["coreaccounts c","c.id","accounts.core"]
                            ]
                        ],
                        "where"=>["c.side"=>"credit"]
                    ])
                    ->set_default($this->val("credit"))
                    ->set_meta([
                        "data-type"=>"input",
                        $this->attr=>$this->attr,
                        "disabled"=>"disabled"
                    ])
                    ->set_pattern("/\d+/")
                    ->set_name("credit")
                    ->html()
                )
            );
    }
    
    public function head()
    {
        $this->len=5;
        return thead()
            ->add(tr()
                ->add(th(["style"=>"width:5%"]))
                ->add(th(["style"=>"width:30%"])->add("Item"))
                ->add(th(["style"=>"width:20%"])->add("Quantity"))
                ->add(th(["style"=>"width:20%"])->add("Cost"))
                ->add(th(["style"=>"width:25%"])->add("Amount"))
            );
    }
    
    public function row($row=[])
    {
        $tr=tr(["data-value"=>$this->linesController]);
        $tr->add(td()
            ->add(i("mdi mdi-trash-can btn-dl text-danger"))
            ->add(input()
                ->attr([
                    "type"=>"hidden","name"=>"flag",
                    "value"=>$row["flag"]??1
                ])
            )
        );
        $desc=!empty($row["details"])?"block":"none";
        $item=!empty($row["details"])?"none":"block";
        $tr->add(td()
                ->add(div("input-group input-group-sm mb-0")
                    ->add(div("input-group-prepend")
                        ->add(span("input-group-text btn-tgl")
                            ->add(i("mdi mdi-swap-horizontal-bold"))
                        )
                    )
                    ->add(input(NPS)
                        ->attr([
                            "name"=>"description","placeholder"=>"Type item description",
                            "value"=>$row["details"]??"","data-pattern"=>CHAR_RGX,
                            "data-type"=>"line-input","style"=>"display:$desc",
                            $this->attr=>$this->attr,"list"=>"description-list"
                        ]) 
                    )
                    ->add(datalist()
                        ->attr([
                            "id"=>"description-list"
                        ]) 
                    )
                    ->add(Combo::init()
                        ->set_model(["Item","Base"])
                        ->set_pattern("/\d+/")
                        ->set_default($row["item"]??"")
                        ->set_meta([
                            "data-type"=>"line-input",
                            $this->attr=>$this->attr,
                            "style"=>"display:$item"
                        ])
                        ->set_name("item")
                        ->html() 
                    )
                )  
            
        );
        $tr->add(td()
            ->add(input(NPS)
                ->attr([
                    "name"=>"quantity","placeholder"=>"Qty",
                    "value"=>$row["quantity"]??0.00,"data-pattern"=>DECIMAL_RGX,
                    "data-type"=>"line-input","step"=>"any","type"=>"number",
                    $this->attr=>$this->attr
                ])  
            )
        );
        $tr->add(td()
            ->add(input(NPS)
                ->attr([
                    "name"=>"price","placeholder"=>"Qty",
                    "value"=>$row["price"]??0.00,"data-pattern"=>DECIMAL_RGX,
                    "data-type"=>"line-input","step"=>"any","type"=>"number",
                    $this->attr=>$this->attr
                ])  
            )
            ->add(input()
                ->attr([
                    "name"=>"exid",
                    "value"=>$row["id"]??"","data-pattern"=>INTEGER_RGX,
                    "type"=>"hidden"
                ])  
            )
        );
        return $tr->add(td()->add(input(NPS)
                ->attr([
                    "name"=>"amt","placeholder"=>"Line Amount",
                    "value"=>0.00,"data-pattern"=>DECIMAL_RGX,
                    "step"=>"any","type"=>"number",
                    "disabled"=>"disabled"
                ]) 
            )
        );      
    }
    
    public function accounts(){
        //return $this->accounts2();
    }
}
