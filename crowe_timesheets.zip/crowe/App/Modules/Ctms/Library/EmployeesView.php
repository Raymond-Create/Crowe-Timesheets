<?php
namespace Mod\Ctms\Library;

class EmployeesView extends TimesheetsView
{
    use \Lib\Init;
    
    public function form() {
        return;
    }
    
    public
        $_title="Employees",
        $url="ctms/employees/create",
        $types="Employees",
        $type="Employee";
}