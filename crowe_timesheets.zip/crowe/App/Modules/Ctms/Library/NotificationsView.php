<?php
namespace Mod\Ctms\Library;

class NotificationsView extends TimesheetsView
{
    use \Lib\Init;
    
    public function form() {
        return;
    }
    
    public
        $_title="Notifications",
        //$url="ctms/employees/create",
        $types="Notifications",
        $type="Notification";
}