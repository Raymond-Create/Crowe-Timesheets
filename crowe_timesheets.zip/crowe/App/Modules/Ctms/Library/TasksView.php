<?php
namespace Mod\Ctms\Library;

class TasksView extends TimesheetsView
{
    use \Lib\Init;
    
    public function form() {
        return false;
    }
    
    public
        $_title="Tasks",
        $url="ctms/tasks/create",
        $types="Tasks",
        $type="Task";
}