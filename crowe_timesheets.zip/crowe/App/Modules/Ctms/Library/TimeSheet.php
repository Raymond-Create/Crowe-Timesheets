<?php

namespace Mod\Ctms\Library;
use Lib\Factory as Lf;

class TimeSheet extends \Core\Base\Library\Editor
{
    
    public
    $script="time-sheet",
    $title="Time Sheet Editor",
    $model=["TimeSheet","Ctms"];
    
    public function rows(){
        $div=div();
        $div->add($this->row1());
        $div->add($this->row2());
        $div->add($this->row3());
        return $div;
    }
    public function row1(){
        $div=div("row");
        
        $div->add(div("col-lg-3 col-xs-6")
            ->add($this->label("Date","Date of Task"))
            ->add(input("form-control form-control-sm")
                ->attr([
                    "name"=>"date","data-addon"=>"datepicker",
                    "data-pattern"=>DATE_RGX,
                    "value"=>$this->val("date"),
                    "data-type"=>"input",
                    "placeholder"=>"Time Sheet Date  (required)",
                    $this->attr=>$this->attr,
                    "required"=>"required"
                ])
            )
        );//Auto populate
        $div->add(div("col-lg-3 col-xs-6")
            ->add($this->label("Client","Client"))
            ->add(\Lib\Combo::init()  
                ->set_model(["Contact","Base"])
                ->set_default($this->val("client"))
                ->set_name("client")
                ->set_meta([
                    $this->attr=>$this->attr,
                    "data-type"=>"input"
                ])
                //->required()
                ->html()
            )
        );
        $div->add(div("col-lg-3 col-xs-6")
            ->add($this->label("Estimate","The budget from which tasks are done"))
            ->add(\Lib\Combo::init()  
                ->set_model(["Record","Base"])
                ->set_default($this->record())
                ->set_name("record")
                ->set_meta([
                    $this->attr=>$this->attr,
                    "data-type"=>"input"
                ])
                //->required()
                ->html()
            )
        );
        $div->add(div("col-lg-3 col-xs-6")
            ->add($this->label("Task","Task done"))
            ->add(\Lib\Combo::init()  
                ->set_model(["Task","Ctms"])
                ->set_default($this->val("task"))
                ->set_pattern("/\d+/")
                ->set_name("task")
                ->set_meta([
                    $this->attr=>$this->attr,
                    "data-type"=>"input"
                ])
                ->required()
                ->html()
            )
        );
        return $div;
    }
	
    public function row2(){
        $div=div("row mt-2");
        $div->add(div("col-lg-6 col-xs-6")
            ->add($this->label("Starting Time","Task starting time"))
            ->add(\Lib\Combo::init()  
                ->set_default($this->val("start")?:"08:00:00")
                ->set_data($this->times)
                ->set_pattern("/^\d{2}\:\d{2}\:\d{2}$/")
                ->set_name("start")
                ->set_meta([
                    $this->attr=>$this->attr,
                    "data-type"=>"input"
                ])
                ->required()
                ->html()
            )
        );
        $div->add(div("col-lg-6 col-xs-6")
            ->add($this->label("Finishing Time","Task finishing time"))
            ->add(\Lib\Combo::init()  
                ->set_default($this->val("finish")?:"08:00:00")
                ->set_data($this->times)
                ->set_pattern("/^\d{2}\:\d{2}\:\d{2}$/")
                ->set_name("finish")
                ->set_meta([
                    $this->attr=>$this->attr,
                    "data-type"=>"input"
                ])
                ->required()
                ->html()
            )
        );
        return $div;
    }
    
    public function row3(){
        $div=div("row mt-2");
        $div->add(div("col-lg-3 col-xs-6")
            ->add($this->label("Billable","Is task billable or not?"))
            ->add(\Lib\Combo::init()
                ->set_data(["No","Yes"])
                ->set_default($this->val("billable")?:0)
                ->set_meta([
                    "data-type"=>"input","disabled"=>"disabled"
                ])
                ->set_name("billable")
                ->set_pattern('/^(0|1)$/')
                ->required()
                ->html()
            )
            ->add(input()
                ->attr([
                    "name"=>"stage","value"=>"Approval",
                    "data-type"=>"input","type"=>"hidden",
                    "data-pattern"=>"/Approval/"
                ])
            )
        );
        $div->add(div("col-lg-9 col-xs-6")
            ->add($this->label("Description","Notes of task"))
            ->add(textarea("form-control form-control-sm")
                ->attr([
                    "name"=>"description",
                    "data-pattern"=>CHAR_RGX,
                    "value"=>$this->val("description"),
                    "data-type"=>"input",
                    "placeholder"=>"Description or notes of task  (required)",
                    $this->attr=>$this->attr,"required"=>"required"
                ])
            )
        );
        return $div;
    }
    
    private function record()
    {
        $mod=Lf::app("Record","Base");
        $mod->fetch([
            "join"=>[
                "join"=>[
                    ["sourcelines s","records.id","s.record"]
                ]
            ],
            "select"=>["records.*"],
            "where"=>["s.id"=>$this->val("line")]
        ]);
        return $mod->id;
    }
    
    private $times=[
        "00:00:00"=>"00:00",
        "00:30:00"=>"00:30",
        "01:00:00"=>"01:00",
        "01:30:00"=>"01:30",
        "02:00:00"=>"02:00",
        "02:30:00"=>"02:30",
        "03:00:00"=>"03:00",
        "03:30:00"=>"03:30",
        "04:00:00"=>"04:00",
        "04:30:00"=>"04:30",
        "05:00:00"=>"05:00",
        "05:30:00"=>"05:30",
        "06:00:00"=>"06:00",
        "06:30:00"=>"06:30",
        "07:00:00"=>"07:00",
        "07:30:00"=>"07:30",
        "08:00:00"=>"08:00",
        "08:30:00"=>"08:30",
        "09:00:00"=>"09:00",
        "09:30:00"=>"09:30",
        "10:00:00"=>"10:00",
        "10:30:00"=>"10:30",
        "11:00:00"=>"11:00",
        "11:30:00"=>"11:30",
        "12:00:00"=>"12:00",
        "12:30:00"=>"12:30",
        "13:00:00"=>"13:00",
        "13:30:00"=>"13:30",
        "14:00:00"=>"14:00",
        "14:30:00"=>"14:30",
        "15:00:00"=>"15:00",
        "15:30:00"=>"15:30",
        "16:00:00"=>"16:00",
        "16:30:00"=>"16:30",
        "17:00:00"=>"17:00",
        "17:30:00"=>"17:30",
        "18:00:00"=>"18:00",
        "18:30:00"=>"18:30",
        "19:00:00"=>"19:00",
        "19:30:00"=>"19:30",
        "20:00:00"=>"20:00",
        "20:30:00"=>"20:30",
        "21:00:00"=>"21:00",
        "21:30:00"=>"21:30",
        "22:00:00"=>"22:00",
        "22:30:00"=>"22:30",
        "23:00:00"=>"23:00",
        "23:30:00"=>"23:30"
    ];
}