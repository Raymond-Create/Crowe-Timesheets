<?php
namespace Mod\Ctms\Library;

class DepartmentsView extends TimesheetsView
{
    use \Lib\Init;
    
    public function form() {
        return false;
    }
    
    public
        $_title="Departments",
        $url="ctms/depatments/create",
        $types="Departments",
        $type="Department";
}