<?php
namespace Mod\Ctms\Library;

class MyAccountView extends TimesheetsView
{
    use \Lib\Init;
    
    public function form() {
        return new Employee;
    }
    
    public
        $_title="Employees",
        $url="ctms/employees/create",
        $types="Employees",
        $type="Employee",
        $drop=[
            "My Details"=>"ctms/staff/index",
            "User Details"=>"ctms/myuser/index"
        ];
}