<?php
namespace Mod\Ctms\Library;

class StaffView extends MyAccountView
{
    use \Lib\Init;
    
    public function form() {
        return new Employee;
    }
    
    public
        $_title="My Details",
        $url="ctms/employees/create",
        $types="My Details",
        $type="My Detail";
}