<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */
/***************************************************************
            DATABASE ALTERATIONS TO ACCOMMODATE MODULE
 * 
 * 
 
ALTER TABLE `employees` ADD `phone_code` INT NULL DEFAULT NULL AFTER `designation`; 
ALTER TABLE `employees` ADD `phone` INT NULL DEFAULT NULL AFTER `designation`; 
ALTER TABLE `employees` ADD `email` VARCHAR(255) CHARACTER SET utf8mb4 NULL DEFAULT NULL AFTER `designation`; 

 *******************************************************************/
return[
    //module ref
    "ref"=>"Ctms",
    //external dependencies
    "dependencies"=>[
        "Base"=>[
            "Category","Currency","Rate","Source","Location","Contact","CashAccount","Payment"
        ]
    ],
    //models in order of dependency
    "models"=>[
        "Department","Employee","Task","TimeSheet"
    ],
    //links
    //'module'=>"Truck",
    "links"=>[
        [
            'url'=>'profile',
            'title'=>'My Account',
            'icon'=>'mdi mdi-account-box',
            'cluster'=>'root',
            'type'=>'MENU',
            'active'=>1,
            'module'=>"Ctms",
            "ranking"=>0.01,
            'allowed'=>[
                'Manager','Supervisor','Staff'
            ]
        ],
        [
            'url'=>'ctms/staff/index',
            'title'=>'My Details',
            'icon'=>'mdi mdi-card-account-details',
            'cluster'=>'profile',
            'type'=>'LINK',
            'active'=>1,
            'module'=>"Ctms",
            "ranking"=>0.01,
            'allowed'=>[
                'Manager','Supervisor','Staff'
            ]
        ],
        [
            'url'=>'ctms/myuser/index',
            'title'=>'User Details',
            'icon'=>'mdi mdi-card-account-details-outline',
            'cluster'=>'profile',
            'type'=>'LINK',
            'active'=>1,
            'module'=>"Ctms",
            "ranking"=>0.01,
            'allowed'=>[
                'Manager','Supervisor','Staff'
            ]
        ],
        [
            'url'=>'time',
            'title'=>'Time Sheet',
            'icon'=>'mdi mdi-file-table',
            'cluster'=>'root',
            'type'=>'MENU',
            'active'=>1,
            'module'=>"Ctms",
            "ranking"=>2.0,
            'allowed'=>[
                'Manager','Supervisor','Staff'
            ]
        ],
        [
            'url'=>'ctms/budgets/index',
            'title'=>'Budgets',
            'icon'=>'fa fa-file-invoice',
            'cluster'=>'time',
            'type'=>'LINK',
            'active'=>1,
            'module'=>"Ctms",
            "ranking"=>2.02,
            'allowed'=>[
                'Manager','Supervisor'//,'Staff'
            ]
        ],
        [
            'url'=>'ctms/assignments/index',
            'title'=>'Assignments',
            'icon'=>'mdi mdi-card-multiple',
            'cluster'=>'time',
            'type'=>'LINK',
            'active'=>1,
            'module'=>"Ctms",
            "ranking"=>2.01,
            'allowed'=>[
                'Manager','Supervisor','Staff'
            ]
        ],
        [
            'url'=>'ctms/approvals/index',
            'title'=>'Approvals',
            'icon'=>'mdi mdi-card-multiple',
            'cluster'=>'time',
            'type'=>'LINK',
            'active'=>1,
            'module'=>"Ctms",
            "ranking"=>2.01,
            'allowed'=>[
                'Manager','Supervisor','Staff'
            ]
        ],
        ,
        [
            'url'=>'ctms/timesheets/index',
            'title'=>'Time Sheet',
            'icon'=>'mdi mdi-card-multiple',
            'cluster'=>'time',
            'type'=>'LINK',
            'active'=>1,
            'module'=>"Ctms",
            "ranking"=>2.01,
            'allowed'=>[
                'Manager','Supervisor','Staff'
            ]
        ],
        [
            'url'=>'ctms/tasks/index',
            'title'=>'Tasks',
            'icon'=>'mdi mdi-card-multiple',
            'cluster'=>'time',
            'type'=>'LINK',
            'active'=>1,
            'module'=>"Ctms",
            "ranking"=>2.02,
            'allowed'=>[
                'Manager','Supervisor'//,'Staff'
            ]
        ],
        [
            'url'=>'ctms/departments/index',
            'title'=>'Departments',
            'icon'=>'mdi mdi-file-tree-outline',
            'cluster'=>'time',
            'type'=>'LINK',
            'active'=>1,
            'module'=>"Ctms",
            "ranking"=>2.03,
            'allowed'=>[
                'Manager','Supervisor'//,'Staff'
            ]
        ],
        [
            'url'=>'ctms/employees/index',
            'title'=>'Employees',
            'icon'=>'mdi mdi-account-group',
            'cluster'=>'time',
            'type'=>'LINK',
            'active'=>1,
            'module'=>"Ctms",
            "ranking"=>2.04,
            'allowed'=>[
                'Manager','Supervisor'//,'Staff'
            ]
        ],
        [
            'url'=>'repo',
            'title'=>'Reporting',
            'icon'=>'fa fa-book-reader',
            'cluster'=>'root',
            'type'=>'MENU',
            'active'=>1,
            'module'=>"Ctms",
            "ranking"=>2.1,
            'allowed'=>[
                'Manager','Supervisor','Staff'
            ]
        ]
    ]
];