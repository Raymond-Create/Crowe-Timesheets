<?php
namespace Core\Authentication\Library;

use Core\Base\Library\AbView;

class AccessView extends AbView
{
    use \Lib\Init;
    
    public function form()
    {
        //return new Access();
    }
    public
    $_title="Access",
    $open_title="",
    $url="authentication/access/create",
    $types="Access",
    $type="Access",
	$drop=[
		"Access"=>"authentication/access/index",
		"Roles"=>"auntentication/roles/index",
		"Users"=>"authentication/userroles/index",
		"Menus"=>"authentication/menus/index"
	];
}