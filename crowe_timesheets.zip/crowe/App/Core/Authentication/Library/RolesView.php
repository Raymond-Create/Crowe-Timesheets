<?php
namespace Core\Authentication\Library;

class RolesView extends AccessView
{
    use \Lib\Init;
    
    public function form()
    {
        return false;
    }
    public
    $_title="Roles",
    $open_title="",
    //$url="truck/access/create",
    $types="Roles",
    $type="Role";
}