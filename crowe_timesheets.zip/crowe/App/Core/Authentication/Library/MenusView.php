<?php
namespace Core\Authentication\Library;

class MenusView extends AccessView
{
    use \Lib\Init;
    
    public function form()
    {
        return false;
    }
    public
    $_title="Menus",
    $open_title="",
    //$url="truck/access/create",
    $types="Menus",
    $type="Menu";
}