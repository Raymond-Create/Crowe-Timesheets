<?php

namespace Core\Authentication\Library;

use Lib\Factory as Fa;

class UserRoles{
	
	public function html()
	{
		return div("card")
			->attr("data-x-mod","user-roles")
			->add(div("card-header")
				->add(h3()->add("User Roles"))
			)
			->add(div("card-"))
			
	}
}