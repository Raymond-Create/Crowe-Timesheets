<?php

namespace Core\Authentication\Library;

use Lib\Factory;

class Access{
	
	private $module,$role;
	
	public function __construct($module=null,$role=null)
	{
			$this->module=$module;
			$this->role=$role;
	}
	
	public function set_url(){}
	
	public function html(){
		$div=div("card")
			->attr("menu-access");
		$div->add(div("card-header")
			->add(h3()->add("Menu Access Control"))
		);
		$body=div("card-body")
			->add(div(ROW)
				->add(div(C444)
					->add(\Lib\Combo::init()
						->set_model(["Menu","Authentication"])
						->set_pattern(CHAR_RGX)
						->set_placeholder("Module")
						->set_filter([
                                                    "table"=>[
                                                        'table'=>'menus','alias'=>"me",
                                                        'select'=>['distinct(module) as md']
                                                    ],
                                                    'select'=>[
                                                        'me.md as id','me.md as title',
                                                        "'1' as active"
                                                    ]
						])
						->html()
					)
				)
				->add(div(C444)
					->add(\Lib\Combo::init()
						->set_model(["Role","Authentication"])
						->set_pattern("/\d+/")
						->set_placeholder("Select Role")
						->html()
					)
				)
				->add(div(C444)->add($this->users()))
				
			)
			->add(div(ROW." list"));
			return $div->add($body);
	}
	
	public function table()
	{
		$table=table("table table-stripped table-sm");
		
	}
	
	private function users()
	{
		$map=[];
		$data=[];
		$users=[];
		$c=\Lib\Combo::init();
		$d=Factory::app("User","Authentication");
		$e=Factory::init()->get_model("Authentication","Authentication");
		foreach($d->read(["where"=>["blocked"=>0]]) as $dd)
		{
			$users[]=$dd["id"];
			$map[$dd["user_id"]]=$dd["id"];
                        $dt=$e->fetch(["where"=>["id"=>$dd["user_id"]]]);
		}//x($users);x($map,9);
		foreach($e->read(["where"=>["id"=>["in"=>$users]]]) as $ee)
		{
                    if(!isset($map[$ee["id"]])){
                        //x($ee["id"]);
                        //x($map[$ee["id"]],9);
                    }
                    //$data[$map[$ee["id"]]]=$ee["name"]." ".$ee["surname"];
		}//x($data,7);
		$c->set_model(["User","Authentication"]);
		$c->set_pattern("/\d+/");
		$c->set_name("user");
		return $c->html();
	}
}