<?php

namespace Core\Authentication\Library;

use Lib\ID;
use Lib\Session as Sess;
use Core\Gs\Models\User as U;
use Core\Admin\Library\Org;
use Lib\Factory as Lf;


class AddUser
{
	
	public function setup()
	{
		$usrId=Sess::get(ID::get());
		//is user logged in
		if(!$usrId)
		{
			return;
		}
		$usr=Lf::app("User","Authentication");
		$usr->tableExists();
		$rol=Lf::app("Role","Authentication");
		$rol->tableExists();
		//find out if user is admin database
		$db=Lf::init()
                    ->get_model("Db","Authentication");
		$db->tableExists();
		$db->fetch([
			"where"=>[
				"dbs.user"=>$usrId,
				"orgs.db"=>Sess::get("user_selected_database")
			],
			"select"=>["dbs.*"],
			"join"=>[
				"join"=>[
					["orgs","orgs.id","dbs.org"]
				]
			]
		]);
		//is user an admin
		if($db->admin)
		{
			//create admin role if not exists
			$rol->fetch([
				"where"=>[
					"name"=>"ADMINISTRATION"
				]
			]);
			if(!$rol->id)
			{
				$rol->name="ADMINISTRATION";
				$rol->priority=1;
				$rol->id=$rol->save();
			}
		}
		else{
			//create accountant role if not exists
			$rol->fetch([
				"where"=>[
					"name"=>"Accountant"
				]
			]);
			if(!$rol->id)
			{
				$rol->name="Accountant";
				$rol->priority=2;
				$rol->id=$rol->save();
			}
		}//x($db->admin8);
		$usr->fetch([
			"where"=>[
				"user_id"=>$usrId
			]
		]);
		if(!$usr->id)
		{
			$usr->user_id=$usrId;
			$usr->role=$rol->id;
			$usr->admin=$db->admin?1:0;
			$usr->id = $usr->save();
		}
		return $usr->id;
	}
	
}