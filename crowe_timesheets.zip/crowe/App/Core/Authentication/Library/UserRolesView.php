<?php
namespace Core\Authentication\Library;

class UserRolesView extends AccessView
{
    use \Lib\Init;
    
    public function form()
    {
        return false;
    }
    public
    $_title="Users",
    $open_title="",
    //$url="truck/access/create",
    $types="Users",
    $type="User";
}