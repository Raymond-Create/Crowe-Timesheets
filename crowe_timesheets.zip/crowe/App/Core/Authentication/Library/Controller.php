<?php

namespace Core\Authentication\Library;

use Lay\Lay;

class Controller extends \Core\Base\Library\Controller{
		
    //use \Core\Gs\Library\Index;
    
		
    public function on_init(){
        $this->check_request();
        if(isset($this->_model))
        {
            $this->model = \Lib\Factory::init()->get_model($this->_model);
        }
        $this->view->MENUS="";
        $this->view->layout=config("layout");
        $this->view->huchijs=Lay::get("huchi-js", "shared");
        $this->view->huchicss=Lay::get("huchi-css", "shared");
        $this->view->pnotifyjs=Lay::get("pnotify-js", "shared");
        $this->view->pnotifycss=Lay::get("pnotify-css", "shared");
        $this->view->ui=LAY .DS. "Files" .DS. config("layout") .DS;
        $this->view->assets=SERVER_URL ."/App/Core/Authentication/static";
        $this->view->userFirstName="";
        $this->view->avatar=REPO . "user-avatar.png";
        $this->view->noticeCount=0;
        $this->view->msgCount=0;
        LoginLog::init()->activity();
    }
}