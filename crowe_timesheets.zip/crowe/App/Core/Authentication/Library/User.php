<?php

namespace Core\Authentication\Library;

use Lib\ID;
use Lib\Session as Sess;
use Core\Gs\Models\User as U;
use Lib\Factory as Lf;

class User
{
	
    use \Lib\Init;//,\Lib\Loader;
	
    public static function id(){
        return self::init()->userExists();
    }
    
    public static function isAdmin()
    {
    		return self::init()->is_admin();
    }
    
    public static function isTheAdmin()
    {
    		return self::init()->is_the_admin();
    }
    
    public static function is($role)
    {
    		return self::init()->hasRole($role);
    }
    
    public static function hasAccess($link)
    {
        return self::init()->link_access($link);
    }

    public static function hasUrlAccess($link)
    {//x("::hasUrlAccess",9);
        return self::init()->url_access($link);
    }
    
    public function __construct(U $model = null)
    {
        $this->model=Lf::app("User","Authentication");
        $role=Lf::app("Role","Authentication");
        $role->tableExists();
        $this->model->tableExists();
        if($model)
        {
            $this->model=$model;
        }
        $this->addUser();
    }
	
    public function isValid(){
        return $this->userExists()&&$this->isActive();
    }
	
    public function addUser()
    {
        try{
            $inst=new AddUser();
            $inst->setup();

        } catch (Exception $ex)
        {
            x($ex,8);
        } 
    }
    public function userExists()
    {
        return $this->val('id');
    }
    
    
  
    public function hasRole($name)
    {
        $model= Lf::app('Role','Authentication');
        $model->fetch([
           'where'=>[
     		 'id'=>$this->val('role'),
     		 'name'=>$name
            ]
        ]);
        return !$model->isEmpty();
    }
	
    public function role()
    {
        return $this->val("role");
    }
    
    public function username()
    {
        return $this->val("username");
    }
	
    public function email()
    {
        return $this->val("email");
    }
	
    public function isActive()
    {
        return $this->val("active"); 
    }
    
    public function url_access($url)
    {
        $_url=explode("/",$url);
        if(count($_url)==2)
        {
            $_url[2]=config("method");
        }
        $mod=Lf::app('MenuAccess','Authentication');
        $mod->fetch([
            "join"=>[
                "join"=>[
                    ["users u","u.role","menuaccesses.role"],
                    ["menus m","m.id","menuaccesses.menu"]
                ]
            ],
            "where"=>[
                "u.id"=>User::id(),
                "m.url"=>implode("/",$_url)
            ],
            "select"=>["menuaccesses.*"]
        ]);//x(qd(),8);
        return $this->isAdmin()||$mod->id;
    }
    public function link_access($link)
    {
        $actual= Lf::app('MenuAccess','Authentication')->select([
        	"table"=>"rolelinks",
        	"join"=>[
        		"join"=>[
                            ["users u","u.role","menuaccesses.role"]
        		]
        	],
        	"where"=>[
        		"u.id"=>Sess::get(ID::get()),
        		"menuaccesses.menu"=>$link
        	]
        ]);
        $privelege=$this->model('Role','Authentication')->select([
        	"table"=>"roles",
        	"join"=>[
        		"join"=>[
        			["users u","u.role","roles.id"]
        		]
        	],
        	"where"=>[
        		"u.id"=>Sess::get(ID::get()),
        		"roles.name"=>"ADMINISTRATION",
        		"roles.active"=>1
        	]
        ]);//x(qd(),7);
        return !empty($actual)||!empty($privelege);
    }
       
    private function user_model(){
        $this->model->fetch([
            "where"=>["email"=>$this->email()]
	]);
        return $this->model;
    }
    
    public function val($field)
    {   
        //unset($_SESSION["user_selected_database"]);
        //$this->model->tableExists();
        //x($_SESSION["user_selected_database"],8);
        //x($this->model->getConnection(),8);
        $this->model->fetch([
            "where"=>[
                "user_id"=>Sess::get(ID::get())
            ]
        ]);//x(,7);
        return $this->model->$field;
    }
    
    private function is_admin()
    {
        if(!$this->is_the_admin())
        {
            return $this->val('admin');
        }
        return true;
    }
    
    private function is_the_admin()
    {
        $mod=Lf::init()->get_model(
                "Authentication","Authentication"
        );
        $mod->get(Sess::get(ID::get()));
        return $mod->admin;
    }
}