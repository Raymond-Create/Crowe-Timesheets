<?php

namespace Core\Authentication\Library;


class RootController extends \Core\Base\Library\Controller{
    
   
    public function on_init(){
        parent::on_init();
    }
}