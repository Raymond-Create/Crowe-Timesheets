<?php

namespace Core\Authentication\Library;

use Lib\Factory as Lf;
use Lib\Session as Sess;
use Lib\ID;

class LoginLog{
		
    //use \Core\Gs\Library\Index;
    
	private $model;
	
	public static function init(){
	    return new self;
	}
	
    public function __construct(){
        $this->model=Lf::init()->get_model("Login","Authentication");
        $this->model->tableExists();
    }
    
	public function attempt($user){
        $this->model->action="Attempt";
        $this->model->username=$user;
        $this->model->save();
    }
	
    public function login():void
    {
        $this->model->action="Login";
		$this->model->user=Sess::get(ID::get());
		$this->model->save();
    }
    
    public function logout($user,$noactivity):void
    {
        if($noactivity)
        {
            $this->model->type="Otherwise";
        }
        $this->model->action="Logout";
        $this->model->user=$user;
        $this->model->save();
    }
	
    public function activity():void
    {
        if(!Sess::get(ID::get()))
        {
            return;
        }
        $this->model->fetch([
            "where"=>[
                "action"=>"Activity",
                "user"=>Sess::get(ID::get())
            ]
        ]);
        //x(Sess::get(ID::get()),7);
        $this->model->action="Activity";
        $this->model->time=date("Y-m-d H:i:s");
        $this->model->user=Sess::get(ID::get());
        $this->model->save();
    }
    
    public function lock():void
    {
        $this->model->action="Lock";
        $this->model->user=Sess::get(ID::get());
        $this->model->save();
    }
    
    public function unlock():void
    {
        $this->model->action="Unlock";
        $this->model->user=Sess::get(ID::get());
        $this->model->save();
    }
}