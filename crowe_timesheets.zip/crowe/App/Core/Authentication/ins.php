<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */
/***************************************************************
            DATABASE ALTERATIONS TO ACCOMMODATE MODULE
 * 
 * 
 
ALTER TABLE `employees` ADD `phone_code` INT NULL DEFAULT NULL AFTER `designation`; 
ALTER TABLE `employees` ADD `phone` INT NULL DEFAULT NULL AFTER `designation`; 
ALTER TABLE `employees` ADD `email` VARCHAR(255) CHARACTER SET utf8mb4 NULL DEFAULT NULL AFTER `designation`; 

 *******************************************************************/
return[
    //module ref
    "ref"=>"Authentication",
    //external dependencies
    "dependencies"=>[
        "Base"=>[
           "Category",
        ]
    ],
    //models in order of dependency
    "models"=>[
        "Role","Menu","User","Menuaccess"
    ],
    //links
    "links"=>[
        [
            'url'=>'access',
            'title'=>'Access',
            'icon'=>'mdi mdi-garage-variant-lock',
            'cluster'=>'root',
            'category'=>[
                ["Category","Base"],
                [
                    "name"=>"LINK GROUP",
                    "type"=>"MENUS"
                ]
            ],
            'active'=>1,
            'module'=>"Authentication",
            'allowed'=>[
                'Manager'
            ]
           
        ],
        [
            'url'=>'authentication/roles',
            'title'=>'Roles',
            'icon'=>'mdi mdi-account-multiple-check-outline',
            'cluster'=>'access',
            'category'=>[
                ["Category","Base"],
                [
                    "name"=>"LINK",
                    "type"=>"MENUS"
                ]
            ],
            'active'=>1,
            'module'=>"Authentication",
            'allowed'=>[
                'Manager'
            ]
        ],
        [
            'url'=>'authentication/menus',
            'title'=>'Menus',
            'icon'=>'mdi mdi-menu-open',
            'cluster'=>'access',
            'category'=>[
                ["Category","Base"],
                [
                    "name"=>"LINK",
                    "type"=>"MENUS"
                ]
            ],
            'active'=>1,
            'module'=>"Authentication",
            'allowed'=>[
                'Manager'
            ]
        ],
        [
            'url'=>'authethication/menuaccess',
            'title'=>'Role Menus',
            'icon'=>'mdi mdi-account-key',
            'cluster'=>'access',
            'category'=>[
                ["Category","Base"],
                [
                    "name"=>"LINK",
                    "type"=>"MENUS"
                ]
            ],
            'active'=>1,
            'module'=>"Authentication",
            'allowed'=>[
                'Manager'
            ]
        ],
        [
            'url'=>'authethication/menuaccess',
            'title'=>'User Roles',
            'icon'=>'mdi mdi-account-box-multiple',
            'cluster'=>'access',
            'category'=>[
                ["Category","Base"],
                [
                    "name"=>"LINK",
                    "type"=>"MENUS"
                ]
            ],
            'active'=>1,
            'module'=>"Authentication",
            'allowed'=>[
                'Manager'
            ]
        ]
    ]
];