<?php

return [
	'path'=>'Authentication',
	'version'=>'1.0',
	'publication'=>'2021-12-01',
	'restriction'=>'Open',
	'notes'=>'Module provides the basic user authentication and system\'s security layer',
	'icon'=>"fa fa-lock",
	'name'=>'Authentication',
	'flag'=>1
 ];