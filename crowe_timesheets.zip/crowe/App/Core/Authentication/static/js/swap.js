CORE.add("swap",x=>{
    let aaList=e=>{
        x.stop(e);
        var aa=x.tag_look(e,"A");
        swap(aa.data('db'));
    };
    let swapList=e=>{
        x.stop(e);
        swap(x.me(e).val());
    };
    let swap=db=>{
        X("authentication/orgs/swap",o=>{
            if(o.status){
                x.notify({type:"info",data:"Active Organisation Changed"},"notify");
                document.location.href=constants.link("home/landing");
            }
        },{database:db});
    };
    return{
        init:()=>{
            x.find('.dropdown-item').each(aa=>{
                x.use(aa).bind().click(aaList);
            });//console.log(x.named("sw-co"));
            if(x.named("sw-co"))
                x.named("sw-co").bind().change(swapList);
        },
        dump:()=>{
            x.find('.dropdown-item').each(aa=>{
                x.use(aa).unbind().click(aaList);
            });
            if(x.named("sw-co"))
                x.named("sw-co").unbind().change(swapList);
        }
    };
})