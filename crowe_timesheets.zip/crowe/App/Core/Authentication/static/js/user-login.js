CORE.add("user-login",x=>{
	let name,surname,email,mobile,password,remember,agree,submit,register,login,code;
	let submitList=e=>{
		x.stop(e);
		var ct=constants.test;
		var cs=constants.shout;
		var data={};
                //return 
               // console.log(register);
		if(register){
			if(!ct(email))return;
			data.email=email.val();
			if(!ct(password))return;
			data.password=md5(password.val());
			X("authentication/login/check/"+remember.val(),o=>{
				 var mod=x.mod().lookup({"class":"modal"});
				if(o.status){
					if(mod)
                                            mod.select(".close").use().click();//return console.log(o)
					x.notify({type:"success",data:"Login Successiful"},"notify");
					document.location.href=constants.link(o.message);
				}
                                else x.notify({type:"error",data:"Invalid username/password"},"notify");
			},data);
		}
            if(login){
                    if(!ct(name))return;
                    data.name=name.val();
                    if(!ct(surname))return;
                    data.surname=surname.val();
                    if(!ct(code))return;
                    data.code=code.val();
                    if(!ct(mobile))return;
                    data.mobile=mobile.val();
                    if(!ct(email))return console.log(email.n);
                    data.email=email.val();
                    if(!ct(password))return;
                    data.password=md5(password.val());
                    if(!agree.n.checked){
                        console.log("not agreing");
                        agree.addClass("is-invalid");
                        return x.notify({type:"error",data:"not agreing"},"notify");
                    }
                    X("authentication/login/register/",o=>{
                            console.log(o)
                    },data);
            }
		
	};
	
	let registerList=e=>{
		x.stop(e);
		document.location.href=constants.link("authentication/login/register");
	};
    let loginList=e=>{
        x.stop(e);
        document.location.href=constants.link("authentication/login/index");
    };
    let build=()=>{
//        console.log(register);
//        if(register)
//            register.bind().click(registerList);
//        if(login)
//           login.bind().click(loginList);
        register=true;
        submit.bind().click(submitList);
    };
	
    let destroy=()=>{
        if(register)
            register.unbind().click(registerList)
        if(login)
            login.unbind().click(loginList)
        submit.unbind().click(submitList);
    };
    return{
        init:()=>{
            name=x.named("name");
            surname=x.named("surname");
            email=x.named("email");
            mobile=x.named("mobile");
            password=x.named("password");
            remember=x.named("remember");
            code=x.named("code");
            agree=x.named("agree");
            submit=x.named("submit");
            register=x.named("register");//console.log(x.mod().use().inner());
            login=x.named("login");
            //return console.log(submit);
            //return console.log(x.mod().use().inner());
            build();
        },
        dump:()=>{
            destroy();
            name=null;
            code=null;
            register=null;
            login=null;
            surname=null;
            email=null;
            mobile=null;
            password=null;
            terms=null;
            agree=null;
            submit=null;
        }
    };
});