<?php

namespace Core\Authentication\Controllers;



class Menuaccess extends Access{
	

}