<?php

namespace Core\Authentication\Controllers;

//use Core\Gs\Library\Crud;
use Core\Authentication\Library\LoginLog;
use Core\Authentication\Library\Controller;
use Lib\Password;
use Lib\Session;
use Lib\ID;
use Lib\Session as Ss;
import("PHPMailer");
import("System");
//use Lib\BinFile as B;
use PHPMailer\PHPMailer;
use Sys\Classes\Tracker;

class Login extends Controller{
		
    //use \Core\Gs\Library\Index;
		
    public 
    	$show_form=true,
        $_model=["User","Authentication"],
        $_left=['Links','advanced'];
    
    
    
    public function index($idcode=null){//x($this,9);
        if($idcode){
            $tra=new Tracker($this->view->application->request);
            $tra->save($idcode);
        }//x(Ss::init()->state(),9);
        if($this->isLoggedIn() && !isAjax())
        {
            redirect(config("login"));
        }
        $this->view->noHeader();
        /*
        $mod=\Lib\Factory::init()->get_model("Authentication","Authentication");
        $mod->email='blessing@huchitech.com';
        $mod->isadmin=1;
        $mod->save();
        //x($mod,9);
        x($mod->read(),9);
        */
    }
    public function finger()
    {
        Ss::set("finger",$this->post()["finger"]);
        $this->json(Ss::get("finger"));
    }
    public function register(){
        if($this->post()){
            $pst=$this->post;
            if($this->email_exists($pst['email'])){
                $this->json("Email already exists",0);
            }
            $model=\Lib\Factory::init()->get_model("Authentication","Authentication");
            foreach ($pst as $k=>$v){
                $model->$k=$v;
            }
			//$this->model->password=Password::hash($pst['password']);
            $save=$model->save();
			$this->json($save?"User created successifully":"User was NOT created",$save);
        }
    }
	
	public function email_exists($mail){
	    $model=\Lib\Factory::init()->get_model("Authentication","Authentication");
		$data=$model->fetch([
			"where"=>["email"=>$mail]
		]);
		return !empty($data);
	}
	
	public function check()
    {   
		
        if($this->isLoggedIn() && isAjax())
        {
            $this->json(config("login"));		
        }
		if($this->post())
        {	
            $model=\Lib\Factory::init()->get_model("Authentication","Authentication");
            $password=$this->post["password"];
            $email=$this->post['email'];
			$w=$model->fetch([
                "where"=>["email"=>$email]
            ]);
			//x($model->id,7);
            //$model->password=$password;x($model->save(),9);
            $pass=$model->is_valid($password);
			//x($pass,7);
            if($pass && !$model->blocked)
            {
                Session::set(ID::get(),$model->id);
                Session::set(USER_KEY,$model->id);
                LoginLog::init()->login();
                $page=config("landing");
                if(config("dedicated"))//http://tech.huchi.co.zw/
                {
                    Session::set("user_selected_database",config("dedicated"));
                    $page=config("landing");
                }else{
                    $mod=\Lib\Factory::init()->get_model("Org","Authentication");
                    $mod->tableExists();
                    $data=$mod->read([
                        "join"=>[
                            "join"=>[
                                ["dbs","dbs.org","orgs.id"]
                            ]
                        ],
                        "where"=>["dbs.user"=>$model->id],
                        "select"=>["db"]
                    ]);
					//Session::remove(ID::get(),$model->id);
                    //x($data,7);
                    if($data&&isset($data[0])&&isset($data[0]["db"])){
                        Session::set("user_selected_database",$data[0]["db"]);
                    }
                    $page=config("landing");
                }
                if(!isAjax()){
                    return redirect($page);
                }
                $this->json($page);
            }	
            $this->json(0,0);	
        }
    }
    
    public function logout($noactivity=null)
    {
        if($this->isLoggedIn())
        {
            $user=Session::get(ID::get(),$this->model->id);
            Session::remove(ID::get());
            Session::remove(USER_KEY);
            Session::remove("user_selected_database");
            LoginLog::init()->logout($user,$noactivity);
        }
        if(!isAjax()){
            return redirect(config("logout"));
        }
        $this->json(config("logout"));
    }
    
    public function activate()
    {
        $data=$this->post();
        Session::set("user_selected_database",$data["database"]);
        //$lib=\Lib\Factory::app("MenuAccess","Home");
        $this->json(1,2);
    }
    
    public function mail_verification($userId,$verification=null){
        
        $model=\Lib\Factory::init()->get_model("Authentication","Authentication");
        $model->fetch([
            "where"=>[
                "id"=>$userId,
                "ehash"=>$verification
            ]
        ]);
        if($model->id)
        {
            $model->wverified=date("Y-m-d H:i:s");
            $ix=$model->save();
            if($ix){
                redirect("authentication/login/mail_verified/$userId");
            }
        }
        $this->view->userId=$userId;
        $model->get($userId);
        $return=$this->mail($model);
        if($return)
        {
            $message="A verification email has been sent to your mail box verify your account to start using it.";
        }
        else{
            $message="Click button below to sent a verification mail to your email.";
        }
        $this->view->message=$message;
    }
    
    private function mail($model)
    {
        $mail = new PHPMailer();
        /* Set the mail sender. */
        $mail->setFrom("huchitechinfo@gmail.com", 'Huchi Technologies');
        
        /* Add a recipient. */
        $mail->addAddress($model->email, 'End User');
        
        //$mail->AddCC('freightalliance21@gmail.com', 'Company Mail');
        /* Set the subject. */
        $mail->Subject = 'Confirm your registration';
        
        //$mail->isHTML(true);
        /* Set the mail message body. */
        $mail->Body = "Hi!\n\n";
        $mail->Body .= "In order to access your huchitech.com account please ";
        $mail->Body .= "<a href='";
        $mail->Body .= PAGE_URL . "authentication/login/mail_verification/";
        $mail->Body .= $model->id. "/" .$model->ehash ."'>";
        $mail->Body .= "click on this confirmation link</a>\n\n";
        $mail->Body .= "Best regards,\n\n";
        $mail->Body .= "The Busuness Pal Team";
        ///*
        $mail->IsSMTP();
        $mail->Mailer = "smtp";
        $mail->SMTPDebug  = 0;
        $mail->SMTPAuth   = TRUE;
        $mail->SMTPSecure = "ssl";
        $mail->Port       = 465 ;
        $mail->Host       = "smtp.gmail.com";
        $mail->Username   = "freightalliance21@gmail.com";
        $mail->Password   = "Alliance2020.";
        //*/
        //x($mail,9);
        /* Finally send the mail. */
        if (!$mail->send())
        {
            /*$mailError=$this->model("MailError","Load");
            $mailError->tableExists();
            $mailError->address=$c->email;
            $mailError->message=var_export($mail,true);
            $mailError->save();*/
            return false;
        }
        return true;
    }
}