<?php

namespace Core\Authentication\Controllers;

use Core\Base\Library\Controller;
use Core\Authentication\Library\UserRolesView as Av;

class Userroles extends Controller{
	
	use \Core\Base\Library\Index;
	
    public 
        $show_form=1,
        $_model=["User","Authentication"];
        
    public function __table($rows,$page):\Huchi\Classes\Tag 
    {
        $this->table["rows"]=$rows;
        $this->table["page"]=$page;
        $this->table["search_forms"]=["registration","color","man_year"];
        $this->table["widths"]=[
			"registration"=>"80px","color"=>"70px","number"=>"70px",
			"engine_no"=>"80px","chasis_no"=>"80px","wheel_plan"=>"80px",
			"man_year"=>"80px","net_mass"=>"70px","gross_mass"=>"70px"
		];
        return Av::init(parent::__table($rows, $page))->html();
    }
}