<?php

namespace Core\Authentication\Controllers;

use Core\Base\Library\Controller;
use Core\Authentication\Library\AccessView as Av;

class Access extends Controller{
	
	use \Core\Base\Library\Index;
	
    public 
        $show_form=1,
        $_model=["MenuAccess","Authentication"],
        $_lib=["Access",'Authentication'];
        
    public function __table($rows,$page):\Huchi\Classes\Tag 
    {
        $this->table["rows"]=$rows;
        $this->table["page"]=$page;
        $this->table["search_forms"]=["menu","role"];
        //$this->table["widths"]=[];
        return Av::init(parent::__table($rows, $page))->html();
    }
}