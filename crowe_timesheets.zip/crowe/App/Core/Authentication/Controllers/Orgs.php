<?php

namespace Core\Authentication\Controllers;

use Core\Base\Library\Logo;

class Orgs extends \Core\Authentication\Library\RootController{
    
    use \Core\Base\Library\Index;
    public 
        $root_db=1,
        $show_form=1,
        $_model=["Org","Authentication"];
    
    public function __table($rows,$page):\Huchi\Classes\Tag
    {
        $this->table["filter"]=[
            "where"=>[
                "db"=>\Lib\Session::get("user_selected_database")
            ]
        ];
        return parent::__table($rows, $page);
    }
    
    public function logo(){
        if($this->post()){
            $this->model->fetch([
                "where"=>["db"=>\Lib\Session::get("user_selected_database")]
            ]);   		
            $this->model->logo =  str_replace('[removed]', $this->post["prefix"] .",", $this->post["avatar"]);
            $s = $this->model->save();
            $this->json($s?"Record successfully modified":"Record NOT modified",$s);
        }
        $this->_left=['Logo','config'];
        $this->ajax((div('row m-5')
                ->attr('data-x-mod','data-display')
                ->add(div('col-md-12 col-lg-12 col-xs-12')->add(Logo::init()->html()))
            )
    	);
    }
    
    public function current_logo(){
        $this->model->fetch([
            "where"=>["db"=>\Lib\Session::get("user_selected_database")]
        ]);
        if(!$this->model->isEmpty()){
            $this->json($this->model->logo);
        }
        $this->json(0,0);
    }
    
    public function swap()
    {
        //\Lib\Session::set("user_selected_database","precicorn");
        $this->post();
        $db=$this->post["database"];
        $model=\Lib\Factory::init()->get_model("Org","Authentication");
        $model->fetch([
            "where"=>[
                "db"=>$db
            ]
        ]);
        if($model->id){
            \Lib\Session::set("user_selected_database",$db);
            $this->json(2,2);
        }
        $this->json(0,0);
    }
} 