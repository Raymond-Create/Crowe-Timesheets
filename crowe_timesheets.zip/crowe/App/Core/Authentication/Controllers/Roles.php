<?php

namespace Core\Authentication\Controllers;

use Core\Base\Library\Controller;
use Core\Authentication\Library\RolesView as Av;

class Roles extends Controller{
	
	use \Core\Base\Library\Index;
    public function __table($rows,$page):\Huchi\Classes\Tag 
    {
        $this->table["rows"]=$rows;
        $this->table["page"]=$page;
        //$this->table["search_forms"]=["registration","color","man_year"];
        return Av::init(parent::__table($rows, $page))->html();
    }
    
    public 
        $show_form=1,
        $_model=["Role","Authentication"],
        $_left=["Roles",'configurations'];
}