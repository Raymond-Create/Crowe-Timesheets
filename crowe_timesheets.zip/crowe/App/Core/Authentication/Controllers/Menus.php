<?php

namespace Core\Authentication\Controllers;

use Core\Base\Library\Controller;
use Core\Authentication\Library\MenusView as Mv;

class Menus extends Controller{
	
	use \Core\Base\Library\Index;
	
    public 
        $show_form=1,
        $_model=["Menu","Authentication"];
		
	    
    public function __table($rows,$page):\Huchi\Classes\Tag 
    {
        $this->table["rows"]=$rows;
        $this->table["page"]=$page;
        $this->table["search_forms"]=["type","cluster","title","module"];
        $this->table["widths"]=[
			"type"=>"60px","cluster"=>"70px","title"=>"70px",
			"ranking"=>"60px","module"=>"80px","wheel_plan"=>"80px",
			"man_year"=>"80px","active"=>"60px","gross_mass"=>"70px"
		];
        return Mv::init(parent::__table($rows, $page))->html();
    }
}