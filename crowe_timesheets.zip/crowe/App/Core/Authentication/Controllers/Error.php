<?php

namespace Core\Authentication\Controllers;

use Core\Base\Library\Logo;

class Error extends \Huchi\Classes\Controller{
    
   
    
    public function on_init() 
    {  
        
    }
    
    public function type404($module=null,$controller=null,$method=null)
    {
        if($module){
            $this->set("module", $module);
        }
        if($controller){
            $this->set("controller", $controller);
        }
        if($method){
            $this->set("method", $method);
        }
    }
    
    
    public function respond() 
    {
        $this->set("scripts", \Lib\Scripts::get("js"));
        $this->set("links", \Lib\Scripts::get("css"));
        $this->view->assets=SERVER_URL ."/App/Core/Authentication/static";
        $this->view->noHeader();
        parent::respond();
    }
} 