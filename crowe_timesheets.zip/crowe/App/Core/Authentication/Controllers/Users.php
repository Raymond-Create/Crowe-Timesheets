<?php

namespace Core\Authentication\Controllers;

use Core\Base\Library\Controller;
use Lib\Factory as Lf;

class Users extends Controller{
	
	use \Core\Base\Library\Index;
	
    public 
        $show_form=1,
        $_model=["User","Authentication"],
        $_left=["Users",'configurations'];
    
    public function names()
    {
        $id=[];
        foreach ($this->model->read() as $user) {
            $this->model->get($user["id"]);
            $auth=Lf::init()->get_model("Authentication","Authentication");
            $auth->get($user["user_id"]);
            $this->model->name=$auth->name ." ". $auth->surname;
            $id[]=$this->model->save();
            $this->model->clear();
        }
        $this->json($id,2);
    }
    
    
    public function sync()
    {
        
        $auth=Lf::init()->get_model("Authentication","Authentication");
        $auth->fetch([
            "join"=>[
                "join"=>[
                    ["dbs d","authentications.id","d.user"],
                    ["orgs o","o.id","d.org"]
                ]
            ],
            "where"=>["o.name"=>"CROWE ZIMBABWE"],
            "select"=>[
                "authentications.*",
            ]
        ]);$arr=[];$i=0;
        $data=$auth->data();//x()
        foreach($data as $row){
            //if($row["id"]!= 73)continue;
            $mod=Lf::app("User","Authentication");
            $mod->fetch([
                "where"=>["user_id"=>$row["id"]]
            ]);//x($mod->data(),8);
            if($mod->id)
            {
                continue;
            }
            $mod->name=$row["name"]." ".$row["surname"];
            $mod->user_id=$row["id"];
            $mod->role=5;
            $arr[$row["id"]]=$mod->save();
            $i++;
        }
       x($arr,8);
        
            
    }
}