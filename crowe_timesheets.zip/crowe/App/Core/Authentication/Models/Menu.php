<?php
	
/**
 * Description of Acl
 *
 * @author bchaumba
 */
 
namespace Core\Authentication\Models;

use Lib\Model;

class Menu extends Model{

    public $_rep_=["title"];

    //public $_group_=["category"];    
	  
	//public function update_struct(array $array){return $array;}
	
    public function _setup(){    
    	return [
            'category'=>_integer([
                'model'=>["Category","Base"],
                "filter"=>["where"=>["type"=>"menus"]],
                "null"=>1,"hide"=>1
            ]),
    	    'type'=>_char([
                'choices'=>["MENU","LINK"],
                "default"=>"LINK"
            ]),
            'cluster'=>_char(['null'=>1]),
            'url'=>_char(['index'=>1,'pattern'=>'/^[a-zA-Z0-9\/\-\.\_\&\=\+\?\:]+$/']),
    	    'title'=>_char(['index'=>1,'pattern'=>'/^[a-zA-Z0-9\+\-\|\. ]+$/']),
    	    'icon'=>_char(['pattern'=>'/^[a-z0-9\- ]+$/']),
    	    'module'=>_char(['null'=>1]),
    	    'ranking'=>_decimal(['default'=>1.0]),
    	    'active'=>_integer(['default'=>0]),
        ];
    }
    
    public function setUrl($url)
    {
        $_url=explode("/",$url);
        if(count($_url)==2)
        {
            $_url[2]=config("method");
        }
        return implode("/",$_url);
    }
}