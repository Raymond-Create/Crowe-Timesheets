<?php
	
/**
 * Description of Acl
 *
 * @author bchaumba
 */
 
namespace Core\Authentication\Models;


class MenuAccess extends \Lib\Model{

    public $_rep_=["menu"];    
	  
	//public function update_struct(array $array){return $array;}
	
    public function _setup(){    
    	return [
    	    'menu'=>_foreign([
    	        'model'=>["Menu","Base"]
    	    ]),
    	    'role'=>_foreign([
    	        'model'=>["Role","Authentication"],"null"=>1
    	    ]),
    	    'user'=>_foreign([
    	        'model'=>["User","Authentication"],"null"=>1,"hide"=>1
    	    ])
        ];
    }
}