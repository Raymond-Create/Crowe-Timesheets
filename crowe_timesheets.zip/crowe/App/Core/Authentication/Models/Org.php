<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Authentication\Models;

use Lib\BaseModel as Model;
use Lib\Session;
use Lib\Factory;
use Lib\Char;
use Lib\ID;

class Org extends Model{

    public $_rep_=["name"];    

    public function _setup(){    
    	return [
    	    'admin'=>_foreign([
    	        'model'=>["Authentication","Authentication"],"null"=>1
    	    ]),
    	    'industry'=>_foreign([
    	        'model'=>["Industry","Authentication"],"null"=>1,"hide"=>1
    	    ]),
    	    'name'=>_char(['pattern'=>'/^[a-zA-Z0-9\.\(\)\'\- ]{5,}$/','null'=>1,'unique'=>1]),
            'email'=>_email(['null'=>1]),
            'phone'=>_char(['pattern'=>'/^[\d\+\, ]+$/','null'=>1]),
            'address'=>_text(['null'=>1]),
            'logo'=>_blob(['null'=>1,'hide'=>1]),
    	    'website'=>_char(['null'=>1]),
    	    'vat'=>_char(['null'=>1]),
    	    'bp'=>_char(['null'=>1]),
    	    'db'=>_char(['null'=>1]),
    	    'active'=>_integer(["default"=>3])
        ];
    }
    public function setName($name)
    {
    	return strtoupper($name);
    }
    
    public function insert(array $data, $table = false) {//x($data,9);
        if(!isset($data["db"]) OR !$data["db"])
        {
            $data['db']=$this->dbName();
        }
        if(!isset($data["admin"]) OR !$data["db"])
        {
            $data['admin']=Session::get(ID::get());
        }
        return parent::insert($data, $table);
    }
    
    private function dbName()
    {
        $gen=Char::gen(rand(7,9));
        $mod=Factory::init()->get_model("Org","Authentication");
        $mod->fetch([
            "where"=>[
                "db"=>$gen
            ]
        ]);
        if($mod->id)
        {
            return $this->dbName();
        }
        return $gen;
    }
	
}