<?php
	
/**
 * Description of Acl
 *
 * @author bchaumba
 */
 
namespace Core\Authentication\Models;

use Lib\Model;

//import("Sys");

class Industry extends Model{

    public $_rep_=["name"];    
	  
	//public function update_struct(array $array){return $array;}
	
    public function _setup(){    
    	return [
    	    'name'=>_char(),
    	    'note'=>_char(['null'=>1])
        ];
    }
}