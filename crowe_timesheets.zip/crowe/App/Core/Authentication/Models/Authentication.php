<?php
	
/**
 * Description of Acl
 *
 * @author bchaumba
 */
 
namespace Core\Authentication\Models;

use Lib\Model;
use Lib\Password;
use Core\Base\Library\Config;

class Authentication extends Model{

    public $_rep_=["email"];    
	  
	//public function update_struct(array $array){return $array;}
	
    public function _setup(){    
    	return [
            'name'=>_char(['null'=>1]),
            'surname'=>_char(['null'=>1]),
            'email'=>_email(["unique"=>1,'index'=>1]),
    	    'code'=>_integer([]),
    	    'mobile'=>_integer([]),
    	    'ehash'=>_char(['unique'=>1,"hide"=>1]),
    	    'mhash'=>_char(['unique'=>1,"hide"=>1]),
    	    'mverified'=> _datetime(['null'=>1,"hide"=>1]),
    	    'wverified'=>_datetime(['null'=>1,"hide"=>1]),
    	    'password'=>_char([
            	"pattern"=>'/^.+$/',"hide"=>1
    	    ]),
    	    'admin'=>_integer([
    	        "default"=>0,
    	        "options"=>['No','Yes']
    	    ]),
    	    'block'=>_integer([
    	        "default"=>0,
    	        "options"=>['No','Yes']
    	    ]),
    	    'active'=>_integer([
    	        "default"=>1,
    	        "options"=>['No','Yes']
    	    ])
        ];
    }
    
    public function insert(array $data,$table=false)
    {
        if(!isset($data["password"])||empty($data['password']))
        {
            $data["password"]=$this->setPassword(md5(Config::init()->defaultPassword));
        }
        if(!isset($data["ehash"])||empty($data['ehash']))
        {
            $data["ehash"]=md5($data["email"].time());
        }
        if(!isset($data["mhash"])||empty($data['mhash']))
        {
           $salt=$data["mobile"]??rand(0,10000); $data["mhash"]=md5($salt.time());
        }
        $data['code']=$data['code']??0;
        $data['mobile']=$data['mobile']??0;
        return parent::insert($data,$table);
    }
    	
    public function setPassword($k)
    {//x($k,9);
        if(preg_match('/^sha256\:\d.+/',$k) || preg_match('/\$2y\$11\$.{50,55}/',$k))
        {
           return $k;
        }
        return Password::hash($k);
    }
	
    public function is_valid($password)
    {
        return Password::verify($password,$this->password,preg_match('/^sha256\:\d.+/',$this->password));
    }
   
}