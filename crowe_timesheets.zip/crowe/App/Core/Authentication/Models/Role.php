<?php
	
/**
 * Description of Acl
 *
 * @author bchaumba
 */
 
namespace Core\Authentication\Models;

use Lib\Model;

//import("Sys");

class Role extends Model{

    public $_rep_=["name"];    
	  
	//public function update_struct(array $array){return $array;}
    //INSERT INTO `dbs` (`user`, `name`, `company`, `address`, `code`, `phone`, `logo`, `id`) VALUES ('2', 'hosp2', 'Huchi Test Hospital', '9 Wheeler Ave', '263', '772358222', NULL, NULL);
    public function _setup(){    
    	return [
    	    'name'=>_char([
                "unique"=>1
            ]),
    	    'priority'=>_integer([
                "default"=>100
            ]),
        ];
    }
	
    public function setName($name){
        return strtoupper($name);
    }
}