<?php
	
/**
 * Description of Acl
 *
 * @author bchaumba
 */
 
namespace Core\Authentication\Models;

use Lib\Model;

//import("Sys");

class Login extends Model{

    public $_rep_=["username"];    
	  
	//public function update_struct(array $array){return $array;}
	
    public function _setup(){    
    	return [
    	    'user'=>_foreign([
    	        'model'=>["Authentication","Authentication"],"null"=>1
    	    ]),
    	    'username'=>_char(["null"=>1]),
    	    'type'=>_char(['choices'=>["Normal","Otherwise"],"default"=>"Normal"]),
    	    'action'=>_char(['choices'=>["Attempt","Lock","Unlock","Login","Activity","Logout"]]),
    	    'time'=>_datetime(['null'=>1])
        ];
    }
}