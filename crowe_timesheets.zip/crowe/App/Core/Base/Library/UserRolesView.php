<?php
namespace Core\Base\Library;

class UserRolesView extends AccessView
{
    use \Lib\Init;
    
    
    public
        
        $_title="User Roles",
        $open_title="",
        //$url="base/axrolemenus/create",
        $types="Role Menus",
        $type="Role Menu";
    
}

