<?php

namespace Core\Base\Library;

import('Pdfmake');

use Lib\Factory; 
use Lib\Csv;
use Lib\Char;
use Lib\BinFile as B;
//use Core\Base\Library\ReportHeader;
use Core\Base\Library\Config;
use Core\Base\Library\Rate;


class Statement extends ReportHeader{
	
    private $payments,$balance,$count=1;
    
	public $from,$to,$period,$type,$contact,$currency,
	$url="base/reports/show_report/Base/Statement",
	$report="Statement of Account",$_query;
	public static  $query=[
	    "table"=>"records",
	    "alias"=>"records",
	    "join"=>[
	        "join"=>[
	            ["rates","records.rate","rates.id",["records.active"=>1]],
	            ["sources","sources.record","records.id"],
	            ["doctypes","doctypes.id","sources.doc_type"],
	            ["contacts","contacts.id","records.contact"]
	        ]
	    ],
	    "select"=>[
	        //accrued receipt or cash paid out
	        "(case when (records.accrual=1 and doctypes.type='Receipt') or (records.accrual=0 and doctypes.type='Payment') then records.amount*rates.reciprocal else '0' end) as debit",
	        //cash received or accrrued payment
	        "(case when (records.accrual=0 and doctypes.type='Receipt') or (records.accrual=1 and doctypes.type='Payment') then records.amount*rates.reciprocal else '0' end) as credit",
	        //
	        "(case when (records.accrual=1 and doctypes.type='Receipt') or (records.accrual=0 and doctypes.type='Payment') then (records.amount-records.paid)*rates.reciprocal else '0' end) as ndebit",
	        "(case when (records.accrual=0 and doctypes.type='Receipt') or (records.accrual=1 and doctypes.type='Payment') then (records.amount-records.paid)*rates.reciprocal else '0' end) as ncredit",
	        "records.contact","records.date","records.comment as narration","records.ref","records.accrual","doctypes.type","'1' as active","contacts.name",
	        "(case when records.due is null then records.date else records.due end) as due",
                "concat(sources.prefix, ' ',sources.number, '/',year(records.date)) as doc","records.date"
	    ],
	    "order"=>["records.date","ASC"]
	];
	
	
	
	public function filters()
	{
	    $this->add(div("row mt-2")
	        ->attr("data-x-mod","accounts-filter")
	        ->add(div("col-md-4 col-xs-4 mt-1")
	            ->add(\Lib\Combo::init()
	                ->set_meta([
	                    'data-type'=>"input"
	                ])
	                ->set_data(["debtor"=>'Debtor Statement',"creditor"=>'Creditor Statement'])
	                ->set_pattern("(debtor|creditor)")
	                ->set_name('type')
	                ->required()
	                ->html()
                )
            )
	        ->add(div("col-md-4")
	            ->add(\Lib\Combo::init()
	                ->set_pattern("\d+")
	                ->set_model(["Contact","Base"])
	                ->set_meta(['data-type'=>"input"])
	                ->set_name("contact")
	                ->required()
	                ->html()
                )
            )
	        ->add(div("col-md-4")
	            ->add(\Lib\Combo::init()
	                ->set_pattern("\d+")
	                ->set_model(["Currency","Base"])
	                ->set_meta(['data-type'=>"input"])
	                ->set_name("currency")
	                ->required()
	                ->html()
                )
            )
        );
    }
	
    public function dsl($csv=false)
    {
	$com=Factory::init()->get_model("Org","Authentication");
        self::$query=[
	    "table"=>"records",
	    "alias"=>"records",
	    "join"=>[
	        "join"=>[
	            ["rates","records.rate","rates.id",["records.active"=>1]],
	            ["sources","sources.record","records.id"],
	            ["doctypes","doctypes.id","sources.doc_type"],
	            ["contacts","contacts.id","records.contact"]
	        ]
	    ],
	    "select"=>[
	        "(case when (records.accrual=1 and doctypes.type='Receipt') or (records.accrual=0 and doctypes.type='Payment') then records.amount*rates.reciprocal else '0' end) as debit",
	        "(case when (records.accrual=0 and doctypes.type='Receipt') or (records.accrual=1 and doctypes.type='Payment') then records.amount*rates.reciprocal else '0' end) as credit",
	        "(case when (records.accrual=1 and doctypes.type='Receipt') or (records.accrual=0 and doctypes.type='Payment') then (records.amount-records.paid)*rates.reciprocal else '0' end) as ndebit",
	        "(case when (records.accrual=0 and doctypes.type='Receipt') or (records.accrual=1 and doctypes.type='Payment') then (records.amount-records.paid)*rates.reciprocal else '0' end) as ncredit",
	        "records.contact","records.date","records.comment as narration","records.ref","records.accrual","doctypes.type","'1' as active","contacts.name",
	        "(case when records.due is null then records.date else records.due end) as due",
                $com->concat(["'sources.prefix'", ' ',"'sources.number'", "/","'year(records.date)'"])." as doc"
	    ],
	    "order"=>["records.date","ASC"]
	];
        if(!$this->currency){
            $this->currency=Config::init()->DEFAULTCURRENCY;
        }

        $com=Factory::init()->get_model("Org","Authentication");
        $com->fetch([
            "where"=>["db"=>\Lib\Session::get("user_selected_database")]
        ]);
        $mod=Factory::app("Record","Base");
        $this->_query=self::$query;
        if(!$this->from)
        {
            $this->from=date("Y-01-01");
        }
        $data=$mod->read([
            "table"=>$this->_query,
            "alias"=>"records",
            "where"=>[
                "contact"=>$this->contact,
                "date"=>[">=",$this->from]
            ]
        ]);//x(qd(),8);
        $this->grid=grid(14);
        //$this->csv=Csv::init(Char::gen(4));
        $this->csv=Csv::init(str_replace(" ", "-", $mod->rep()));
        $this->csv->add("DATE");
        $this->csv->add("NARRATION");
        $this->csv->add("REF");
        $this->csv->add("SOURCE");
        $this->csv->add("DEBIT");
        $this->csv->add("CREDIT");
        $this->csv->add("BALANCE");
        //Create Header
        $this->head($com);
        $this->blank();
        $this->client();
        $this->blank();
        $this->tb($data);
        $this->blank();
        $this->ageTitle();
        $this->age();
        $this->ageBase();
        $this->blank();
        if($csv==707)
        {
            $this->csv->download();
        }
        return [
            "content"=>[
                $this->grid->rep()," ",
                $this->bankbare()
            ],
            "styles"=> [
                "header"=> [
                    "fontSize"=> 10,
                    "bold"=>"true",
                    "fillColor"=>"#DCDCDC"
                ],
                "anotherStyle"=>[
                    "italics"=> true,
                    "alignment"=> 'right'
                ]
            ],
            "images"=>[
                "logo"=>$com->logo
            ]/*,
            "background"=>[
                "image"=>"logo",
                "width"=> 200,"opacity"=>0.4,
                "absolutePosition"=> ["x"=> 170, "y"=>350]
            ]*/
        ];
        //x($data);x(qd(),9);
    }
	
    protected function bankbare(){
        return ["columns"=>[$this->bank()],"columnGap"=>10];
    }
	public function firstRow($data)
	{
	    $mod=Factory::app("Record","Base");
	    $data=$mod->select([
	        "table"=>$this->_query,
	        "alias"=>"records",
	        "where"=>[
	            "contact"=>$this->contact,"date"=>["<",$this->from]
	        ],
	        "select"=>[
	            "sum(debit) as debit",
	            "sum(credit) as credit"
	        ]
	    ]);
	    $debit=isset($data[0])&&isset($data[0]["debit"])&&is_numeric($data[0]["debit"])?currency($data[0]["debit"]):0;
	    $credit=isset($data[0])&&isset($data[0]["credit"])&&is_numeric($data[0]["credit"])?currency($data[0]["credit"]):0;
	    //x([$debit,$credit],8);
	    //x($data);x(qd(),7);
	    $this->tr([
	        "date"=>$this->from,
	        "doc"=>"",
	        "ref"=>"b/f",
	        "narration"=>"balance before ".date("d-m-y",strtotime($this->from)),
	        "name"=>"",
	        "debit"=>$debit,
	        "credit"=>$credit
	    ]);
	    
	}
	
		
	public function th()
	{
	    $this->grid->row();
	    $this->grid->cell("DATE",1,[
	        "border"=>[0,0,0,0],
	        "fontSize"=>8,
	        "bold"=>"true",
	        "fillColor"=>"#EAEAEA"
	    ]);
	    $this->grid->cell("REF",2,[
	        "border"=>[0,0,0,0],
	        "fontSize"=>8,
	        "bold"=>"true",
	        "fillColor"=>"#EAEAEA"
	    ]);
	    $this->grid->cell("SOURCE",2,[
	        "border"=>[0,0,0,0],
	        "fontSize"=>8,
	        "bold"=>"true",
	        "fillColor"=>"#EAEAEA"
	    ]);
	    $this->grid->cell("NARRATION",3,[
	        "border"=>[0,0,0,0],
	        "fontSize"=>8,
	        "bold"=>"true",
	        "fillColor"=>"#EAEAEA"
	    ]);
	    $this->grid->cell("DEBIT",2,[
	        "border"=>[0,0,0,0],
	        "fontSize"=>8,
	        "bold"=>"true",
	        "alignment"=>"right",
	        "fillColor"=>"#EAEAEA"
	    ]);
	    $this->grid->cell("CREDIT",2,[
	        "border"=>[0,0,0,0],
	        "fontSize"=>8,
	        "bold"=>"true",
	        "alignment"=>"right",
	        "fillColor"=>"#EAEAEA"
	    ]);
	    $this->grid->cell("BALANCE",2,[
	        "border"=>[0,0,0,0],
	        "fontSize"=>8,
	        "bold"=>"true",
	        "alignment"=>"right",
	        "fillColor"=>"#EAEAEA"
	    ]);
	}
	
	public function tr($data)
	{
	    $color=$this->count%2?"#FAFAFA":"#FFFFFF";
	    $factor=Rate::init()->near($this->currency);
	    $deb=$factor*(is_numeric($data["debit"])?$data["debit"]:0);
	    $cred=$factor*(is_numeric($data["credit"])?$data["credit"]:0);//x([$factor,$cred,$deb],9);
        if($this->type=="creditor")
	    {
	        //$temp=$deb;
	        //$deb=$cred;
	        //$cred=$temp;
	        $this->payments+=$deb?:0;
	        $this->balance-=$deb?:0;
	        $this->balance+=$cred?:0;
	    }
	    else{
	        $this->payments+=$cred?:0;
	        $this->balance+=$deb?:0;
	        $this->balance-=$cred?:0;
	    }
	    //x($data);x([$deb,$cred],7);
	    $this->grid->row();
	    $this->csv->line();
	    $this->grid->cell(date("d-m-y",strtotime($data["date"])),1,[
	        "border"=>[0,0,0,0],
	        "fontSize"=>6.5,
	        "fillColor"=>$color
	    ]);
            $this->grid->cell($data["doc"],2,[
	        "border"=>[0,0,0,0],
	        "fontSize"=>7,
	        "fillColor"=>$color
	    ]);
	    $this->csv->add($data["doc"]);
	    
	    $this->grid->cell($data["ref"],2,[
	        "border"=>[0,0,0,0],
	        "fontSize"=>7,
	        "fillColor"=>$color
	    ]);
	    $this->csv->add($data["ref"]);
	    $this->csv->add($data["date"]);
	    $this->grid->cell($data["narration"],3,[
	        "border"=>[0,0,0,0],
	        "fontSize"=>7,
	        "fillColor"=>$color
	    ]);
	    $this->csv->add($data["narration"]);
	    $this->grid->cell($deb>0?num($deb):" ",2,[
	        "border"=>[0,0,0,0],
	        "fontSize"=>7,
	        "alignment"=>"right",
	        "fillColor"=>$color
	    ]);
	    $this->csv->add($deb>0?currency($deb):" ");
	    $this->grid->cell($cred>0?num($cred):" ",2,[
	        "border"=>[0,0,0,0],
	        "fontSize"=>7,
	        "alignment"=>"right",
	        "fillColor"=>$color
	    ]);
	    $this->csv->add($cred>0?currency($cred):" ");
	    $this->grid->cell(num($this->balance),2,[
	        "border"=>[0,0,0,0],
	        "fontSize"=>7,
	        "alignment"=>"right",
	        "fillColor"=>$color
	    ]);
	    $this->count++;
	    $this->csv->add(currency($this->balance));
	}
	
	private function ageTitle()
	{
	    $this->grid->row();
	    $this->grid->cell("90+ DAYS",2,[
	        "border"=>[1,1,1,1],
	        "fontSize"=>8,
	        "bold"=>"true",
	        "fillColor"=>"#EAEAEA"
	    ]);
	    $this->grid->cell("90 DAYS",2,[
	        "border"=>[1,1,1,1],
	        "fontSize"=>8,
	        "bold"=>"true",
	        "fillColor"=>"#EAEAEA"
	    ]);
	    $this->grid->cell("60 DAYS",2,[
	        "border"=>[1,1,1,1],
	        "fontSize"=>8,
	        "bold"=>"true",
	        "alignment"=>"right",
	        "fillColor"=>"#EAEAEA"
	    ]);
	    $this->grid->cell("CURRENT",2,[
	        "border"=>[1,1,1,1],
	        "fontSize"=>8,
	        "bold"=>"true",
	        "alignment"=>"right",
	        "fillColor"=>"#EAEAEA"
	    ]);
	    $this->grid->cell("BALANCE ACCRUED",3,[
	        "border"=>[1,1,1,1],
	        "fontSize"=>8,
	        "bold"=>"true",
	        "alignment"=>"right",
	        "fillColor"=>"#EAEAEA"
	    ]);
	    $this->grid->cell(num($this->balance+$this->payments),3,[
	        "border"=>[1,1,1,1],
	        "fontSize"=>8,
	        "alignment"=>"right",
	        "fillColor"=>"#FAFAFA"
	    ]);
	}
	private function age(){
	    $age=new AgeSupport();
	    $age->set_contact($this->contact);
	    $age->set_type($this->type);
	    $this->grid->row();
	    //x($age->aged30()+$age->aged30plus(),8);
	    $this->grid->cell(num($age->aged90plus()),2,[
	        "border"=>[1,1,1,1],
	        "fontSize"=>8,
	        "bold"=>"true",
	        "fillColor"=>"#EAEAEA"
	    ]);//x(qd(),9);
	    $this->grid->cell(num($age->aged90()),2,[
	        "border"=>[1,1,1,1],
	        "fontSize"=>8,
	        "bold"=>"true",
	        "fillColor"=>"#EAEAEA"
	    ]);
	    $this->grid->cell(num($age->aged60()),2,[
	        "border"=>[1,1,1,1],
	        "fontSize"=>8,
	        "bold"=>"true",
	        "alignment"=>"right",
	        "fillColor"=>"#EAEAEA"
	    ]);
	    $this->grid->cell(num($age->aged30()),2,[
	        "border"=>[1,1,1,1],
	        "fontSize"=>8,
	        "bold"=>"true",
	        "alignment"=>"right",
	        "fillColor"=>"#EAEAEA"
	    ]);
	    $this->grid->cell("AMOUNT PAID",3,[
	        "border"=>[1,1,1,1],
	        "fontSize"=>8,
	        "bold"=>"true",
	        "alignment"=>"right",
	        "fillColor"=>"#EAEAEA"
	    ]);
	    $this->grid->cell(num($this->payments),3,[
	        "border"=>[1,1,1,1],
	        "fontSize"=>8,
	        "alignment"=>"right",
	        "fillColor"=>"#FAFAFA"
	    ]);
	}
	protected function bank(){
        $bank = Factory::app("CashAccount","Base");
        $doc = $bank->select([
            "join"=>[
                "join"=>[
                    ["currencies c","c.id","cashaccounts.currency"]
                ]
            ],
            "select"=>["cashaccounts.name","company","branch","number","c.name as currency"],
            "where"=>["type"=>"Bank"]
        ]);
        $table = ["table"=>["widths"=>["*","15%","20%","20%","20%"],"body"=>[
            [["text"=>"Name","fontSize"=>7],["text"=>"Bank","fontSize"=>7],
                ["text"=>"Branch","fontSize"=>7],["text"=>"Account","fontSize"=>7],["text"=>"Type","fontSize"=>7]
            ]
        ]]];
        foreach($doc as $row){
            $table["table"]["body"][] = [
                ["text"=>$row["name"],"fontSize"=>6],
                ["text"=>$row["company"],"fontSize"=>6],
                ["text"=>$row["branch"],"fontSize"=>6],
                ["text"=>$row["number"] ,"fontSize"=>6],
                ["text"=>$row["currency"] ,"fontSize"=>6]
            ];
        }//x($table,9);
        return $table;
    }
    
	private function ageBase(){
	    $this->grid->row();
	    $this->grid->cell("PLEASE PAY BALANCE DUE",8,[
	        "border"=>[1,1,1,1],
	        "fontSize"=>9,
	        "bold"=>"true",
	        "fillColor"=>"#FAFAFA"
	    ]);
	    $this->grid->cell("BALANCE DUE ",3,[
	        "border"=>[1,1,1,1],
	        "fontSize"=>9,
	        "alignment"=>"right",
	        "fillColor"=>"#EAEAEA"
	    ]);
	    $this->grid->cell(num($this->balance),3,[
	        "border"=>[1,1,1,1],
	        "fontSize"=>9,
	        "alignment"=>"right",
	        "bold"=>"true",
	        "fillColor"=>"#FAFAFA"
	    ]);
	}
}