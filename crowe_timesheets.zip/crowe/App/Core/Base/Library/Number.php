<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Base\Library;

/**
 * Description of Number
 *
 * @author Hp
 */
use Lib\Factory as LF;

class Number{
	
    use \Lib\Init;
    
    public 
        $scheme="asc",
        $init=0,
        $object,
        $field,
        $value,
        $group,
        $date;
        
    public static function next($object,$field="number",$date="date",$group=null,$value=null){
        $numObj = new self($object,$field,$date,$group,$value);
        return $numObj->getNext();
    }

    public function __construct($object,$field="number",$date=false,$group=null,$value=null){
        $this->group=$group;
        $this->object=$object;
        $this->date=$date;
        $this->field=$field;
        $this->value=$value;
    }
	
    public function getNext(){
        $mod=[
            "select"=>$this->scheme=="asc"?["max(".$this->field.") as num"]:["min(".$this->field.") as num"]
        ];
        if($this->date&&isset($this->object->_struct_[$this->date]))
        {
            $mod["where"][$this->date]=["between"=>[date("Y-01-01"),date("Y-12-31")]];
        }
        if($this->group&&$this->value)
        {
            $mod["where"][$this->group]=$this->value;
        }
        $nums=$this->object->select($mod);//x(qd(),8);
        if(!empty($nums)&&isset($nums[0]["num"])&&is_numeric($nums[0]["num"])){
            $u = $nums[0]["num"];//x($nums,8);
            return $this->scheme=="asc"?$u+1:$u-1;
        }//x('non',9);
        return $this->init?:1;
    }
}

