<?php
namespace Core\Base\Library;

class ContactsView extends ContacttypesView
{
    use \Lib\Init;
    
    public function form()
    {
        return new Contact();
    }
    public
            $_title="Contacts",
            $url="base/contacts/create",
            $types="Contacts",
            $type="Contact";
            
   
}