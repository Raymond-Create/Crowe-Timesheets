<?php
namespace Core\Base\Library;

use Core\Base\Library\AbView;


class SettlementsView extends AbView
{
    use \Lib\Init;
    
    public function form(){
        return new Settlement();
    }
    
    public
    		$_title="Settlements",
    		$url="base/settlements/create",
			$types="Settlements",
            $type="Settlement";
    
}