<?php

namespace Core\Base\Library;

class Logo
{
	
    use \Lib\Init;
    
    public function html(){
        $card=div('card')
            ->add(div('card-header')
                ->add(i('fa fa-file-img'))
                ->add(h4()->add(' Company Logo'))				
            )
            ->add(div('card-body')
                ->add(div('row')
                    ->add($this->preview())
                    ->add($this->form())
                )
            );
        return div("container")
            ->add(div('row')
            ->attr('data-x-mod','com-logo')
            ->add(d1212()->add($card)));
    }

    private function preview(){
        $col = div("col-xs-12 col-md-6");
        $_c1 = div("col-xs-12 col-md-12");
        $_c2 = div("col-xs-12 col-md-12");
        $_c1->add(label("col-sm-12 col-form-label")->add("Preview"));
        $_c2->add(div("preview"));
        return $col->add($_c1)->add($_c2);
    }
    private function form(){
        $col = div("col-xs-12 col-md-6");
        $_c1 = div("col-xs-12 col-md-12");
        $_c2 = div("col-xs-12 col-md-12");
        $_c3 = div("col-xs-12 col-md-12");
        $input = input('custom-file-input field')
            ->attr("type","file");
        $div=div("custom-file");
    	$div->add($input)->add(label("custom-file-label")->add("Browse..."));
		$_c1->add(label("col-sm-12 col-form-label")->add("Upload"));
        $_c2->add($div);
        //$_c2->add($input);
        $_c3->add(button("btn btn-primary submit btn-block")->add(span("fa fa-cloud-upload-alt")->add(" Submit")));
        return $col->add($_c1)->add($_c2)->add($_c3);
    }
}