<?php

namespace Core\Base\Library;
use Core\Authentication\Library\User;

class AuditTrail
{
	
    public function __construct(Trail $model)
    {
        $this->model=$model;
    }

    private
        $action,
        $model,
        $table,
        $crit;
	
    public static function delete($model,$crit,$table)
    {
        if(is_array($crit))
        {
            $i=false;
            foreach($crit as $key)
            {	
                $i=$i||self::delete($model,$key,$table);
            }
            return $i;
        }
        return self::add(
            $crit,"remove",
            $table?:$model->table()
        );
    }
    
    public static function update($model,$crit,$table)
    {
        if(is_array($crit))
        {
            $i=false;
            foreach($crit as $key)
            {	
                $i=$i||self::update($model,$key,$table);
            }
            return $i;
        }
        return self::add(
            $crit,"modify",
            $table?:$model->table()
        );
    }
    
    public static function create($model,$crit,$table)
    {
        if(is_array($crit))
        {
            $i=false;
            foreach($crit as $key)
            {	
                $i=$i||self::create($model,$key,$table);
            }
            return $i;
        }
        return self::add(
            $crit,"insert",
            $table?:$model->table()
        ); 
    }
	
    public static function cancel($model,$crit,$table)
    {
        return self::add(
            $crit,"cancel",
            $table?:$model->table()
        ); 
    }
    public static function decline($model,$crit,$table)
    {
        return self::add(
            $crit,"decline",
            $table?:$model->table()
        ); 
    }
    
    public static function request($model,$crit,$table)
    {
        return self::add(
            $crit,"request",
            $table?:$model->table()
        ); 
    }
    
    public static  function add($id,$type,$table)
    {
        if(!AUDIT_TRAIL)
        {
            //return false;
        }
        global $AGENT,$QUERY;
        $obj= \Lib\TableFixer::init("Trail","Base");
        $device= \Lib\TableFixer::init("Sys\Classes\Device");
        $device->fetch([
            "device" => $AGENT->device(),
            "platform" => $AGENT->os(),
            "browser" => $AGENT->browser(),
            "agent_string" => $AGENT->id()
        ]);
        if(!$device->id)
        {
            $device->device = $AGENT->device();
            $device->platform = $AGENT->os();
            $device->browser = $AGENT->browser();
            $device->agent_string = $AGENT->id();
            $device->id=$device->save();
        }
        $obj->ip=ip();
        $obj->record=$id;
        $obj->type=$table;
        $obj->action=$type;
        $obj->request=$QUERY;
        $obj->user=User::id();
        $obj->device=$device->id;
        $obj->session=session_id();
        $obj->action_time=date("Y-m-d H:i:s");
        $obj->finger= \Lib\Session::get("finger")?:"0";
        return $obj->save(); 
    }
    
}