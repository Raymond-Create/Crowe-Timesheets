<?php

namespace Core\Base\Library;

use Core\Authentication\Library\User;

class AbView extends \Lib\AbViewPlain{
    
    public $url,$type,$types,$_btn="btn",$script,$div;
    
    public function body()
    {
        //add a list
        $this->set($this->types." List",$this->mainView->html(),"list");
        //add a form
        $form=$this->form();
        //x($form,8);
        if($form && method_exists($form,"set_url")){
            $form->set_url($this->url);
            $this->set("Update ".$this->type,$form->html(),"update");
        }else{
            $this->set("Update ".$this->type,$form,"update");
        }
        //x($form,7);
        //add a report
        $report=$this->report();
        if($report){
            $this->set($this->types . " Report",$report->html(),"report");
        }
        $this->set("PDF Viewer",PdfView::init()->html(),"viewer");
    }
    
    private function set($title,$html,$link)
    {
        $div=div(C121212." m-0 p-0");
        $div->add(div(C121212." m-0 p-0")->add($this->tabs()));
        $div->add(div(C121212." m-0 p-0")->add($html));
        $this->view->add($title,$div,$link);
    }
    
    public function splash()
    {
    			$btn=$this->_btn;
    			$this->div=div("col-xs-6 col-lg-8 col-sm-8");
        if($this->script)
        {
        	$this->div->attr("data-x-mod",$this->script);
        }  
        $this->div->add($this->$btn([
        	"List","init btn-".OTHER,"btn-add","list"
        ]));   
        if($this->report())  
        {
            $this->div->add($this->$btn([
                    "Report","btn-secondary",
                    "btn-add","report"
            ]));   
        }
        if($this->form())  
        {
            $this->div->add($this->$btn([
                    "New","btn-".SUBMIT,
                    "btn-add","update"
            ]));   
        }
        $this->other_buttons();  
        return div("row")
        ->add(div("col-xs-6 col-lg-4 col-sm-4")
            ->add(h2()->add($this->_title))
        )
        ->add($this->div);
            
    }
    
    
    public function form(){
        return false;
    }
    
    public function report(){
        return false;
    }
    
    public function btn($array)
    {
    		$class="btn btn-sm float-right x-b mr-2";
    		//btn-primary
    		if(isset($array["1"]))
    		{
    			$class.=" ".$array[1];
    		}
    		//btn-search
    		if(isset($array["2"]))
    		{
    			$class.=" ".$array[2];
    		}
    		$btn=button($class)->add($array[0]);
    		$btn->attr("type","button");
    		//btn-search
    		if(isset($array["3"]))
    		{
    			$btn->attr("data-value",$array["3"]);
    		}
    		return $btn;
    }
    
    public function other_buttons()
    {//x($this,9);
    	if(isset($this->drop)&& is_array($this->drop))
        {
            $div=div("dropdown")
            ->add(button("btn btn-light dropdown-toggle btn-sm float-right mr-2")
                ->attr([
                    "type"=>"button",
                    "id"=>"dropdownMenuButton",
                    "data-toggle"=>"dropdown",
                    "aria-haspopup"=>"true",
                    "aria-expanded"=>"false"
                ])
                ->add("Go To")
            );
            $menu=div("dropdown-menu")
                ->attr(
                    "aria-labelledby","dropdownMenuButton"
                );
            foreach ($this->drop as $key => $value) {
                $val=$this->url_access($value);
                if(!$val){continue;}
                $class="dropdown-item";
                $class.=($key== $this->types)?" active":"";
                $menu->add(a($class)
                    ->attr(["href"=>"#","data-value"=>$val])
                    ->add($key)
                );    
            }
            
            $this->div->add($div->add($menu));
        }
    }
    
    public function tabs(){
        if(isset($this->drop)&& is_array($this->drop))
       {
            $tabbed=ul("nav nav-tabs");
            foreach ($this->drop as $key => $value) {
                $val=$this->url_access($value);
                if(!$val){continue;}
                $tab=li("nav-item");
                $class="nav-link reload-link";
                $class.=($key== $this->types)?" active":"";
                $tab->add(a($class)
                    ->attr(["href"=>"#","data-value"=>$val])
                    ->add($key)
                );  
               $tabbed->add($tab);
            } 
            return $tabbed;
        }
        return '';
    }
    
    private function url_access($value)
    {
        if(is_string($value))
        {
            return User::hasUrlAccess($value)?$value:false;
        }
        if(!is_array($value))
        {
            return false;
        }            
        if(isset($value[1]))
        {
            
            $bool=false;
            foreach($value[1] as $role)
            {
                $test=User::is($role);
                $bool=$bool||$test;
            }
            return $bool||User::isAdmin()?$value[0]:false;
        }
        return User::hasUrlAccess($value[0])?$value[0]:false;
    }
}
/*
 <ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="#">Active</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Link</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Link</a>
  </li>
  <li class="nav-item">
    <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
  </li>
</ul> 
 */