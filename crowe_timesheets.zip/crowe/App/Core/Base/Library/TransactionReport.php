<?php

namespace Core\Base\Library;

use Core\Base\Library\Rate;
use Lib\Factory as Fa;
use Lib\Char;
use Lib\Csv;

class TransactionReport extends \Core\Base\Library\AbstractReport{
	
    public $url="base/reports/show_report/Base/TransactionReport";
    public $title="Transaction Report";
    
    private function noval($index)
    {
        return !isset($this->post[$index])||!$this->post[$index];
    }
    public function content($id=null){
        $this->InternalCompanyReportDetails();
        $this->contentAdd(' ');
        $this->contentAdd(' ');
        $this->contentAdd(' ');
        $mod=Fa::app("Record","Base");
        $filterOld=[
            "join"=>[
                "join"=>[//sint_2
                    ["sources s","records.id","s.record"],
                    ["doctypes dt","dt.id","s.doc_type"],
                    ["docs d","d.id","dt.doc"],
                    ["categories c","s.category","c.id"],
                    ["rates r","records.rate","r.id"],
                    ["locations l","records.location","l.id"]
                ]
            ],
            "select"=>[
                "records.date","l.name as location","d.name as doc",
                "dt.name as doctype","c.name as category","records.amount*r.reciprocal as amount"
            ]
        ];
        if(!$this->noval("location")&&$this->noval("doc")){
            $filterOld["select"]=[
                "'' as date","l.name as location","d.name as doc",
                "' ' as doctype","' ' as category","sum(records.amount*r.reciprocal) as amount" 
            ];
            $filterOld["group"]=["d.id"];
        }
        if(!$this->noval("location")&&!$this->noval("doc")&&$this->noval("doctype")){
            $filterOld["select"]=[
                "'' as date","l.name as location","d.name as doc",
                "d.name as doctype","' ' as category","sum(records.amount*r.reciprocal) as amount" 
            ];
            $filterOld["group"]=["dt.id"];
        }
        if(!$this->noval("location")&&!$this->noval("doc")&&!$this->noval("doctype")&&$this->noval("category")){
            $filterOld["select"]=[
                "'' as date","l.name as location","d.name as doc",
                "d.name as doctype","c.name as category","sum(records.amount*r.reciprocal) as amount" 
            ];
            $filterOld["group"]=["c.id"];
        }
        if(!$this->noval("location")){
            $filterOld["where"]["l.id"]=$this->post["location"];
        }
        if(!$this->noval("doctype")){
            $filterOld["where"]["dt.id"]=$this->post["doctype"];
        }
        if(!$this->noval("doc")){
            $filterOld["where"]["d.id"]=$this->post["doc"];
        }
        if(!$this->noval("category")){
            $filterOld["where"]["c.id"]=$this->post["category"];
        }
        $queryAST=$this->setBounds($filterOld,'records.date');
        
        $data=$mod->read($queryAST);
        $amount=0;$dark="#DCDCDC";$light="#ECECEC";$i=1;
        $this->csv=Csv::init(Char::gen(4));
        $grid=Grid();
        $grid->row();
        $grid->cell("Date",2,[
            'border'=>[0,0,0,1]
        ]);
        $this->csv->add("DATE");
        $grid->cell("Business",2,[
            'border'=>[0,0,0,1]
        ]);
        $this->csv->add("BUSINESS");
        $grid->cell("Document",2,[
            'border'=>[0,0,0,1]
        ]);
        $this->csv->add("DOCUMENT");
        $grid->cell("Type",2,[
            'border'=>[0,0,0,1]
        ]);
        $this->csv->add("TYPE");
        $grid->cell("Category",2,[
            'border'=>[0,0,0,1]
        ]);
        $this->csv->add("CATEGORY");
        $grid->cell("Amount",2,[
            'border'=>[0,0,0,1]
        ]);
        $this->csv->add("AMOUNT");
        foreach($data as $row){
            $grid->row();
            $this->csv->line();
            $factor=Rate::init()->near($this->post["currency"]);
	    $amnt=$factor*(is_numeric($row["amount"])?$row["amount"]:0);
            $amount+=$amnt;
            $grid->cell($row['date'],2,[
                'border'=>[0,0,0,0],
                "fontSize"=> 10,
                //"bold"=>"true",
                "fillColor"=>$i%2?$dark:$light
            ]);$this->csv->add($row["date"]);
            $grid->cell($row['location'],2,[
                'border'=>[0,0,0,0],
                "fontSize"=> 10,
                //"bold"=>"true",
                "fillColor"=>$i%2?$dark:$light
            ]);$this->csv->add($row["location"]);
            $grid->cell($row['doc'],2,[
                'border'=>[0,0,0,0],
                "fontSize"=> 10,
                //"bold"=>"true",
                "fillColor"=>$i%2?$dark:$light
            ]);$this->csv->add($row["doc"]);
            $grid->cell($row['doctype'],2,[
                'border'=>[0,0,0,0],
                "fontSize"=> 10,
                //"bold"=>"true",
                "fillColor"=>$i%2?$dark:$light
            ]);$this->csv->add($row["doctype"]);
            $grid->cell($row['category'],2,[
                'border'=>[0,0,0,0],
                "fontSize"=> 10,
                //"bold"=>"true",
                "fillColor"=>$i%2?$dark:$light
            ]);$this->csv->add($row["category"]);
            $grid->cell(num($amnt),2,[
                'border'=>[0,0,0,0],
                "fontSize"=> 10,
                //"bold"=>"true",
                "fillColor"=>$i%2?$dark:$light
            ]);
            $this->csv->add($amnt);$i++;
        }
        $grid->row();
        $this->csv->line();
        $grid->cell("TOTAL",10,[
            'border'=>[0,1,0,0],
            "bold"=>"true",
            "fillColor"=>"#DCDCDC"
        ]);
        $this->csv->add("TOTAL");
        $this->csv->add(" ");
        $this->csv->add(" ");
        $this->csv->add(" ");
        $this->csv->add(" ");
        $grid->cell(num($amount),2,[
            'border'=>[0,1,0,0],
            "bold"=>"true",
            "fillColor"=>"#DCDCDC"
        ]);
        $this->csv->add($amount);
        $this->contentAdd($grid->rep());
    }
    
    public function controls(){
        return div("row mt-2")
            ->attr("data-x-mod","doc-pop")
            ->add(div("col-md-6 col-xs-12 mt-1")
                ->add(\Lib\Combo::init()
                    ->set_meta(['data-type'=>"input"])
                    ->required()
                    ->set_name('currency')
                    ->set_model(['Currency','Base'])
                    ->set_placeholder('Select Currency')
                    ->html()
                )
            )  
            ->add(div("col-md-6 col-xs-12 mt-1")
                ->add(\Lib\Combo::init()
                    ->set_meta(['data-type'=>"input"])
                    ->set_name('location')
                    ->set_filter([
                        "where"=>["type"=>"BusinessUnit"]
                    ])
                    ->set_model(['Location','Base'])
                    ->set_placeholder('Select Business')
                    ->html()
                )
            ) 
            ->add(div("col-md-4 col-xs-12 mt-1")
                ->add(\Lib\Combo::init()
                    ->set_name('doc')
                    ->set_model(['Doc','Base'])
                    ->set_meta(['data-type'=>"input"])
                    ->set_placeholder('Select Document')
                    ->html()
                )
            )
            ->add(div("col-md-4 col-xs-12 mt-1")
                ->add(\Lib\Combo::init()
                    ->set_meta(['data-type'=>"input"])
                    ->set_name('doctype')
                    ->set_model(['DocType','Base'])
                    ->set_placeholder('Select Document Type')
                    ->html()
                )
            )    
            ->add(div("col-md-4 col-xs-12 mt-1")
                ->add(\Lib\Combo::init()
                    ->set_meta(['data-type'=>"input"])
                    ->set_name('category')
                    ->set_model(['Category','Base'])
                    ->set_placeholder('Select Category')
                    ->html()
                )
            );
    }
   
}