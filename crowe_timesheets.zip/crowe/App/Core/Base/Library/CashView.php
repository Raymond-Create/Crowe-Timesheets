<?php
namespace Core\Base\Library;

use Core\Base\Library\AbView;


class CashView extends AbView
{
    use \Lib\Init;
    
    public function form()
    {
        return new Settlement();
    }
    
    public function splash()
    {
        $div=div("col-xs-6 col-lg-6 col-sm-6")
            ->add(button("btn btn-sm btn-light btn-add float-right x-b init")
                ->add("List")
                ->attr(["data-value"=>"list","type"=>"button"])
            )
            ->add(button("btn btn-sm btn-danger btn-add float-right x-b mr-2")
                ->add("PDF View")
                ->attr(["data-value"=>"viewer","type"=>"button","style"=>"display:none"])
            );
        if($this->report()){
            $div->add(button("btn btn-sm btn-secondary btn-add float-right x-b mr-2")
                ->add("Cash Book Report")
                ->attr(["data-value"=>"report","type"=>"button"])
            ); 
        }
        if($this->form()){
            $div->add(button("btn btn-sm btn-primary btn-add float-right x-b mr-2")
                ->add("New")
                ->attr(["data-value"=>"update","type"=>"button"])
                );
        }
        return div("row")
        ->add(div("col-xs-6 col-lg-6 col-sm-6")
            ->add(h2()->add($this->_title))
        )
        ->add($div);
            
    }
    
    public function report(){
    		return new CashBook();
    }
    
    public
    		$_title="Cash",
    		$open_title="Cash",
    		$url="base/cash/create",
			$types="Cash",
            $type="Cash";
    
}
