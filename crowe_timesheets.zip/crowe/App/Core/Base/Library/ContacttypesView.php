<?php
namespace Core\Base\Library;

use Core\Base\Library\AbView;


class ContacttypesView extends AbView
{
    use \Lib\Init;
    
    public
        $_title="Contact Types",
        //$url="base/contacts/create",
        $types="Contact Types",
        $type="Contact Type",
        $drop=[
            "Contact Types"=>"base/contacttypes",
            "Contacts"=>"base/contacts"
        ];
            
   
}