<?php


namespace Core\Base\Library;
use Lib\Factory;

abstract class ReportHeader{

    public $data=[],$grid,$csv,$from,$to,$period,$contact,$currency;
    
    public function __construct(){//x($this,8);
        Periods::init()->update_periods();
        $this->header();
    }
    
    public function set_post($post)
    {
        $this->data=$post;
        if(isset($post['from'])){
            $this->set_dates($post['from'],null);
        }
        if(isset($post['to'])){
            $this->set_dates(null,$post['to']);
        }
        if(isset($post['period'])){
            $this->set_period($post['period']);
        }
        if(isset($post['contact'])){
            $this->set_contact($post['contact']);
        }
        if(isset($post['type'])){
            $this->set_type($post['type']);
        }
        if(isset($post['currency'])){
            $this->set_currency($post['currency']);
        }
    }
    
    public function set_currency($currency)
    {
        $this->currency=$currency;
    }
    
    public function set_contact($contact)
    {
        $this->contact=$contact;
    }
    
    public function set_type($type)
    {//x($type,8);
        $this->type=strtolower($type)=="creditor"?"creditor":"debtor";
    }
    
    public function set_dates($date0=null,$date1=null)
    {
        if($this->is_date($date0))
        {
            $this->from=$date0;
        }
        if($this->is_date($date1))
        {
            $this->to=$date1;
        }
    }
    
    public function set_period($period)
    {
        $mod=Factory::app("Period","Base");
        $mod->get($period);
        if($mod->id){
            $this->period=$mod->id;
            $this->set_dates($mod->start,$mod->finish);
        }
    }

    public function add($tag){
        $this->row->add($tag);
    }

    public function html(){
        $row = div("cont")
            ->attr("data-x-mod","report-viewer")
            ->attr("style","width:100%");
        $this->row=div("card-body")
            ->add($this->header());
        $this->filters();
        $this->viewer();
        return $row->add(
            div("card")
                ->add(div("card-header")
                    ->add(h4("float-left")->add($this->report))      
                ) 
                ->add($this->row)
        );
    }
    
    public function header(){
        return $this->_filters();
    }
	
    public function _filters(){
        $row=div("row");
        $col1=d124();
        $col2=d124();
        $col3=d124();
        $col4=d124();
        $col5=d124();
        $col1->add(select('form-control')
            ->attr('name','method')
            ->add(option(['value'=>'','text'=>'Select Date Method']))
            ->add(option(['value'=>'period','text'=>'Period']))
            ->add(option(['value'=>'range','text'=>'Range']))
        );
        $col2->add(\Lib\BootSelect::init()
            ->set_name('baseperiod')
            ->set_model(['Base','Base'])
            ->set_placeholder('Select Period Base')
            ->html()
        );
        $col3->add(\Lib\BootSelect::init()
            ->set_name('period')
            ->set_model(['Period','Base'])
            ->set_placeholder('Select Period')
            ->set_filter(['order'=>['start','DESC']])
            ->html()
        );
        $col4->add(div('input-group')
            ->add(div('input-group-addon input-group-prepend')
                ->add(div('input-group-text')
                    ->add("From")    
                )    
            )
            ->add(input('form-control')
                ->attr("name","from")  
                ->attr("data-addon","datepicker")  
                ->attr("placeholder","Report From")  
            )
        );
        $col5->add(div('input-group')
            ->add(div('input-group-addon input-group-prepend')
                ->add(div('input-group-text')
                    ->add("To")    
                )    
            )
            ->add(input('form-control')
                ->attr("name","to")  
                ->attr("data-addon","datepicker")  
                ->attr("placeholder","Report To")  
            )
        );
        return $row->add($col1)->add($col2)->add($col3)->add($col4)->add($col5);
    }
	
    public $row;

    public function viewer(){
        $row = div([
            "class"=>"row index mt-2",
            "data-url"=>$this->url
        ]);
        $col =div("col-md-8 col-lg-8 col-xs-8");
        $col_offset = div("col-md-2 col-lg-2 col-xs-2");
        $this->add($row->add($col_offset)->add($col->add(button([
            "text"=>"Generate Report",
            "class"=>"btn btn-primary  generate-btn form-control"
        ]))));
        $this->add(div("row mt-5")->add(div("col-xs-12 col-md-12 iframe")));
    }
    
    public 
        $url,
        $company,
        $period_id,
        $beginning,
        $ending;
    
    abstract public function dsl($data);

    abstract public function filters();
    public function is_date($date)
    {
        return $this->isDate($date);
    }	
    public function isDate($date){
        return preg_match(DATE_RGX,$date);
    }
	
    public function nm($num){
        return number_format($num, 2);
    }
  
    public function title(){
        $string = $this->report ." for ".$this->company." for period ".
            $this->period . ", beginning on (".$this->beginning.
            ") and ending on (".$this->ending.")";
        return ["columns"=>[[
            "text"=>$string,
            "alignment"=>"center",
            
        ]]];
    }
    public function dates($crit,$data,$field){//x($data,9);
        if(!isset($data["period"])&&!isset($data["from"])&&!isset($data["to"]))
        {
            return $crit;
        }
        $p=Factory::app("Period","Base");
        if($data["period"]&&$p->struct()[$p->pk()]->isValid($data["period"])&&$data['date_method']!="range"){
            $p->get($data["period"]);
            if(!$p->isEmpty()){
                $data['from'] = $p->start;
                $data['to'] = $p->finish;
                $this->period = $p->name;
                $this->period_id = $p->id;
            }
        }
        $this->beginning = $data['from'];
        $this->ending = $data['to'];
        if(!$this->isDate($data["from"]) && !$this->isDate($data["to"])){
            return $crit;
        }
        $crit["where"] = isset($crit["where"])?$crit["where"]:[];
        if($this->isDate($data["from"]) && !$this->isDate($data["to"])){
            $crit["where"][$field]=[">=",$data["from"]];
        }
        if(!$this->isDate($data["from"]) && $this->isDate($data["to"])){
            $crit["where"][$field]=["<=",$data["to"]];
        }
        if($this->isDate($data["from"]) && $this->isDate($data["to"])){
                $crit["where"][$field]=["between"=>[$data["from"],$data["to"]]];
        }//x($crit,8);
        return $crit;
    }
	
    public function head($com)
    {
        $len=$this->grid->length();
        $left=$len/2;
        $right=$len/2;
        if($len%2){
            $left= floor($len/2);
            $right= ceil($len/2);
        }
        $right_a=$right/2;
        $right_b=$right/2;
        if($right%2){
            $right_a= floor($right/2);
            $right_b= ceil($right/2);
        }//x([$right,$right_a,$right_b],8);
        $curr=Factory::app("Currency","Base");
        $curr->get($this->currency);
        $con=Factory::app("Contact","Base");
        $con->get($this->contact);
        $this->grid->row();
        $this->grid->cell($this->company($com)->rep(),$left,[
            "colSpan"=>7,
            "border"=>[1,1,1,1],
            "rowSpan"=>4
        ]);
        $this->grid->cell(strtoupper($this->type). " STATEMENT",$right,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->row();
        $this->grid->cell("",$left);
        $this->grid->cell("DATE",$right_a,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->cell(date("d F, y"),$right_b,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->row();
        $this->grid->cell(" ",$left);
        $this->grid->cell("CURRENCY",$right_a,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->cell($curr->rep(),$right_b,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->row();
        $this->grid->cell(" ",$left);
        /*$this->grid->cell("ACCOUNT NAME",$right_a,[
            "border"=>[1,1,1,1],
            "alignment"=>"right",
            "fontSize"=>8
        ]);*/
        $this->grid->cell(trim($con->rep()),$right,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
    }
    
    public function company($com)
    {
        $font=7;
        $align="left";
        return dic()
        ->set("stack",lst()
            ->append(dic()                  //Company name
                ->set("text",$com->name)
                ->set("style","header")
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company address
                ->set("text",str_replace("\n", "",$com->address) ." ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company email
                ->set("text",$com->email . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company phone
                ->set("text",$com->phone . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
            )
            ->append(dic()                  //Company phone
                ->set("text",". ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
            )
        );
    }
    
    public function client()
    {
        $this->grid->row();
        $com=Factory::app("Contact","Base");
        $com->get($this->contact);
        $font=7;
        $align="left";
        $dic=dic()
        ->set("stack",lst()
            ->append(dic()                  //Company name
                ->set("text","Deliver To:")
                ->set("bold","true")
                ->set("fontSize",$font)
                ->set("alignment",$align)
            )
            ->append(dic()                  //Company name
                ->set("text",$com->name)
                ->set("fontSize",$font)
                ->set("alignment",$align)
            )
            ->append(dic()                  //Company address
                ->set("text",str_replace("\n", "",$com->address) ." ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
            )
            ->append(dic()                  //Company email
                ->set("text",$com->email . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
            )
            ->append(dic()                  //Company phone
                ->set("text",$com->phone . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            );
        $len=$this->grid->length();
        $left=$len/2;
        $right=$len/2;
        if($len%2){
            $left= floor($len/2);
            $right= ceil($len/2);
        }
        $this->grid->cell($dic->rep(),$left,[
            "border"=>[1,1,1,1]
        ]);
        $this->grid->cell($this->logopos(),$right,[
            "border"=>[1,1,1,1]
        ]);
    }
    
    public function blank()
    {   
        $this->grid->row();
        $this->grid->cell(" ",$this->grid->length(),[
            "border"=>[0,0,0,0]
        ]);
    }
    
    public function logopos(){
        return [
            "image" => "logo",
            "height" => 90
        ];
    }
    
    public function tb($data)
    {
        $this->th();
        $this->firstRow($data);
        foreach($data as $d)
        {
            $this->tr($d);
        }
        $this->lastRow($data);
    }
    
    
    public function th()
    {
        
    }
    
    public function tr($data)
    {
        
    }
    
    public function lastRow()
    {
        
    }
    
    public function firstRow($data)
    {
        
    }
    
}