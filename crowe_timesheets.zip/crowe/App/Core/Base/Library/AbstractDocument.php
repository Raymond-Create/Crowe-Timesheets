<?php
////__________________________________________________
namespace Core\Base\Library;


use Lib\BootSelect as Bs;
use Lib\Factory as Lf;
use Lib\Combo;

class AbstractDocument{
	
    use \Lib\Recid;
    
    public 
        $url,
        $id,
        $doc,
        $sorce,
        $body,
        $card="",
        $script='',
        $mode="edit",
        $card_body="",
        $doc_filter=[],
        $con_filter=[],
        $cre_filter=[],
        $deb_filter=[],
        $cat_filter=[],
        $_categories=null,
        $internal_comment='',
        $attr="data-editable",
        $title="Record Updator",
        $doc_type=false,
        $multiple_doc=false,
        $asset_doc=[["DocType","Base"],[
        "name"=>"FIXED ASSETS",
        "doc"=>[
            ["Doc","Base"],
            [
                "name"=>"ASSETS"
            ]
        ],
        "postable"=>1,
        "debit_core"=>[
            ["CoreAccount","Base"],
        [
            "type"=>"Assets",
            "side"=>"debit",
            "name"=>"FIXED ASSETS"
        ]
        ],
        "credit_core"=>[
            ["CoreAccount","Base"],
            [
            "type"=>"Liabilities",
            "side"=>"credit",
            "name"=>"CREDITORS"
        ]
        ]
    ]];

    public function __construct($record=null)
    {
            $this->id=$record;
            if($record){
                    //$this->set_source($record);
            }

            $this->set_categories();
    }

    public function set_categories()
    {
        if($this->_categories){
            foreach ($this->_categories as $cat)
            {
                $this->cat_filter[]=$this->idOf($cat);
            }
        }
    }

    //set_source

    public function set_url($url)
    {
            $this->url=$url;
    }

    public function set_script($script)
    {
            $this->script=$script;
    }

    public function set_mode($mode)
    {
        $this->mode=$mode;
        if($mode=="view"){
            $this->attr="disabled";
        }
    }

    public function html()
    {
        if($this->rec("journalised")==2)
        {
            $this->set_mode("view");
        }
        $this->body=div("card-body ".$this->card_body)
              ->attr("data-url",$this->url);
            $this->essentials();
            $this->fields();
            $this->table();//x($this->mode,9);
            $div=div("row")
                ->attr("data-x-mod","abstract-document")
                ->add(div("col-md-12 col-lg-12 col-xs-12")
                    ->attr("data-x-mod",$this->script)
                    ->add(div("card ".$this->card)
                        ->add(div("card-header")
                            ->add(h4()->add($this->title))
                        )
                        ->add($this->body)
                        ->add(div("card-footer")
                            ->add(div("row")
                                ->add(div("col-lg-4 col-md-4")
                            ->add(button("btn btn-success btn-prev btn-sm btn-square btn-block  mt-0")
                              ->add($this->mode=="view"?"Previous":"List")    
                    )
                                           ->add(input()
                                                ->attr([
                                                    "name"=>"record","data-pattern"=>"/\d+/",
                                                    "type"=>"hidden","value"=>$this->rec("id"),
                                                    "data-for"=>"source"
                                                ])
                                        )
                                            ->add(input()
                                                ->attr([
                                                    "name"=>"rid","data-pattern"=>"/\d+/",
                                                    "type"=>"hidden","value"=>$this->rec("id"),
                                                    "data-key"=>"record"
                                                ])
                                        )
                                        ->add(input()
                                            ->attr([
                                                "data-pattern"=>"/(Payment|Receipt|Other)/",
                                                "data-for"=>"record",
                                                "type"=>"hidden",
                                                "value"=>$this->rec("type"),
                                                "name"=>"type"
                                            ])
                                        )
                                        ->add(input()
                                            ->attr([
                                                "data-pattern"=>DATE_RGX,
                                                "data-for"=>"source",
                                                "type"=>"hidden",
                                                "value"=>date("Y-m-d"),
                                                "name"=>"date_1"
                                            ])
                                        )
                                    )
                                        ->add(div("col-lg-4 col-md-4")
                                            ->add(Combo::init()
                                                ->set_data(["view"=>"View","edit"=>"Edit"])
                                                ->set_default($this->mode)
                                                ->set_name("mode")
                                                ->html()
                                        )
                                       )
                                        ->add(div("col-lg-4 col-md-4")
                                            ->add(button("btn btn-primary btn-next  btn-sm btn-square btn-block  mt-0")
                                                ->add($this->mode=="view"?"Next":"Save")
                                )
                                    ->add(input()
                                                ->attr([
                                                    "name"=>"sid","data-pattern"=>"/\d+/",
                                                    "type"=>"hidden","value"=>$this->src("id"),
                                                    "data-key"=>"source"
                                                ])
                                        )
                                    )
                                )
                            )
                            )
            );
            return $div;
    }

    public function table()
    {
        $this->body->add(div("row")
                ->add(div("col-lg-12 col-md-12")
                    ->add(div("table-responsive")
                        ->add($this->tb())
                )
            )
        );
    }
	
	public function tb()
	{
    	$table=table("table table-hover table-bordered table-sm thead-dark");
    	//$table=table("table table-bordered thead-primary");
    	$table->add(thead()
	        ->add(tr()
	            ->add(th(["style"=>"width:5%"])->add(i("flaticon-trash")))
	            ->add(th(["style"=>"width:5%"])->add(i("mdi mdi-toggle-switch-off-outline")))
	            ->add(th(["style"=>"width:35%"])->add("Item"))
	            ->add(th(["style"=>"width:10%"])->add("Units"))
	            ->add(th(["style"=>"width:10%"])->add("Quantity"))
	            ->add(th(["style"=>"width:12%"])->add("Price"))
	            ->add(th(["style"=>"width:10%"])->add("Num"))
	            ->add(th(["style"=>"width:13%"])->add("Amount"))
            )
        );
	    $body=tbody(); 
	    $model=Lf::app("SourceLine","Base");
	    $data=$model->read([
	        "where"=>[
	            "source"=>$this->src("id")
	        ]
	    ]);
	    foreach($data as $row)
	    {
	        $body->add($this->row($row));
	    }
	    $table->add($body);
	    $table->add(tfoot()
	        ->add(tr()
	            ->add(td(["colspan"=>7])
	                ->add(button("btn btn-primary btn-sm btn-square btn-new-line mt-0")
	                    ->add("Add New line")
                    )
                )
	            ->add(td()
	                ->add(input("form-control form-control-sm")
	                    ->attr([
	                        "name"=>"sub_total","data-pattern"=>CURRENCY_RGX,
	                        "type"=>"number","step"=>"any","disabled"=>"disabled",
	                        "data-for"=>"source","value"=>$this->src("sub_total")
	                    ])
                        )
                    )
                )
                ->add(tr()
	            ->add(td(["colspan"=>3]))
	            ->add(td(["colspan"=>5])
	                ->add($this->additionalTable())
                    )
                )
            );
	    return $table;
	}
	
	public function row($data=[])
	{
	   $tr=tr();
	   $tr->add(td()
	       ->add(button("ms-btn-icon btn-danger btn-sm btn-square btn-del-line mt-0 mb-0")
	           ->add("X")
           )
	       ->add(input()
	           ->attr([
	               "type"=>"hidden",
	               "name"=>"lid",
	               "value"=>$data["id"]??""
	           ])
           )
       );
	   $tr->add(td()
	       ->add(button("ms-btn-icon btn-light btn-sm btn-square btn-input-toggle mt-0 mb-0")
	           ->add(i("mdi mdi-form-textbox"))
           )
       );
	$tr->add(td()
            ->add(div()
                ->add(Bs::init()
	           ->set_model(["Item","Base"])
	           ->set_default($data["item"]??"")
	           ->set_meta([$this->attr=>$this->attr])
	           ->set_name("item")
	           ->html()
                )  
            )  
	       
            ->add(input("form-control form-control-sm x-details")
                ->attr([
                    "data-pattern"=>"/^.+$/","style"=>"display:none",
                    "value"=>$data["details"]??"",$this->attr=>$this->attr
                ])
            )
       );
	 
         //x($tr,7);
	   
        $tr->add(td()
            ->add(input("form-control form-control-sm x-unit")
                ->attr([
                    "name"=>"unit","data-pattern"=>CHAR_RGX,
                    "value"=>$data["units"]??"",$this->attr=>$this->attr
                ])
           )
       );
	   
	   
	   $tr->add(td()
	       ->add(input("form-control form-control-sm x-quantity")
	           ->attr([
	               "name"=>"quantity","data-pattern"=>DECIMAL_RGX,
	               "value"=>$data["quantity"]??1.0,$this->attr=>$this->attr,
	               "step"=>"any","type"=>"number"
	           ])
           )
       );
	   
	   $tr->add(td()
	       ->add(input("form-control form-control-sm x-price")
	           ->attr([
	               "data-pattern"=>DECIMAL_RGX,
	               "value"=>$data["price"]??0.0,$this->attr=>$this->attr,
	               "step"=>"any","type"=>"number"
	           ])
           )
       );
	   
	   $tr->add(td()
	       ->add(input("form-control form-control-sm x-flag")
	           ->attr([
	               "data-pattern"=>DECIMAL_RGX,
	               "value"=>$data["flag"]??0,$this->attr=>$this->attr,
	               "step"=>"1","type"=>"number"
	           ])
           )
       );
	   
	   return $tr->add(td()
	       ->add(input("form-control form-control-sm x-amount")
	           ->attr([
	               "data-pattern"=>DECIMAL_RGX,
	               "disabled"=>"disabled","step"=>"any","type"=>"number"
	           ])
           )
       );
	}
	
	public function fields()
	{
		$this->body->add(div("row")
			->add(div("col-lg-6 col-md-6")
			
			)
		);
	}
	
	public function notes()
	{
	    $this->body->add(div("row  mb-2")
	        
	        ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Title 1"))
	            ->add(input("form-control form-control-sm")
	                ->attr([
	                    "name"=>"title_1","data-pattern"=>CHAR_RGX,
	                    "data-for"=>"source","value"=>$this->src("title_1"),
	                    "placeholder"=>"Note 1 Title (NOT Required)",
	                    $this->attr=>$this->attr
	                ])
                )
            )
	        ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Note 1"))
	            ->add(textarea("form-control form-control-sm")
	                ->attr([
	                    "name"=>"note_1","data-pattern"=>CHAR_RGX,
	                    "data-for"=>"source","value"=>$this->src("note_1"),
	                    "placeholder"=>"Note 1 (NOT Required)",
	                    $this->attr=>$this->attr
	                ])
                )
            )
	        
	        ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Title 2"))
	            ->add(input("form-control form-control-sm")
	                ->attr([
	                    "name"=>"title_2","data-pattern"=>CHAR_RGX,
	                    "data-for"=>"source","value"=>$this->src("title_2"),
	                    "placeholder"=>"Note 2 Title (NOT Required)",
	                    $this->attr=>$this->attr
	                ])
                )
            )
	        ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Note 2"))
	            ->add(textarea("form-control form-control-sm")
	                ->attr([
	                    "name"=>"note_2","data-pattern"=>CHAR_RGX,
	                    "data-for"=>"source","value"=>$this->src("note_2"),
	                    "placeholder"=>"Note 2 (NOT Required)",
	                    $this->attr=>$this->attr
	                ])
                )
            )
        );
	}
	
	public function method()
	{
	    $this->body->add(div("row")
	        
            ->add(div("col-lg-4 col-md-4 x-x")
                ->add(label("control-label")->add("Posted"))
	            ->add(Combo::init()
	                ->set_data(["No","Yes","Never"])
	                ->set_placeholder("Posted (Required)")
	                ->set_default($this->rec("journalised")?:"0")
	                ->set_meta(["data-for"=>"record",$this->attr=>$this->attr])
	                ->set_pattern("/[0-2]/")
	                ->set_name("journalised")
	                ->required()
	                ->html()
                )
            )
	        
	        ->add(div("col-lg-4 col-md-4 x-x")
	            ->add(label("control-label")->add("Order #"))
	            ->add(input("form-control form-control-sm")
	                ->attr([
	                    "name"=>"order_no","data-pattern"=>CHAR_RGX,
	                    "data-for"=>"source","value"=>$this->src("order_no"),
	                    "placeholder"=>"Order No (NOT Required)",
	                    $this->attr=>$this->attr
	                ])
                )
            )
	        
	        ->add(div("col-lg-4 col-md-4 x-x")
	            ->add(label("control-label")->add("Attention"))
	            ->add(input("form-control form-control-sm")
	                ->attr([
	                    "name"=>"attention","data-pattern"=>CHAR_RGX,
	                    "data-for"=>"source","value"=>$this->src("attention"),
	                    "placeholder"=>"Attention (NOT Required)",
	                    $this->attr=>$this->attr
	                ])
                )
            )
        );
	}
	
	public function accounts1()
	{
	    $this->body->add(div("row")
	        ->add(div("col-lg-6 col-md-6 x-x")
	            ->add(label("control-label")->add("Debit Account"))
	            ->add(Bs::init()
	                ->set_model(["Account","Base"])
	                ->set_placeholder("Debit Account (Not Required)")
	                ->set_filter([
	                    "select"=>["accounts.*"],
	                    "join"=>[
	                        "join"=>[
	                            ["coreaccounts c","c.id","accounts.core"]
	                        ]
	                    ],
	                    "where"=>["c.side"=>"debit"]
	                ])
	                ->set_default($this->rec("debit"))
	                ->set_meta(["data-for"=>"record",$this->attr=>$this->attr])
	                ->set_pattern("/\d+/")
	                ->set_name("debit")
	                ->html()
                )
            )
	        ->add(div("col-lg-6 col-md-6 x-x")
	            ->add(label("control-label")->add("Credit Account"))
	            ->add(Bs::init()
	                ->set_model(["Account","Base"])
	                ->set_placeholder("Credit Account (Not Required)")
	                ->set_filter([
	                    "select"=>["accounts.*"],
	                    "join"=>[
	                        "join"=>[
	                            ["coreaccounts c","c.id","accounts.core"]
	                        ]
	                    ],
	                    "where"=>["c.side"=>"credit"]
	                ])
	                ->set_default($this->rec("credit"))
	                ->set_meta(["data-for"=>"record",$this->attr=>$this->attr])
	                ->set_pattern("/\d+/")
	                ->set_name("credit")
	                ->html()
                )
            )
        );
	}
	
	public function accounts2()
	{
	    $this->body->add(div("row")
	        ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Associated Record"))
	            ->add(Combo::init()
	                ->set_model(["Record","Base"])
	                ->set_placeholder("Linked Record (Not Required)")
	                //->set_filter($this->deb_filter)
	                ->set_default($this->src("record_ref"))
	                ->set_meta(["data-for"=>"source",$this->attr=>$this->attr])
	                ->set_pattern("/\d+/")
	                ->set_name("record_ref")
	                ->html()
                )
            )
	        ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Associated Asset"))
	            ->add(Combo::init()
	                ->set_model(["Record","Base"])
	                ->set_placeholder("Linked Asset (Not Required)")
	                ->set_filter([
	                    "join"=>[
	                        "join"=>[
	                            ["sources","sources.record","records.id"]
	                        ]
	                    ],
	                    "select"=>["records.*"],
	                    "where"=>["sources.doc_type"=>$this->idOf($this->asset_doc)]
	                ])
	                ->set_default($this->src("record_ref"))
	                ->set_meta(["data-for"=>"source",$this->attr=>$this->attr])
	                ->set_pattern("/\d+/")
	                ->set_name("record_ref")
	                ->html()
	                )
	            )
	        ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Debit Account"))
	            ->add(Bs::init()
	                ->set_model(["Account","Base"])
	                ->set_placeholder("Debit Account (Not Required)")
	                ->set_filter([
	                    /*"select"=>["accounts.*"],
	                    "join"=>[
	                        "join"=>[
	                            ["coreaccounts c","c.id","accounts.core"]
	                        ]
	                    ],
	                    "where"=>["c.side"=>"debit"]*/
	                ])
	                ->set_default($this->rec("debit"))
	                ->set_meta(["data-for"=>"record",$this->attr=>$this->attr])
	                ->set_pattern("/\d+/")
	                ->set_name("debit")
	                ->html()
                )
            )
	        ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Credit Account"))
	            ->add(Bs::init()
	                ->set_model(["Account","Base"])
	                ->set_placeholder("Credit Account (Not Required)")
	                ->set_filter([
	                   /* "select"=>["accounts.*"],
	                    "join"=>[
	                        "join"=>[
	                            ["coreaccounts c","c.id","accounts.core"]
	                        ]
	                    ],
	                    "where"=>["c.side"=>"credit"]*/
	                ])
	                ->set_default($this->rec("credit"))
	                ->set_meta(["data-for"=>"record",$this->attr=>$this->attr])
	                ->set_pattern("/\d+/")
	                ->set_name("credit")
	                ->html()
	                )
	            )
	        );
	}
	public function comment()
	{
	    $this->body->add(div("row mb-4")
	        ->add(div("col-lg-6 col-md-6 x-x")
	            ->add(label("control-label")->add("Description"))
	            ->add(textarea("form-control form-control-sm")
	                ->attr([///^[0-9A-Za-z'\_\,\.\- ]+$/
	                    "name"=>"comment","data-pattern"=>"/^[a-zA-Z0-9\/\-\,\(\)\+\.\:\$ ]+$/",
	                    "data-for"=>"record","value"=>$this->rec("comment")?:$this->internal_comment,
	                    "placeholder"=>"Description (Required)",
	                    "required"=>"required",$this->attr=>$this->attr
	                ])
                )
            )
	        
	        ->add(div("col-lg-6 col-md-6 x-x")
	            ->add(label("control-label")->add("External Comment"))
	            ->add(textarea("form-control form-control-sm")
	                ->attr([
	                    "name"=>"extra_comment","data-pattern"=>CHAR_RGX,
	                    "data-for"=>"source","value"=>$this->src("extra_comment"),
	                    "placeholder"=>"Extra Comment (Not Required)",
	                    $this->attr=>$this->attr
	                ])
                )
            )
        );
	}
	
	public function accounts(){
	    return $this->accounts2();
	}
	//public function 
	public function essentials()
	{
	    $this->date_due_contact_location();
	    $this->doc_currency_rate_amount();
	    $this->category_journalised_ref_discount();
	    $this->notes();
	    $this->method();
	    $this->accounts();
	    $this->comment();
	}
	
	public function date_due_contact_location()
	{  
	    //Config::init()->defaultlocation=1;
	    //Config::init()->defaultrate=1;
		$this->body->add(div("row")/*
                    ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Credit Account"))
	            ->add(Bs::init()
	                ->set_model(["DocType","Base"])
	                ->set_placeholder("Credit Account (Not Required)")
	                ->set_filter([
	                    "select"=>["accounts.*"],
	                    "join"=>[
	                        "join"=>[
	                            ["coreaccounts c","c.id","accounts.core"]
	                        ]
	                    ],
	                    "where"=>["c.side"=>"credit"]
	                ])
	                ->set_default($this->rec("credit"))
	                ->set_meta(["data-for"=>"record",$this->attr=>$this->attr])
	                ->set_pattern("/\d+/")
	                ->set_name("credit")
	                ->html()
	                )
	            )  */  
			->add(div("col-lg-3 col-md-3 x-x")
			    ->add(label("control-label")->add("Date"))
				->add(input("form-control form-control-sm")
					->attr([
						"name"=>"date","data-pattern"=>DATE_RGX,
						"data-addon"=>"datepicker",
						"data-for"=>"record","value"=>$this->rec("date")?:date("Y-m-d"),
						"placeholder"=>"Date - YY-MM-DD (Required)",
					    "required"=>"required",$this->attr=>$this->attr
					])
				)
			)
			->add(div("col-lg-3 col-md-3 x-x")
			    ->add(label("control-label")->add("Due Date"))
				->add(input("form-control form-control-sm")
					->attr([
					    "name"=>"due","data-pattern"=>DATE_RGX,"required"=>"required",
					    "data-addon"=>"datepicker",$this->attr=>$this->attr,
					    "data-for"=>"record","value"=>$this->rec("due")?:date("Y-m-d"),
						"placeholder"=>"Due Date - YY-MM-DD (Required)"
					])
				)
			)
		    
		    ->add(div("col-lg-3 col-md-3 x-x")
		        ->add(label("control-label")->add("Contact"))
		        ->add(Combo::init()
		            ->set_model(["Contact","Base"])
		            ->set_placeholder("Contact (Not Required)")
		            ->set_default($this->rec("contact"))
		            ->set_meta([
		                "data-for"=>"record",
		                $this->attr=>$this->attr,
		                "data-acc"=>1
		            ])
		            ->set_pattern("/\d+/")
		            ->set_name("contact")
		            ->html()
	            )
	        )
		    
		    ->add(div("col-lg-3 col-md-3 x-x")
		        ->add(label("control-label")->add("Business Unit"))
		        ->add(Bs::init()
		            ->set_model(["Location","Base"])
		            ->set_placeholder("Business Unit (Required)")
		            ->set_default($this->rec("location")?:Config::init()->defaultlocation)
		            ->set_filter([
		                "where"=>["type"=>"BusinessUnit"]
		            ])
		            ->set_meta(["data-for"=>"record",$this->attr=>$this->attr])
		            ->set_pattern("/\d+/")
		            ->set_name("location")
		            ->required()
		            ->html()
	            )
	        )
		);
	}
	protected $dt=[];
	public function doc_currency_rate_amount()
	{   
	    $m= Lf::app("Doc","Base");
	    $this->body->add(div("row")
	       
	        
                ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Account"))
	            ->add(Bs::init()
	                ->set_model(["CashAccount","Base"])
	                ->set_placeholder("Cash Book Type (Not Required)")
	                ->set_default($this->src("method"))
	                ->set_meta(["data-for"=>"source",$this->attr=>$this->attr,"data-acc"=>1])
	                ->set_pattern("/\d+/")
	                ->set_name("method")
	                ->html()
                )
            )
                ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Currency"))
	            ->add(Bs::init()
	                ->set_model(["Currency","Base"])
	                ->set_placeholder("Record Currency Type (Required)")
	                ->set_default($this->rec("currency")?:Config::init()->defaultcurrency)
	                ->set_meta(["data-for"=>"record",$this->attr=>$this->attr])
	                ->set_pattern("/\d+/")
	                ->set_name("currency")
	                ->required()
	                ->html()
                )
            )
	        
	        ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Exchange Rate"))
	            ->add(Bs::init()
	                ->set_model(["Rate","Base"])
	                ->set_placeholder("Rate - one unit of base (Required)")
	                ->set_default($this->rec("rate")?:Config::init()->defaultrate)
	                ->set_filter([
	                   "table"=>[
                                "table"=>"rates","alias"=>"rates",
                                "join"=>[
                                    "join"=>[
                                        ["currencies c1","rates.currency","c1.id"],
                                        ["currencies c2","rates.base","c2.id"]
                                    ]
                                ],
                                "select"=>["rates.id","rates.date","round(rates.rate,3) as rate", "round(1/rates.rate,3) as rateinverse","c1.name as n1","c2.name as n2"]
                            ],
                            "select"=>[
                               //"*"
                                "id",$m->concat(["'rate'",' (', "'rates.rateinverse'", ') ',"'n1'",'/',"'n2'" ]) ." as rate ","rates.date"
                            ]
	                ])
	                ->set_meta(["data-for"=>"record",$this->attr=>$this->attr])
	                ->set_pattern("/\d+/")
	                ->set_name("rate")
	                ->required()
	                ->html()
                )
            )
	        
	        ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Amount"))
	            ->add(input("form-control form-control-sm x-total")
	                ->attr([
	                    "name"=>"amount","data-pattern"=>CURRENCY_RGX,
	                    "type"=>"number","step"=>"any",
	                    "data-for"=>"record","value"=>$this->rec("amount")?currency($this->rec("amount")):0.00,
	                    "placeholder"=>"Amount 000.00 (Required)",
	                    "required"=>"required",$this->attr=>$this->attr
	                ])
                )
            )
        );
	}
	
	
	public function category_journalised_ref_discount()
	{
	    $a=($this->rec("accrued")===0)?"required":"data-Y";// x($this->rec("accrued"),9);
            $attr="data-y";
	    if($this->doc_type){
	        if(!$this->multiple_doc)
	        {
	            $dt=[$this->doc_type];
	            $attr="disabled";
	        }else{
	            $dt=$this->doc_type;
	        }
	        foreach($dt as $doc){
	            $this->dt[]=$this->idOf($doc);
	        }
	    }
	    $this->body->add(div("row")
	         ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Document Type"))
	            ->add(Combo::init()
	                ->set_model(["DocType","Base"])
	                ->set_placeholder("Document Type (Required)")
	                ->set_default(
	                    $this->src("doc_type")?:(count($this->dt)==1?$this->dt[0]:null)
                    )
	                ->set_filter(empty($this->dt)?[]:[
	                    "where"=>["id"=>["in"=>$this->dt]]
	                ])
	                ->set_meta([
	                    "data-for"=>"source",
	                    $this->attr=>$this->attr,
	                    $attr=>$attr,"data-acc"=>1
	                ])
	                ->set_pattern("/\d+/")
	                ->set_name("doc_type")
	                ->required()
	                ->html()
                )
            )
	        ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Category"))
	            ->add(Bs::init()
	                ->set_model(["Category","Base"])
	                ->set_placeholder("Category (Required)")
	                ->set_default($this->src("category"))
	                ->set_filter($this->cat_filter?:[
	                    "where"=>[
	                        "doc_type"=>$this->dt?["in"=>$this->dt]:["<>",null]
	                    ]
	                ])
	                ->set_meta([
	                    "data-for"=>"source",
	                    $this->attr=>$this->attr
	                    ,"data-acc"=>1,$a=>$a
	                ])
	                ->set_pattern("/\d+/")
	                ->set_name("category")
	                ->html()
                )
            )  
            ->add(div("col-lg-3 col-md-3 x-x")
                ->add(label("control-label")->add("Reference"))
	            ->add(input("form-control form-control-sm")
	                ->attr([
	                    "name"=>"ref","data-pattern"=>CHAR_RGX,
	                    "data-for"=>"record","value"=>$this->rec("ref")?:date("ymdHis"),
	                    "placeholder"=>"Referrence (Required)",
	                    "required"=>"required",$this->attr=>$this->attr
	                ])
	            )
            )
	        
            ->add(div("col-lg-3 col-md-3 x-x")
                ->add(label("control-label")->add("Discount"))
	            ->add(input("form-control form-control-sm")
	                ->attr([
	                    "name"=>"discount","data-pattern"=>CURRENCY_RGX,
	                    "type"=>"number","step"=>"any",
	                    "data-for"=>"source","value"=>currency($this->src("discount")),
	                    "placeholder"=>"Discount 000.00 (Not Required)",
	                    $this->attr=>$this->attr
	                ])
                )
            )
        );
	}
	public function rec($field)
	{
		$mod=\Lib\Factory::app("Record","Base");
		$mod->get($this->id);
		return $mod->$field;
	}
	
	
	public function src($field){
		$mod=Lf::app("Source","Base");
		$mod->fetch([
			"where"=>["record"=>$this->id]
		]);
		return $mod->$field;
	}
	
	public function det_accounts($post)
	{
	    $mod=Lf::app("DocType","Base");
	    $data=$mod->get($post["doc_type"]);
	    $debit_method=$data[0]["debit_notes"];
	    if(!method_exists($this, $debit_method)){
	        throw new \Exception("Method $debit_method in undefined");
	    }
	    $credit_method=$data[0]["credit_notes"];
	    if(!method_exists($this, $debit_method)){
	        throw new \Exception("Method $credit_method in undefined");
	    }
	    return[
	        $this->{$debit_method}($data[0],$post,"debit"),
	        $this->{$credit_method}($data[0],$post,"credit")
	    ];
	}
	public function suspense($name){
	    return $this->acc($name,$this->idOf([
	        ["CoreAccount","Base"],
	        [
	            "type"=>"Equity",
	            "side"=>"credit",
	            "name"=>"SUSPENSE"
	        ]
	    ]),"credit");
	}
	
	public function contact_acc($doc,$post,$side)
	{
	    $mod=Lf::app("Contact","Base");
	    $mod->get($post["contact"]);
	    if(!$mod->id){
	        throw new \Exception("Contact not found");
	    }
	    return $this->acc($mod->rep(),$doc,$side);
	}
	
	public function method_acc($doc,$post,$side)
	{
	    $mod=Lf::app("CashAccount","Base");
	    $mod->get($post["method"]);
	    if(!$mod->id){
	        throw new \Exception("CashAccount not found");
	    }
	    return $this->acc($mod->rep(),$doc,$side);
	}
	
	public function category_acc($doc,$post,$side)
	{
	    if(!is_numeric($post["category"])){
	        throw new \Exception("Category not given");
	    }
	    $mod=\Lib\Factory::app("Category","Base");
	    $mod->get($post["category"]);
	    return $this->acc($mod->rep(),$doc,$side);
	}
	
	public function null_acc($doc,$post,$side){
	    return null;
	}
	public function acc($name,$doc,$side){
	    $acc=new Account($name,$doc[$side=="debit"?"debit_core":"credit_core"]);
	    return $acc->get_account();
	}
	
	public function save($post,$id=null)
	{
	    $sl=Lf::app("DocType","Base");
	    $source=Lf::app("Source","Base");
	    try{
	        $bool=false;
	        if(!$sl->trans()){
	            $sl->begin();
	            $bool=true;
	        }
	        if(!isset($post["credit"])||!isset($post["debit"])){
	            $acc=$this->det_accounts($post);
	            $post["debit"]=$acc[0];
	            $post["credit"]=$acc[1];
	        }
	        $sl->get($post["doc_type"]);
	        $post["type"]=$sl->type;
	        $recId=$this->addRecord($post,$id);
	        //x($recId,9);
	        if($recId[0]){
	            $source->fetch(["where"=>["record"=>$recId[0]]]);
	            $post["record"]=$recId[0];
	            $srcId=$this->addSource($post,$source->id);
	            if(!$srcId[0]){
        	        throw new \Exception("Source not created");
        	    }
	        }else{
	            throw new \Exception("Record not created");
	        }
    	    if($bool){
    	       $sl->commit();
    	    }
    	    return [[$recId[0],$srcId[0]],$recId[1]||$srcId[1]];
	    }catch(\Exception $ex){x($ex,9);
	        if($bool){
    	        $sl->rollback();
    	        return [$ex->getMessage(),false];
	        }
	        else {
	            throw $ex;
	        }
	    }
	}
	
	protected function addRecord($post,$id=null)
	{
	    return $this->put("Record",$post,$id);
	}
	
	protected function addSource($post,$id=null)
	{
	    return $this->put("Source",$post,$id);
	}
	
	private function put($model,$post,$id=null){
	    //record object
	    $record=Lf::app($model,"Base");
	    if($id){
	        $record->get($id);
	    }
	    foreach ($record->_struct_ as $ky=>$value){
            $bool=($value->getForeign()&&$value->isNull()&&(!isset($post[$ky])||empty($post[$ky])));
            if($bool){
                continue;
            }
            if(isset($post[$ky])){
                $record->$ky=$post[$ky];
            }
        }
        //if($model=="Source")
            //x($record->data(),8);
	    $sid=$record->save();
	    return [$record->id?:$sid,$sid];
	}
    
    public function additionalTable()
    {
        $addMod=\Lib\TableFixer::init("Addition","Base");
        $additions=$addMod->read([
            "where"=>["record"=>$this->rec("id")]
        ]);
        $table=table("table table-sm table-bordered");
        $table->add(thead()
            ->add(tr()
                ->add(th()->add(i("flaticon-trash")))
                ->add(th()->add("Name"))
                ->add(th()->add("Effect"))
                ->add(th()->add("Amount"))
            )
        );
        $tableBody=tbody("additions");
        foreach($additions as $addition){
            $tableBody->add($this->additionRow($addition));
        }
        $table->add($tableBody);
        $table->add(tfoot()
            ->add(tr()
                ->add(td(["colspan"=>2])
                    ->add(button("btn btn-primary btn-sm mt-0 btn-add-add btn-block")
                        ->add("New Addition")
                    )    
                )
                ->add(th(["colspan"=>2]))
            )
            ->add(tr()
                ->add(th(["colspan"=>3])->add("Total"))
                ->add(td()->add(input(NPS)
                    ->attr([
                       "name"=>"additionTotal","value"=>$this->rec("amount"),
                       "data-pattern"=>CURRENCY_RGX,"type"=>"number",
                       "step"=>"any","disabled"=>"disabled"
                   ])
                        
                ))
            )
        );
        return $table;
    }
    
    public function additionRow($data=[])
    {
        $tr=tr();
        $tr->add(td()->add(span("flaticon-trash btn-add-del text-danger")
            ->attr([
                "title"=>"Delete Additional row","data-toggle"=>"tooltip"
            ]) 
        ));
        $tr->add(td()->add(input(NPS)
            ->attr([
                "name"=>"additionName","value"=>$data["name"]??"",
                "data-pattern"=>CHAR_RGX
            ]) 
        ));
        $tr->add(td()->add(Combo::init()
            ->set_data([
                "Decrease","Increase"
            ]) 
            ->set_placeholder("Choose Effect")
            ->set_default($data["effect"]??"")
            ->set_name("additionEffect")
            ->set_pattern(INTEGER_RGX)
            ->required()
            ->html()
        ));
        return $tr->add(td()
            ->add(input(NPS)
                ->attr([
                    "name"=>"additionAmount","value"=>$data["amount"]??"",
                    "data-pattern"=>CURRENCY_RGX,"type"=>"number",
                    "step"=>"any"
                ]) 
            )
            ->add(input()
                ->attr([
                    "name"=>"additionId","value"=>$data["id"]??"",
                    "data-pattern"=>INTEGER_RGX,"type"=>"hidden"
                ]) 
            )
        );        
    }
}
