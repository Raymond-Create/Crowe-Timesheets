<?php

namespace Core\Base\Library;

import("Pdfmake");

use Lib\Factory as Fa;

abstract class AbstractReport{
	
	public $title="",$url="",$dis="data-ignore";
	
	abstract function content($id=null);
	
	public $body=[],$dateFrom,$dateTo,$report,$imageScale="height",$imageScaleSize="90",
	$com,$contentArray;
	
        public function __construct(){
            Periods::init()->update_periods();
            //$this->header();
        }
	
	public function bodyAdd($component, $index)
	{
		$this->body[$index]=$component;
		return $this;
	}
	
	public function contentAdd($component)
	{
		$this->contentArray[]=$component;
		return $this;
	}
	
	public function setBounds(array $queryAST,$dateField='date')
	{
            //x([$this->dateFrom,preg_match(DATE_RGX,$this->dateFrom)]);
            if(preg_match(DATE_RGX,$this->dateFrom)&&preg_match(DATE_RGX,$this->dateTo))
            {
                $queryAST["where"][$dateField]=["between"=>[$this->dateFrom,$this->dateTo]];
            }
            if(preg_match(DATE_RGX,$this->dateFrom)&&!preg_match(DATE_RGX,$this->dateTo))
            {
                $queryAST["where"][$dateField]=[">=",$this->dateFrom];
            }
            if(!preg_match(DATE_RGX,$this->dateFrom)&&preg_match(DATE_RGX,$this->dateTo))
            {
                $queryAST["where"][$dateField]=["<=",$this->dateTo];
            }//x($queryAST,9);
            return $queryAST;
	}
	
	public function html()
	{
            $card=div("card")
            ->attr("data-x-mod","new-report-viewer")
            ->attr("sytle","width:100%");
            $card->add(div("card-header")
                ->add(h3()->add($this->title))
            );
            $card->add(div("card-body")
                ->add($this->dates())
                ->add($this->controls())
                ->add($this->buttons())
                ->add(div(ROW." mt-2")->add(div(C121212." iframe")))
                ->add(span("index")->attr("data-url",$this->url))
            );
            return div(ROW)->add(div(C121212)->add($card));
	}
    public function dates()
    {
        return div(ROW)
            ->add(div(C666)
                ->add($this->label(
                        "Report From Date",
                        "If you set this date you report will be generated from that date otherwise if you leave date blank report will begin from the first applicable reord in database"
                    )
                )
                ->add(input(NPS)
                    ->attr([
                        "name"=>"date_from","data-pattern"=>DATE_RGX,
                        "value"=>date("Y-m-01"),"data-addon"=>"datepicker",
                        $this->dis=> $this->dis
                    ])
                )
            )
            ->add(div(C666)
                ->add($this->label(
                        "Report To Date",
                        "If you set this date you report will be generated up the that date otherwise if you leave date blank report will end at the last applicable reord in database"
                    )
                )
                ->add(input(NPS)
                    ->attr([
                        "name"=>"date_to","data-pattern"=>DATE_RGX,
                        "value"=>date("Y-m-t"),"data-addon"=>"datepicker",
                        $this->dis=> $this->dis
                    ])
                )
            );
    }
	
    public function controls()
    {
            return ;
    }

    public function buttons()
    {
        return div(ROW)
            ->add(div(C666)
                ->add(button(BNPS." btn-block btn-pdf")
                    ->add("Generate PDF")
                )
            )
            ->add(div(C666)
                ->add(button(BNSS." btn-block btn-csv")
                    ->add("Download CSV")
                )
            );
    }
	public function label($text,$tip="")
	{
		$lb=label(LB);
		if($tip)
		{
			$lb->attr([
				"data-toggle"=>"tooltip","title"=>$tip
			]);
		}
		return $lb->add($text);
	}
	
	public function set_post($post){
		if(isset($post['from'])&&preg_match(DATE_RGX,$post['from'])) 
		{
			$this->dateFrom=$post['from'];
		}
		if (isset($post['to'])&&preg_match(DATE_RGX,$post['to'])) {
			$this->dateTo=$post['to'];
		}
		$this->post=$post;
	}
	
	public function dsl($csv=null)
	{
            $com=Fa::init()->get_model("Org","Authentication");
            $com->fetch([
                "where"=>["db"=>\Lib\Session::get("user_selected_database")]
            ]);
            $this->com=$com;
            $this->bodyAdd([
                "header"=> [
                    "fontSize"=> 10,
                    "bold"=>"true",
                    "fillColor"=>"#DCDCDC"
                ],
                "anotherStyle"=>[
                    "italics"=> true,
                    "alignment"=> 'right'
                ]
            ],"styles");
            $this->bodyAdd(["logo"=>$com->logo],"images");
            $this->content();
            $this->bodyAdd($this->contentArray,"content");
            if($csv==707 && $this->csv instanceof \Lib\Csv)
            {
                $this->csv->download();
            }
            return $this->body;
	}
	
	public function InternalCompanyReportDetails()
	{
		$grid=Grid();
		$grid->row();
		$grid->cell($this->logopos(),6,[
		"border"=>[0,0,0,0]
		]);
		$grid->cell($this->CompanyDetails() ,6,[
		"border"=>[0,0,0,0]
		]);
		$grid->row();
		$grid->cell(" ",$grid->length(),[
			"border"=>[0,0,0,0]
		]);
		

		$grid->row();
		$grid->cell(
			$this->title." being reported from '".
			$this->readableDate($this->dateFrom)."' up to '".
			$this->readableDate($this->dateTo)."'",
			$grid->length(),[
			"fontSize"=>11,
			"border"=>[0,1,0,0],
			"alignment"=>"center"
		]);
		$this->contentAdd($grid->rep());
	}
	
	public function logopos()
	{
            return [
                "image"=>"logo",
                "width" => 90
                //$this->imageScale=>$this->imageScaleSize
		];
	}
	
	public function CompanyDetails()
	{
		$grid=Grid();
		$grid->row();
		$grid->cell($this->com->rep(),12,[
			"border"=>[0,0,0,0],
			"alignment"=>"right"
		]);
		$grid->row();
		$grid->cell($this->com->address." " ,12,[
			"border"=>[0,0,0,0],
			"alignment"=>"right",
			"fontSize"=>10
		]);
		$grid->cell($this->com->email." " ,12,[
			"border"=>[0,0,0,0],
			"alignment"=>"right",
			"fontSize"=>10
		]);
		$grid->cell($this->com->phone." " ,12,[
			"border"=>[0,0,0,0],
			"alignment"=>"right",
			"fontSize"=>10
		]);
		return $grid->rep();
	}
	
	public function line($width=1,$landscape=false)
	{
            return ["canvas"=> [[ 
                    "type"=> 'line', "x1"=> 0, "y1"=> 5,
                    "x2"=>$landscape?(850-2*40):(595-2*40) , 
                     "y2"=> 5, "lineWidth"=>$width 
            ]]];
	}
	
    public function readableDate($date)
    {
        return $date&&preg_match(DATE_RGX,$date)?date("d M y",strtotime($date)):"";
    }
}