<?php
namespace Core\Base\Library;

use Core\Base\Library\AbView;


class RatesView extends AbView
{
    use \Lib\Init;
    
    public function form()
    {
        return new ExchangeRates();
    }
    public
    		$_title="Rates",
    		$url="base/rates/create",
			$types="Rates",
            $type="Rates";
    
}