<?php

namespace Core\Base\Library;

use Lib\Factory;

trait BankAccounts{
    
    public function bank(){
        $bank = Factory::app("CashAccount","Base");
        $doc = $bank->select([
            "join"=>[
                "join"=>[
                    ["currencies c","c.id","cashaccounts.currency"]
                ]
            ],
            "select"=>[
                "cashaccounts.name","company","branch","number","c.name as currency",
                "swift"
            ],
            "where"=>["type"=>"Bank"]
        ]);
        $table = ["table"=>["widths"=>["*","15%","20%","20%","15%","15%"],"body"=>[
            [["text"=>"Name","fontSize"=>7],["text"=>"Bank","fontSize"=>7],
                ["text"=>"Branch","fontSize"=>7],["text"=>"Account","fontSize"=>7],["text"=>"Type","fontSize"=>7]
            ]
        ]]];
        foreach($doc as $row){
            $table["table"]["body"][] = [
                ["text"=>$row["name"],"fontSize"=>6],
                ["text"=>$row["company"],"fontSize"=>6],
                ["text"=>$row["branch"],"fontSize"=>6],
                ["text"=>$row["number"] ,"fontSize"=>6],
                ["text"=>$row["currency"] ,"fontSize"=>6],
                ["text"=>$row["swift"] ,"fontSize"=>6]
            ];
        }//x($table,9);
        return $table;
    }
    
    
}
