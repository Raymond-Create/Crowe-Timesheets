<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */
namespace Core\Base\Library;
/**
 * Description of PdfView
 *
 * @author blessing
 */
class PdfView {
    use \Lib\Init;
    
    private $url,$sec;
    
    public function __construct($sec=null){
        $this->sec=$sec;
    }
    
    public function set_url($url)
    {
        $this->url=$url;
    }
    
    public function html()
    {
        return div(ROW." mt-2")
            ->attr('data-x-mod',$this->sec?'pdf-view-2s':'pdf-view')
            ->add(div(C121212)
                ->add(div("card")
                    ->add(div("card-header")
                       ->add(h3()->add("PDF Document viewer"))
                    )
                    ->add(div("card-body")
                        ->add(div(ROW)
                            ->add(div(C121212)
                                ->add(div('col-xs-12 col-md-12 iframe')) 
                                ->add(input()
                                    ->attr([
                                        "value"=> $this->url,
                                        "type"=>"hidden",
                                        "name"=>"url"
                                    ])
                                )
                            )
                        )
                    )
                )
            );
    }
}
