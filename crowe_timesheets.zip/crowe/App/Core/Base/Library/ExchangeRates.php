<?php

namespace Core\Base\Library;

class ExchangeRates
{
	
	use \Lib\Init,\Lib\Loader;
	
	public function set_url()
	{
		//Config::init()->defaultCurrency=1;
	}
	
	public function html()
	{
		return div("card")
			->add(div("card-header")
				->add(h3()->add("Exchange Rates"))
			)
			->add(div("card-body")
				->add($this->table())
			);
	}
	
	public function table()
	{
            
		$table=table("table table-sm table-bordered")
			->attr('data-x-mod','exchange-rate');
		$thead=thead()
			->add(tr()
				->add(th()
					->attr("style","width:19%")
					->add("Currency (float)")
				)
				->add(th()
					->add("Base (Unit)")
					->attr("style","width:19%")
				)
				->add(th()
					->add("Date")
					->attr("style","width:19%")
				)
				->add(th()
					->add("Rate")
					->attr("style","width:19%")
				)
				->add(th()
					->add("Report")
					->attr("style","width:24%")
				)
			);
		$tbody=tbody()
			->add(
				tr()
				->add(td()
					->add(
						$this->select(Config::init()->defaultCurrency)
					)
				)
				->add(td()
					->add(
						$this->select(Config::init()->defaultCurrency,1)
					)
				)
				->add(td()
					->add(input("form-control form-control-sm m-d")
						->attr([
							"name"=>"date","required"=>"required","data-addon"=>"datepicker",
							"data-pattern"=>DATE_RGX ,"value"=>date("Y-m-d")
						])
					)
				)
				->add(td()
						->add(input("form-control form-control-sm")
							->attr([
								"type"=>"number","name"=>"rate",
								"data-pattern"=>CURRENCY_RGX,
								"value"=>1,"disabled"=>"disabled"
							])
						)
					)
					
				->add(td('report'))
			);
			foreach($this->model("Currency","Base")->select() as $row)
			{
				if($row["id"]==Config::init()->defaultCurrency)
				{
					continue;
				}
				$tbody->add(tr()
					->add(td()
						->add(
							$this->select($row["id"])
						)
					)
					->add(td()
						->add(
							$this->select(Config::init()->defaultCurrency,1)
						)
					)
					->add(td()
						->add(input("form-control form-control-sm")
							->attr([
								"data-addon"=>"datepicker","name"=>"date",
								"data-pattern"=>DATE_RGX,"value"=>date("Y-m-d"),
								"required"=>"required"
							])
						)
					)
					->add(td()
						->add(input("form-control form-control-sm")
							->attr([
								"type"=>"number","name"=>"rate","required"=>"required",
								"data-pattern"=>CURRENCY_RGX,"step"=>"any"
							])
						)
					)
					->add(td('report'))
				);
			}
		
		return $table->add($thead)->add($tbody)->add(tfoot()
			->add(tr()
				->add(td()
					->attr("colspan",5)
					->add(button("btn btn-sm btn-block btn-primary save")
						->add("Save Exchange Rates")
					)
				)
			)
		);
	}
	
	private function select($default,$base=false)
	{
		return \Lib\Combo::init()
			->set_model(["Currency","Base"])
			->set_default($default)
			->set_meta(["disabled"=>"disabled"])
			->set_name($base?"base":"currency")
			->required()
			->html();
	}
}