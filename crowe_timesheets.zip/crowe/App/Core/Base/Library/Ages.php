<?php

namespace Core\Base\Library;

use Lib\Factory;

class Ages{
	
	public $filter=[
	    "table"=>"records",
	    "alias"=>"x",
	    "join"=>[
	        "join"=>[
	            ["rates","records.rate","rates.id",["records.active"=>1]],
	            ["sources","sources.record","records.id"],
	            ["doctypes","doctypes.id","sources.doc_type"],
	        ]
	    ],
	    "where"=>[
			"due"=>["<=","{NOW()}"],"accrual"=>1
		],
	    "select"=>[
	        "due","amount*reciprocal as amount","paid*reciprocal as paid",
	        "contact"//,"amount*reciprocal-paid*reciprocal as bal"
	    ]
	];
	
	public function html()
	{
	    $row=div("row")->attr('data-x-mod','ages');
		$mod=Factory::app("Record","Base");
		$row->add($this->col1($mod));	
		$row->add($this->col2($mod));	
		$row->add($this->col3($mod));	
		$row->add($this->col4($mod));	
		$row->add($this->col5($mod));
		$row->add($this->col6($mod));	
		return $row;
	}
	
	public function col1($mod)
	{
		return div("col-xs-6 col-md-6 col-lg-6")
			->add(h2("fa")->add("DEBTORS"));
	}
	
	public function col2($mod)
	{
		return div("col-xs-6 col-md-6 col-lg-6")
			->add(h2("fas")->add("CREDITORS"));
	}
	
	public function col3($mod)//Aging Debtors
	{
		return $this->col4($mod,"OVERDUE DEBTORS","Receipt");
	}
	
	public function col4($mod,$title="OVERDUE CREDITORS",$type="Payment")//Aging Creditors
	{
	    $this->filter["where"]["doctypes.type"]=$type;
	    $value=$mod->selectx([
	        "table"=>$this->filter,
	        "select"=>["sum(amount-paid) as value"]
	    ]);//x($value);x(qd(),8);
	    $count=$mod->selectx([
	        "table"=>[
	            "table"=>$this->filter,
	            "alias"=>"y",
	            "select"=>["sum(amount-paid) as bal"],
	            "group"=>[
	                "contact"
	            ]
	        ],
	        "select"=>["count(*) as num"]
	    ]);//x($value);x(qd(),8);
	    $val=isset($value[0])&&isset($value[0]["value"])?num($value[0]["value"]):0.00;
	    $num=isset($count[0])&&isset($count[0]["num"])?(int)($count[0]["num"]):0;//x($value);
	    return div("col-xs-6 col-md-6 col-lg-6")
			->add($this->box($title,[
			    "label1"=>$val,"label2"=>$num
			],[
			    "type"=>$type=="Payment"?"card-gradient-danger":"card-gradient-success",
			    "icon"=>$type=="Payment"?"mdi mdi-basket-minus-outline":"mdi mdi-basket-plus-outline"
			])
	    );
	}
	
	
	public function col5($mod)//Aging Creditors
	{
	    return $this->col6($mod,"DEBTORS BECOMING DUE IN 30 DAYS","Receipt");
	}
	
	
	public function col6($mod,$title="CREDITORS BECOMING DUE IN 30 DAYS",$type="Payment")//Aging Creditors
	{
	    $this->filter["where"]["doctypes.type"]=$type;
	    $this->filter["where"]["records.due"]=["<","{(CURRENT_DATE + INTERVAL 30 DAY)}"];
	    $this->filter["_and"]["records.due"]=[">","{CURRENT_DATE}"];
	    $value=$mod->selectx([
	        "table"=>$this->filter,
	        //"aka"=>"records",
	        "select"=>["sum(amount-paid) as value"]
	    ]);//x(qd(),9);
	    $count=$mod->selectx([
	        "table"=>[
	            "table"=>$this->filter,
	            "alias"=>"y",
	            "select"=>["sum(amount-paid) as bal"],
	            "group"=>[
	                "contact"
	            ]
	        ],
	        "select"=>["count(*) as num"]
	    ]);
	    $val=isset($value[0])&&isset($value[0]["value"])?num($value[0]["value"]):0.00;
	    $num=isset($count[0])&&isset($count[0]["num"])?(int)($count[0]["num"]):0;//x($value);
	    return div("col-xs-6 col-md-6 col-lg-6")
	    ->add($this->box($title,[
	        "label1"=>$val,"label2"=>$num
	    ],[
	        "type"=>$type=="Payment"?"card-gradient-danger":"card-gradient-success",
	        "icon"=>$type=="Payment"?"mdi mdi-basket-minus-outline":"mdi mdi-basket-plus-outline"
	    ])
	        );
	}
	private function box($title,$content=[],$styles=[])
	{
	    $label1=isset($content["label1"])?$content["label1"]:"";
	    $label2=isset($content["label2"])?$content["label2"]:"";
	    $style=isset($styles["type"])?$styles["type"]:"card-gradient-secondary";
	    $icon=isset($styles["icon"])?$styles["icon"]:"flaticon-user";
	    //<div class="ms-card card-gradient-warning ms-widget ms-infographics-widget">
	    return div("ms-card ms-widget ms-infographics-widget ".$style)
	    //<div class="ms-card-body media">
    	    ->add(div("ms-card-body media")
    	       ->add(div("media-body")
    	           ->add(h6()->add($title)) 
    	           ->add(p("ms-card-change")
    	               ->add(i("fa fa-dollar-sign"))
    	               ->add(span(["style"=>"color:#ffffff !important;"])->add($label1))
                   ) 
    	           ->add(p("fs-12")
    	               ->add(i("fa fa-users"))
    	               ->add(span(["style"=>"color:#ffffff !important;"])->add($label2))
                   )
               )
    	    )
    	    ->add(i($icon));
	}
}