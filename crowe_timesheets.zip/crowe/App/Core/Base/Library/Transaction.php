<?php

namespace Core\Doc\Models;

use Core\Gs\Library\Ratedmodel as Model;
use Lib\Factory as Lf;
use Core\Gs\Library\Config;
use Core\Doc\Library\Lock;

class Record extends Model
{
    use Lock;
    
    public $_rep_=['comment'];
    
    public function _setup()
    {
        return [
            'location'=>_foreign([
                'model'=>['Location','Gs'],
                'null'=>1
            ]),
            'currency'=>_foreign([
                'model'=>['Currency','Gs']
            ]),
            'rate'=>_foreign([
                'model'=>['Rate','Gs']
            ]),
            'location'=>_foreign([
                'model'=>['Location','Gs'],
                'null'=>1
            ]),
            'source'=>_foreign([
                'model'=>['Source','Base']
            ]),
            'ref'=>_char([
                'null'=>1,'hide'=>1,'index'=>1
            ]),
            'contact'=>_foreign([
                'model'=>['Contact','Gs'],'null'=>1
            ]),
            'debit'=>_foreign([
                'model'=>['Account','Base'],'null'=>1
            ]),
            'credit'=>_foreign([
                'model'=>['Account','Base'],'null'=>1
            ]),
            'journaled'=>_integer([
                'default'=>1,'hide'=>1,
                'options'=>["No","Yes","Never"]
             ]),
             'type'=>_char([
                'choices'=>["Receipt","Payment","Other"]
             ]),
            'date'=>_date(),
            'comment'=>_char(['null'=>1,"pattern"=>"/^[a-zA-Z0-9\/\-\,\(\)\+\.\:\$ ]+$/"]),
            'amount'=>_decimal(["pattern"=>'/^-?[0-9]\d*(\.\d+)?$/']),
            'tax'=>_decimal(['null'=>1]),
            'paid'=>_decimal(['default'=>0,'hide'=>1]),
            'active'=>_integer([
                'default'=>1,'hide'=>1,
                'options'=>["No","Yes"]
            ])
            'active'=>_integer([
                'default'=>1,'hide'=>1,
                'options'=>["No","Yes"]
            ])
        ];
    }
    public function insert(array $data, $table = false) {//x($data,9);
        if(!isset($data['slu'])||!$data["slu"])
        {
            $data['slu']=Config::init()->defaultLocation;
        }
        if(!isset($data['currency'])||!$data["currency"])
        {
            //$data['currency']=Config::init()->defaultBaseLocation;
        }
        if($this->isLocked($data)){
            return false;
        }
        return parent::insert($data, $table);
    }
    
    public function update(array $data=[], $cr=[], $table=false)
    {
        if($this->isLocked($data)){
            return false;
        }
        return parent::update($data, $cr, $table);
    }
    
    public function isLocked($data){
        return $this->locked($data)&&$this->isNotEntry($data);
    }
    
   
    
    
    
    public function isNotEntry($data){
        $mod=Lf::app("Source","Doc");
        $data=$mod->read([
            "where"=>[
                "model"=>["in"=>["Depreciation","Entry"]],
                "id"=>$data["source"]
            ]
        ]);
        //empty data mean source is not entry or deprecition
        return empty($data);
    }
    
    public function setAmount($amnt)
    {
        return currency($amnt);
    }
    
    public function setPaid($amnt)
    {
        return currency($amnt);
    }
    
}