<?php
namespace Core\Base\Library;

use Core\Base\Library\AbView;


class LocationsView extends AbView
{
    use \Lib\Init;
    
    public function form(){
        return false;
    }
    
    public
    		$_title="Locations",
    		$url="base/locations/create",
			$types="Locations",
            $type="Location";
    
}