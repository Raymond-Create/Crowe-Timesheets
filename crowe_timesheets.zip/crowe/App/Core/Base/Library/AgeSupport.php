<?php

namespace Core\Base\Library;


use Lib\Factory as Lf;

class AgeSupport{
    
    public $_query; 
    private
        $_type,$_contact;
    
    public function set_type($type){
        $this->_type=$type;
    }
    
    public function set_contact($contact){
        $this->_contact=$contact;
    }
    
    public function aged30(){
        return $this->aged("under",30);
    }
    
    public function aged60(){
        return $this->aged("between",60,90);
    }
    
    public function aged90(){
        return $this->aged("between",90,60);
    }
    
    public function aged30plus(){
        return $this->aged("beyond",30);
    }
    
    public function aged60plus(){
        return $this->aged("beyond",60);
    }
    
    public function aged90plus(){
        return $this->aged("beyond",90);
    }
    
    public function aged($type,$days1,$days2=false){
        $filter=[
            "table"=>Statement::$query,
            //"alias"=>"records",
            "select"=>["sum(ndebit) as lft","sum(ncredit) as rght","sum(ndebit-ncredit) as net"]
        ];
        if($type=="under"){
            $filter["where"]["date"]=[">","{(CURRENT_DATE - INTERVAL $days1 DAY)}"];
        }
        if($type=="beyond"){
            $filter["where"]=["date"=>["<","{(CURRENT_DATE - INTERVAL $days1 DAY)}"]];
        }
        if($type=="between"){
            $filter["where"]["date"]=[
                "between"=>[
                    "{(CURRENT_DATE - INTERVAL $days1 DAY)}",                
                    "{(CURRENT_DATE - INTERVAL $days1 DAY)}"
                ]
            ];
        }
        if($this->_contact){
            $filter["where"]["contact"]=$this->_contact;
        }
        $mod=Lf::app("Record","Base");
        $data=$mod->select($filter);
        $return=isset($data[0])&&isset($data[0]["net"])&&$data[0]["net"]?$data[0]["net"]:0;
        return $this->_type=="creditor"?-1*$return:$return;
    }
    public function read(){
        $this->aged60();
    }
    
   
}
