<?php
namespace Core\Base\Library;

class AccessView extends AbView
{
    use \Lib\Init;
    
    
    public
        $_title="Employees",
        $open_title="",
        //$url="truck/triporders/create",
        $types="Employees",
        $type="Employee",
        $drop=[
            "Pay Roll"=>"hr/payroll",
            "Employees"=>"hr/employees",
            "Designations"=>"hr/designations",
            "Departments"=>"hr/departments",
            "Settings"=>"hr/payconfigs"
        ];
    
}

