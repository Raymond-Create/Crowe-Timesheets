<?php

namespace Core\Base\Library;
use Lib\Factory;
//php_ini_loaded_file()

class PayLink{
    
    public $accrual,$realisation,$base_amount;
    
    public static function init($realisation=null,$accrual=null)
    {
        return new self($realisation,$accrual);
    }
    
    public function __construct($realisation=null,$accrual=null)
    {
       if($realisation)
       {
           $this->set_realisation($realisation);
       }
       if($accrual)
       {
           $this->set_accrual($accrual);
       }
    }
    
    public function set_realisation($realisation)
    {
        $this->realisation=$realisation;
    }
    
    public function set_base_amount($base_amount)
    {
        $this->base_amount=$base_amount;
    }
    
    public function set_accrual($accrual){
        $this->accrual=$accrual;
    }
    
    public function unlink($id=null){
        $doc=Factory::app("Doc","Base");
        $real=Factory::app("Record","Base");
        $accr=Factory::app("Record","Base");
        try{
            if($id){
                $pay=Factory::app("Payment","Base");
                $pay->get($id);//x($pay->data(),9);
                if(!$pay->id)
                {
                    throw new \Exception("Payment Link not found");
                }
                $this->set_realisation($pay->realisation);
                $this->set_accrual($pay->accrual);//x($this,8);
            }
            //find accrual rate
            $acFilter=$accr->read([
                "join"=>[
                    "join"=>[
                        ["rates","records.rate","rates.id"]
                    ]
                ],
                "select"=>["rates.rate"],
                "where"=>["records.id"=>$this->accrual]
            ]);
            $ac=$accr->read($acFilter);
            $reFilter=$acFilter;
            $reFilter["where"]["records.id"]=$this->realisation;
            //find accrual rate
            $re=$real->read($reFilter);
            $mytrans=!$doc->trans();
            if($mytrans){
                $doc->begin();
            }
            if(empty($ac))
            {
                throw new \Exception("Accrual record not found");
            }
            $accr->get($this->accrual);
            $real->get($this->realisation);
            $payData=$pay->read([
                "where"=>[
                    "realisation"=>$this->realisation,"accrual"=>$this->accrual
                ]
            ]);
            if(empty($payData))
            {
                throw new \Exception("Payment record not found");
            }
            if(!$this->base_amount){
                $this->set_base_amount($payData[0]["amount"]);
            }
            $payDel=$pay->remove([
                "where"=>["id"=>$payData[0]["id"]]
            ]);//x(qd(),9);
            if(empty($payDel))
            {
                throw new \Exception("Payment record not deleted");
            }
            $accrAmount=currency($this->base_amount/$ac[0]["rate"]);
            $realAmount=currency($this->base_amount/$re[0]["rate"]);
            //TODO
            //check if payment incrementation does not exceed amount
            //if($acc->amount>=($acc->paid+$amount))
            $real->paid-=$realAmount;
            $accr->paid-=$accrAmount;
            $realId=$real->save();
            $accrId=$accr->save();//x([$realId,$accrId],9);
            if(!$accrId){
                throw new \Exception("Payment change not saved");
            }
            if($mytrans){
                $doc->commit();
            }
            return [true,$payDel];
        }
        catch(\Exception $ex)
        {
            if($mytrans){
                $doc->rollback();
            }
            return [false,$ex->getMessage()];
        }
    }
        
    public function link(){
        $doc=Factory::app("Doc","Base");
        $real=Factory::app("Record","Base");
        $accr=Factory::app("Record","Base");
        $acFilter=[
            "join"=>[
                "join"=>[
                    ["rates","records.rate","rates.id"]
                ]
            ],
            "select"=>[
                /*
                "records.id","records.amount",
                "records.paid","rates.rate",
                "records.paid*rates.rate as basePaid",
                "records.amount*rates.rate as baseAmount"*/
                "records.amount*rates.rate as baseAmount","rates.rate"
            ],
            "where"=>["records.id"=>$this->accrual]
        ];
        $reFilter=$acFilter;
        $reFilter["where"]["records.id"]=$this->realisation;
        //find accrual rate
        $ac=$accr->read($acFilter);
        //find realisation base amount
        $re=$real->read($reFilter);
        try{
            $mytrans=!$doc->trans();
            if($mytrans){
                $doc->begin();
            }
            if(empty($re))
            {
                throw new \Exception("Realisation record not found");
            }
            if(empty($ac))
            {
                throw new \Exception("Accrual record not found");
            }
            if(!$this->base_amount){
                $this->set_base_amount($re[0]["baseAmount"]);
            }
            //Create Payment
            $pay=Factory::app("Payment","Base");
            $accr->get($this->accrual);
            $real->get($this->realisation);
            $pay->realisation=$this->realisation;
            $pay->accrual=$this->accrual;
            $pay->amount=currency($re[0]["baseAmount"]);
            $payId=$pay->save();
            //Update accrual paid
            if($payId){
                $accrAmount=currency($this->base_amount/$ac[0]["rate"]);
                $realAmount=currency($this->base_amount/$re[0]["rate"]);
                //TODO
                //check if payment incrementation does not exceed amount
                //if($acc->amount>=($acc->paid+$amount))
                $real->paid+=$realAmount;
                $accr->paid+=$accrAmount;
                $real->save();
                $accrId=$accr->save();
                if(!$accrId){
                    throw new \Exception("Payment change not saved");
                }
            }
            else{
                throw new \Exception("Payment not saved");
            }
            if($mytrans){
                $doc->commit();
            }
            return [true,$payId];
        }
        catch(\Exception $ex)
        {
            if($mytrans){
                $doc->rollback();
            }
            return [false,$ex->getMessage()];
        }
    }
}
