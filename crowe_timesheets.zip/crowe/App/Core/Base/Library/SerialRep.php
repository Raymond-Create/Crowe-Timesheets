<?php


namespace Core\Base\Library;


trait SerialRep{
	
		public function serial($prefix,$number,$date)
		{
				$year=date("Y",strtotime($date));
				if(config("serial")=="PN/Y"){
					return $prefix.$number.'/'.$year;
				}else{
					return $prefix.$number.$year;
				}
		}
	
}