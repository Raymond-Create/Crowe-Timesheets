<?php
namespace Core\Base\Library;

use Core\Base\Library\AbView;


class ReportsView extends AbView
{
    use \Lib\Init;
    
    
    public
    		$_title="Reports",
    		$url="",
			$types="Reports",
            $type="Reports";
    
}