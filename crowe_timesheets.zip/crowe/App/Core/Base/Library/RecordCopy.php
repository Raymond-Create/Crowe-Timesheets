<?php

namespace Core\Doc\Library;

use Lib\LibraryFactory as Lf;

class DocCopy
{
    use \Lib\Init;
    
    public function __construct($id=null)
    {
        $this->id=$id;
        $this->mod=Lf::app("Document","Doc");
        $this->mod->get($id);
    }
	
    public function html()
    {
       return div("row")->attr("data-x-mod","copy-document")
            ->add(div("col-xs-3 col-md-12")
                ->add(div("card")
                    ->add(div("card-header")
                        ->add(h4()
                            ->add(i("fa fa-copy"))
                            ->add(span()->add("Make Document Copy"))
                        )
                    )
                    ->add(div("card-body")
                        ->add(div("row mt-1")
                            ->add(div("col-md-3  col-xs-12")
                                ->add(label("control-label")->add("Attention"))
                            )
                            ->add(div("col-md-9 col-xs-12")
                                ->add(input("form-control")
                                    ->attr("value",$this->mod->attention)
                                    ->attr("placeholder","Attention")
                                    ->attr('data-pattern',CHAR_RGX)
                                    ->attr("name",'attention')
                                )
                            )
                        )
                         ->add(div("row mt-1")
                            ->add(div("col-md-3  col-xs-12")
                                ->add(label("control-label")->add("Customer"))
                            )
                            ->add(div("col-md-9 col-xs-12")
                                ->add(\Lib\BootSelect::init()
                                    ->set_placeholder('Select Customer')
                                    ->set_default($this->mod->customer)
                                    ->set_model(['Contact','Gs'])
                                    ->set_name('customer')  
                                    ->required()
                                    ->html()
                                )
                            )
                        )
                       
                        ->add(div("row mt-1")
                            ->add(div("col-md-3 col-xs-12")
                                ->add(label("control-label")->add("Date"))
                            )
                            ->add(div("col-md-9 col-xs-12")
                                ->add(input("form-control")
                                    ->attr("data-addon","datepicker")
                                    ->attr("value",$this->mod->date)  
                                    ->attr("data-pattern",DATE_RGX)  
                                    ->attr("required","required") 
                                    ->attr("name","date")
                                )
                            )
                        )
                        ->add(div("row mt-1")
                            ->add(div("col-md-3 col-xs-12")
                                ->add(label("control-label")->add("Due Date"))
                            )
                            ->add(div("col-md-9 col-xs-12")
                                ->add(input("form-control")
                                    ->attr("data-addon","datepicker")
                                    ->attr("value",$this->mod->due)  
                                    ->attr("data-pattern",DATE_RGX)  
                                    ->attr("name","due")  
                                )
                            )
                        )
                        ->add(div("row mt-1")
                            ->add(div("col-md-3 col-xs-12")
                                ->add(label("control-label")->add("Type"))
                            )
                            ->add(div("col-md-9 col-xs-12")
                                ->add(select('form-control')
                                    ->attr('name','type')
                                    ->attr('required','required')
                                    ->attr('data-pattern','/^(Invoice|Quotation)$/')
                                    ->add(option()
                                        ->attr("text","Document Type")
                                        ->attr("value","")
                                    )
                                    ->add(option()
                                         ->attr("text","Invoice")
                                        ->attr("value","Invoice")
                                        ->attr(
                                            $this->mod->type=="Invoice"?"selected":"data-ignore",
                                            $this->mod->type=="Invoice"?"selected":"data-ignore"
                                        )
                                    )
                                    ->add(option()
                                        ->attr("text","Quotation")
                                        ->attr("value","Quotation")
                                        ->attr(
                                            $this->mod->type=="Quotation"?"selected":"data-ignore",
                                            $this->mod->type=="Quotation"?"selected":"data-ignore"
                                        )
                                    )
                                )
                            )
                        )
                        ->add(div("row mt-1")
                            ->add(div("col-md-3 col-xs-12")
                                ->add(label("control-label pull-right")->add("Location"))
                            )
                            ->add(div("col-md-9 col-xs-12")
                                ->add(\Lib\BootSelect::init()
                                    ->set_placeholder('Select Location')
                                    ->set_default($this->mod->slu)
                                    ->set_model(['Location','Gs'])
                                    ->set_name('slu')
                                    ->required()
                                    ->html()
                                )
                            )
                        )
                        ->add(div("row mt-1")
                            ->add(div("col-md-3  col-xs-12")
                                ->add(label("control-label")->add("Currency"))
                            )
                            ->add(div("col-md-9 col-xs-12")
                                ->add(\Lib\BootSelect::init()
                                    ->set_placeholder('Select Currency')
                                    ->set_default($this->mod->currency)
                                    ->set_model(['Currency','Gs'])
                                    ->set_name('currency')
                                    ->required()
                                    ->html()
                                )
                            )
                        )
                    )
                    ->add(div("card-footer")
                        ->add(div("row")
                            ->add(div("col-md-12 col-xs-12")
                                ->add(button("btn btn-block btn-submit btn-primary")
                                   ->add(i("fa fa-file-medical"))    
                                   ->add(span()->add("Create Copy"))  
                                )
                                ->add(input()
                                   ->attr("value",$this->mod->id)
                                   ->attr("type","hidden")
                                   ->attr("name","id") 
                                )
                            )
                        )
                    )
                )   
            );
    }
    
    public function row1()
    {
        
    }
    
    public function save($post)
    {
        $cst=Lf::app("Cost","Doc");
        $mod=Lf::app("Document","Doc");
        $iln=Lf::app("Iline","Doc");
        if($post["attention"]){
            $mod->attention=$post["attention"];
        }
        $mod->due=$post["due"];
        $mod->date=$post["date"];
        $mod->customer=$post["customer"];
        $mod->type=$post["type"];
        $mod->slu=$post["slu"];
        $mod->curency=$post["currency"];
        $data=$this->mod->data()[0];
        $lines=$iln->select([
            "where"=>["document"=>$this->mod->id]
        ]);
        foreach ($data as $key=>$value)
        {
            if(isset($post[$key])|| in_array($key,["id","number"]) ){
                continue;
            }
            $mod->$key=$value;
        }
        try{
            $cst->begin();
            foreach ($data as $key=>$value)
            {
                if(isset($post[$key])|| in_array($key,["id","number"]) ){
                    continue;
                }
                $mod->$key=$value;
            }
            $dc=$mod->save();
            $this->addLines($lines,$dc);
            $cst->commit();
            return $dc;
        } catch (Exception $ex){
            $cst->rollback();
            return false;
        }
    }
    
    public function addLines($lines,$dc){
        if(!$dc){
            return;
        }
        foreach ($lines as $line)
        {
            $ln=Lf::app("Iline","Doc");
            foreach ($line as $key=>$value)
            {
                if(in_array($key,["id","document"]) ){
                    continue;
                }
                $ln->$key=$value;
                $ln->document=$dc;
            }
            $ln->save();
        }
            
    }
}