<?php

namespace Core\Base\Library;

use Lib\Factory as Lf;
use Lib\Session;
use Lib\ID;
class Config
{
    use \Lib\Init;

    private $model=null,$user=false;

    public function __construct($user=false){
        $this->model=\Lib\TableFixer::model(Lf::app('Setting','Base'));
        $this->user=$user;
    }

    public function __set($key,$value){
        $this->model->fetch([
            "where"=>[
                "name"=>strtoupper($key),
                "user"=>$this->user?Session::get(ID::get()):null
            ]
        ]);
        $this->model->name=$key;
        $this->model->value=$value;
        if($this->user)
        {
            $this->model->user=Session::get(ID::get());
        }
        return $this->model->save();
    }

    public function __get($key){
        $this->model->fetch([
            "where"=>[
                "name"=>strtoupper($key),
                "user"=>$this->user?Session::get(ID::get()):null
            ]
        ]);
        return $this->model->value;
    }

    public function id($key){
        $this->model->fetch([
            "where"=>[
                "name"=>$key,
                "user"=>$this->user?Session::get(ID::get()):null
            ]
        ]);
        return $this->model->id;
    }
}