<?php
namespace Core\Base\Library;

class AccessView extends AbView
{
    use \Lib\Init;
    
    
    public
        $drop=[
            "Roles"=>"base/axroles",
            "User Roles"=>"base/axuserroles",
            "Role Menus"=>"base/axrolemenus"
        ];
    
}

