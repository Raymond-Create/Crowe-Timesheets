<?php


namespace Core\Base\Library;

use Lib\Factory;
use Lib\Session;
use Lib\ID;

class Menu{
    
    public static function init()
    {
        return new self;
    }
    
    public function html()
    {
        //<ul class="accordion ms-main-aside fs-14" id="side-nav-accordion">
        $ul=ul("accordion ms-main-aside fs-14")
        ->attr("data-x-mod","side-nav-accordion")
        ->attr("id","side-nav-accordion");
        $menus= \Lib\TableFixer::init("Menu","Base");
        $data=$menus->read([
            "where"=>["cluster"=>"root","menus.active"=>1],
            "join"=>[
                "join"=>[
                    ["categories","menus.category","categories.id"]
                ]
            ],
            "select"=>["menus.*","categories.name"],
            "order"=>[["categories.name","menus.title"],"DESC"]
        ]);//x($data,7);
        foreach($data as $row){
            if($row["name"]=="LINK GROUP")
            {
                $ul->add($this->add_group($row));
            }
            else{
                $ul->add($this->link($row));
            }
        }//x($ul,9);
        return $ul;
    }
    
    public function add_group($row,$parent="side-nav-accordion")
    {
        $li=li("menu-item");
        $li->add(a("has-chevron")
            ->attr([
                "href"=>"#","data-toggle"=>"collapse",
                "data-target"=>"#".$row["url"],
                "aria-expanded"=>"false",
                "aria-controls"=>$row["url"]
            ])
            ->add(span()->add(i($row["icon"]." fs-16")))
            ->add(span()->add($row["title"]))
            );
        return $this->add_links($li,$row["url"],$parent);
    }
    public function add_links($li,$cluster,$parent)
    {  ;
        $model=Factory::app("Menu","Base");
        $data=$model->read([
            "where"=>[
                "cluster"=>$cluster,"menus.active"=>1
            ],
            "join"=>[
                "join"=>[
                    ["categories","menus.category","categories.id"]
                ]
            ],
            "select"=>["menus.*","categories.name"],
            "order"=>[["categories.name","menus.title"],"DESC"]
        ]);
        $ul=ul([
            "id"=>$cluster,"class"=>"collapse",
            "aria-labelledby"=>$cluster,"data-parent"=>"#$parent"
        ]);
        foreach ($data as $row){
            if($row["name"]=="LINK GROUP")
            {
                $l=$this->add_group($row,$cluster);
            }
            else{
                $l=$this->link($row);
            }//x($l);
            if($l){
                $ul->add($l);
            }
        }
        return $li->add($ul);
    }
    public function id_access($id)
    {
        return $this->link_access($id, "id");
    }
    
    public function title_access($id)
    {
        return $this->link_access($id, "title");
    }
    
    public function id_url($id)
    {
        return $this->link_access($id, "url");
    }
    
    public function link_access($id,$field){
        return $this->link([$field=>$id],true);
    }
    
    private function link($data,$access=false){
        //user id
        $userId=Session::get(ID::get());
        //get create model
        $model=Factory::app("MenuAccess","Authentication");
        $model->tableExists();
        $userModel=Factory::app("User","Authentication");
        $userModel->fetch(["where"=>["user_id"=>$userId]]);//x($userModel->data(),8);
        $admin=$userModel->admin;
        $dat=$model->read([
            "where"=>[
				"role"=>$userModel->role,"menu"=>$data["id"]//,"active"=>1
			]
        ]);
        $role=($dat&&!empty($dat));
        $dat=$model->read([
            "where"=>[
				"id"=>$userId,"menu"=>$data["id"]//,"active"=>1
			]
        ]);
        $user=($dat&&!empty($dat));
        $bool=($admin||$user||$role);
        if($access)
        {
            return $bool;
        }
        if($bool){
            //<li> <a href="../dashboard/web-analytics.html">Web Analytics</a> </li>
            return li()->add(a("anchor-link")
                ->attr("href","#")
                ->attr("data-menu",$data["id"])
                ->attr("data-value",$data["url"])
                ->add(i($data["icon"]." ml-1 mr-3"))
                ->add(span()->add($data["title"]))
            );
        }
        
        return null;
    }
}
/*
     <!-- Pages -->
        <li class="menu-item">
          <a href="#" class="has-chevron" data-toggle="collapse" data-target="#pages" aria-expanded="false" aria-controls="pages">
            <span><i class="material-icons fs-16">insert_drive_file</i>Pages</span>
          </a>
          <ul id="pages" class="collapse" aria-labelledby="pages" data-parent="#side-nav-accordion">
            <li class="menu-item">
              <a href="#" class="has-chevron" data-toggle="collapse" data-target="#authentication" aria-expanded="false" aria-controls="authentication">Authentication</a>
              <ul id="authentication" class="collapse" aria-labelledby="authentication" data-parent="#pages">
                <li> <a href="../prebuilt-pages/default-login.html">Default Login</a> </li>
                <li> <a href="../prebuilt-pages/modal-login.html">Modal Login</a> </li>
                <li> <a href="../prebuilt-pages/default-register.html">Default Registration</a> </li>
                <li> <a href="../prebuilt-pages/modal-register.html">Modal Registration</a> </li>
                <li> <a href="../prebuilt-pages/lock-screen.html">Lock Screen</a> </li>
              </ul>
            </li>
            <li> <a href="../prebuilt-pages/coming-soon.html">Coming Soon</a> </li>
            <li> <a href="../prebuilt-pages/error.html">Error Page</a> </li>
            <li class="menu-item"> <a href="../prebuilt-pages/faq.html"> FAQ </a> </li>
            <li class="menu-item"> <a href="../prebuilt-pages/portfolio.html"> Portfolio </a> </li>
            <li class="menu-item"> <a href="../prebuilt-pages/user-profile.html"> User Profile </a> </li>
            <li class="menu-item"> <a href="../prebuilt-pages/invoice.html"> Invoice </a> </li>

          </ul>
        </li>
*/