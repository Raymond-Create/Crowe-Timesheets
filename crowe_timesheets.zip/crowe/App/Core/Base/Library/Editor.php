<?php
namespace Core\Base\Library;

use Lib\Factory as Fac;

abstract class Editor{
    
    public
    $id,
    $status,
    $message,
    $attr,
    $mode="edit",
    $script=false,
    $script2=false,
    $script3=false,
    $title="Editor",
    $pattern="/\d+/",
    $model=["Record","Base"],
    $main_db=false,
    $main_script="editor";
    
    public function __construct($id=null,$mode=null)
    {
        if($id)
        {
            $this->set_id($id);
        }
        if($mode&&in_array($mode, ["view","edit"]))
        {
            $this->set_mode($mode);
        }
    }
    
    public function set_id(int $id):self
    {
        $this->id=$id;
        return $this;
    }
    
    public function set_mode($mode):self
    {
        $this->mode=$mode;
        $this->attr=($mode=="view")?"disabled":"data-w";
        return $this;
    }
    
    public function set_url($url):self
    {
        $this->url=$url;
        return $this;
    }
    
    abstract public function rows();
    
    public function html()
    {
        $div=$this->rows();
        return div("card")
        ->attr("data-x-mod",$this->main_script)
        ->add(div("card-header")
            ->add(h3()->add($this->title))
            )
            ->add(div("card-body")
                ->attr(
                    $this->script?"data-x-mod":"data-ignore",$this->script
                )
                ->add(div("row")
                    ->attr(
                        $this->script2?"data-x-mod":"data-ignore",$this->script2
                    )
                    ->add(div("col-md-12 col-lg-12")
                        ->attr(
                            $this->script3?"data-x-mod":"data-ignore",$this->script3
                        )
                        ->add($div)
                        ->add(input()
                            ->attr([
                                "name"=>"id",
                                "data-pk"=>1,
                                "type"=>"hidden",
                                "value"=>$this->val("id"),
                                "data-pattern"=>$this->pattern
                            ])
                            )
                        ->add(input()
                            ->attr([
                                "name"=>"url",
                                "type"=>"hidden",
                                "value"=>$this->url
                            ])
                            )
                        )
                    )
                )
                ->add(div("card-footer")
                    ->add(div("row")
                        ->add(div("col-md-4 col-lg-4")
                            ->add(button("btn btn-sm btn-block btn-prev mt-0 mb-0 btn-outline-".SUCCESS)
                                ->add($this->mode=="edit"?"List":"Prev")
                                )
                            )
                        ->add(div("col-md-4 col-lg-4")
                            ->add(\Lib\Combo::init()
                                ->set_data(["view"=>"VIEW","edit"=>"EDIT"])
                                ->set_placeholder("CLEAR")
                                ->set_default($this->mode)
                                ->set_name("mode")
                                ->html()
                                )
                            )
                        ->add(div("col-md-4 col-lg-4")
                            ->add(button("btn btn-sm btn-block btn-next mt-0 mb-0 btn-outline-".SUBMIT)
                                ->add($this->mode=="edit"?"Submit":"Next")
                                )
                            )
                        )
                    );
    }
    
    public function val($field)
    {
        $mod=$this->mod();//x($mod,8);
        $mod->get($this->id);//x($mod->data(),8);
        return $mod->$field;
    }
    
    public function save($post)
    {
        $mod=new \Lib\ModelData($this->mod());
        $mod->set_id($this->id);
        $mod->set_data($post);
        $kj=$mod->save();
        $this->message=$kj[0];
        $this->status=$kj[1];
        return $kj[1];
    }
    
    public function mod()
    {
        if($this->main_db){
            return Fac::init()->get_model($this->model);
        }
        return Fac::app($this->model);
    }
    
    public function label($text,$tip="")
    {
        $lb=label(LB);
        if($tip)
        {
            $lb->attr([
                "data-toggle"=>"tooltip","title"=>$tip
            ]);
        }
        return $lb->add($text);
    }
}