<?php

namespace Core\Base\Library;

use Lib\Lang;
use Lib\Table;
use Huchi\Classes\Tag;
use Lib\Factory as Lf;
use Core\Admin\Library\ModuleLib;
use Core\Admin\Library\LicenseLib;
use Core\Authentication\Library\User;
use Core\Authentication\Library\LoginLog;
use Lib\VerticalModelForm as Form;
use Huchi\Classes\Tag as t;
use Lib\ModelData as Md;
use Lib\Session as Sess;
use Lib\Scripts;
use Lout\Menu;
use Lay\Lay;
use Lib\ID;


class Controller extends \Lib\Controller{
    
    public $table=[
        
    ];
    protected function check_request()
    {
        $req=$this->view->application;
        $lib=new LicenseLib(new ModuleLib($req->module));
        $access=$lib->access();
        //x($access,6);
    	
    }
    public function on_init(){
        $this->check_request();
        if($this->isLoggedIn())
        {
            $menu=new Menu();
            $menu->list_menu_roots();
            $this->view->MENUS=Menu::init()->html();
            $this->setcom();
        }else{
            redirect(config("logout"));
        }
        parent::on_init();
        $this->view->ui=LAY .DS. "Files" .DS. config("layout") .DS;
        $this->view->noHeader();
        $this->view->layout=config("layout");
        $this->view->huchijs=Lay::get("huchi-js", "shared");
        $this->view->huchicss=Lay::get("huchi-css", "shared");
        $this->view->pnotifyjs=Lay::get("pnotify-js", "shared");
        $this->view->pnotifycss=Lay::get("pnotify-css", "shared");
        $this->view->assets=SERVER_URL ."/App/Core/Authentication/static";
        $this->view->userFirstName=User::init()->val("name");
        $this->view->avatar=$this->avatar();
        $this->view->noticeCount=0;
        $this->view->msgCount=0;
        LoginLog::init()->activity();
    }
    
    protected function avatar()
    {
        $va=User::init()->val("avatar");
        if($va){
            return $va;
        }
        return REPO . "user-avatar.png";
    }
    
    public function request(){
        return $this->view->application->request;
    }
    
    protected function isLoggedIn()
    {
        return User::id();
    }
    
    public function respond()
    {
        //x('ttt',7);
        $this->set("scripts", Scripts::get("js"));
        $this->set("links", Scripts::get("css"));
        if(isAjax())
        {
            $this->view->noHeader();
        }
        parent::respond();
    }
    
    public function tracking($visitor)
    {
        if($visitor)
        {
            $visitor->processed=implode("/",$this->page);
        }
        /*
         if(!\Lib\Access::linkAllowed($visitor,$this->page))
         {
         if(isAjax())
         {
         $this->json("Error insufficient permissions",0);
         }
         redirect(config("login"));
         }
         */
    }
    
    public function ajax($html)
    {
        if(\isAjax())
        {
            $this->json(
                $html instanceof t?$html->as_list():$html,
                1,$html instanceof t?'htmlObject':"text"
                );
        }
        $this->set('html',$html);
    }
    public function __table($rows,$page):Tag
    {
        $this->table["rows"]=$this->table["rows"]??$rows;
        $this->table["page"]=$this->table["page"]??$page;
        $this->table["model"]=$this->table["model"]??$this->model;
        $this->table["url"]=$this->table["url"]??implode("/",$this->page);
        $table=new Table($this->table);
        $table->set_connection($this->model->getConnection());
        if(!isset($this->show_form))
        {//x(4,7);
            $table->hide_form();
        }
        if($this->post())
        {
            if(isset($this->post['search_filter'])){
                $table->set_seach_filters($this->post['search_filter']);
            }
        }
        return $table->html();
    }
    public function get_lib($id)
    {
        $lib=Lf::lib($this->_lib[0], $this->_lib[1], $id);
        return $lib;
    }
    public function create($id=null,$mode="edit"){//x(7,9);
        if(!is_numeric($id))
        {
            $id=null;
        }
        $lib=$this->get_lib($id);
        if(method_exists($lib, "set_url"))
        {
            $lib->set_url(implode('/', $this->page));
        }
        //x($this->post(),9);
        if(method_exists($lib, "set_mode"))
        {
            $lib->set_mode($mode);
        }
        if($this->post())
        {
            $e=$lib->save($this->post);
            if(!isset($lib->message))
            {
                $message=Lang::get($e?"record-modified":"record-created");
            }
            else{
                $message=$lib->message;
                $e=$lib->status;
            }
            $this->json($message,$e);
        }//x(5,9);
        //$this->_left=$this->_left_2;
        if(method_exists($lib,"set_title"))
        {
            $lib->set_title($this->_left[0]);
        }
        $this->ajax(div('row m-5')
            //->attr('data-x-mod','data-display')
            ->add(div("col-xs-12 col-md-12") 
                ->add($lib->html())
            )
            
        );
    }
    public function records($rows=25,$page=1,$extra=null)
    {
        $table=$this->__table($rows,$page,$extra);
        $this->ajax($table);
    }
    
    public function model_form($module,$model=0,$id=0,$bare=0)
    {
        $mod=Lf::app($module,$model);
        if($mod->table())
        {
            $this->model=$mod;
        }
        if(!$this->model->_struct_[$this->model->pk()]->is_valid($id))
        {
            $id=0;
        }
        $form= Form::init($this->model);
        $form->set_id($id);
        $form->set_model_name($model?[$module,$model]:str_replace("+",NS,$module));
        if($this->post()){
            $this->_put($id,$form->get_model());
        }
        $this->ajax($bare?$form->form():$form->html());
    }
    
    public function options()
    {
        $filter=[];
        if($this->post() && isset($this->post['filter']))
        {
            $filter=jsonToArray(json_decode($this->post['filter']));//x($filter);
        }
        $opt=[["id"=>"","title"=>"Select ".$this->model->table()]];
        $selexn=$this->model->select($filter);
        $combo=\Lib\Combo::opts($selexn,$this->model);
        $return=array_merge($opt,$combo);//x($return,9);
        $this->json($return);
    }
    
    public function combo_data($model,$module)
    {
        $this->model=Lf::app($model,$module);
        $this->options();
    }
    
    public function confirm_box()
    {
        $lib=\Core\Gs\Library\Confirm::init();
        $this->ajax($lib->html($this->post()));
    }
    
    public function remove()
    {
        if($this->post())
        {
            if($this->post["type"]=="delete")
            {
                $state=$this->model->delete($this->post['id']);
                $message=$state?"Delete successiful":"Delete NOT successiful";
            }
            if($this->post["type"]=="decline")
            {
                $state=$this->model->decline_request($this->post['id']);
                $message=$state?"Decline request delete successiful":"Decline request delete NOT successiful";
            }
            if($this->post["type"]=="request")
            {
                $state=$this->model->delete_request($this->post['id']);
                $message=$state?"Request for delete successiful":"Request for delete NOT successiful";
            }
            if($this->post["type"]=="cancel")
            {
                $state=$this->model->cancel_request($this->post['id']);
                $message=$state?"Cancellation of delete request successiful":"Cancellation of delete request NOT successiful";
            }
            $this->json($message,$state);
        }
        $this->json("No data supplied",0);
    }
    public function put($id=null){
        if($this->post())
        {
            $this->_put($id);
        }//x($this->post,9);
        $this->json("No data supplied",0);
    }
    public function read()
    {//x($this->model,9);
        $filter=[];
        if($this->post() && isset($this->post['filter']))
        {
            $filter=jsonToArray(json_decode($this->post['filter']));//x($filter,9);
        }
        $data=$this->model->select($filter);
        //x(qd(),9);
        $this->json($data);
    }
    
    protected function _put($id,$model=null)
    {
        $lib=Md::init($this->model);
        $lib->set_data($this->post);
        $lib->set_id($id);
        $resp=$lib->save();
        $this->json($resp[0],$resp[1]);
    }
    
    protected function setcom(){
        $db=\Lib\Session::get("user_selected_database");
        $model=\Lib\Factory::init()->get_model("Org","Authentication");
        $model->fetch([
            "where"=>["db"=>$db]
        ]);
        $filter=[
            "join"=>[
                "join"=>[
                    ["dbs","dbs.org","orgs.id"]
                ]
            ],
            "where"=>["dbs.user"=>\Lib\Session::get(\Lib\ID::get())],
            "select"=>["db","name"]
        ];
        if(config("dedicated")){
            $filter["where"]["orgs.db"]=config("dedicated");
        }
        $data=$model->read($filter);
        $combodiv=div("mt-0")
            ->attr("data-x-mod","swap");
        $combo=select("form-control form-control-sm")
            ->attr("name","sw-co");
        $div=div("dropdown dropdown-action mt-0")
            ->attr("data-x-mod","swap");
        $div->add(a("action-icon dropdown-toggle")
            ->attr([
                "href"=>"#","data-toggle"=>"dropdown","aria-expanded"=>"false"
            ])
            ->add($model->name)
            );
        $menu=div("dropdown-menu dropdown-menu-right");
        foreach ($data as $row)
        {
            $optconfig=[
                "value"=>$row['db']
            ];
            $attr=["data-db"=>$row['db']];
            if($db==$row["db"]){
                $attr["style"]="color:blue;";
                $optconfig["selected"]="selected";
            }
            $menu->add(a("dropdown-item ")
                ->attr($attr)
                ->add(i("mdi mdi-city-variant-outline mr-2"))
                ->add(span($attr)->add($row['name']))
            );
            $combo->add(option($optconfig)->add($row['name']));
        }
        if(config("swap-type")=="dropdown"){
            $swap=$div->add($menu);
        }else{
            $swap=$combodiv->add($combo);
        }
        $this->set("com",$swap);
    }
}
