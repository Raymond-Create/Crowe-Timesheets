<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

namespace Core\Base\Library;

class Prefix{
    
    public $model,$data,$obj;
    
    public static function set($model,$module)
    {
        $mod= \Lib\Factory::app($model,$module);
        if(!$mod->prefix_desc||!$mod->prefix_desc)
        {
            return false;
        }
        $array=[];
        //doc_type
        //description
        $array['description']=$mod->prefix_desc;
        //        prefix
        $array['prefix']=$mod->_prefix;
        //        yearly_rest
        $array['yearly_rest']=!!$mod->num_reset;
        //        start
        $array['start']=$mod->num_from?:1;
        //        decrement
        $array['decrement']=$mod->num_order?:0;
        $mod2=\Lib\Factory::app("Prefix","Base");
        $mod2->tableExists();
        $mod2->fetch(["where"=>$array]);
        foreach($array as $k=>$v)
        {
            $mod2->$k=$v;
        }
        $id=$mod2->save();
        return $mod2->id?:$id;
    }
    
    public static function init($model,$data)
    {
        return new self($model,$data);
    }
    
    public static function get($model,$data)
    {
        $self=self::init($model,$data);
        return $self->get_prefix();
    }
    
    public function __construct($model,$data){
        $this->obj= \Lib\Factory::app("Prefix","Base");
        $this->obj->tableExists();
        $this->model=$model; 
        $this->data=$data;
    }
    
    public function get_prefix()
    {
        
        $data=$this->data;
        $filter=false;
        if(isset($this->model->_struct_["doc_type"])&&isset($data["doc_type"]))
        {
            $filter=["where"=>["doc_type"=>$data["doc_type"]]];
        }else if(isset($this->model->prefix_desc)){
            $filter=[
                "where"=>["description"=>$this->model->prefix_desc]
            ];
        }
        if($filter)
        {
            $this->obj->fetch($filter);
            if($this->obj->prefix){
                return $this->obj->prefix;
            }
        }
        if(isset($this->model->_prefix)&&$this->model->_prefix){
            return $this->model->_prefix;
        }
        return "NIL";
    }
    
    public function get_initial()
    {
        $this->get_prefix();
        return $this->obj->start?:1;
    }
    
    public function get_order()
    {
        $this->get_prefix();
        return $this->obj->decrement?"asc":"desc";
    }
}