<?php
namespace Core\Base\Library;

class BasesView extends LocationsView
{
    use \Lib\Init;
    
    public
    		$_title="Bases",
    		$url="base/bases/create",
			$types="Bases",
            $type="Base";
    
}