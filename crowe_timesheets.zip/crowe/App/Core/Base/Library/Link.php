<?php

namespace Core\Base\Libraryl

class Link{
	
	use Lib\Factory;
	
	public $data,$id;
	
	public function __construct($id)
	{
		$this->id=$id;
		$this->setup_data();
	}
	
	public function html()
	{
		 return div("card")
		 		->add(div("card-header")
		 			->add(h3()->add(
		 					ucfirst($this->data["type"]). "Allocation"
		 				)
		 			)
		 		)
		 		->add(div("card-body")
		 			->add($this->row1())
		 			->add($this->row2())
		 			->add($this->row3())
		 		)
	}
	
	public function row3()
	{
		return div("row row-3")
			->add(div("col-md-12 col-lg-12 table-responsive")
				->add($this->table())
			);
	}
	
	private function row2()
	{
			return div("row")
			->add(div("col-md-4 col-lg-4")
				->add(\Lib\Combo::init()
					->set_model(["Currency","Base"])
					->set_default($this->data["currency"])
					->set_name("currency")
					->set_meta([
						"disabled"=>"disabled"
					])
					->html()
				)
			)
			->add(div("col-md-4 col-lg-4")
				->add(input("form-control form-control-sm")
					->attr([
						"name"=>"amount",
						"disabled"=>"disabled",
						"value"=>$this->data["amount"]
					])
				)
			)
			->add(div("col-md-4 col-lg-4")
				->add(input("form-control form-control-sm")
					->attr([
						"name"=>"available",
						"disabled"=>"disabled",
						"value"=>$this->data["available"]
					])
				)
			);
	}
	
	private function row1()
	{
			return div("row")
			->add(div("col-md-4 col-lg-4")
				->add(input("form-control form-control-sm")
					->attr([
						"name"=>"date",
						"disabled"=>"disabled",
						"value"=>$this->data["date"]
					])
				)
			)
			->add(div("col-md-4 col-lg-4")
				->add(input("form-control form-control-sm")
					->attr([
						"name"=>"type",
						"disabled"=>"disabled",
						"value"=>$this->data["type"]
					])
				)
			)
			->add(div("col-md-4 col-lg-4")
				->add(input("form-control form-control-sm")
					->attr([
						"name"=>"ref",
						"disabled"=>"disabled",
						"value"=>$this->data["ref"]
					])
				)
			);
	}
	
	private function table()
	{
			$mod=Factory::app("Record","Base");
			$data=$mod->read([
				"join"=>[
					"join"=>[
						["rates r","records.rate","r.id"],
						["payments p","p.realisation","records.id"]
					]
				],
				"where"=>["accrual"=>0,"id"=>$this->id],
				"select"=>[
					"id","ref","date","currency","amount",
					"type","amount-paid as available"				
				]
			]);
			if($data&&!empty($data))
			{
				$this->data=$data[0];
			}
	}
	private function setup_data()
	{
			$mod=Factory::app("Record","Base");
			$data=$mod->read([
				/*
				,*/
				"where"=>["accrual"=>0,"id"=>$this->id],
				"select"=>[
					"id","ref","date","currency","amount",
					"type","amount-paid as available"				
				]
			]);
			if($data&&!empty($data))
			{
				$this->data=$data[0];
			}
	}
}