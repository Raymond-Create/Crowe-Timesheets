<?php 

namespace  Core\Base\Library;

class PdfViewer extends PdfView{
    
    
}