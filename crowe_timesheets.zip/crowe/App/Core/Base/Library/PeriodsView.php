<?php
namespace Core\Base\Library;

class PeriodsView extends LocationsView
{
    use \Lib\Init;
    
    public
    		$_title="Periods",
    		$url="base/Periods/create",
			$types="Periods",
            $type="Period";
    
}