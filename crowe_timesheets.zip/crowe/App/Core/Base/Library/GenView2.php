<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Base\Library;

use Lib\Factory as Lf;
//use Lib\Session as Sess;
use Lib\BinFile as B;
//use Huchi\Tag as t;
/**
 * Description of Invoice
 *
 * @author bchaumba
 */
import('Pdfmake');

class GenView2
{
    
    
    use \Lib\Init;
  
    
    private $id;
    
    protected function content($id){//Lf::app("Description","Doc")->tableExists();
        $container=lst();
        $container
        ->append($this->logoRow())->append(" ")
        ->append($this->line(0.7))->append(" ")
        ->append($this->docNumber())->append(" ")
        ->append($this->titlesRow())->append(" ")
        ->append($this->line(0.7))->append(" ");
        $attr=$this->attribute_col();
        if(!empty($attr))
        {
            $container
            ->append($this->attribute_col())->append(" ")
            ->append($this->line(0.7))->append(" ");
        }
        $container
        ->append($this->body())->append(" ")
        ->append($this->adjusts())->append(" ")
        ->append($this->line(0.7))->append(" ")
        //->append($this->line())->append(" ")
        ->append($this->bankbare());
        
        return $container->rep();
    }
    
    protected function line($width=1){
        return dic()
        ->set("canvas",lst()
            ->append(dic()
                ->set("type",'line')
                ->set("x1",0)
                ->set("y1",5)
                ->set("x2",595-2*40)
                ->set("y2",5)
                ->set("lineWidth",$width)
                )
            );
    }
    protected function logoRow(){
        $row=dic();
        $row->columnGap=10;
        $cols=lst();
        $cols->append(dic()
            ->set("image","logo")
            ->set("width",170)
            );
        $cols->append(" ");
        $cols->append($this->company_details());
        $row->columns=$cols;
        return $row;
    }
    
    protected function titlesRow(){
        //["columns"=>[$this->client($id)," ",$this->doc($id)],"columnGap"=>10]
        $cli=Lf::app("Contact","Base");
        $cli->get($this->rec("contact"));
        $row=dic();
        $cols=lst();
        $cols->append($this->com($cli,9,"left"));
        $cols->append(" ");
        $cols->append($this->docInfo());
        $row->columns=$cols;
        return $row;
    }
    
    private function company_details()
    {
        //$model=\Lib\Factory::init()->get_model("Org","Authentication");
        $com=Lf::init()->get_model("Org","Authentication");
        $com->fetch([
            "join"=>[
                "join"=>[
                    ["dbs","dbs.org","orgs.id"]
                ]
            ],
            "where"=>["orgs.db"=>\Lib\Session::get("user_selected_database")],
            "select"=>["orgs.*"]
        ]);////x($com->data(),9);
        return $this->com($com);
    }
    
    private function com($com,$font=9,$align="right")
    {
        $lst=lst();
        if($com->type&&$this->src("attention"))
        {
            $lst->append(dic()                  //Company address
                ->set("text","ATTENTION: ".$this->doc("attention"))
                ->set("fontSize",$font)
                ->set("alignment",$align)
            );
        }
        $lst->append(dic()                  //Company name
            ->set("text",$com->name)
            ->set("style","header")
            ->set("alignment",$align)
        )
        ->append(dic()                  //Company address
            ->set("text",$com->address ." ")
            ->set("fontSize",$font)
            ->set("alignment",$align)
        )
        ->append(dic()                  //Company email
            ->set("text",$com->email . " ")
            ->set("fontSize",$font)
            ->set("alignment",$align)
        )
        ->append(dic()                  //Company phone
            ->set("text",$com->phone . " ")
            ->set("fontSize",$font)
            ->set("alignment",$align)
        );
        if($com->vat){
            $lst->append(dic()                  //Company vat
                ->set("text","VAT Number: ".$com->vat . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
            );
        }
        if($com->bp){
            $lst->append(dic()                  //Company bp
                ->set("text","BP Number: ".$com->bp . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
            );
        }
        return dic()->set("stack",$lst);
    }
    private function src($field)
    {
        $data=Lf::app("Source","Base")
        ->read([
            "where"=>["record"=>$this->id],
            "select"=>[$field]
        ]);
        return $data&&isset($data[0])&&isset($data[0][$field])?$data[0][$field]:0;
    }
    private function doctype($field)
    {
        $data=Lf::app("Source","Base")
        ->read([
            "join"=>[
                "join"=>[
                    ["doctypes d","d.id","sources.doc_type"]
                ]
            ],
            "where"=>["sources.record"=>$this->id],
            "select"=>["d.".$field]
        ]);
        return $data&&isset($data[0])&&isset($data[0][$field])?$data[0][$field]:"";
    }
    private function rec($field)
    {
        $mod=Lf::app("Record","Base");
        $mod->get($this->id);
        return $mod->$field;
    }
    protected function docNumber(){
        return dic()
        ->set("columns",lst()
            ->append(dic()->append(["text"=>" ","width"=>"30%"]))
            ->append(dic()
                ->set("width","30%")
                ->set("stack",lst()
                    ->append(dic()
                        ->set("text",$this->doctype("name"))
                        ->set("alignment","center")
                        )
                    ->append(dic()
                        ->set("text",$this->src("number") . "/" . date("Y",strtotime($this->rec("date"))))
                        ->set("alignment","center")
                        )
                    )
                )
            )
            ->set("columnGap",10);
    }
    private function styles()
    {
        $a= dic();
        $a->header=dic()->append([
            "fontSize"=> 10,
            "bold"=>"true",
            "fillColor"=>"#DCDCDC"
        ]);
        $a->iright=dic()->append([
            "italics"=> true,
            "alignment"=> 'right'
        ]);
    }
    protected function docInfo(){
        $x = Lf::app("Currency","Base");//x($this->doctype("name"),8);
        $x->fetch(['where'=>['id'=>$this->rec("currency")]]);
        $table = ["table"=>["widths"=>["*","*"],"body"=>[]]];
        $table["table"]["body"][] = [["text"=>$this->doctype("name"),"style"=>"header"],["text"=>"#".$this->src("number"),"style"=>"header"]];
        $table["table"]["body"][] = [["text"=>"Date","fontSize"=>9],["text"=>$this->rec("date"),"fontSize"=>9]];
        $table["table"]["body"][] = [["text"=>"Due Date","fontSize"=>9],["text"=>$this->rec("due")." ","fontSize"=>9]];
        $table["table"]["body"][] = [["text"=>"Order","fontSize"=>9],["text"=>$this->src("order_no"). " ","fontSize"=>9]];
        $table["table"]["body"][] = [["text"=>"Currency","fontSize"=>9],["text"=>$x->rep(),"fontSize"=>9]];
        $table["table"]["body"][] = [["text"=>"Amount","fontSize"=>9],["text"=>num($this->rec("amount")),"fontSize"=>9]];
        return $table;
    }
    
    protected function doc($key){
        $x = Lf::app("Source","Base");
        //$x->tableExists();
        $x->fetch(['where'=>['record'=>$this->id]]);
        return $x->{$key};
    }
    
    protected function body(){
        $table = ["table"=>["widths"=>["10%","38%","13%","13%","13%","13%"],"body"=>[[
            ["text"=>"CODE","fontSize"=>9,"alignment"=>"left","border"=>[0,0,0,1],"fillColor"=>"#D0D0D0"],
			["text"=>"DESCRIPTION","fontSize"=>9,"alignment"=>"left","border"=>[0,0,0,1],"fillColor"=>"#D0D0D0"],
			["text"=>"QUANTITY","fontSize"=>9,"alignment"=>"left","border"=>[0,0,0,1],"fillColor"=>"#D0D0D0"],
			["text"=>"UNIT","fontSize"=>9,"alignment"=>"left","border"=>[0,0,0,1],"fillColor"=>"#D0D0D0"],
            ["text"=>"UNIT PRICE","fontSize"=>9,"alignment"=>"right","border"=>[0,0,0,1],"fillColor"=>"#D0D0D0"],
			["text"=>"AMOUNT","fontSize"=>9,"alignment"=>"right","border"=>[0,0,0,1],"fillColor"=>"#D0D0D0"]]
        ]]];
        $body=Lf::app("SourceLine","Base");//_
        $body->tableExists();
        $rows = $body->select([
            "select"=>[
                "s.code","sourcelines.quantity","sourcelines.price","(sourcelines.quantity*sourcelines.price) as amount","s.units","s.name"
            ],
            "where"=>["sources.record"=>$this->id],
            "join"=>[
                "join"=>[
                    ["sources","sources.id","sourcelines.source"],
                    ["items s","s.id","sourcelines.item"],
                    ["itemtypes ic","s.type","ic.id"]
                ]
            ],
            "order"=>["ic.name","asc"]
        ]);
		$i=1;
        foreach($rows as $row){
			$c=$i%2?"#F8F8F8":"#E8E8E8";
            $table["table"]["body"][] = [//$row["name"],$row["quantity"],,right
                ["text"=>$row["code"],"fontSize"=>8,"alignment"=>"left","border"=>[0,0,0,0],"fillColor"=>$c],
                ["text"=>$row["name"],"fontSize"=>8,"alignment"=>"left","border"=>[0,0,0,0],"fillColor"=>$c],
                ["text"=>num($row["quantity"]),"fontSize"=>8,"alignment"=>"right","border"=>[0,0,0,0],"fillColor"=>$c],
                ["text"=>$row["units"],"fontSize"=>8,"alignment"=>"left","border"=>[0,0,0,0],"fillColor"=>$c],
                ["text"=>num($row["price"]),"fontSize"=>8,"alignment"=>"right","border"=>[0,0,0,0],"fillColor"=>$c],
                ["text"=>num($row["amount"]),"fontSize"=>8,"alignment"=>"right","border"=>[0,0,0,0],"fillColor"=>$c]
            ];
			$i++;
        }
		$table["table"]["body"][] = [
			["text"=>" ","border"=>[0,1,0,0]],
			["text"=>" ","border"=>[0,1,0,0]],
			["text"=>" ","border"=>[0,1,0,0]],
			["text"=>" ","border"=>[0,1,0,0]],
			["text"=>" ","border"=>[0,1,0,0]],
			["text"=>" ","border"=>[0,1,0,0]]
		];
        return $table;
    }
    
    public function dsl($id){
        $co=Lf::init()->get_model("Org","Authentication");
        $co->fetch([
            "where"=>["db"=>\Lib\Session::get("user_selected_database")]
        ]);
        $logo = $co->logo;
        if(!$this->id)
        {
            $this->id=$id;
        }
        return [
            "content"=>$this->content($id),
            "styles"=> [
                "header"=> [
                    "fontSize"=> 10,
                    "bold"=>"true",
                    "fillColor"=>"#DCDCDC"
                ],
                "anotherStyle"=>[
                    "italics"=> true,
                    "alignment"=> 'right'
                ]
            ],
            "images"=>[
                "logo"=>$logo,
                //"huchi"=>$huchi
            ]
        ];
    }
    protected function titles($id){
        return ["columns"=>[$this->client($id)," ",$this->doc($id)],"columnGap"=>10];
    }
    protected function company($model){
        return ["stack"=>[
            ["text"=>$model->name." ","style"=>"header","alignment"=>"right"],
            //["text"=>$this->on("contact","company")." ","fontSize"=>9,"alignment"=>"right"],
            ["text"=>$model->email." ","fontSize"=>9,"alignment"=>"right"],
            ["text"=>$model->phone." ","fontSize"=>9,"alignment"=>"right"],
            ["text"=>$model->address." ","fontSize"=>9,"alignment"=>"right"],
            ["text"=>"VAT: " .$model->vat ." ","fontSize"=>9,"alignment"=>"right"],
            ["text"=>"BP: " . $model->bp ." ","fontSize"=>9,"alignment"=>"right"]
        ]];
    }
    
    protected function adjusts(){
        //return ["columns"=>[["text"=>" ","width"=>"42.3%"],$this->base($id)],"columnGap"=>10];
        $row=dic();
        $row->columnGap=10;
        $cols=lst();
        $cols->append(dic()->append(["text"=>" ","width"=>"59%"]));
        $cols->append($this->base());
        $row->columns=$cols;
        return $row;
    }
    protected function bankbare(){
        return ["columns"=>[$this->bank()],"columnGap"=>10];
    }
    
    
    private function base(){
        $table = ["table"=>["widths"=>["*","*"],"body"=>[]]];
        $table["table"]["body"][] = [
            ["text"=>"Sub Total","fontSize"=>9],
            ["text"=>num($this->src("sub_total")),"fontSize"=>9,"alignment"=>'right']
        ];
        $table["table"]["body"][] = [
            ["text"=>"Discount","fontSize"=>9],
            ["text"=>num($this->src("discount")),"fontSize"=>9,"alignment"=>'right']
        ];
        $table["table"]["body"][] = [
            ["text"=>"Discounted Total","fontSize"=>9],
            ["text"=>num($this->src("sub_total")-$this->src("discount")),"fontSize"=>9,"alignment"=>'right']
        ];
        $vat=(float)$this->doc("total")*0.145;
        $tax=is_numeric($this->doc("tax"))&&$this->rec("tax")>0?$this->doc("tax"):$vat;
        $table["table"]["body"][] = [
            ["text"=>"Tax","fontSize"=>9],
            ["text"=>num($tax),"fontSize"=>9,"alignment"=>'right']
        ];
        $table["table"]["body"][] = [
            ["text"=>"Total","bold"=>"true","fontSize"=>9],
            ["text"=>num($this->rec("amount")),"fontSize"=>9,"bold"=>"true","alignment"=>'right']
        ];
        return $table;
    }
    protected function bank(){
        $bank = Lf::app("CashAccount","Base");
        $doc = $bank->select([
            "join"=>[
                "join"=>[
                    ["currencies c","c.id","cashaccounts.currency"]
                ]
            ],
            "select"=>["cashaccounts.name","company","branch","number","c.name as currency"],
            "where"=>["type"=>"Bank"]
        ]);
        $table = ["table"=>["widths"=>["*","15%","20%","20%","20%"],"body"=>[
            [["text"=>"Name","fontSize"=>7],["text"=>"Bank","fontSize"=>7],
                ["text"=>"Branch","fontSize"=>7],["text"=>"Account","fontSize"=>7],["text"=>"Type","fontSize"=>7]
            ]
        ]]];
        foreach($doc as $row){
            $table["table"]["body"][] = [
                ["text"=>$row["name"],"fontSize"=>6],
                ["text"=>$row["company"],"fontSize"=>6],
                ["text"=>$row["branch"],"fontSize"=>6],
                ["text"=>$row["number"] ,"fontSize"=>6],
                ["text"=>$row["currency"] ,"fontSize"=>6]
            ];
        }//x($table,9);
        return $table;
    }
    
    private function attr($field)
    {
        $i=Lf::app("Attribute","Doc");
        $j = $i->select([
            'where'=>['id'=>$this->id]
        ]);
        return (is_array($j) && isset($j[0]) && isset($j[0][$field]))?$j[0][$field]:false;
    }
    
    private function attribute_col(){
        return"";
        $attr=Lf::app("Attribute","Doc")->select(["where"=>["document"=>$this->id]]);
        Lf::app("Description","Doc")->tableExists();//x();
        Lf::app("Attribute","Doc")->tableExists();//x();
        $desc=Lf::app("Description","Doc")->select(["where"=>["document"=>$this->id]]);//x();
        if(empty($attr)&&empty($desc))
        {
            return "";
        }
        return ["columns"=>[$this->desc($desc),$this->attributes($attr)],"columnGap"=>10];
    }
    
    private function desc($desc){
        $table = ["table"=>["widths"=>["*"],"body"=>[
            ["text"=>'DESCRIPTION OF WORK',"style"=>"header","alignment"=>"centre"]
        ]]];
        $table = [
            "table"=>[
                "widths"=>["*"],
                "body"=>[
                    [
                        ["text"=>'DESCRIPTION OF WORK',"style"=>"header"],
                        //["text"=>'VALUE',"style"=>"header"]
                    ]
                ]
            ]
        ];
        foreach($desc as $ds)
        {
            $table["table"]["body"][] = [["text"=>$ds["detail"].' ',"fontSize"=>9]];
        }//x($table,9);
        return $table;
    }
    private function attributes($desc){
        $table = [
            "table"=>[
                "widths"=>["*","*"],
                "body"=>[
                    [
                        ["text"=>'NAME',"style"=>"header"],
                        ["text"=>'VALUE',"style"=>"header"]
                    ]
                ]
            ]
        ];
        foreach($desc as $ds)
        {
            $table["table"]["body"][] = [
                ["text"=>$ds["key"].' ',"fontSize"=>9],
                ["text"=>$ds["value"].' ',"fontSize"=>9]
            ];
        }
        return $table;
    }
    private function banks()
    {
        //$b=
    }
}
