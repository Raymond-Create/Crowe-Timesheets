<?php
namespace Core\Base\Library;

use Core\Base\Library\AbView;


class MenusView extends AbView
{
    use \Lib\Init;
    
    public
    		$_title="Menus",
    	//	$url="base/locations/create",
			$types="Menus",
            $type="Menu";
    
}