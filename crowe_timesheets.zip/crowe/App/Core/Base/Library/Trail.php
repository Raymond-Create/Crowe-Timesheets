<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Base\Library;

use Lib\Access;
use Lib\BaseModel; 
use Core\Base\Library\AuditTrail as At;

class Trail extends BaseModel{
    
    public function _setup(){}
	
    public function setName($name)
    {
    	return strtoupper($name);
    }
	
    public function update_struct(array $array)
    {    
        //Add the active flag
        $array["active"]=_integer([
            "hide"=>1,"default"=>1,
            "options"=>[
                -1=>"Other",
                0=>"Deleted",
                1=>"Active",
                2=>"Request Delete"
            ]
        ]);
        return $array;
    }
	
	public function select(array $cr=[],$table=false){
        if(!$table)
        {
            if(isset($cr["alias"]))
            {
                $field=$cr["alias"].".active";
            }
            else{
                $field=$this->table().".active";
            }
            $cr["where"]=isset($cr["where"])?$cr["where"]:[];
            if(!isset($cr["where"][$field]))
            {
                $cr["where"][$field]=["<>",0];
            }
        }//x($cr);
        return parent::select($cr,$table);
    }
    
    public function selectx(array $cr=[],$table=false){
        return parent::select($cr,$table);
    }
    
    public function modify(array $data=[],$c=[],$table=false)
    {

        if(is_array($c))
        {
            $ids=$this->ids($c,$table);
            if($this->table()=="sources"){
                x($ids);x(qd(),8);
            }
        }
        $affected=0;
        $i=$table?'id':$this->pk();
        $table=$table?:$this->table();
        foreach($ids as $id)
        {
            $state=parent::modify(
                $data,[
                    "where"=>[$table .'.'. $i=>$id]
                ],$table
            );
            if($state)
            {
                At::update($this,$id,$table);
                $affected++;
            }		
        }	
        return $affected;
    }
    
    public function modifyx(array $data=[],$c=[],$table=false)
    {
        
        return parent::modify($data,$c,$table);
    }
  
    public function remove($crit = [], $table = false)
    {	
        $state=parent::modify(["active"=>0],$crit,$table);
        if($state)
        {
            if(is_array($crit))
            {
                $crit=$this->ids($crit,$table);
            }
            At::delete($this,$crit,$table);
        }
        return $state;
    }
    
    public function _remove($crit = [], $table = false)
    {
        return parent::remove($crit, $table);
    }
    
    public function removex($crit = [], $table = false)
    {
        return parent::remove($crit, $table);
    }
    public function insert(array $crit,$table=false)
    {	
        $state=parent::insert($crit,$table);
        if($state)
        {
            if(is_index($crit))
            {
                $this->insert_helper($crit,$table);
            }
            else{
                At::create($this,$state,$table);
            }
        }
        return $state;
    }
  
    public function decline_request($crit,$table=false)
    {
        if(!is_array($crit))
        {
            $id=$crit;
            $i=$table?'id':$this->pk();
            $table=$table?:$this->table();
            $crit=["where"=>[$table .'.'. $i=>$crit]];
        }
        $state=parent::modify(["active"=>1],$crit,$table);
        At::decline($this,$id,$table);
        return $state;
    }
    
    public function cancel_request($crit,$table=false)
    {
        if(!is_array($crit))
        {
            $id=$crit;
            $i=$table?'id':$this->pk();
            $table=$table?:$this->table();
            $crit=["where"=>[$table .'.'. $i=>$crit]];
        }
        $state=parent::modify(["active"=>1],$crit,$table);
        At::cancel($this,$id,$table);
        return $state;
    }
  
    public function delete_request($crit,$table=false)
    {
        
		if(!is_array($crit))
		{
			$id=$crit;
			$i=$table?'id':$this->pk();
			$table=$table?:$this->table();
			$crit=["where"=>[$table .'.'. $i=>$crit]];
		}
		$state=parent::modify(["active"=>2],$crit,$table);//x($state);
        At::request($this,$id,$table);
        return $state;
    }
  
    private function insert_helper($crit,$table)
    {
        foreach($crit as $o)
        {
            $id=$this->ids(["where"=>$o],$table);
            At::create($this,$id[0],$table);
        }
    }
    
    private function ids($crit,$table) 
    {
        $id=$table?'id':$this->pk();
        $table=$table?:$this->table();
        $crit["select"]=[$table .'.'. $id];
        $data=[];
        foreach($this->select($crit) as $row)
        {
            $data[]=$row[$id];
        }
        return $data;
    }
}