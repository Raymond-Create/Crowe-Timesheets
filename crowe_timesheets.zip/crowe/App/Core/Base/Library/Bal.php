<?php

namespace Core\Acc\Library;

use Lib\LibraryFactory as Lf;
use Core\Gs\Library\Rate;
use Core\Gs\Library\Config;

class Bal{
	
    use \Lib\Init;
    //UPDATE `accounts` set side='credit' where type in ('Liabilities','Equity','Income');
    
    public 
    	$nums;
    
    private
        $side,
    	$type,
    	$currency;
    	
    public static function assets(){
        $obj =  new self();
        $obj->type="Assets";
        return $obj;
    }
    
    public static function expenses(){
        $obj =  new self();
        $obj->type="Expenses";
        return $obj;
    }
    
    public static function liabilities(){
        $obj =  new self();
        $obj->type="Liabilities";
        return $obj;
    }
    
    public static function income(){
        $obj =  new self();
        $obj->type="Income";
        return $obj;
    }
    
    public static function equity(){
        $obj =  new self();
        $obj->type="Equity";
        return $obj;
    }
    
    public function __construct($id=null){
        if($id){
            $this->set_account($id);
        }
    }

    public function set_to($to){
        $this->to = $this->is_date($to);
        return $this;
    }
    
    public function set_currency($currency){
        $this->currency = $currency;
        return $this;
    }
    
    public function set_from($from){
        $this->from = $this->is_date($from);
        return $this;
    }

    public function set_code($code){
        $this->code = $code;
        return $this;
    }
    
    public function set_side($side){
        $this->side = $side;
        return $this;
    }
    
    public function credits(){
        return $this->calc(1);
    }

    public function debits(){
        return $this->calc();
    }
    
    public function total(){
        $cred = $this->credits();
        $deb = $this->debits();
        $this->nums=[$deb,$cred];
        $diff = $deb-$cred;
        return currency(($this->side=="debit")?$diff:-1*$diff);
    }

    private $account,$to,$from,$code;

    private function is_date($date){
        if(preg_match(DATE_RGX,$date)){
            return $date;
        }
        return false;
    }

    private function calc($s=false){
        $journ = Lf::app("Journal","Doc");
        $field = $s?"credit":"debit";
        $filter = [
            "select"=>[
                "sum(amount) as total","active"
                //"a.*"
            ],
            "table"=>JournalLog::$query,
            "aka"=>"journals",
            "where"=>[
                $field=>[
                    "in"=>[
                        "table"=>"accounts","select"=>["id"],
                        "where"=>["code"=>["like%",$this->code]]
                    ]
                ]
            ]
        ];//x($filter,8);
        if($this->to && $this->from){
            $a=["between"=>[
                $this->from,$this->to
            ]];
            if($journ->getSql()->getDialect()=="mysql")
            {
                $a =["between"=> [
                    "CAST('".$this->from."' AS DATE)",
                    "CAST('".$this->to."' AS DATE)"
                ]];
            }
            //$filter["where"]["a.date"] = $a;
            $filter["where"]["journals.date"] = [">=",$this->from];
            $filter["_and"]["journals.date"] = ["<=",$this->to];
        }
        if(!$this->to && $this->from){
            $filter["where"]["journals.date"] = [">=",$this->from];
        }
        if($this->to && !$this->from){
            $filter["where"]["journals.date"] = ["<=",$this->to];
        }        
        //try{
            $res = $journ->select($filter);
            //x($res);
            //x(qd(),9);
        //}catch(\PDOException $ex)
        //{
        //    x(qd(),9);
        //}
        $amount=(isset($res[0]) && !empty($res[0]))?$res[0]["total"]:0;
        if($this->currency){
            $r=Rate::init()->near(Config::init()->defaultBaseCurrency, $this->currency,$this->to?:date("Y-m-d"));
            $amount=$r*$amount;
        }
        return $amount;
    }

    private function set_account($account){
        $acc = Lf::app("Account","Acc");
        $this->account = $account;
        $acc->get($account);
        $this->set_code($acc->code);
        $this->side=$acc->side;
    }
    
    private function main($name){
        $ma = $this->mod("MainAccount","ledger");
        $ma->get($name,"name");
        $this->setCode($ma->id);
        $this->setSide($ma->type);
    }
}