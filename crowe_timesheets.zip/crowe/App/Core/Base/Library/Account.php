<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Base\Library;

use Lib\Factory as Lf;

class Account{
    
    public 
        $_name,
        $_core,
        $core_data;
    
    public function __construct($name=null,$core=null)
    {
        if($name){
            $this->set_name($name);
        }
        if($core){
            $this->set_core($core);
        }
    }
    public function set_name($name)
    {
        $this->_name=$name;
    }
    
    public function set_core($id)
    {
        $this->_core=$id;
        $mod=Lf::app("CoreAccount","Base");
        $mod->get($id);
        if(!$mod->id){
            throw new \Exception("Core Account not found");
        }
        $this->core_data=$mod->data()[0];
    }
    
    public function get_account()
    {
        $mod=Lf::app("Account","Base");
        $mod->fetch([
            "where"=>[
                "core"=>$this->_core,
                "name"=>$this->_name
            ]
        ]);
        if($mod->id){
            return $mod->id;
        }
        $mod->core=$this->_core;
        $mod->name=$this->_name;
        return $mod->save();
    }
}