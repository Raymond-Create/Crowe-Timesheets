<?php

namespace Core\Base\Library;
use Lib\Factory as Lf;

class Contact extends Editor
{
    
    public
    $script="contact-form",
    $title="Contact Editor",
    $model=["Contact","Base"];
    
    public function rows(){
        $div=div();
        $div->add($this->row1());
        $div->add($this->row2());
        $div->add($this->row3());
        $div->add($this->row4());
        return $div;
    }
    public function row1(){
        $div=div("row");
        $div->add(div("col-lg-3 col-xs-6")
            ->add(\Lib\BootSelect::init()
                ->set_model(["ContactType","Base"])
                ->set_default($this->val("type"))
                ->set_name("type")
                ->set_meta([
                    $this->attr=>$this->attr,
                    "data-type"=>"input"
                ])
                ->required()
                ->html()
            )
        );
        $div->add(div("col-lg-6 col-xs-6")
            ->add(input("form-control form-control-sm")
                ->attr([
                    "name"=>"name","list"=>"name-list",
                    "data-pattern"=>'/^[0-9A-Za-z\'\_\,\.\-\(\) ]+$/',
                    "value"=>$this->val("name"),
                    "data-type"=>"input",
                    "placeholder"=>"Contact Name  (required)",
                    $this->attr=>$this->attr,
                    "required"=>"required"
                ])
            )
            ->add($this->name_data_list())
        );
        $div->add(div("col-lg-3 col-xs-6")
             ->add(input("form-control form-control-sm")
                ->attr([
                    "name"=>"code",
                    "data-pattern"=>CHAR_RGX,
                    "value"=>$this->val("code"),
                    "data-type"=>"input",
                    "placeholder"=>"Contact Code  (Not Required)",
                    $this->attr=>$this->attr
                ])
            )
        );
        return $div;
    }
	
    public function row2(){
        $div=div("row mt-2");
        $div->add(div("col-lg-6 col-xs-6")
            ->add(input("form-control form-control-sm")
                ->attr([
                    "name"=>"email",
                    "data-pattern"=>EMAIL_RGX,
                    "value"=>$this->val("email"),
                    "data-type"=>"input",
                    "placeholder"=>"email@address.com  (not required)",
                    $this->attr=>$this->attr
                ])
            )
        );
        $div->add(div("col-lg-6 col-xs-6")
            ->add(input("form-control form-control-sm")
                ->attr([
                    "name"=>"phone",
                    "data-pattern"=>"/[0-9\+\, ]+/",
                    "value"=>$this->val("phone"),
                    "data-type"=>"input",
                    "placeholder"=>"+263 777 888 999  (not required)",
                    $this->attr=>$this->attr
                ])
            )
        );
        return $div;
    }
    
    public function row3(){
        $div=div("row mt-2");
        $div->add(div("col-lg-6 col-xs-6")
            ->add(input("form-control form-control-sm")
                ->attr([
                    "name"=>"vat",
                    "data-pattern"=>CHAR_RGX,
                    "value"=>$this->val("vat"),
                    "data-type"=>"input",
                    "placeholder"=>"VAT number (not required)",
                    $this->attr=>$this->attr
                ])
            )
        );
        $div->add(div("col-lg-6 col-xs-6")
            ->add(input("form-control form-control-sm")
                ->attr([
                    "name"=>"bp",
                    "data-pattern"=>CHAR_RGX,
                    "value"=>$this->val("bp"),
                    "data-type"=>"input",
                    "placeholder"=>"Tax BP number  (not required)",
                    $this->attr=>$this->attr
                ])
            )
        );
        return $div;
    }
    public function row4(){
        $div=div("row mt-2");
        $div->add(div("col-lg-12 col-xs-12")
            ->add(textarea("form-control form-control-sm")
                ->attr([
                    "name"=>"address",
                    "data-pattern"=>CHAR_RGX,
                    "value"=>$this->val("address"),
                    "data-type"=>"input",
                    "placeholder"=>"Business Address (not required)",
                    $this->attr=>$this->attr
                ])
            )
        );
        return $div;
    }
	private function name_data_list()
	{
		$mod=Lf::app("Contact","Base");
		$data=datalist();
		foreach($mod->read() as $row)
		{
			$data->add(option([
				'data-value'=>$row['id'],
				'value'=>$row["name"]
			]));
		}	
		return $data->attr("id","name-list");
	}
}