<?php
namespace Core\Base\Library;

use Core\Base\Library\AbView;


class PrefixesView extends AbView
{
    use \Lib\Init;
    
    public
        $_title="Prefixes",
        $types="Prefixes",
        $drop=[
            "Prefixes"=>"base/prefixes",
            "Currencies"=>"base/currencies",
            "Rates"=>"base/rates"
        ];
      //$type="Expense";
    
}
