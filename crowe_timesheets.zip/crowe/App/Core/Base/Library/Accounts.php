<?php

namespace Core\Fin\Library;



use Lib\Csv;
use Lib\Char;
use Lib\BinFile as B;
use Core\Gs\Library\ReportHeader;
use Lib\LibraryFactory as Lf;
use Core\Gs\Library\Config;
use Core\Gs\Library\Rate;

import("Pdfmake");

class Accounts extends ReportHeader{
    
    protected $url="gs/reports/show_report/Fin/Accounts",
    $company,$period="_",$beginning,$ending;
    
    public $report="Statement of Accounts";
    
    private
    $_id;
    
    private function listSql($type="Debtors"){
		if($type=="Debtors")
		{
			$debit="(case when s.type = 'Receipt' then accruals.amount*r.rate else 0 end) as debit";
			$credit="(case when s.type = 'Payment' then accruals.amount*r.rate else 0 end) as credit";
		
		}else{
			$debit="(case when s.type = 'Receipt' then accruals.amount*r.rate else 0 end) as debit";
			$credit="(case when s.type = 'Payment' then accruals.amount*r.rate else 0 end) as credit";
		}
        return [
            "table"=>"accruals",
            "alias"=>"accruals",
            "join"=>[
                "join"=>[
                    ["sources s","s.id","accruals.source"],
                    ["rates r","r.id","accruals.rate"]
                ]
            ],
            "where"=>["s.model"=>["notin"=>["Prepaid","Anote"]]],
            "select"=>[
                "accruals.date","accruals.comment as narration","accruals.tax_ref as ref",
                //"accruals.amount*r.rate as debit","'0' as credit",
                //$type=="Debtors"?"accruals.amount*r.rate as debit":"'0' as debit",
                //$type=="Creditors"?"accruals.amount*r.rate as credit":"'0' as credit",
                $debit,$credit,
                "accruals.contact","accruals.active","accruals.amount as amt","accruals.currency"
            ],
            "union"=>[
                //Credit notes
                [
                    "table"=>"accruals",
                    "alias"=>"accruals",
                    "join"=>[
                        "join"=>[
                            ["anotes a","a.accrual","accruals.id"],
                            ["sources s","s.id","accruals.source"],
                            ["rates r","r.id","accruals.rate"],
                            ["notes n","a.note","n.id"],
                            ["accruals a2","a2.id","n.accrual"]
                        ]
                    ],
                    "where"=>["n.type"=>"Credit"],
                    "select"=>[
                        "a2.date","accruals.comment as narration","accruals.tax_ref as ref",
                        "'0' as debit","accruals.amount*r.rate as credit",
                        //$type=="Debtors"?"'0' as debit":"accruals.amount*r.rate as debit",
                        //$type=="Creditors"?"'0' as credit":"accruals.amount*r.rate as credit",
                        "accruals.contact","accruals.active","accruals.amount as amt","accruals.currency"
                    ]
                ],//Debit notes
                [
                    "table"=>"accruals",
                    "alias"=>"accruals",
                    "join"=>[
                        "join"=>[
                            ["anotes a","a.accrual","accruals.id"],
                            ["sources s","s.id","accruals.source"],
                            ["rates r","r.id","accruals.rate"],
                            ["notes n","a.note","n.id"],
                            ["accruals a2","a2.id","n.accrual"]
                        ]
                    ],
                    "where"=>["a.type"=>"Debit"],
                    "select"=>[
                        "a2.date","accruals.comment as narration","accruals.tax_ref as ref",
                        "accruals.amount*r.rate as debit","'0' as credit",
                        //$type=="Debtors"?"accruals.amount*r.rate as debit":"'0' as debit",
                        //$type=="Creditors"?"accruals.amount*r.rate as credit":"'0' as credit",
                        "accruals.contact","accruals.active","accruals.amount as amt","accruals.currency"
                    ]
                ],//Payments
                [
                    "table"=>"accruals",
                    "alias"=>"accruals",
                    "join"=>[
                        "join"=>[
                            ["prepaids px","px.accrual","accruals.id"],
                            ["sources s","s.id","accruals.source"],
                            ["rates r","r.id","accruals.rate"]
                        ]
                    ],
                    "where"=>["px.type"=>"Payment"],
                    "select"=>[
                        "accruals.date","accruals.comment as narration","px.manual as ref",
                        "accruals.amount*r.rate as credit","'0' as debit",
                        //$type=="Debtors"?"'0' as debit":"accruals.amount*r.rate as debit",
                        //$type=="Creditors"?"'0' as credit":"accruals.amount*r.rate as credit",
                        "accruals.contact","accruals.active","accruals.amount as amt","accruals.currency"
                    ]
                ],
                //Receipts
                [
                    "table"=>"accruals",
                    "alias"=>"accruals",
                    "join"=>[
                        "join"=>[
                            ["prepaids p","p.accrual","accruals.id"],
                            ["sources s","s.id","accruals.source"],
                            ["rates r","r.id","accruals.rate"]
                        ]
                    ],
                    "where"=>["p.type"=>"Receipt"],
                    "select"=>[
                        "accruals.date","accruals.comment as narration","p.manual as ref",
                        "'0' as debit","accruals.amount*r.rate as credit",
                        //$type=="Debtors"?"'0' as debit":"accruals.amount*r.rate as debit",
                        //$type=="Creditors"?"accruals.amount*r.rate as credit":"'0' as credit",
                        "accruals.contact","accruals.active","accruals.amount as amt","accruals.currency"
                    ]
                ],
                [
                    "table"=>"realisations",
                    "alias"=>"realisations",
                    "join"=>[
                        "join"=>[
                            ["accruals a","a.id","realisations.accrual"],
                            ["sources s","s.id","a.source"],
                            ["rates r","r.id","realisations.rate"]
                        ],
                        "left join"=>[
                            ["prepaiduses pu","pu.realisation","realisations.id"]
                        ]
                    ],
                    "where"=>["pu.id"=>null,"s.model"=>["<>","Prepaid"]],
                    "select"=>[
                        "realisations.date",
                        "concat('Receipt for ',a.comment) as narration",
                        "realisations.manual as ref",
                        //"'0' as debit","realisations.amount*r.rate as credit",
                        $type=="Debtors"?"'0' as debit":"realisations.amount*r.rate as debit",
                        $type=="Creditors"?"'0' as credit":"realisations.amount*r.rate as credit",
                        "a.contact","realisations.active","realisations.amount as amt","realisations.currency"
                    ]
                ]
            ]
        ];
    }
    private function ageSql($type="Debtors"){
        if($type=="Debtors")
		{
			$debit="(case when s.type = 'Receipt' then accruals.amount*r.rate else 0 end) as debit";
			$credit="(case when s.type = 'Payment' then accruals.amount*r.rate else 0 end) as credit";
		
		}else{
			$debit="(case when s.type = 'Receipt' then accruals.amount*r.rate else 0 end) as debit";
			$credit="(case when s.type = 'Payment' then accruals.amount*r.rate else 0 end) as credit";
		}
        return [
            //Select all accruals that are not Prepaids or Notes
            "table"=>"accruals",
            "alias"=>"accruals",
            "join"=>[
                "join"=>[
                    ["sources s","s.id","accruals.source"],
                    ["rates r","r.id","accruals.rate"]
                ]
            ],
            "where"=>["s.model"=>["notin"=>["Prepaid","Anote"]]],
            "select"=>[
                "accruals.date","accruals.comment as narration","accruals.tax_ref as ref",
                //"accruals.amount*r.rate as debit","'0' as credit",
                //$type=="Debtors"?"accruals.amount*r.rate as debit":"'0' as debit",
                //$type=="Creditors"?"accruals.amount*r.rate as credit":"'0' as credit",
                $debit,$credit,
                "accruals.contact","accruals.active"
            ],
            //Select all Credit Note accruals
            "union"=>[
                [
                    "table"=>"accruals",
                    "alias"=>"accruals",
                    "join"=>[
                        "join"=>[
                            ["anotes a","a.accrual","accruals.id"],
                            ["sources s","s.id","accruals.source"],
                            ["rates r","r.id","accruals.rate"],
                            ["notes n","a.note","n.id"],
                            ["accruals a2","a2.id","n.accrual"]
                        ]
                    ],
                    "where"=>["a.type"=>"Credit"],
                    "select"=>[
                        "a2.date","accruals.comment as narration","accruals.tax_ref as ref",
                        "'0' as debit","accruals.amount*r.rate as credit",
                        //$type=="Debtors"?"'0' as debit":"accruals.amount*r.rate as debit",
                        //$type=="Creditors"?"'0' as credit":"accruals.amount*r.rate as credit",
                        "accruals.contact","accruals.active"
                    ]
                ],
                //Select all Debit Note accruals
                [
                    "table"=>"accruals",
                    "alias"=>"accruals",
                    "join"=>[
                        "join"=>[
                            ["anotes aa","aa.accrual","accruals.id"],
                            ["sources s","s.id","accruals.source"],
                            ["rates r","r.id","accruals.rate"],
                            ["notes n","aa.note","n.id"],
                            ["accruals a2","a2.id","n.accrual"]
                        ]
                    ],
                    "where"=>["n.type"=>"Debit"],
                    "select"=>[
                        "a2.date","accruals.comment as narration","accruals.tax_ref as ref",
                        "accruals.amount*r.rate as debit","'0' as credit",
                        //$type=="Debtors"?"accruals.amount*r.rate as debit":"'0' as debit",
                        //$type=="Creditors"?"accruals.amount*r.rate as credit":"'0' as credit",
                        "accruals.contact","accruals.active"
                    ]
                ],
                //Select unallocated Prapayments
                [
                    "alias"=>"accruals",
                    "table"=>[
                        "alias"=>"accruals",
                        "table"=>[
                            "alias"=>"accruals",
                            "table"=>[
                                "table"=>"prepaids",
                                "alias"=>"accruals",
                                "join"=>[
                                    "left join"=>[
                                        ["prepaiduses p","p.prepaid","prepaids.id"]
                                    ]
                                ],
                                "select"=>[
                                    "prepaids.id as pid","p.id as puid","p.realisation","prepaids.accrual","prepaids.active"
                                ],
                                
                            ],
                            "join"=>[
                                "join"=>[
                                    ["accruals a","a.id","accruals.accrual"],
                                    ["rates ar","ar.id","a.rate"]
                                ],
                                "left join"=>[
                                    ["realisations r","r.id","accruals.realisation"],
                                    ["rates rr","rr.id","r.rate"]
                                ]
                            ],
                            "select"=>[
                                "a.date","a.comment as narration","a.tax_ref as ref",
                                "a.amount*ar.rate as aamount","r.amount*rr.rate as ramount",
                                "a.contact","accruals.active","pid"
                            ],
                            "where"=>["accruals.active"=>1,"a.active"=>1],
                        ],
                        "select"=>[
                            "date","narration","ref",
                            "aamount",
                            "sum(case when ramount is null then 0 else ramount end) as ramount",
                            "contact","active"
                        ],
                        "group"=>["pid"]
                        
                    ],
                    "select"=>[
                        "date","narration","ref",
                        //"sum(aamount)-sum(ramount) as amount",
                        $type=="Debtors"?"'0' as debit":"sum(case when aamount is null then 0 else aamount end)-sum(case when ramount is null then 0 else ramount end) as debit",
                        $type=="Creditors"?"'0' as credit":"sum(case when aamount is null then 0 else aamount end)-sum(case when ramount is null then 0 else ramount end) as credit",
                        
                        "contact","active"
                    ],
                    "group"=>["contact"]
                ],
                //Select all realisations
                [
                    "table"=>"realisations",
                    "alias"=>"realisations",
                    "join"=>[
                        "join"=>[
                            ["accruals a","a.id","realisations.accrual"],
                            ["sources s","s.id","a.source"],
                            ["rates r","r.id","realisations.rate"]
                        ]
                    ],
                    "where"=>["s.model"=>["<>","Prepaid"]],
                    "select"=>[
                        "a.date",
                        "concat('Receipt for ',a.comment) as narration",
                        "realisations.manual as ref",
                        $type=="Debtors"?"'0' as debit":"realisations.amount*r.rate as debit",
                        $type=="Creditors"?"'0' as credit":"realisations.amount*r.rate as credit",
                        "a.contact","realisations.active"
                    ]
                ]
            ]
        ];
    }
    protected function filters(){
        $a=div("row mt-2")
        ->attr("data-x-mod","accounts-filter")
        ->add(div("col-md-4 col-xs-4 mt-1")
            ->add(\Lib\ChoiceInput::init()
                ->setMeta([
                    'data-type'=>"input",
                    'required'=>'required'
                ])
                ->setName('type')
                ->setOptions(['Debtors','Creditors'])
                ->html()
            )
        )
        ->add(div("col-md-4 col-xs-4 mt-1")
            ->attr("data-apply","csv")
            ->add(\Lib\BootSelect::init()
                ->set_meta(['data-type'=>"input"])
                ->set_name('currency')
                ->set_model(['Currency','Gs'])
                ->set_placeholder('Select Currency')
                ->set_pattern("/\d+/")
                ->required()
                ->html()
            )
        )
        ->add(div("col-md-4 col-xs-4 mt-1")
            ->add(\Lib\BootSelect::init()
                ->set_meta(['data-type'=>"input"])
                ->set_name('contact')
                ->set_model(['Contact','Gs'])
                ->set_placeholder('Select Account')
                ->required()
                ->set_filter([
                    "join"=>[
                        "join"=>[
                            ["contacttypes ct","ct.id","contacts.type"]
                        ]
                    ],
                    "select"=>["contacts.*"],
                    "order"=>[["ct.name","contacts.name"],"DESC"]
                ])
                ->html()
            )
        );
        $this->add($a);
    }
	
    private $data,$csv;
    
    public function dsl($data,$csv=false){
        $this->data=$data;
        $fund=Lf::app('Accrual','Doc');
        $filter = [];
        $com=Lf::app('Company','Gs');
        
        $query = [
            "table"=>$this->listSql($data["type"]),"alias"=>"accruals",
            "order"=>["accruals.date","ASC"]
        ];
        $query["where"]["contact"]=$data["contact"];
        $this->setPeriods();
        $this->date=$this->data["to"]?:date("Y-m-d");
        if(isset($data["account"]))
        {
            $mod=Lf::app("Contact","Gs");
            $mod->get($data["contact"]);
            $this->csv=Csv::init(str_replace(" ", "-", $mod->rep()));
        }
        else{
            $this->csv=Csv::init(Char::gen(4));
        }
        $this->csv->add("DATE");
        $this->csv->add("NARRATION");
        $this->csv->add("REF");
        $this->csv->add("DEBIT");
        $this->csv->add("CREDIT");
        $this->csv->add("BALANCE");
        $this->type=$data["type"];
        $this->query=$query;
        $this->balance=0;
        $this->payments=0;
        $results = $fund->select($this->dates($query,$data,"date"));//x($results,9);
        $this->grid=grid();
        $this->head($data);
        $this->blank();
        $this->clientBox($data["contact"]);
        $this->blank();
        $this->tb($results);
        $this->blank();
        $this->age();
        $com=Lf::app("Company","Gs");
        $com->fetch();
        if(!$com->logo){
            $bin = B::init("Files/assets/images/logo.png");
            $logo = 'data:'.$bin->mime() .";base64,".$bin->read();
        }
        else{
            $logo = $com->logo;
        }
        $this->company = $com->name;
        if($csv==707)
        {
            $this->csv->download();
        }
        return [
            "content"=>[
                //$this->logo()," ",
                //$this->line()," ",
                //$this->title()," ",
                //$this->line()," ",
                //$this->filts($filter,$results)," ",
                $this->table($this->grid->rep())," ",
                //"table"=>$table
            ],
            "styles"=> [
                "header"=> [
                    "fontSize"=> 10,
                    "bold"=>"true",
                    "fillColor"=>"#DCDCDC"
                ],
                "anotherStyle"=>[
                    "italics"=> true,
                    "alignment"=> 'right'
                ]
            ],
            "images"=>[
                "logo"=>$logo
            ]
        ];
    }
    
    private function tb($data)
    {
        $this->th();
        $this->bf();
        foreach($data as $d)
        {
            $this->tr($d);
        }
    }
    
    private function setPeriods()
    {
        if($this->data["period"])
        {
            $mod=Lf::app("Period","Gs");
            $mod->get($this->data["period"]);
            $this->data["from"]=$mod->start;
            $this->data["to"]=$mod->finish;
        }
    }
    private function bf()
    {
        if(!$this->data["from"]){
          return;  
        }
        $mod=Lf::app("Accrual","Doc");
        $this->query["alias"]="accruals";
        $data=$mod->read([
            "table"=>$this->query,
            "select"=>[
                 $this->type=="Creditors"?"sum(credit-debit) as amount":"sum(debit-credit) as amount"
            ],
            "where"=>["date"=>["<",$this->data["from"]]]
        ]);
        //if($this->type=="Credit")
        //{
        //    $this->balance=$data[0]["amount"];
        //}
        //else{
            $this->balance+=$data[0]["amount"];
        //}
        $this->grid->row();
        $this->grid->cell($this->data["from"],1,[
            "border"=>[1,1,1,1],
            "fontSize"=>6.5
        ]);
        $this->grid->cell("Balance before ".$this->data["from"],4,[
            "border"=>[1,1,1,1],
            "fontSize"=>7
        ]);
        $this->grid->cell(" ",1,[
            "border"=>[1,1,1,1],
            "fontSize"=>7
        ]);
        $this->grid->cell(" ",2,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "alignment"=>"right"
        ]);
        $this->grid->cell(" ",2,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "alignment"=>"right"
        ]);
        $this->grid->cell($this->balance>0?num($this->balance):" ",2,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "alignment"=>"right"
        ]);
    }
    
    private function age()
    {
        $this->ageTitle();
        $mod=Lf::app("Accrual","Doc");
        $filter=$this->ageSql($this->data["type"]);
        $data90=$mod->read([
            "table"=>$filter,
            "select"=>[
                'sum(debit) as debit','sum(credit) as credit',
                $this->data["type"]=="Debtors"?"sum(debit-credit) as amount":"sum(credit-debit) as amount"
            ],
            "where"=>[
                "date"=>["<=","{('".$this->date."' - INTERVAL 90 DAY)}"],
                "contact"=>$this->data["contact"]
            ]
        ]);
        $data60=$mod->read([
            "table"=>$filter,
            "select"=>[
                $this->data["type"]=="Debtors"?"sum(debit-credit) as amount":"sum(credit-debit) as amount"
            ],
            "where"=>[
                "date"=>["<=","{('".$this->date."' - INTERVAL 60 DAY)}"],
                "contact"=>$this->data["contact"]
            ]
        ]);
        $data30=$mod->read([
            "table"=>$filter,
            "select"=>[
                $this->data["type"]=="Debtors"?"sum(debit-credit) as amount":"sum(credit-debit) as amount"
            ],
            "where"=>[
                "date"=>["<=","{('".$this->date."' - INTERVAL 30 DAY)}"],
                "contact"=>$this->data["contact"]
            ]
        ]);
        $curr=$mod->read([
            "table"=>$filter,
            "select"=>[
                $this->data["type"]=="Debtors"?"sum(debit-credit) as amount":"sum(credit-debit) as amount"
            ],
            "where"=>[
                "date"=>[">","{('".$this->date."'  - INTERVAL 30 DAY)}"],
                "contact"=>$this->data["contact"]
            ]
        ]);
        
        //x([$data90,$data60,$data30,$curr]);
        //x(qd(),8);
        $this->ageValue($data90,$data60,$data30,$curr);
        $this->grid->row();
        $this->grid->cell("PLEASE PAY BALANCE DUE",8,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "bold"=>"true"
        ]);
        $this->grid->cell("BALANCE DUE ",2,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell(num($this->balance),2,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "alignment"=>"right",
            "bold"=>"true"
        ]);
    }
    private function tr($data)
    {
        $base=Config::init()->defaultBaseCurrency;
        $deb=Rate::init()->near($base,$this->data["currency"],date("Y-m-d"))*$data["debit"];
        $cred=Rate::init()->near($base,$this->data["currency"],date("Y-m-d"))*$data["credit"];
        if($data["currency"]==$this->data["currency"]){//x($data,9);
            if($data["credit"]==0){
                $deb=$data["amt"];
            }
            if($data["debit"]==0){
                $cred=$data["amt"];
            }
            
        }
        if($this->type=="Creditors")
        {
            $this->payments+=$deb?:0;
            $this->balance-=$deb?:0;
            $this->balance+=$cred?:0;
        }
        else{
            $this->payments+=$cred?:0;
            $this->balance+=$deb?:0;
            $this->balance-=$cred?:0;
        }
        $this->grid->row();
        $this->csv->line();
        $this->grid->cell($data["date"],1,[
            "border"=>[1,1,1,1],
            "fontSize"=>6.5
        ]);
        $this->csv->add($data["date"]);
        $this->grid->cell($data["narration"],4,[
            "border"=>[1,1,1,1],
            "fontSize"=>7
        ]);
        $this->csv->add($data["narration"]);
        $this->grid->cell($data["ref"],1,[
            "border"=>[1,1,1,1],
            "fontSize"=>7
        ]);
        $this->csv->add($data["ref"]);
        $this->grid->cell($data["debit"]>0?num($deb):" ",2,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "alignment"=>"right"
        ]);
        $this->csv->add($data["debit"]>0?currency($deb):" ");
        $this->grid->cell($data["credit"]>0?num($cred):" ",2,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "alignment"=>"right"
        ]);
        $this->csv->add($data["credit"]>0?currency($cred):" ");
        $this->grid->cell(num($this->balance),2,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "alignment"=>"right"
        ]);
        $this->csv->add(currency($this->balance));
    }
    
    private function th()
    {
        $this->grid->row();
        $this->grid->cell("DATE",1,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("DESCRIPTION",4,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("REF",1,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("DEBIT",2,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "alignment"=>"right",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("CREDIT",2,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "alignment"=>"right",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("BALANCE",2,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "alignment"=>"right",
            "fillColor"=>"#EAEAEA"
        ]);
    }
    
    private function ageTitle()
    {
        $this->grid->row();
        $this->grid->cell("90+ DAYS",2,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("60+ DAYS",2,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("30+ DAYS",2,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "alignment"=>"right",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("CURRENT",2,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "alignment"=>"right",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("TOTAL DUE",2,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "alignment"=>"right",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell(num($this->balance+$this->payments),2,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "alignment"=>"right"
        ]);
    }
    
    private function ageValue($d90,$d60,$d30,$curr)
    {
        $base=Config::init()->defaultBaseCurrency;
        $v90=Rate::init()->near($base,$this->data["currency"],date("Y-m-d"))*$d90[0]["amount"];
        $v60=Rate::init()->near($base,$this->data["currency"],date("Y-m-d"))*$d60[0]["amount"];
        $v30=Rate::init()->near($base,$this->data["currency"],date("Y-m-d"))*$d30[0]["amount"];
        $vCurr=Rate::init()->near($base,$this->data["currency"],date("Y-m-d"))*$curr[0]["amount"];
        /*x([$d90,$d60,$d30,$curr],9);
        $v90=$v90>0?$v90:0;
        $v60=$v60>0?$v60:0;
        $v30=$v30>0?$v30:0;*/
        $within30=$v30-$v60;
        $within60=$v60-$v90;
        $this->grid->row();
        $this->grid->cell(num($v90),2,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell(num($within60),2,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell(num($within30),2,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "alignment"=>"right",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell(num($vCurr),2,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "alignment"=>"right",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("AMOUNT PAID",2,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "alignment"=>"right",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell(num($this->payments),2,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "alignment"=>"right"
        ]);
    }
    
    private function blank()
    {
        $this->grid->row();
        $this->grid->cell(" ",12,[
            "border"=>[0,0,0,0]
        ]);
    }
    
    private function head($data)
    {
        $curr=Lf::app("Currency","Gs");
        $curr->get($data["currency"]);
        $this->grid->row();
        $this->grid->cell($this->companyDet()->rep(),7,[
            "colSpan"=>7,
            "border"=>[1,1,1,1],
            "rowSpan"=>4
        ]);
        $this->grid->cell(strtoupper($data["type"]). " STATEMENT",5,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->row();
        $this->grid->cell("",7);
        $this->grid->cell("DATE",2,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->cell($this->date,3,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->row();
        $this->grid->cell("",7);
        $this->grid->cell("CURRENCY",2,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->cell($curr->rep(),3,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->row();
        $this->grid->cell("",7);
        $this->grid->cell("ACCOUNT NAME",2,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $com=Lf::app("Contact","Gs");
        $com->get($data["contact"]);
        $this->grid->cell($com->rep(),3,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
    }
    private function clientBox($id)
    {
        $this->grid->row();
        $this->grid->cell($this->clientDet($id)->rep(),7,[
            "border"=>[1,1,1,1]
        ]);
        $this->grid->cell($this->logopos(),5,[
            "border"=>[1,1,1,1]
        ]);
    }
    private function companyDet()
    {
        $com=Lf::app("Company","Gs");
        $com->fetch();
        $font=7;
        $align="left";
        return dic()
        ->set("stack",lst()
            ->append(dic()                  //Company name
                ->set("text",$com->name)
                ->set("style","header")
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company address
                ->set("text",str_replace("\n", "",$com->address) ." ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company email
                ->set("text",$com->email . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company phone
                ->set("text",$com->phone . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            );
    }
    
    private function clientDet($id)
    {
        $com=Lf::app("Contact","Gs");
        $com->get($id);
        $font=7;
        $align="left";
        return dic()
        ->set("stack",lst()
            ->append(dic()                  //Company name
                ->set("text","Deliver To:")
                ->set("bold","true")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company name
                ->set("text",$com->name)
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company address
                ->set("text",str_replace("\n", "",$com->address) ." ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company email
                ->set("text",$com->email . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company phone
                ->set("text",$com->phone . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            );
    }
    private function filts($filter,$results){//x($filter,9);
        if(empty($filter)){
            return " ";
        }
        $text = "";
        $count = 0;
        foreach($filter as $key){
            if(isset($results[0][$key])){
                $text .= " [";
                $text .= ucfirst($key) ." : ".$results[0][$key];
                $text .= " ] ";
                if($count<(count($filter)-1)){
                    $text .= " | ";
                }
            }
            $count++;
        }
        return ["columns"=>[["text"=>$text,"bold"=>"true","fontSize"=>11]],"columnGap"=>10];
    }
	
    private function logo(){
        return ["columns"=>[$this->logopos()," ",$this->com()],"columnGap"=>10];
    }
    
    private function table($table){
        return $table;//["columns"=>[$table]];
    }
    private function logopos(){
        return [
            "image" => "logo",
            "width" => 150
        ];
    }
    
    private function com(){
        //$com = new \Modules\start\Models\Company();
        //$d = $com->select(["select"=>["name"],"where"=>["id"=>Session::get("company")]]);
        return ["stack"=>[
            ["text"=>$this->company,"style"=>"header","alignment"=>"right"],
            //["text"=>$d[0]["address"],"style"=>"header","alignment"=>"right"],
            //["text"=>$d[0]["phone"],"style"=>"header","alignment"=>"right"],
            //["text"=>$this->advice("advice_month",$id)." ".$this->advice("advice_year",$id),"fontSize"=>9,"alignment"=>"center"]
        ]];
    }
    
	private function titles($id){
        return ["columns"=>[$this->client($id)," ",$this->doc($id)],"columnGap"=>10];
    }
    
    private function line(){
        return ["canvas"=> [[ "type"=> 'line', "x1"=> 0, "y1"=> 5, "x2"=> 595-2*40, "y2"=> 5, "lineWidth"=> 1 ]]];
    }
}
