<?php
namespace Core\Base\Library;

class CurrenciesView extends LocationsView
{
    use \Lib\Init;
    
    public
    		$_title="Currencies",
    		$url="base/Currencies/create",
			$types="Currencies",
            $type="Currency";
    
}