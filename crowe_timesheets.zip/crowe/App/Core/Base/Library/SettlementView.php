<?php

namespace Core\Base\Library;


use Lib\Factory as Lf;
use Core\Base\Library\Config;
use Core\Base\Library\Rate;

import("Pdfmake");

class SettlementView{
    
    private $company;
    
    public function dsl($id){
        $fund=Lf::app('Record','Base');
        $filter = [];
        $com=Lf::init()->get_model("Org","Authentication");
        $inv=[
            "join"=>[
                "join"=>[
                    ["contacts c","c.id","records.contact"],
                    ["currencies r","r.id","records.currency"],
                    ["sources s","s.record","records.id"]
                ]
            ],
            "select"=>[
                "s.prefix",
                "records.date","s.number",
                "records.amount","r.name",
                "c.id as contact","records.type"
            ],
            "where"=>['records.id'=>$id]
        ];
        $com->fetch([
            "where"=>[
            "db"=>\Lib\Session::get("user_selected_database")
            ]
        ]);
        $this->company = $com;
        $results = $fund->select($inv);//x($results);x(qd(),9);
        $this->grid=grid();
        $this->head($results[0]);
        $this->blank();
        $this->clientBox($results[0]["contact"]);
        //Add acknoledgement statement
        //x($this->grid,8);
        return [
            "content"=>[
                //$this->logo()," ",
                //$this->line()," ",
                //$this->title()," ",
                //$this->line()," ",
                //$this->filts($filter,$results)," ",
                $this->table($this->grid->rep())," ",
                //"table"=>$table
            ],
            "styles"=> [
                "header"=> [
                    "fontSize"=> 10,
                    "bold"=>"true",
                    "fillColor"=>"#DCDCDC"
                ],
                "anotherStyle"=>[
                    "italics"=> true,
                    "alignment"=> 'right'
                ]
            ],
            "images"=>[
                "logo"=>$com->logo
            ],
            "watermark"=> strtoupper($results[0]["type"])
        ];
    }
    
    
    
    private function blank()
    {
        $this->grid->row();
        $this->grid->cell(" ",12,[
            "border"=>[0,0,0,0]
        ]);
    }
    
    private function head($data)
    {
        $this->grid->row();
        $this->grid->cell($this->companyDet()->rep(),7,[
            "colSpan"=>7,
            "border"=>[1,1,1,1],
            "rowSpan"=>5
        ]);
        $title= strtoupper($data["type"])." ";
        $title.=strtoupper(substr($data["type"], 0, 3));
        $title.=$data["number"];
        
        $title.="/".date("Y",strtotime($data["date"]));
        $this->grid->cell($title . " ",5,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->row();
        $this->grid->cell("",7);
        $this->grid->cell("DATE",2,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->cell(date("d M, y",strtotime($data["date"])),3,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->row();
        $this->grid->cell("",7);
        $this->grid->cell("CURRENCY",2,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->cell($data["name"],3,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->row();
        $this->grid->cell("",7);
        $this->grid->cell("AMOUNT",2,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->cell(num($data["amount"]),3,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8,"bold"=>"true"
        ]);
        $this->grid->row();
        $this->grid->cell("",7);
        $this->grid->cell("",2,[
            "border"=>[1,0,1,1],"fillColor"=>"#000000"
        ]);
        $this->grid->cell("",3,[
            "border"=>[1,0,1,1],"fillColor"=>"#000000"
        ]);
    }
    private function clientBox($id)
    {
        $this->grid->row();
        $this->grid->cell($this->clientDet($id)->rep(),7,[
            "border"=>[1,1,1,1]
        ]);
        $this->grid->cell($this->logopos(),5,[
            "border"=>[1,1,1,1]
        ]);
    }
    private function companyDet()
    {
        $font=7;
        $align="left";
        $com=$this->company;
        return dic()
        ->set("stack",lst()
            ->append(dic()                  //Company name
                ->set("text",$com->name)
                ->set("style","header")
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company address
                ->set("text",str_replace("\n", "",$com->address) ." ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company email
                ->set("text",$com->email . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company phone
                ->set("text",$com->phone . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            );
    }
    
    private function clientDet($id)
    {
        $com=Lf::app("Contact","Base");
        $com->get($id);
        $font=7;
        $align="left";
        return dic()
        ->set("stack",lst()
            ->append(dic()                  //Company name
                ->set("text","Deliver To:")
                ->set("bold","true")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company name
                ->set("text",$com->name)
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company address
                ->set("text",str_replace("\n", "",$com->address) ." ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company email
                ->set("text",$com->email . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company phone
                ->set("text",$com->phone . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            );
    }
    private function filts($filter,$results){//x($filter,9);
        if(empty($filter)){
            return " ";
        }
        $text = "";
        $count = 0;
        foreach($filter as $key){
            if(isset($results[0][$key])){
                $text .= " [";
                $text .= ucfirst($key) ." : ".$results[0][$key];
                $text .= " ] ";
                if($count<(count($filter)-1)){
                    $text .= " | ";
                }
            }
            $count++;
        }
        return ["columns"=>[["text"=>$text,"bold"=>"true","fontSize"=>11]],"columnGap"=>10];
    }
	
    private function logo(){
        return ["columns"=>[$this->logopos()," ",$this->com()],"columnGap"=>10];
    }
    
    private function table($table){
        return $table;//["columns"=>[$table]];
    }
    private function logopos(){
        return [
            "image" => "logo",
            "width" => 150
        ];
    }
    
    
    
    private function line(){
        return ["canvas"=> [[ "type"=> 'line', "x1"=> 0, "y1"=> 5, "x2"=> 595-2*40, "y2"=> 5, "lineWidth"=> 1 ]]];
    }
}