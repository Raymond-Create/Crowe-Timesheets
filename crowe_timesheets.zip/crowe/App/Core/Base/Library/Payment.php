<?php
//__________________________________________________//__________________________________________________
namespace Core\Base\Library;

use Lib\Init;
use Lib\Recid;
use Lib\Factory as Lf;
use Core\BAse\Library\Config;
use Lib\Factory;

class Payment
{
    use Init,Recid;
    
    private
        $id;
    
    public function __construct($param) {
        $this->id=$param;
    }
    
    public function html()
    {
        return div("row")
            ->attr("data-x-mod","money-script-2")
            ->add(div("col-xs-12 col-lg-12 table-responsive")
                ->attr("data-value",$this->id)
                ->add($this->table())
            );
    }
    
    public function save($post){
        $settlement=new Settlement();
        $src=Factory::app("Source","Base");
        $rec=Factory::app("Record","Base");
        $pay=Factory::app("Payment","Base");
        $recoData=$rec->read([
            "where"=>["records.id"=>$this->id],
            "join"=>[
                "join"=>[
                    ["rates","records.rate","rates.id"],
                    ["sources","sources.record","records.id"],
                    ["doctypes","doctypes.id","sources.doc_type"]
                ]
            ],
            "select"=>[
                "records.ref","doctypes.type as dt",
                "records.comment","records.location"
            ]
        ]);
        $rec->get($this->id);//x($recoData[0]["dt"],8);
        try{
            $src->begin();
            //$post["paid"]=$post["amount"];
            $post["location"]=$recoData[0]["location"];
            $post["comment"]=$rec->comment . " - " . $recoData[0]["dt"];
            $post["ref"]=isset($post["ref"])&&!empty($post["ref"])?$post["ref"]:date("YmdHi");
            $post["accrual"]=0;
            $resp=$settlement->save($post);
            if($resp[1]){
                $res=PayLink::init($resp[0][0],$this->id)->link();
                if(!$res[0]){
                    throw new \Exception("Link error: ".$res[1]);
                }
                $src->commit();
                return [true,'Saved'];
            }
        }catch(\Exception $ex){
            \Core\Admin\Library\ErrorLog::log($ex);
            $src->rollback();
            return [false,$ex->getMessage()];
        }
        
    }
    
    public function table()
    {
        $form=form();
        $mod=Factory::app("Record","Base");
        $data=$mod->read([
            "join"=>[
                "join"=>[
                    ["sources s","records.id","s.record"],
                    ["doctypes d","s.doc_type","d.id"],
                    ["rates","rates.id","records.rate"]
                ]
            ],
            "where"=>["records.id"=>$this->id],
            "select"=>[
                "records.ref","records.contact",
                "d.type","records.due as date",
                "records.currency","records.rate",
                "records.amount-records.paid as amt",
                "rates.reciprocal*(records.amount-records.paid) as based",
            ]
        ]);//x($data,8);
        $form->add($this->row1(
            isset($data[0])&&isset($data[0]["contact"])?$data[0]["contact"]:null,
            isset($data[0])&&isset($data[0]["currency"])?$data[0]["currency"]:null,
            isset($data[0])&&isset($data[0]["type"])?$data[0]["type"]:null
        ));
        $form->add($this->row2(
            isset($data[0])&&isset($data[0]["amt"])?$data[0]["amt"]:null,
            isset($data[0])&&isset($data[0]["based"])?$data[0]["based"]:null,
            isset($data[0])&&isset($data[0]["type"])?$data[0]["type"]:null
        ));
        $form->add($this->row3(
            isset($data[0])&&isset($data[0]["type"])?$data[0]["type"]:null
        ));
        
        $form->add($this->row4());
        $table=$this->body($this->head(table("table table-sm table-bordered")
                ->attr("style","font-size:0.7em")
            )
        );
        return div()
            ->add($form)
            ->add(div("table-responsive")->add($table));
    }
    
    private function db($field)
    {
        $mod=Lf::app("Record","Base");
        $mod->get($this->id);
        return $mod->$field;
    }
    
    private function sDate()
    {
        
    }
    private function head($table)
    {
        return $table->add(
            thead()
            ->add(tr()
                ->add(th()
                    ->attr([
                        "colspan"=>8,
                        "style"=>"text-align:center;font-weight:bold;font-size:1.4em"
                    ])
                    ->add(span()->add("Payments History"))
                )
            )
            ->add(tr()
                ->add(th()
                    ->attr("style","width:10%")
                    ->add("Date")
                )
                ->add(th()
                    ->attr("style","width:10%")
                    ->add("Ref")
                )
                ->add(th()
                    ->attr("style","width:15%")
                    ->add("Method")
                )
                ->add(th()
                    ->attr("style","width:10%")
                    ->add("Currency")
                )
                ->add(th()
                    ->attr("style","width:20%")
                    ->add("Rate")
                )
                ->add(th()
                    ->attr("style","width:10%")
                    ->add("Amount")
                    )
                ->add(th()
                    ->add("Action")
                    )
                )
            );
    }
    
    public function body($table)
    {
        //return;
        $mod=Lf::app("Payment","Base");
        $body=tbody();
        $data=$mod->select([
            "where"=>[
                "payments.accrual"=>$this->id
            ],
            "join"=>[
                "join"=>[
                    ["records","payments.realisation","records.id"],
                    ["sources s","s.record","records.id"],
                    ["cashaccounts b","b.id","s.method"],
                    ["currencies c","c.id","records.currency"]
                ]
            ],
            "select"=>[
                "records.*","b.name as method","c.name as currency","s.authoriser",
                "payments.id as payment"
            ]
        ]);//x(qd(),7);
        foreach ($data as $row)
        {
            $body->add(tr()
                ->add(td()
                    ->add($row["date"])
                )
                ->add(td()
                    ->add($row["ref"])
                )
                ->add(td()
                    ->add($row["method"])
                )
                ->add(td()
                    ->add($row["currency"])
                )
                ->add(td()
                    ->add(num($row["rate"]))
                )
                ->add(td()
                    ->add(num($row["amount"]))
                )
                ->add(td()
                    ->add($this->btn($row))
                )
            );
        }
        return $table->add($body);
    }
    
    private function row1($contact=null,$currency=null,$type=null){
        return div("row")
            ->add(div("col-lg-3 col-md-3 col-xs-12")
                ->add(label("control-label")->add("Contact"))
                ->add(\Lib\BootSelect::init()
                    ->set_pattern("/\d+")
                    ->set_name("contact")
                    ->set_default($contact)
                    ->set_model(["Contact","Base"])
                    ->set_meta([
                        "disabled"=>"disabled",
                        "data-acc"=>1
                    ])
                    ->html()
                )
            )
            ->add(div("col-lg-3 col-md-3 col-xs-12")
                ->add(label("control-label")->add("Date (*Required)"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"date","data-addon"=>"datepicker",
                        "value"=>date("Y-m-d"),"data-pattern"=>DATE_RGX,
                        "required"=>"required"
                    ])
                )
            )
            ->add(div("col-lg-3 col-md-3 col-xs-12")
                ->add(label("control-label")->add($type=="Receipt"?"Receipt Method (*Required)":"Payment Method (*Required)"))
                ->add(\Lib\BootSelect::init()
                    ->set_pattern("/\d+")
                    ->set_name("method")
                    ->set_meta(["data-acc"=>1])
                    ->set_model(["CashAccount","Base"])
                    ->set_placeholder($type=="Receipt"?"Receipt Method":"Payment Method")
                    ->required()
                    ->html()
                )
            )
            
            ->add(div("col-lg-3 col-md-3 col-xs-12")
                ->add(label("control-label")->add("Currency (*Required)"))
                ->add(\Lib\BootSelect::init()
                    ->set_pattern("/\d+")
                    ->set_name("currency")
                    ->set_default($currency)
                    ->set_model(["Currency","Base"])
                    ->set_placeholder("Select Currency")
                    ->required()
                    ->html()
                )
				->add(input()
					->attr([
						"data-pattern"=>"/(Payment|Receipt)/",
						"data-for"=>"record",
						"type"=>"hidden",
						"value"=>$type,
						"name"=>"type"
					])
				)
                ->add(input("cur")
                    ->attr([
                        "type"=>"hidden","value"=>$currency
                    ])
                )
            )
        ;
    }
    
    private function row2($amount,$based=null,$type=null){
        return div("row")
            ->add(div("col-lg-3 col-md-3 col-xs-12")
                ->add(label("control-label")->add("Expected Amount"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"amt","data-value"=>currency($based),
                        "value"=>currency($amount),"disabled"=>"disabled",
                        "data-pattern"=>CURRENCY_RGX,"type"=>"number",
                        "step"=>"any"
                    ])
                )
            )
            ->add(div("col-lg-3 col-md-3 col-xs-12")
                ->add(label("control-label")->add("Amount (*Required)"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"amount","type"=>"number","step"=>"any",
                        "data-pattern"=>CURRENCY_RGX,
                        "required"=>"required",
                        "placeholder"=>$type=="Receipt"?"Amount Received":"Amount Paid"
                    ])
                )
            )
            ->add(div("col-lg-3 col-md-3 col-xs-12")
                ->add(label("control-label")->add("Exchange Rate"))
                ->add(\Lib\BootSelect::init()
                    ->set_pattern("/\d+")
                    ->set_name("rate")
                    ->set_model(["Rate","Base"])
                    ->set_placeholder("Rate to base")
                    ->html()
                )
            )
            
            ->add(div("col-lg-3 col-md-3 col-xs-12")
                ->add(label("control-label")->add("Ref"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"ref","data-pattern"=>CHAR_RGX
                    ])
                )
            );
    }
    
    
    
    private function row3($type=null){
        return div("row")
            ->add(div("col-lg-4 col-md-4 col-xs-12")
                ->add(label("control-label")->add("Type"))
                ->add(\Lib\Combo::init()
                    ->set_model(["DocType","Base"])
                    ->set_default($this->default($type=="Receipt"?$type:"Payment"))
                    ->set_meta([
                        "disabled"=>"disabled",
                        "data-acc"=>1
                    ])
                    ->set_pattern("/\d+/")
                    ->set_name("doc_type")
                    ->required()
                    ->html()
                )
            )
            ->add(div("col-lg-4 col-md-4 col-xs-12")
                ->add(label("control-label")->add("Debit Account"))
                ->add(\Lib\Combo::init()
                    ->set_model(["Account","Base"])
                    //->set_default($this->default($type=="Receipt"?$type:"Payment"))
                    //->set_meta(["disabled"=>"disabled"])
                    ->set_pattern("/\d+/")
                    ->set_name("debit")
                    ->required()
                    ->html()
                )
                ->add(input("record")
                    ->attr([
                        "type"=>"hidden","value"=>$this->id
                    ])
                )
            )
            ->add(div("col-lg-4 col-md-4 col-xs-12")
                ->add(label("control-label")->add("Credit Account"))
                ->add(\Lib\Combo::init()
                    ->set_model(["Account","Base"])
                    //->set_default($this->default($type=="Receipt"?$type:"Payment"))
                    //->set_meta(["disabled"=>"disabled"])
                    ->set_pattern("/\d+/")
                    ->set_name("credit")
                    ->required()
                    ->html()
                )
        );
    }
    
    private function row4(){
        return div("row mt-2 mb-2")
            ->add(div("col-lg-12 col-md-12 col-xs-12")
                ->add(button("btn btn-sm btn-primary btn-block mt-0 btn-save")
                    ->add(span("mdi mdi-content-save"))
                    ->add(span()->add(" Save"))
                )
            );
    }
    
    private function default($type){
        $arr=(new Settlement())->doc_type;
        foreach($arr as $r){ //x([$r[1]["name"],strtoupper($type)]);
            if(strtoupper($r[1]["name"])==strtoupper($type)){
                //x($r[1]["name"],9);
                return $this->idOf($r);
            }
        }//x($r[1]["name"],9);
    }
    private function btn($row)
    {   
        $div=span();
        $div->add(span("fa fa-file-pdf fa-2x text-success btn-view")//->add(button("btn btn-danger btn-sm btn-delete  mt-0 p-1")
            ->attr("data-toggle","tooltip")
            ->attr("data-value",$row["id"])
            ->attr("title","View Settlement Document")
        );
        return $div->add(span("fa fa-trash fa-2x text-danger btn-delete")//->add(button("btn btn-danger btn-sm btn-delete  mt-0 p-1")
            ->attr("data-toggle","tooltip")
            ->attr("data-value",$row["id"])
            ->attr("data-payment",$row["payment"])
            ->attr("title","Delete Settlement Record(s)")
        );
    }
    
    
}