<?php

namespace Core\Base\Library;

use Lib\Lang;
use Lib\Table;
use Huchi\Classes\Tag;
use Lib\Factory as Lf;
use Core\Authentication\Library\LoginLog;
use Huchi\Classes\Tag as t;
use Lib\Session as Sess;
use Lib\Scripts;
use Lib\ID;

trait View{
    
    
    public function view($id)
    {
        $lib=new GenView();
        $this->json($lib->dsl($id));
    }
}

