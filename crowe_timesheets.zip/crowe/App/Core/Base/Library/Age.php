<?php

namespace Core\Fin\Library;


use Lib\BinFile as B;
use Core\Gs\Library\ReportHeader;
use Lib\LibraryFactory as Lf;

import("Pdfmake");

class Age extends ReportHeader{
    
    protected $url="gs/reports/show_report/Fin/Age",
    $company,$period="_",$beginning,$ending;
    
    public $report="Aged Report";
    
    private
    $_id;
    
    protected function filters(){
        $a=div("row mt-2")
        ->attr("data-x-mod","accounts-filter")
        ->attr("data-xsl","xsl")
        ->add(div("col-md-6 col-xs-6 mt-1")
            ->add(\Lib\ChoiceInput::init()
                ->setMeta([
                    'data-type'=>"input",
                    'required'=>'required'
                ])
                ->setName('type')
                ->setOptions(['Debtors','Creditors'])
                ->html()
            )
        )
        ->add(div("col-md-6 col-xs-6 mt-1")
            ->add(\Lib\BootSelect::init()
                ->set_meta(['data-type'=>"input"])
                ->set_name('contact')
                ->set_model(['Contact','Gs'])
                ->set_placeholder('Select Account')
                ->html()
            )
        );
        $this->add($a);
    }
	
    private $data,$tot120,$tot301,$tot90,$tot60,$tot30;
    
    public function dsl($data){
        $this->data=$data;
        $fund=Lf::app('Accrual','Doc');
        $filter = [
            "select"=>[
                $data['type']=="Debtors"?"sum(debit-credit) as total":"sum(credit-debit) as total",
                "c.name","c.id"
            ],
            "table"=>$this->ageSql($data["type"]),
            "join"=>[
                "join"=>[
                   ["contacts c","c.id","accruals.contact"] 
                ],
            ]
        ];
        if($data['contact']&&is_numeric($data["contact"]))
        {
            $filter["where"]["c.id"]=$data["contact"];
        }
        else
        {
            $filter["group"]=["c.id"];
        }
        $com=Lf::app('Company','Gs');
        $this->type=$data["type"];
        $this->balance=0;
        $this->payments=0;//x($filter,7);
        $results = $fund->select($filter);//x($results,8);
        //x(qd(),8);
        $this->grid=grid();
        $this->head($data);
        $this->blank();
        $this->tb($results);
        $com=Lf::app("Company","Gs");
        $com->fetch();
        if(!$com->logo){
            $bin = B::init("Files/assets/images/logo.png");
            $logo = 'data:'.$bin->mime() .";base64,".$bin->read();
        }
        else{
            $logo = $com->logo;
        }
        $this->company = $com->name;
        return [
            "content"=>[
                //$this->logo()," ",
                //$this->line()," ",
                //$this->title()," ",
                //$this->line()," ",
                //$this->filts($filter,$results)," ",
                $this->table($this->grid->rep())," ",
                //"table"=>$table
            ],
            "pageOrientation"=>"landscape",
            "styles"=> [
                "header"=> [
                    "fontSize"=> 10,
                    "bold"=>"true",
                    "fillColor"=>"#DCDCDC"
                ],
                "anotherStyle"=>[
                    "italics"=> true,
                    "alignment"=> 'right'
                ]
            ],
            "images"=>[
                "logo"=>$logo
            ]
        ];
    }
    
    private function tb($data)
    {
        $this->th();
        foreach($data as $d)
        {
            $this->tr($d);
        }
        $this->last();
    }
    
    
    private function last()
    {
        if($this->balance==0)
        {
            $balance=0;
            $tot120=0;
            $tot301=0;
            $tot90=0;
            $tot60=0;
            $tot30=0;
        }
        else{
            $balance=$this->balance/$this->balance*100;
            $tot120=$this->tot120/$this->balance*100;
            $tot301=$this->tot301/$this->balance*100;
            $tot90=$this->tot90/$this->balance*100;
            $tot60=$this->tot60/$this->balance*100;
            $tot30=$this->tot30/$this->balance*100;
        }
        /*
        x([
            $this->tot120,
            $this->tot30,
            ($this->tot301-$this->tot60-$this->tot90-$this->tot120),
            ($this->tot90-$this->tot120),
            ($this->tot60-$this->tot90-$this->tot120),
            
            $this->tot120+
            ($this->tot301-$this->tot60-$this->tot90-$this->tot120)+
            ($this->tot90-$this->tot120)+$this->tot30+
            ($this->tot60-$this->tot90-$this->tot120),
            
            $this->balance
        ],9);
        */
        $this->grid->row();
        $this->grid->cell("TOTALS",4,[
            "border"=>[1,1,1,1],
            "fontSize"=>6.5,
            "fillColor"=>"#FAFAFA",
            "bold"=>"true"
        ]);
        $this->grid->cell(num($this->tot30),2,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "fillColor"=>"#FAFAFA",
            "bold"=>"true"
        ]);
        $this->grid->cell(num($this->tot301),1,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "fillColor"=>"#FAFAFA",
            "bold"=>"true"
        ]);
        $this->grid->cell(num($this->tot60),1,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "alignment"=>"right",
            "fillColor"=>"#FAFAFA",
            "bold"=>"true"
        ]);
        $this->grid->cell(num($this->tot90),1,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "alignment"=>"right",
            "fillColor"=>"#FAFAFA",
            "bold"=>"true"
        ]);
        $this->grid->cell(num($this->tot120),1,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "alignment"=>"right",
            "fillColor"=>"#FAFAFA",
            "bold"=>"true"
        ]);
        $this->grid->cell(num($this->balance),2,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "alignment"=>"right",
            "fillColor"=>"#FAFAFA",
            "bold"=>"true"
        ]);
        $this->grid->row();
        $this->grid->cell("PERCENTAGES",4,[
            "border"=>[1,1,1,1],
            "fontSize"=>6.5,
            "fillColor"=>"#FAFAFA",
            "bold"=>"true"
        ]);
        $this->grid->cell(round($tot30)."%",2,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "fillColor"=>"#FAFAFA",
            "bold"=>"true"
        ]);
        $this->grid->cell(round($tot301)."%",1,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "fillColor"=>"#FAFAFA",
            "bold"=>"true"
        ]);
        $this->grid->cell(round($tot60)."%",1,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "alignment"=>"right",
            "fillColor"=>"#FAFAFA",
            "bold"=>"true"
        ]);
        $this->grid->cell(round($tot90)."%",1,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "alignment"=>"right",
            "fillColor"=>"#FAFAFA",
            "bold"=>"true"
        ]);
        $this->grid->cell(round($tot120)."%",1,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "alignment"=>"right",
            "fillColor"=>"#FAFAFA",
            "bold"=>"true"
        ]);
        $this->grid->cell(round($balance)."%",2,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "alignment"=>"right",
            "fillColor"=>"#FAFAFA",
            "bold"=>"true"
        ]);
    }
    
    
    
    private function tr($data)
    {
        
        $tot30=$this->calc($data["id"], [">","{(CURRENT_DATE - INTERVAL 30 DAY)}"]);
        $tot301=$this->calc($data["id"], ["<=","{(CURRENT_DATE - INTERVAL 30 DAY)}"]);
        $tot60=$this->calc($data["id"], ["<=","{(CURRENT_DATE - INTERVAL 60 DAY)}"]);
        $tot90=$this->calc($data["id"], ["<=","{(CURRENT_DATE - INTERVAL 90 DAY)}"]);
        $tot120=$this->calc($data["id"], ["<=","{(CURRENT_DATE - INTERVAL 120 DAY)}"]);
        $this->balance+=$data["total"];
        $this->tot120+=$tot120;
        $this->tot301+=$tot301-$tot60;
        $this->tot90+=$tot90-$tot120;
        $this->tot60+=$tot60-$tot90;
        $this->tot30+=$tot30;
        $this->grid->row();
        $this->grid->cell($data["name"],4,[
            "border"=>[1,1,1,1],
            "fontSize"=>6.5
        ]);
        $this->grid->cell(num($tot30),2,[
            "border"=>[1,1,1,1],
            "fontSize"=>7
        ]);
        $this->grid->cell(num($tot301-$tot60),1,[
            "border"=>[1,1,1,1],
            "fontSize"=>7
        ]);
        $this->grid->cell(num($tot60-$tot90),1,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "alignment"=>"right"
        ]);
        $this->grid->cell(num($tot90-$tot120),1,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "alignment"=>"right"
        ]);
        $this->grid->cell(num($tot120),1,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "alignment"=>"right"
        ]);
        $this->grid->cell(num($data["total"]),2,[
            "border"=>[1,1,1,1],
            "fontSize"=>7,
            "alignment"=>"right"
        ]);
    }
    
    
    private function th()
    {
        $name=$this->type=="Creditors"?"CREDITOR":"DEBTOR";
        $this->grid->row();
        $this->grid->cell($name,4,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("CURRENT",2,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("30 DAYS",1,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("60 DAYS",1,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "alignment"=>"right",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("90 DAYS",1,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "alignment"=>"right",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("120+ DAYS",1,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "alignment"=>"right",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("TOTAL",2,[
            "border"=>[1,1,1,1],
            "fontSize"=>8,
            "bold"=>"true",
            "alignment"=>"right",
            "fillColor"=>"#EAEAEA"
        ]);
    }
    
   
    private function blank()
    {
        $this->grid->row();
        $this->grid->cell(" ",12,[
            "border"=>[0,0,0,0]
        ]);
    }
    
    private function head($data)
    {
        $this->grid->row();
        $this->grid->cell($this->companyDet()->rep(),7,[
            "colSpan"=>7,
            "border"=>[1,1,1,1],
            "rowSpan"=>4
        ]);
        $this->grid->cell(strtoupper($data["type"]). " REPORT",5,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->row();
        $this->grid->cell("",7);
        $this->grid->cell("DATE",2,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->cell(date("Y-m-d"),3,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->row();
        $this->grid->cell("",7);
        $this->grid->cell("PAGE",2,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->cell(1,3,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->row();
        $this->grid->cell("",7);
        $this->grid->cell("REPORT NAME",2,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $com=Lf::app("Contact","Gs");
        $com->get($data["contact"]);
        $this->grid->cell("AGED ".strtoupper($data["type"]). " ANALYSIS",3,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
    }
    
    private function calc($contact,$criteria)
    {
        $d=[
            "alias"=>"accruals",
            "select"=>[
                $this->data['type']=="Debtors"?"sum(debit-credit) as total":"sum(credit-debit) as total"
            ]
        ];
        $d["table"]=$this->ageSql($this->data['type']);
        $d["where"]["contact"]=$contact;
        $d["where"]["date"]=$criteria;
        $mod=Lf::app("Accrual","Doc");
        $data=$mod->read($d);
        return !empty($data)&&isset($data[0])&&is_numeric($data[0]["total"])?$data[0]["total"]:0;
    }
    private function clientBox($id)
    {
        $this->grid->row();
        $this->grid->cell($this->clientDet($id)->rep(),7,[
            "border"=>[1,1,1,1]
        ]);
        $this->grid->cell($this->logopos(),5,[
            "border"=>[1,1,1,1]
        ]);
    }
    private function companyDet()
    {
        $com=Lf::app("Company","Gs");
        $com->fetch();
        $font=7;
        $align="left";
        return dic()
        ->set("stack",lst()
            ->append(dic()                  //Company name
                ->set("text",$com->name)
                ->set("style","header")
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company address
                ->set("text",str_replace("\n", "",$com->address) ." ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company email
                ->set("text",$com->email . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company phone
                ->set("text",$com->phone . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            );
    }
    
    private function clientDet($id)
    {
        $com=Lf::app("Contact","Gs");
        $com->get($id);
        $font=7;
        $align="left";
        return dic()
        ->set("stack",lst()
            ->append(dic()                  //Company name
                ->set("text","Deliver To:")
                ->set("bold","true")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company name
                ->set("text",$com->name)
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company address
                ->set("text",str_replace("\n", "",$com->address) ." ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company email
                ->set("text",$com->email . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company phone
                ->set("text",$com->phone . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            );
    }
    private function filts($filter,$results){//x($filter,9);
        if(empty($filter)){
            return " ";
        }
        $text = "";
        $count = 0;
        foreach($filter as $key){
            if(isset($results[0][$key])){
                $text .= " [";
                $text .= ucfirst($key) ." : ".$results[0][$key];
                $text .= " ] ";
                if($count<(count($filter)-1)){
                    $text .= " | ";
                }
            }
            $count++;
        }
        return ["columns"=>[["text"=>$text,"bold"=>"true","fontSize"=>11]],"columnGap"=>10];
    }
	
    private function logo(){
        return ["columns"=>[$this->logopos()," ",$this->com()],"columnGap"=>10];
    }
    
    private function table($table){
        return $table;//["columns"=>[$table]];
    }
    private function logopos(){
        return [
            "image" => "logo",
            "width" => 150
        ];
    }
    
    private function com(){
        //$com = new \Modules\start\Models\Company();
        //$d = $com->select(["select"=>["name"],"where"=>["id"=>Session::get("company")]]);
        return ["stack"=>[
            ["text"=>$this->company,"style"=>"header","alignment"=>"right"],
            //["text"=>$d[0]["address"],"style"=>"header","alignment"=>"right"],
            //["text"=>$d[0]["phone"],"style"=>"header","alignment"=>"right"],
            //["text"=>$this->advice("advice_month",$id)." ".$this->advice("advice_year",$id),"fontSize"=>9,"alignment"=>"center"]
        ]];
    }
    
	private function titles($id){
        return ["columns"=>[$this->client($id)," ",$this->doc($id)],"columnGap"=>10];
    }
    
    private function line(){
        return ["canvas"=> [[ "type"=> 'line', "x1"=> 0, "y1"=> 5, "x2"=> 595-2*40, "y2"=> 5, "lineWidth"=> 1 ]]];
    }
    
    private function ageSql($type="Debtors"){
        if($type=="Debtors")
        {
            $debit="(case when s.type = 'Receipt' then accruals.amount*r.rate else 0 end) as debit";
            $credit="(case when s.type = 'Payment' then accruals.amount*r.rate else 0 end) as credit";
            
        }else{
            $debit="(case when s.type = 'Receipt' then accruals.amount*r.rate else 0 end) as debit";
            $credit="(case when s.type = 'Payment' then accruals.amount*r.rate else 0 end) as credit";
        }
        return [
            //Select all accruals that are not Prepaids or Notes
            "table"=>"accruals",
            "alias"=>"accruals",
            "join"=>[
                "join"=>[
                    ["sources s","s.id","accruals.source"],
                    ["rates r","r.id","accruals.rate"]
                ]
            ],
            "where"=>["s.model"=>["notin"=>["Prepaid","Anote"]]],
            "select"=>[
                "accruals.date","accruals.comment as narration","accruals.tax_ref as ref",
                //"accruals.amount*r.rate as debit","'0' as credit",
                //$type=="Debtors"?"accruals.amount*r.rate as debit":"'0' as debit",
                //$type=="Creditors"?"accruals.amount*r.rate as credit":"'0' as credit",
                $debit,$credit,
                "accruals.contact","accruals.active"
            ],
            //Select all Credit Note accruals
            "union"=>[
                [
                    "table"=>"accruals",
                    "alias"=>"accruals",
                    "join"=>[
                        "join"=>[
                            ["anotes a","a.accrual","accruals.id"],
                            ["sources s","s.id","accruals.source"],
                            ["rates r","r.id","accruals.rate"],
                            ["notes n","a.note","n.id"],
                            ["accruals a2","a2.id","n.accrual"]
                        ]
                    ],
                    "where"=>["a.type"=>"Credit"],
                    "select"=>[
                        "a2.date","accruals.comment as narration","accruals.tax_ref as ref",
                        "'0' as debit","accruals.amount*r.rate as credit",
                        //$type=="Debtors"?"'0' as debit":"accruals.amount*r.rate as debit",
                        //$type=="Creditors"?"'0' as credit":"accruals.amount*r.rate as credit",
                        "accruals.contact","accruals.active"
                    ]
                ],
                //Select all Debit Note accruals
                [
                    "table"=>"accruals",
                    "alias"=>"accruals",
                    "join"=>[
                        "join"=>[
                            ["anotes aa","aa.accrual","accruals.id"],
                            ["sources s","s.id","accruals.source"],
                            ["rates r","r.id","accruals.rate"],
                            ["notes n","aa.note","n.id"],
                            ["accruals a2","a2.id","n.accrual"]
                        ]
                    ],
                    "where"=>["n.type"=>"Debit"],
                    "select"=>[
                        "a2.date","accruals.comment as narration","accruals.tax_ref as ref",
                        "accruals.amount*r.rate as debit","'0' as credit",
                        //$type=="Debtors"?"accruals.amount*r.rate as debit":"'0' as debit",
                        //$type=="Creditors"?"accruals.amount*r.rate as credit":"'0' as credit",
                        "accruals.contact","accruals.active"
                    ]
                ],
                //Select unallocated Prapayments
                [
                    "alias"=>"accruals",
                    "table"=>[
                        "alias"=>"accruals",
                        "table"=>[
                            "alias"=>"accruals",
                            "table"=>[
                                "table"=>"prepaids",
                                "alias"=>"accruals",
                                "join"=>[
                                    "left join"=>[
                                        ["prepaiduses p","p.prepaid","prepaids.id"]
                                    ]
                                ],
                                "select"=>[
                                    "prepaids.id as pid","p.id as puid","p.realisation","prepaids.accrual","prepaids.active"
                                ],
                                
                            ],
                            "join"=>[
                                "join"=>[
                                    ["accruals a","a.id","accruals.accrual"],
                                    ["rates ar","ar.id","a.rate"]
                                ],
                                "left join"=>[
                                    ["realisations r","r.id","accruals.realisation"],
                                    ["rates rr","rr.id","r.rate"]
                                ]
                            ],
                            "select"=>[
                                "a.date","a.comment as narration","a.tax_ref as ref",
                                "a.amount*ar.rate as aamount","r.amount*rr.rate as ramount",
                                "a.contact","accruals.active","pid"
                            ],
                            "where"=>["accruals.active"=>1,"a.active"=>1],
                        ],
                        "select"=>[
                            "date","narration","ref",
                            "aamount",
                            "sum(case when ramount is null then 0 else ramount end) as ramount",
                            "contact","active"
                        ],
                        "group"=>["pid"]
                        
                    ],
                    "select"=>[
                        "date","narration","ref",
                        //"sum(aamount)-sum(ramount) as amount",
                        $type=="Debtors"?"'0' as debit":"sum(case when aamount is null then 0 else aamount end)-sum(case when ramount is null then 0 else ramount end) as debit",
                        $type=="Creditors"?"'0' as credit":"sum(case when aamount is null then 0 else aamount end)-sum(case when ramount is null then 0 else ramount end) as credit",
                        
                        "contact","active"
                    ],
                    "group"=>["contact"]
                ],
                //Select all realisations
                [
                    "table"=>"realisations",
                    "alias"=>"realisations",
                    "join"=>[
                        "join"=>[
                            ["accruals a","a.id","realisations.accrual"],
                            ["sources s","s.id","a.source"],
                            ["rates r","r.id","realisations.rate"]
                        ]
                    ],
                    "where"=>["s.model"=>["<>","Prepaid"]],
                    "select"=>[
                        "a.date",
                        "concat('Receipt for ',a.comment) as narration",
                        "realisations.manual as ref",
                        $type=="Debtors"?"'0' as debit":"realisations.amount*r.rate as debit",
                        $type=="Creditors"?"'0' as credit":"realisations.amount*r.rate as credit",
                        "a.contact","realisations.active"
                    ]
                ]
            ]
        ];
    }
}
