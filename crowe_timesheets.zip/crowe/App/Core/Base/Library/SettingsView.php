<?php
namespace Core\Base\Library;

use Core\Base\Library\AbView;


class SettingsView extends AbView
{
    use \Lib\Init;
    
	public function form()
    {
        return new Settings();
    }
	
    public
        $_title="General",
        $url="base/settings/create",
        $types="General",
        $type="General",
        $drop=[
            "General"=>"base/settings",
            "Admin"=>"base/settings/auth"
        ];
            
   
}