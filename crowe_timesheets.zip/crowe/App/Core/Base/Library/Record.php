<?php
////__________________________________________________
namespace Core\Base\Library;


use Core\Base\Library\Config;
use Lib\BootSelect as Bs;
use Lib\Factory as Lf;
use Lib\Combo;


class Record extends Editor{
	
    use \Lib\Recid;
    
    public 
        $url,
        $id,
        $card="",
        $script="editor-lines",
        $linesScript="",
        $linesController="base/sourcelines",
        $linesFk="record",
        $lines=["SourceLine","Base"],
        $script2='record-support',
        $mode="edit",
        $card_body="",
        $doc_filter=[],
        $con_filter=[],
        $cre_filter=[],
        $deb_filter=[],
        $cat_filter=[],
        $_categories=null,
        $internal_comment='',
        $attr="data-editable",
        $title="Record Updator",
        $doc_type=false,
        $multiple_doc=false,
        $prefix="UDOC",
        $prefixKey="nil",
        $asset_doc=[["DocType","Base"],[
        "name"=>"FIXED ASSETS",
        "doc"=>[
            ["Doc","Base"],
            [
                "name"=>"ASSETS"
            ]
        ],
        "postable"=>1,
        "debit_core"=>[
            ["CoreAccount","Base"],
        [
            "type"=>"Assets",
            "side"=>"debit",
            "name"=>"FIXED ASSETS"
        ]
        ],
        "credit_core"=>[
            ["CoreAccount","Base"],
            [
            "type"=>"Liabilities",
            "side"=>"credit",
            "name"=>"CREDITORS"
        ]
        ]
    ]];

    public function rows(){
        $div=div();
        $fix=Config::init()->{$this->prefixKey};
        $div->add($this->row1());
        $div->add($this->row2());
        $div->add($this->row3());
        $div->add($this->row4());
        $div->add($this->row5());
        $div->add($this->row6());
        $div->add($this->row7());
        $div->add($this->rowX());
        $div->add(div(ROW)
            ->add(div(C121212)
                ->add(input()
                    ->attr([
                        "name"=>"prefix","data-pattern"=>CHAR_RGX,
                        "value"=>$fix?:$this->prefix,
                        "type"=>"hidden","data-type"=>"input"
                    ])
                )
            )
        );
        return $div;
    }
    
    public function row5(){}
    public function row6(){}
    public function row7(){}
    //date due contact business
    public function row1()
    {  
        return div(ROW)
           ->add(div("col-lg-3 col-md-3 x-x")
                ->add($this->label("Date"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"date","data-pattern"=>DATE_RGX,
                        "data-addon"=>"datepicker","data-type"=>"input",
                        "value"=>$this->val("date")?:date("Y-m-d"),
                        "placeholder"=>"Date - YY-MM-DD (Required)",
                        "required"=>"required",$this->attr=>$this->attr
                    ])
                )
            )
            ->add(div("col-lg-3 col-md-3 x-x")
                ->add($this->label("Due Date"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"due","data-pattern"=>DATE_RGX,"required"=>"required",
                        "data-addon"=>"datepicker",$this->attr=>$this->attr,
                        "data-type"=>"input","value"=>$this->val("due")?:date("Y-m-d"),
                        "placeholder"=>"Due Date - YY-MM-DD (Required)"
                    ])
                )
            )
            ->add(div("col-lg-3 col-md-3 x-x")
                ->add($this->label("Contact","Name of customet or supplier"))
                ->add(Combo::init()
                    ->set_model(["Contact","Base"])
                    ->set_placeholder("Contact (Not Required)")
                    ->set_default($this->val("contact"))
                    ->set_meta([
                        "data-type"=>"input",
                        $this->attr=>$this->attr,
                        "data-acc"=>1
                    ])
                    ->set_pattern("/\d+/")
                    ->set_name("contact")
                    ->html()
                )
            )

            ->add(div("col-lg-3 col-md-3 x-x")
                ->add($this->label("Business Unit"))
                ->add(Bs::init()
                    ->set_model(["Location","Base"])
                    ->set_placeholder("Business Unit (Required)")
                    ->set_default($this->val("business")?:Config::init()->defaultlocation)
                    ->set_filter([
                        "where"=>["type"=>"BusinessUnit"]
                    ])
                    ->set_meta(["data-type"=>"input",$this->attr=>$this->attr])
                    ->set_pattern("/\d+/")
                    ->set_name("business")
                    ->required()
                    ->html()
                )
            );
    }

    //method currency rate amount
    public function row2()
    {   
        $m= Lf::app("Doc","Base");
        return div("row")


            ->add(div("col-lg-3 col-md-3 x-x")
                ->add($this->label("Cash Account"))
                ->add(Bs::init()
                    ->set_model(["CashAccount","Base"])
                    ->set_placeholder("Cash Book Type (Not Required)")
                    ->set_default($this->val("method"))
                    ->set_meta(["data-type"=>"input",$this->attr=>$this->attr,"data-acc"=>1])
                    ->set_pattern("/\d+/")
                    ->set_name("method")
                    ->html()
            )
        )
            ->add(div("col-lg-3 col-md-3 x-x")
                ->add($this->label("Currency"))
                ->add(Bs::init()
                    ->set_model(["Currency","Base"])
                    ->set_placeholder("Record Currency Type (Required)")
                    ->set_default($this->val("currency")?:Config::init()->defaultcurrency)
                    ->set_meta(["data-type"=>"input",$this->attr=>$this->attr])
                    ->set_pattern("/\d+/")
                    ->set_name("currency")
                    ->required()
                    ->html()
            )
        )

            ->add(div("col-lg-3 col-md-3 x-x")
                ->add($this->label("Exchange Rate"))
                ->add(Bs::init()
                    ->set_model(["Rate","Base"])
                    ->set_placeholder("Rate - one unit of base (Required)")
                    ->set_default($this->val("rate")?:Config::init()->defaultrate)
                    ->set_filter([
                       "table"=>[
                            "table"=>"rates","alias"=>"rates",
                            "join"=>[
                                "join"=>[
                                    ["currencies c1","rates.currency","c1.id"],
                                    ["currencies c2","rates.base","c2.id"]
                                ]
                            ],
                            "select"=>["rates.id","rates.date","round(rates.rate,3) as rate", "round(1/rates.rate,3) as rateinverse","c1.name as n1","c2.name as n2"]
                        ],
                        "select"=>[
                           //"*"
                            "id",$m->concat(["'rate'",' (', "'rates.rateinverse'", ') ',"'n1'",'/',"'n2'" ]) ." as rate ","rates.date"
                        ]
                    ])
                    ->set_meta(["data-type"=>"input",$this->attr=>$this->attr])
                    ->set_pattern("/\d+/")
                    ->set_name("rate")
                    ->required()
                    ->html()
            )
        )

        ->add(div("col-lg-3 col-md-3 x-x")
            ->add($this->label("Amount"))
            ->add(input("form-control form-control-sm x-total")
                ->attr([
                    "name"=>"amount","data-pattern"=>CURRENCY_RGX,
                    "type"=>"number","step"=>"any",
                    "data-type"=>"input","value"=>$this->val("amount")?currency($this->rec("amount")):0.00,
                    "placeholder"=>"Amount 000.00 (Required)",
                    "required"=>"required",$this->attr=>$this->attr
                ])
            )
        );
    }
	
    //DocType Category Reference discount
    public function row3()
    {
        $a=($this->rec("accrued")===0)?"required":"data-Y";// x($this->rec("accrued"),9);
        $attr="data-y";
        if($this->doc_type){
            if(!$this->multiple_doc)
            {
                $dt=[$this->doc_type];
                $attr="disabled";
            }else{
                $dt=$this->doc_type;
            }
            foreach($dt as $doc){
                $this->dt[]=$this->idOf($doc);
            }
        }
        return div("row")
             ->add(div(C4412." x-x")
                ->add($this->label("Document Type"))
                ->add(Combo::init()
                    ->set_model(["DocType","Base"])
                    ->set_placeholder("Document Type (Required)")
                    ->set_default(
                        $this->val("doc_type")?:(count($this->dt)==1?$this->dt[0]:null)
                )
                    ->set_filter(empty($this->dt)?[]:[
                        "where"=>["id"=>["in"=>$this->dt]]
                    ])
                    ->set_meta([
                        "data-type"=>"input",
                        $this->attr=>$this->attr,
                        $attr=>$attr,"data-acc"=>1
                    ])
                    ->set_pattern("/\d+/")
                    ->set_name("doc_type")
                    ->required()
                    ->html()
            )
        )
        ->add(div(C4412. " x-x")
            ->add($this->label("Category"))
            ->add(Bs::init()
                ->set_model(["Category","Base"])
                ->set_placeholder("Category (Required)")
                ->set_default($this->val("category"))
                ->set_filter($this->cat_filter?:[
                    "where"=>[
                        "doc_type"=>$this->dt?["in"=>$this->dt]:["<>",null]
                    ]
                ])
                ->set_meta([
                    "data-type"=>"input",
                    $this->attr=>$this->attr
                    ,"data-acc"=>1,$a=>$a
                ])
                ->set_pattern("/\d+/")
                ->set_name("category")
                ->html()
            )
        )  
        ->add(div(C4412." x-x")
            ->add($this->label("Reference"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"ref","data-pattern"=>CHAR_RGX,
                        "data-type"=>"input","value"=>$this->val("ref")?:date("ymdHis"),
                        "placeholder"=>"Referrence (Required)",
                        "required"=>"required",$this->attr=>$this->attr
                    ])
                )
        );
    }
    
    
     public function row4()
    {
        return div("row")
            ->add(div("col-lg-4 col-md-4 x-x")
                ->add($this->label("Stock Location"))
                ->add(Bs::init()
                    ->set_model(["Location","Base"])
                    ->set_placeholder("Stock Location (Required)")
                    ->set_filter([
                        "where"=>[
                            "type"=>"StockLocation"
                        ]
                    ])
                    ->set_default($this->val("location")?:Config::init()->defaultstocklocation)
                    ->set_meta([
                        "data-type"=>"input",$this->attr=>$this->attr,"data-acc"=>1
                    ])
                    ->set_pattern("/\d+/")
                    ->set_name("location")
                    ->required()
                    ->html()
                )
            )
            ->add(div("col-lg-4 col-md-4 x-x")
                ->add($this->label("Debit"))
                ->add(Bs::init()
                    ->set_model(["Account","Base"])
                    ->set_placeholder("Debit Account (Not Required)")
                    ->set_filter([
                        "select"=>["accounts.*"],
                        "join"=>[
                            "join"=>[
                                ["coreaccounts c","c.id","accounts.core"]
                            ]
                        ],
                        "where"=>["c.side"=>"debit"]
                    ])
                    ->set_default($this->val("debit"))
                    ->set_meta(["data-type"=>"input",$this->attr=>$this->attr])
                    ->set_pattern("/\d+/")
                    ->set_name("debit")
                    ->html()
                )
            )
            ->add(div("col-lg-4 col-md-4 x-x")
                ->add($this->label("Credit"))
                ->add(Bs::init()
                    ->set_model(["Account","Base"])
                    ->set_placeholder("Credit Account (Not Required)")
                    ->set_filter([
                        "select"=>["accounts.*"],
                        "join"=>[
                            "join"=>[
                                ["coreaccounts c","c.id","accounts.core"]
                            ]
                        ],
                        "where"=>["c.side"=>"credit"]
                    ])
                    ->set_default($this->val("credit"))
                    ->set_meta(["data-type"=>"input",$this->attr=>$this->attr])
                    ->set_pattern("/\d+/")
                    ->set_name("credit")
                    ->html()
                )
            );
    }
    
    
    public function set_categories()
    {
        if($this->_categories){
            foreach ($this->_categories as $cat)
            {
                $this->cat_filter[]=$this->idOf($cat);
            }
        }
    }
    
    public $len;
    public function head()
    {
        $this->len=6;
        return thead()
            ->add(tr()
                ->add(th(["style"=>"width:5%"]))
                //->add(th(["style"=>"width:15%"])->add("Creditor"))
                ->add(th(["style"=>"width:15%"])->add("Item"))
                ->add(th(["style"=>"width:15%"])->add("Number"))
                ->add(th(["style"=>"width:15%"])->add("Quantity"))
                ->add(th(["style"=>"width:15%"])->add("Price"))
                ->add(th(["style"=>"width:30%"])->add("Amount"))
            );
    }
    public function rowX()
    {
        $table=table("table table-sm mt-4 table-bordered");
        $table->attr("style","border-top:1px solid #CCCCCC;");
        $table->add($this->head());
        $body=tbody("lines-body")
            ->attr([
                "data-lineUrl"=> str_replace("/create","/get_line_row",$this->url)
            ]);
        $mod= \Lib\TableFixer::model(Lf::app(...$this->lines));
        $e=$mod->read(["where"=>[$this->linesFk=>$this->id]]);
        //x($this->id);x($this->val("id"));x($e);
        //x(qd(),8);
        foreach($e as $row){
            $body->add($this->row($row));
        }//$body->add($this->row());
        $table->add($body);
        $table->add(tfoot()
            ->add(tr()
                ->add(th(["colspan"=>$this->len])
                    ->add(button("btn btn-sm btn-nl btn-".SUBMIT)
                        ->add("Add Line")
                    )
                )
            )
            ->add(tr()
                ->add(th(["colspan"=>$this->len-1])->add("Total"))
                ->add(th()->add(input("form-control form-control-sm sum")
                    ->attr([
                        "name"=>"subtotal","placeholder"=>"Value ( Required)",
                        "value"=>num($this->val("subtotal")?:0.00),"data-pattern"=>CURRENCY_RGX,
                        $this->attr=>$this->attr,"data-type"=>"input",
                        "step"=>"any","type"=>"number","required"=>"required"
                    ]))
                )
            )
        );
        return div(ROW)
            ->attr("data-x-mod", $this->linesScript)
            ->add(div(C121212." table-responsive")
                ->add($table)
            );
    }
    
    public function row($row=[])
    {
        $tr=tr(["data-value"=>$this->linesController]);
        $tr->add(td()
            ->add(i("mdi mdi-trash-can btn-dl text-danger"))
            ->add(input()
                ->attr([
                    "type"=>"hidden","name"=>"flag",
                    "value"=>$row["flag"]??1
                ])
            )
        );
        $desc=!empty($row["details"])?"block":"none";
        $item=!empty($row["details"])?"none":"block";
        $tr->add(td()
                ->add(div("input-group input-group-sm mb-0")
                    ->add(div("input-group-prepend")
                        ->add(span("input-group-text btn-tgl")
                            ->add(i("mdi mdi-swap-horizontal-bold"))
                        )
                    )
                    ->add(input(NPS)
                        ->attr([
                            "name"=>"details","placeholder"=>"Type item description",
                            "value"=>$row["details"]??"","data-pattern"=>CHAR_RGX,
                            "data-type"=>"line-input","style"=>"display:$desc",
                            $this->attr=>$this->attr,"list"=>"description-list"
                        ]) 
                    )
                    ->add(datalist()
                        ->attr([
                            "id"=>"description-list"
                        ]) 
                    ) 
                    ->add(Combo::init()
                        ->set_model(["Item","Base"])
                        ->set_pattern("/\d+/")
                        ->set_default($row["item"]??"")
                        ->set_meta([
                            "data-type"=>"line-input",
                            $this->attr=>$this->attr,
                            "style"=>"display:$item"
                        ])
                        ->set_name("item")
                        ->html() 
                    )
                )  
            
        );
        $tr->add(td()
            ->add(input(NPS)
                ->attr([
                    "name"=>"number","placeholder"=>"Qty",
                    "value"=>$row["flag"]??0.00,"data-pattern"=>INTEGER_RGX,
                    "step"=>"any","type"=>"number","disabled"=>"disabled"
                ])  
            )
        );
        $tr->add(td()
            ->add(input(NPS)
                ->attr([
                    "name"=>"quantity","placeholder"=>"Qty",
                    "value"=>$row["quantity"]??0.00,"data-pattern"=>DECIMAL_RGX,
                    "data-type"=>"line-input","step"=>"any","type"=>"number"
                ])  
            )
        );
        $tr->add(td()
            ->add(input(NPS)
                ->attr([
                    "name"=>"price","placeholder"=>"Unit Price",
                    "value"=>$row["price"]??0.00,"data-pattern"=>DECIMAL_RGX,
                    "data-type"=>"line-input","step"=>"any","type"=>"number"
                ])  
            )
            ->add(input()
                ->attr([
                    "name"=>"exid",
                    "value"=>$row["id"]??"","data-pattern"=>INTEGER_RGX,
                    "type"=>"hidden"
                ])  
            )
        );
        //return $tr->add(td()->add($this->amount($row, "value")));
        return $tr->add(td()->add(input(NPS)
                ->attr([
                    "name"=>"amt","placeholder"=>"Line Amount",
                    "value"=>0.00,"data-pattern"=>DECIMAL_RGX,
                    "step"=>"any","type"=>"number",
                    "disabled"=>"disabled"
                ]) 
            )
        );    
    }
    
    public function amount($row,$field="amount")
    {
        $div=div("input-group mb-3");
        $b1=div("input-group-prepend btn-view b-x")
            ->attr("data-url","project/benchmarks/ebl/view/")
            ->add(div("input-group-text")
                ->add(i("fa fa-info"))
            );
        $b3=div("input-group-prepend btn-edit b-x")
            ->attr("data-url","project/benchmarks/ebl/edit/")
            ->add(div("input-group-text")
                ->add(i("fa fa-edit"))
            );
        $b2=input(NPS)
            ->attr([
                "name"=>$field,"placeholder"=>"Amount Due",
                "value"=>$row[$field]??0.00,"data-pattern"=>DECIMAL_RGX,
                "data-type"=>"input","step"=>"any","type"=>"number"
            ]); 
        return $div->add($b2)->add($b1);
    }

  

    
	public function notes()
	{
	    $this->body->add(div("row  mb-2")
	        
	        ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Title 1"))
	            ->add(input("form-control form-control-sm")
	                ->attr([
	                    "name"=>"title_1","data-pattern"=>CHAR_RGX,
	                    "data-for"=>"source","value"=>$this->src("title_1"),
	                    "placeholder"=>"Note 1 Title (NOT Required)",
	                    $this->attr=>$this->attr
	                ])
                )
            )
	        ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Note 1"))
	            ->add(textarea("form-control form-control-sm")
	                ->attr([
	                    "name"=>"note_1","data-pattern"=>CHAR_RGX,
	                    "data-for"=>"source","value"=>$this->src("note_1"),
	                    "placeholder"=>"Note 1 (NOT Required)",
	                    $this->attr=>$this->attr
	                ])
                )
            )
	        
	        ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Title 2"))
	            ->add(input("form-control form-control-sm")
	                ->attr([
	                    "name"=>"title_2","data-pattern"=>CHAR_RGX,
	                    "data-for"=>"source","value"=>$this->src("title_2"),
	                    "placeholder"=>"Note 2 Title (NOT Required)",
	                    $this->attr=>$this->attr
	                ])
                )
            )
	        ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Note 2"))
	            ->add(textarea("form-control form-control-sm")
	                ->attr([
	                    "name"=>"note_2","data-pattern"=>CHAR_RGX,
	                    "data-for"=>"source","value"=>$this->src("note_2"),
	                    "placeholder"=>"Note 2 (NOT Required)",
	                    $this->attr=>$this->attr
	                ])
                )
            )
        );
	}
	
	public function method()
	{
	    $this->body->add(div("row")
	        
            ->add(div("col-lg-4 col-md-4 x-x")
                ->add(label("control-label")->add("Posted"))
	            ->add(Combo::init()
	                ->set_data(["No","Yes","Never"])
	                ->set_placeholder("Posted (Required)")
	                ->set_default($this->rec("journalised")?:"0")
	                ->set_meta(["data-for"=>"record",$this->attr=>$this->attr])
	                ->set_pattern("/[0-2]/")
	                ->set_name("journalised")
	                ->required()
	                ->html()
                )
            )
	        
	        ->add(div("col-lg-4 col-md-4 x-x")
	            ->add(label("control-label")->add("Order #"))
	            ->add(input("form-control form-control-sm")
	                ->attr([
	                    "name"=>"order_no","data-pattern"=>CHAR_RGX,
	                    "data-for"=>"source","value"=>$this->src("order_no"),
	                    "placeholder"=>"Order No (NOT Required)",
	                    $this->attr=>$this->attr
	                ])
                )
            )
	        
	        ->add(div("col-lg-4 col-md-4 x-x")
	            ->add(label("control-label")->add("Attention"))
	            ->add(input("form-control form-control-sm")
	                ->attr([
	                    "name"=>"attention","data-pattern"=>CHAR_RGX,
	                    "data-for"=>"source","value"=>$this->src("attention"),
	                    "placeholder"=>"Attention (NOT Required)",
	                    $this->attr=>$this->attr
	                ])
                )
            )
        );
	}
	
	public function accounts1()
	{
	    $this->body->add(div("row")
	        ->add(div("col-lg-6 col-md-6 x-x")
	            ->add(label("control-label")->add("Debit Account"))
	            ->add(Bs::init()
	                ->set_model(["Account","Base"])
	                ->set_placeholder("Debit Account (Not Required)")
	                ->set_filter([
	                    "select"=>["accounts.*"],
	                    "join"=>[
	                        "join"=>[
	                            ["coreaccounts c","c.id","accounts.core"]
	                        ]
	                    ],
	                    "where"=>["c.side"=>"debit"]
	                ])
	                ->set_default($this->rec("debit"))
	                ->set_meta(["data-for"=>"record",$this->attr=>$this->attr])
	                ->set_pattern("/\d+/")
	                ->set_name("debit")
	                ->html()
                )
            )
	        ->add(div("col-lg-6 col-md-6 x-x")
	            ->add(label("control-label")->add("Credit Account"))
	            ->add(Bs::init()
	                ->set_model(["Account","Base"])
	                ->set_placeholder("Credit Account (Not Required)")
	                ->set_filter([
	                    "select"=>["accounts.*"],
	                    "join"=>[
	                        "join"=>[
	                            ["coreaccounts c","c.id","accounts.core"]
	                        ]
	                    ],
	                    "where"=>["c.side"=>"credit"]
	                ])
	                ->set_default($this->rec("credit"))
	                ->set_meta(["data-for"=>"record",$this->attr=>$this->attr])
	                ->set_pattern("/\d+/")
	                ->set_name("credit")
	                ->html()
                )
            )
        );
	}
	
	public function accounts2()
	{
	    $this->body->add(div("row")
	        ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Associated Record"))
	            ->add(Combo::init()
	                ->set_model(["Record","Base"])
	                ->set_placeholder("Linked Record (Not Required)")
	                //->set_filter($this->deb_filter)
	                ->set_default($this->src("record_ref"))
	                ->set_meta(["data-for"=>"source",$this->attr=>$this->attr])
	                ->set_pattern("/\d+/")
	                ->set_name("record_ref")
	                ->html()
                )
            )
	        ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Associated Asset"))
	            ->add(Combo::init()
	                ->set_model(["Record","Base"])
	                ->set_placeholder("Linked Asset (Not Required)")
	                ->set_filter([
	                    "join"=>[
	                        "join"=>[
	                            ["sources","sources.record","records.id"]
	                        ]
	                    ],
	                    "select"=>["records.*"],
	                    "where"=>["sources.doc_type"=>$this->idOf($this->asset_doc)]
	                ])
	                ->set_default($this->src("record_ref"))
	                ->set_meta(["data-for"=>"source",$this->attr=>$this->attr])
	                ->set_pattern("/\d+/")
	                ->set_name("record_ref")
	                ->html()
	                )
	            )
	        ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Debit Account"))
	            ->add(Bs::init()
	                ->set_model(["Account","Base"])
	                ->set_placeholder("Debit Account (Not Required)")
	                ->set_filter([
	                    /*"select"=>["accounts.*"],
	                    "join"=>[
	                        "join"=>[
	                            ["coreaccounts c","c.id","accounts.core"]
	                        ]
	                    ],
	                    "where"=>["c.side"=>"debit"]*/
	                ])
	                ->set_default($this->rec("debit"))
	                ->set_meta(["data-for"=>"record",$this->attr=>$this->attr])
	                ->set_pattern("/\d+/")
	                ->set_name("debit")
	                ->html()
                )
            )
	        ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Credit Account"))
	            ->add(Bs::init()
	                ->set_model(["Account","Base"])
	                ->set_placeholder("Credit Account (Not Required)")
	                ->set_filter([
	                   /* "select"=>["accounts.*"],
	                    "join"=>[
	                        "join"=>[
	                            ["coreaccounts c","c.id","accounts.core"]
	                        ]
	                    ],
	                    "where"=>["c.side"=>"credit"]*/
	                ])
	                ->set_default($this->rec("credit"))
	                ->set_meta(["data-for"=>"record",$this->attr=>$this->attr])
	                ->set_pattern("/\d+/")
	                ->set_name("credit")
	                ->html()
	                )
	            )
	        );
	}
	public function comment()
	{
	    $this->body->add(div("row mb-4")
	        ->add(div("col-lg-6 col-md-6 x-x")
	            ->add(label("control-label")->add("Description"))
	            ->add(textarea("form-control form-control-sm")
	                ->attr([///^[0-9A-Za-z'\_\,\.\- ]+$/
	                    "name"=>"comment","data-pattern"=>"/^[a-zA-Z0-9\/\-\,\(\)\+\.\:\$ ]+$/",
	                    "data-for"=>"record","value"=>$this->rec("comment")?:$this->internal_comment,
	                    "placeholder"=>"Description (Required)",
	                    "required"=>"required",$this->attr=>$this->attr
	                ])
                )
            )
	        
	        ->add(div("col-lg-6 col-md-6 x-x")
	            ->add(label("control-label")->add("External Comment"))
	            ->add(textarea("form-control form-control-sm")
	                ->attr([
	                    "name"=>"extra_comment","data-pattern"=>CHAR_RGX,
	                    "data-for"=>"source","value"=>$this->src("extra_comment"),
	                    "placeholder"=>"Extra Comment (Not Required)",
	                    $this->attr=>$this->attr
	                ])
                )
            )
        );
	}
	
	public function accounts(){
	    return $this->accounts2();
	}
	//public function 
	public function essentials()
	{
	    $this->date_due_contact_location();
	    $this->doc_currency_rate_amount();
	    $this->category_journalised_ref_discount();
	    $this->notes();
	    $this->method();
	    $this->accounts();
	    $this->comment();
	}
	
	public function date_due_contact_location()
	{  
	    //Config::init()->defaultlocation=1;
	    //Config::init()->defaultrate=1;
		$this->body->add(div("row")/*
                    ->add(div("col-lg-3 col-md-3 x-x")
	            ->add(label("control-label")->add("Credit Account"))
	            ->add(Bs::init()
	                ->set_model(["DocType","Base"])
	                ->set_placeholder("Credit Account (Not Required)")
	                ->set_filter([
	                    "select"=>["accounts.*"],
	                    "join"=>[
	                        "join"=>[
	                            ["coreaccounts c","c.id","accounts.core"]
	                        ]
	                    ],
	                    "where"=>["c.side"=>"credit"]
	                ])
	                ->set_default($this->rec("credit"))
	                ->set_meta(["data-for"=>"record",$this->attr=>$this->attr])
	                ->set_pattern("/\d+/")
	                ->set_name("credit")
	                ->html()
	                )
	            )  */  
			->add(div("col-lg-3 col-md-3 x-x")
			    ->add(label("control-label")->add("Date"))
				->add(input("form-control form-control-sm")
					->attr([
						"name"=>"date","data-pattern"=>DATE_RGX,
						"data-addon"=>"datepicker",
						"data-for"=>"record","value"=>$this->rec("date")?:date("Y-m-d"),
						"placeholder"=>"Date - YY-MM-DD (Required)",
					    "required"=>"required",$this->attr=>$this->attr
					])
				)
			)
			->add(div("col-lg-3 col-md-3 x-x")
			    ->add(label("control-label")->add("Due Date"))
				->add(input("form-control form-control-sm")
					->attr([
					    "name"=>"due","data-pattern"=>DATE_RGX,"required"=>"required",
					    "data-addon"=>"datepicker",$this->attr=>$this->attr,
					    "data-for"=>"record","value"=>$this->rec("due")?:date("Y-m-d"),
						"placeholder"=>"Due Date - YY-MM-DD (Required)"
					])
				)
			)
		    
		    ->add(div("col-lg-3 col-md-3 x-x")
		        ->add(label("control-label")->add("Contact"))
		        ->add(Combo::init()
		            ->set_model(["Contact","Base"])
		            ->set_placeholder("Contact (Not Required)")
		            ->set_default($this->rec("contact"))
		            ->set_meta([
		                "data-for"=>"record",
		                $this->attr=>$this->attr,
		                "data-acc"=>1
		            ])
		            ->set_pattern("/\d+/")
		            ->set_name("contact")
		            ->html()
	            )
	        )
		    
		    ->add(div("col-lg-3 col-md-3 x-x")
		        ->add(label("control-label")->add("Business Unit"))
		        ->add(Bs::init()
		            ->set_model(["Location","Base"])
		            ->set_placeholder("Business Unit (Required)")
		            ->set_default($this->rec("location")?:Config::init()->defaultlocation)
		            ->set_filter([
		                "where"=>["type"=>"BusinessUnit"]
		            ])
		            ->set_meta(["data-for"=>"record",$this->attr=>$this->attr])
		            ->set_pattern("/\d+/")
		            ->set_name("location")
		            ->required()
		            ->html()
	            )
	        )
		);
	}
	protected $dt=[];
	
	
	
    
	public function rec($field)
	{
		$mod=\Lib\Factory::app("Record","Base");
		$mod->get($this->id);
		return $mod->$field;
	}
	
	
	public function src($field){
		$mod=Lf::app("Source","Base");
		$mod->fetch([
			"where"=>["record"=>$this->id]
		]);
		return $mod->$field;
	}
	
	public function det_accounts($post)
	{
	    $mod=Lf::app("DocType","Base");
	    $data=$mod->get($post["doc_type"]);
	    $debit_method=$data[0]["debit_notes"];
	    if(!method_exists($this, $debit_method)){
	        throw new \Exception("Method $debit_method in undefined");
	    }
	    $credit_method=$data[0]["credit_notes"];
	    if(!method_exists($this, $debit_method)){
	        throw new \Exception("Method $credit_method in undefined");
	    }
	    return[
	        $this->{$debit_method}($data[0],$post,"debit"),
	        $this->{$credit_method}($data[0],$post,"credit")
	    ];
	}
	public function suspense($name){
	    return $this->acc($name,$this->idOf([
	        ["CoreAccount","Base"],
	        [
	            "type"=>"Equity",
	            "side"=>"credit",
	            "name"=>"SUSPENSE"
	        ]
	    ]),"credit");
	}
	
	public function contact_acc($doc,$post,$side)
	{
	    $mod=Lf::app("Contact","Base");
	    $mod->get($post["contact"]);
	    if(!$mod->id){
	        throw new \Exception("Contact not found");
	    }
	    return $this->acc($mod->rep(),$doc,$side);
	}
	
	public function method_acc($doc,$post,$side)
	{
	    $mod=Lf::app("CashAccount","Base");
	    $mod->get($post["method"]);
	    if(!$mod->id){
	        throw new \Exception("CashAccount not found");
	    }
	    return $this->acc($mod->rep(),$doc,$side);
	}
	
	public function category_acc($doc,$post,$side)
	{
	    if(!is_numeric($post["category"])){
	        throw new \Exception("Category not given");
	    }
	    $mod=\Lib\Factory::app("Category","Base");
	    $mod->get($post["category"]);
	    return $this->acc($mod->rep(),$doc,$side);
	}
	
	public function null_acc($doc,$post,$side){
	    return null;
	}
	public function acc($name,$doc,$side){
	    $acc=new Account($name,$doc[$side=="debit"?"debit_core":"credit_core"]);
	    return $acc->get_account();
	}
	
	public function save($post,$id=null)
	{
	    $sl=Lf::app("DocType","Base");
	    $source=Lf::app("Source","Base");
	    $bool=false;
            try{
	        if(!$sl->trans()){
	            $sl->begin();
	            $bool=true;
	        }
	        if(!isset($post["credit"])||!isset($post["debit"])){
	            $acc=$this->det_accounts($post);
	            $post["debit"]=$acc[0];
	            $post["credit"]=$acc[1];
	        }
	        $sl->get($post["doc_type"]);
	        $post["type"]=$sl->type;
	        $recId=$this->addRecord($post,$id);
	        
                if($bool){
                   $sl->commit();
                }
                return $recId;
	    }catch(\Exception $ex){x($ex,9);
	        if($bool){
    	        $sl->rollback();
    	        return [$ex->getMessage(),false];
	        }
	        else {
	            throw $ex;
	        }
	    }
	}
	
    protected function addRecord($post,$id=null)
    {
        $record=Lf::app("Record","Base");
        if($id){
            $record->get($id);
        }
        foreach ($post as $ky=>$value){
            if(!empty($value)){
                $record->$ky=$value;
            }
        }
        //if($model=="Source")
        //x($record->data(),8);
        $sid=$record->save();
        return $record->id?:$sid;
    }
    
    public function additionalTable()
    {
        $addMod=\Lib\TableFixer::init("Addition","Base");
        $additions=$addMod->read([
            "where"=>["record"=>$this->rec("id")]
        ]);
        $table=table("table table-sm table-bordered");
        $table->add(thead()
            ->add(tr()
                ->add(th()->add(i("flaticon-trash")))
                ->add(th()->add("Name"))
                ->add(th()->add("Effect"))
                ->add(th()->add("Amount"))
            )
        );
        $tableBody=tbody("additions");
        foreach($additions as $addition){
            $tableBody->add($this->additionRow($addition));
        }
        $table->add($tableBody);
        $table->add(tfoot()
            ->add(tr()
                ->add(td(["colspan"=>2])
                    ->add(button("btn btn-sm mt-0 btn-add-add btn-block btn-".SUBMIT)
                        ->add("New Addition")
                    )    
                )
                ->add(th(["colspan"=>2]))
            )
            ->add(tr()
                ->add(th(["colspan"=>3])->add("Total"))
                ->add(td()->add(input(NPS)
                    ->attr([
                       "name"=>"additionTotal","value"=>$this->rec("amount"),
                       "data-pattern"=>CURRENCY_RGX,"type"=>"number",
                       "step"=>"any","disabled"=>"disabled"
                   ])
                        
                ))
            )
        );
        return $table;
    }
    
    public function additionRow($data=[])
    {
        $tr=tr();
        $tr->add(td()->add(span("flaticon-trash btn-add-del text-danger")
            ->attr([
                "title"=>"Delete Additional row","data-toggle"=>"tooltip"
            ]) 
        ));
        $tr->add(td()->add(input(NPS)
            ->attr([
                "name"=>"additionName","value"=>$data["name"]??"",
                "data-pattern"=>CHAR_RGX
            ]) 
        ));
        $tr->add(td()->add(Combo::init()
            ->set_data([
                "Decrease","Increase"
            ]) 
            ->set_placeholder("Choose Effect")
            ->set_default($data["effect"]??"")
            ->set_name("additionEffect")
            ->set_pattern(INTEGER_RGX)
            ->required()
            ->html()
        ));
        return $tr->add(td()
            ->add(input(NPS)
                ->attr([
                    "name"=>"additionAmount","value"=>$data["amount"]??"",
                    "data-pattern"=>CURRENCY_RGX,"type"=>"number",
                    "step"=>"any"
                ]) 
            )
            ->add(input()
                ->attr([
                    "name"=>"additionId","value"=>$data["id"]??"",
                    "data-pattern"=>INTEGER_RGX,"type"=>"hidden"
                ]) 
            )
        );        
    }
}
