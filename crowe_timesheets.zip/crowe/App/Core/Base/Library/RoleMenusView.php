<?php
namespace Core\Base\Library;

class RoleMenusView extends AccessView
{
    use \Lib\Init;
    
    public function form() {
        return new RoleMenus();
    }
    
    public
        $_title="Role Menus",
        $open_title="",
        $url="base/axrolemenus/create",
        $types="Role Menus",
        $type="Role Menu";
    
}

