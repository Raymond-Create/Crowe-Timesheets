<?php
namespace Core\Base\Library;

use Lib\Factory as Fa;


class Settings
{
    public function set_url(){}
    
	public function html()
    {
        $this->lbw=C4412;
		$this->inw=C8812;
		$main=div("card")
			->attr("data-x-mod","gen-set");
		$main->add(div("card-header")
			->add(h3()->add("General/Default Settings"))
		)
		->add($this->body(div("card-body")));
		return div(ROW." mt-2")->add(div(C121212)->add($main));
    }
	
    public function body($div){
		return $this->add(APP .DS. "Core",$this->add(APP .DS. "Modules",$div));
	}
            
    public function add($dir,$div){
		$gen="gen.php";
		foreach(ls($dir) as $module)
		{
			$file=$dir.DS.$module.DS.$gen;
			if(!file_exists($file)){
				continue;
			}
			foreach(require($file) as $config){
				$div->add($this->row($config));
			}
		}
		return $div;
	}
	
	public function row($config){
		return div(ROW ." mb-3")->add($this->label($config))->add($this->input($config));
			
	}
	
	private function label($config){
		// key label desctiption
		//["defaultCurrency","Default Currency","The default currency used by the system"]
		$con=div($this->lbw);
		$label=label(LB);
		if(isset($config[0])&&isset($config[0][0])){
			$label->add($config[0][0]);
		}
		if(isset($config[0])&&isset($config[0][1])){
			$label->attr(["data-toggle"=>"tooltip","title"=>$config[0][1]]);
		}
		return $con->add($label);
	}
	
	private function input($config){
		//type(combo/field/area), name,  meta,model,  filter, data
		//["combo","defaultCurrency",["data-pattern"=>"/\d+/"],["Currency","Base"]]
		$con=div($this->inw);
		if(isset($config[1])&&isset($config[1][0])){
			$meta=[];
			if(isset($config[1][2])){
				$meta=$config[1][2];
			}
			if(isset($config[1][1])){
				$meta["name"]=$config[1][1];
			}
			if($config[1][0]=="combo"){
				$input=\Lib\Combo::init()->set_meta($meta);
			}
			if($config[1][0]=="field"){
				$input=input(NPS)->attr($meta);
			}
			if($config[1][0]=="area"){
				$input=textarea(NPS)->attr($meta);
			}
			if($config[1][0]=="combo"&&isset($config[1][3])&&$config[1][3]){
				$input->set_model($config[1][3]);
			}
			if($config[1][0]=="combo"&&isset($config[1][4])&&$config[1][4]){
				$input->set_filter($config[1][4]);
			}
			if($config[1][0]=="combo"&&isset($config[1][5])&&$config[1][5]){
				$input->set_data($config[1][5]);
			}
			$key=$config[1][1];
			$def=Config::init()->$key;
			if($config[1][0]=="combo"){
				$input->set_default($def);
				$input=$input->html();
			}else{
				$input->attr("value",$def);
			}
			$con->add($input);
		}
		return $con;
	}
	
	private $lbw,$inw;
}