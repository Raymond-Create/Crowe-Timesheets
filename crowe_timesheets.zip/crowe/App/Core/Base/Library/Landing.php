<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Core\Base\Library;

use Core\Authentication\Library\User;
use Lib\Factory as F;
use Lib\Page;

/**
 * Description of Landing
 *
 * @author blessing
 */
class Landing {
    //put your code here
    use \Lib\PageHtml;
    
    public $rows,$page,$filter=[],$result;
    
    public function __construct($rows,$page)
    {
        $this->rows=$rows;
        $this->page=$page;
    }

    public function html()
    {
        $sect= section("container")
            ->attr("data-x-mod","landing-1");
        $sect->add($this->searchRow());
        $sect->add($this->contentRow());
        $sect->add($this->paginationRow());
        return $sect;
    }
    
    public function searchRow() {
        return div(ROW." mb-4")
            ->add(div(C6612)
                ->add(div("input-group input-group-sm")
                    ->add(input(NPS)
                        ->attr([
                            "name"=>"search","list"=>"search-list"
                        ])
                    )
                    ->add(datalist(["id"=>"search-list"]))
                    ->add(div("input-group-append")
                        ->add(button(BNOCS/*BNODS*/." btn-clear")->add("Clear"))
                    )
                )
            );
    }
    public function contentRow() {
        $rw=div(ROW);
        $mod=F::init()->get_model("Org","Authentication");
        $f= $this->filter;
        $f["select"]=["orgs.*"];
        $f["join"]=[
            "join"=>[
                ["dbs","dbs.org","orgs.id",["dbs.user"=>User::id()]]
            ]
        ];
        $page=new Page($mod,$this->filter,$this->rows,$this->page);
        $data=$page->read();//x($data["data"],9);
        $this->result=$data;
        if(isset($data["data"]))
        {
            
            foreach ($data["data"] as $row)
            {
                $rw->add(div(C4412)->add($this->bx($row)));
            }
        }
        return $rw;      
    }
    public function paginationRow() {
       return $this->pages(); 
    }
    
    private function box($rw="")
    {
       //<div class="ms-card ms-widget ms-profile-widget ms-card-fh">
        $box=div("ms-card ms-widget ms-profile-widget ms-card-fh");
        /*    <div class="ms-card-img">
              <img src="../assets/img/project-management/portfolio-sm.jpg" alt="card_img">
            </div>
         */
        $box->add(div("ms-card-img")
            ->add(img()
                ->attr([
                    "src"=>""
                ])
            )
        );
        //<img src="../assets/img/project-management/people-5.jpg" class="ms-img-large ms-img-round ms-user-img" alt="people">
        $box->add(img("ms-img-large ms-img-round ms-user-img")
            ->attr([
                "src"=>""
            ])
        );
        //<div class="ms-card-body">
        return $box->add(div("s-card-body")
            ->add(h2()->add("Organisation"))
            ->add(span()->add($rw["name"]??'COMPANY NAME'))
            ->add(button("btn btn-gradient-primary")
                ->add("Open")
                ->attr("data-value",$rw["db"]??"")
            )
        );
    }
    
    public function bx($rw=[])
    {
        //<div class="card" style="width: 25rem">
        return div(["class"=>"card"])
            //<div class="card-body p-1">
            ->add(div("card-body p-1")
                //<div class="pane border-bottom p-3">
                ->add(div("pane border-bottom p-3")
                    ->add(img("pane-img pane-sm")
                        ->attr([
                            "style"=>"max-width:50px;max-height:50px;display:inline",
                            "src"=>$rw["logo"]??"",
                        ])
                    ) /*
                    ->add(p("card-text m-0 ml-3")
                        ->add("Org")
                    )
                    ->add(div("dropdown ml-auto")
                        ->add(button("btn btn-white btn-flat mr-0")
                            ->attr([
                                "type"=>"button","id"=>"dropDownMenuButton",
                                "data-toggle"=>"dropdown","aria-expanded"=>"false"
                            ])
                            ->add(i("text-dark fa fa-ellipsis-h"))
                        )
                        ->add(ul("dropdown-menu")
                            ->attr("aria-labelledby","dropdownMenuButton")
                            ->add(li()
                                ->add(span("dropdown-item disabled")
                                    ->attr("href","#")->add("Edit Profile")
                                )
                            )
                            ->add(li()
                                ->add(span("dropdown-item divider"))
                            )
                            ->add(li()
                                ->add(span("dropdown-item disabled")
                                    ->attr("href","#")->add("1")
                                )
                            )
                            ->add(li()
                                ->add(span("dropdown-item disabled")
                                    ->attr("href","#")->add("2")
                                )
                            )
                            ->add(li()
                                ->add(span("dropdown-item disabled")
                                    ->attr("href","#")->add("3")
                                )
                            )
                        )
                    )*/
                )
                ->add(img("card-img img-fluid rounded-0 my-3")
                    ->attr([
                        "style"=>"max-width:200px;max-height:200px;",
                        "src"=>$rw["logo"]??"",
                    ])
                )
                ->add(div("mx-2 mb-4")
                    ->add(h2("card-title")->add($rw["name"]??"COMPANY NAME"))
                    ->add(p("card-text text-muted mb-5")
                        ->add("You have access to the records of ".($rw["name"]??"COMPANY NAME").
                            ". Click button below to gain that access")
                    )
                    ->add(div("my-2")
                        ->add(button("btn btn-success text-dark py-1 btn-block")
                            ->add("open")
                        )
                    )
                )
            );
    
    }
}
