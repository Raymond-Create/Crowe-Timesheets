<?php
namespace Core\Base\Library;

use Core\Base\Library\AbView;


class CategoriesView extends AbView
{
    use \Lib\Init;
    
    public function form(){
        return false;
    }
    
    public
    		$_title="Categories",
    		$url="base/categories/create",
			$types="Categories",
            $type="Category";
    
}