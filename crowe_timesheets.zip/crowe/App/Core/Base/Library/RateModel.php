<?php

namespace Core\Base\Library;

//use Lib\Factory as Lf;
//use Core\Base\Library\Rate;

class RateModel extends Trail
{
    public function insert(array $data,$table=false)
    {
        /*
        if(!isset($data['currency'])||empty($data['currency']))
        {
            $data['currency']=Config::init()->defaultCurrency;
        }
        if($data['currency']==Config::init()->defaultCurrency){
            $data['rate']=1;
        }
        else{
            $data['rate']=Rate::pair($data['currency'],Config::init()->defaultCurrency);
        }*/
        return parent::insert($data,$table);
    }
     
    public function _setup() {
        //parent::struct();
    }
    
    public function update_struct(array $struct)
    {
        $struct['currency']=_foreign([
            'model'=>['Currency','Base']
        ]);
        $struct['rate']=_foreign([
            'model'=>['Rate','Base'],'hide'=>1
        ]);//x(array_keys($struct),9);
        return parent::update_struct($struct);
    }
}