<?php

namespace Core\Base\Library;


use Lib\BootSelect as Bs;
use Lib\Factory as Lf;
use Lib\Combo;
use Lib\Factory;

class Settlement extends AbstractDocument
{
    
    public 
    $multiple_doc=true,
    $script="money-script-1",
    $doc_type=[
        [["DocType","Base"],[
            "name"=>"PAYMENT",
            "doc"=>[
                ["Doc","Base"],
                [
                    "name"=>"CASHBOOK"
                ]
            ],
            "type"=>"Payment",
            "postable"=>1,
            "debit_notes"=>"contact_acc",
            "debit_core"=>[
                ["CoreAccount","Base"],
                [
                    "type"=>"Liabilities",
                    "side"=>"credit",
                    "name"=>"CREDITORS"
                ]
            ],
            "credit_notes"=>"method_acc",
            "credit_core"=>[
                ["CoreAccount","Base"],
                [
                    "type"=>"Assets",
                    "side"=>"debit",
                    "name"=>"CASH"
                ]
            ]
        ]],
        [["DocType","Base"],[
            "name"=>"RECEIPT",
            "doc"=>[
                ["Doc","Base"],
                [
                    "name"=>"CASHBOOK"
                ]
            ],
            "type"=>"Receipt",
            "postable"=>1,
            "debit_notes"=>"method_acc",
            "debit_core"=>[
                ["CoreAccount","Base"],
                [
                    "type"=>"Assets",
                    "side"=>"debit",
                    "name"=>"CASH"
                ]
            ],
            "credit_notes"=>"contact_acc",
            "credit_core"=>[
                ["CoreAccount","Base"],
                [
                    "type"=>"Assets",
                    "side"=>"debit",
                    "name"=>"DEBTORS"
                ]
            ]
        ]]
    ],$payment=0,$receipt=1;
    
    public function date_due_contact_location()
    {
        //Config::init()->defaultlocation=1;
        //Config::init()->defaultrate=1;
        $this->body->add(div("row")
            ->add(div("col-lg-4 col-md-4 x-x")
                ->add(label("control-label")->add("Date"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"date","data-pattern"=>DATE_RGX,
                        "data-addon"=>"datepicker",
                        "data-for"=>"record","value"=>$this->rec("date")?:date("Y-m-d"),
                        "placeholder"=>"Date - YY-MM-DD (Required)",
                        "required"=>"required",$this->attr=>$this->attr
                    ])
                )
            )
            ->add(div("col-lg-4 col-md-4 x-x")
                ->add(label("control-label")->add("Account"))
                ->add(Bs::init()
                    ->set_model(["CashAccount","Base"])
                    ->set_placeholder("Account (*Required)")
                    ->set_default($this->src("method"))
                    ->set_filter([
                        //"where"=>["type"=>"BusinessUnit"]
                    ])
                    ->set_meta([
                        "data-acc"=>1,
                        "data-for"=>"source",
                        $this->attr=>$this->attr
                    ])
                    ->set_pattern("/\d+/")
                    ->set_name("method")
                    ->required()
                    ->html()
                    
                )
            )
            ->add(div("col-lg-4 col-md-4 x-x")
                ->add(label("control-label")->add("Contact"))
                ->add(Bs::init()
                    ->set_model(["Contact","Base"])
                    ->set_placeholder("Contact (Not Required)")
                    ->set_default($this->rec("contact"))
                    ->set_meta([
                        "data-for"=>"record",
                        $this->attr=>$this->attr,
                        "data-acc"=>1
                    ])
                    ->set_pattern("/\d+/")
                    ->set_name("contact")
                    ->html()
                )
                ->add(input()
                    ->attr([
                       "name"=>"int_3","type"=>"hidden",
                        "data-for"=>"record","value"=>$this->rec("int_3")
                    ])
                )
            )
        );
        
    }
    
    public  function set_categories(){
        
        $this->_categories=[
            [
                ["Category","Base"],
                [
                    "doc_type"=>$this->doc_type[0],
                    "name"=>"CASH PAYMENT",
                    "type"=>"SETTLEMENT"
                ]
            ],
            [
                ["Category","Base"],
                [
                    "doc_type"=>$this->doc_type[1],
                    "name"=>"CASH RECEIPT",
                    "type"=>"SETTLEMENT"
                ]
            ]
        ];
        return parent::set_categories();
    }
    
    public function table(){
        
    }
    
    public function accounts(){
        return $this->accounts1();
    }
    
    public function notes(){
        
    }
    
    public function method(){
        
    }
    
    public function method2_acc($doc,$post,$side)
    {
        $mod=Lf::app("CashAccount","Base");
        $mod->get($post["sint_3"]);
        if(!$mod->id){
            throw new \Exception("Transfer Cash Account not found");
        }
        return $this->acc($mod->rep(),$doc,$side);
    }
    
    public function payment_doc($receipt=false)
    {
        $mod=Lf::app("DocType","Base");
        $mod->fetch([
            "join"=>[
                "join"=>[
                    ["Doc","Base"]
                ]
            ],
            "select"=>["doctypes.*"],
            "where"=>[
                "docs.name"=>"CASHBOOK",
                "doctypes.name"=>$receipt?"RECEIPT":"PAYMENT"
            ]
        ]);
        return $mod->id;
    }
    
    
    public function receipt_doc()
    {
        return $this->payment_doc(true);
    }
    
    public function contact_acc($doc,$post,$side)
    {
        $mod=Lf::app("Contact","Base");
        $mod->get($post["contact"]);
        if((!isset($post["contact"])||$post["contact"])&&isset($post["sint_3"])){
            return $this->suspense("Cash Transfer");
        }
        return parent::contact_acc($doc, $post, $side);
    }
    public function save($post,$id=null)
    {
        if(!isset($post["sint_3"]))
        {
            return parent::save($post);
        }
        $default=$post;
        $counter=$post;
        $trans=Factory::app("Base","Base");
        try{
            $trans->begin();
            //Create 
            if($post["type"]=="Payment")
            {
                
            }
            else{
                
            }
            $recSrc=parent::save($post);
              
            $trans->commit();
            
        }catch(\Exception $Ex){
            $trans->rollback();
            x($Ex,8);
            return false;
        }
    }
    
}
