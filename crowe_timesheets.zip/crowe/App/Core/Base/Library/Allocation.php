<?php


namespace Core\Base\Library;

use Lib\Factory as Lf;
use Lib\Session;
use Lib\ID;



class Allocation{
    
    use \Core\Base\Library\SerialRep;
    
    public $stlmnt;
    
    public function __construct($stlmnt){
        $this->stlmnt=$stlmnt;
    }

    public function html(){
        $row=div(ROW)
            ->attr("data-x-mod","allocations");
        $body=div("card-body");
        $body->add($this->row0());
        $body->add($this->row1());
        $body->add($this->row2());
        $body->add($this->row3());
        return $row->add(div(C121212)
            ->add(div("card")
                ->add(div("card-header")
                    ->add(h3()->add("Allocation Table"))
                )  
                ->add($body)  
            )   
        );
    }    
    
    public function row0()
    {
        return div(ROW)
            ->add(div(C6612)
            	->add(label(LB)->add("Contact"))
                ->add(\Lib\Combo::init()
                    ->set_model([
                        "Contact","Base"
                    ])
                    ->set_default($this->val("contact"))
                    ->set_name("contact")
                    ->set_meta([
                    	"disabled"=>"disabled"
                    ])
                    ->html()
                )
            )
            ->add(div(C6612)
            	->add(label(LB)->add("Settlement Date"))
                ->add(input(NPS)
                    ->attr([
                        "name"=>"date",
                        "value"=>$this->val("date"),
                        "disabled"=>"disabled"
                    ])
                )
            );
    }
    
    public function row1()
    {
        return div(ROW." mt-2")
            ->add(div(C4412)
            	->add(label(LB)->add("Currency"))
                ->add(\Lib\Combo::init()
                    ->set_model([
                        "Currency","Base"
                    ])
                    ->set_default($this->val("currency"))
                    ->set_name("currency")
                    ->set_meta([
                    	"disabled"=>"disabled"
                    ])
                    ->html()
                )
            )
            ->add(div(C4412)
            	->add(label(LB)->add("Settlement Rate"))
                ->add(\Lib\Combo::init()
                    ->set_model([
                        "Rate","Base"
                    ])
                    ->set_default($this->val("rate"))
                    ->set_name("rate")
                    ->set_meta([
                    	"disabled"=>"disabled"
                    ])
                    ->html()
                )
            )
            ->add(div(C4412)
            	->add(label(LB)->add("Current Rate"))
                ->add(\Lib\Combo::init()
                    ->set_model([
                        "Rate","Base"
                    ])
                    ->set_default($this->val("rate"))
                    ->set_name("rate")
                    ->set_meta([
                    	"disabled"=>"disabled"
                    ])
                    ->html()
                )
            );
    }    
    
    public function row2()
    {
        $num=$this->serial(
        		$this->val("prefix"),
        		$this->val("number"),
        		$this->val("date")
        	);
        return div(ROW." mt-2")
            ->add(div(C336)
            	->add(label(LB)->add("Type"))
                ->add(\Lib\Combo::init()
                    ->set_data([
                        "Receipt"=>"Receipt","Payment"=>"Payment"
                    ])
                    ->set_default($this->val("type"))
                    ->set_name("type")
                    ->set_meta([
                    	"disabled"=>"disabled"
                    ])
                    ->html()
                )
            )
            ->add(div(C336)
            	->add(label(LB)->add("Doc Ref"))
                ->add(input(NPS)
                    ->attr([
                        "name"=>"ref",
                        "value"=>$num,
                        "disabled"=>"disabled"
                    ])
                )
            )
            ->add(div(C336)
            	->add(label(LB)->add("Settlement Amount"))
                ->add(input(NPS)
                    ->attr([
                        "name"=>"amount",
                        "value"=>num($this->val("amount")),
                        "disabled"=>"disabled"
                    ])
                )
            )
            ->add(div(C336)
            	->add(label(LB)->add("Unallocated"))
                ->add(input(NPS." has-warning")
                    ->attr([
                         "name"=>"available",
                        "value"=>num(
                        $this->val("amount")-$this->val("paid")
                        ),
                        "disabled"=>"disabled"
                    ])
                )
            );
    }
    
    
    public function row3()
    {
        $mod=Lf::app("Record","Base");
        $data=$mod->read([
            "join"=>[
                "join"=>[
                    ["sources s","s.record","records.id"]
                ],
                "left join"=>[
                    ["payments p","p.accrual","records.id",[
                            "p.realisation"=>$this->stlmnt
                    ]],
                    ["records r","r.id","p.realisation"]
                ]
            ],
            "where"=>[
                "records.contact"=>$this->val("contact"),
                "records.type"=>$this->val("type"),
                "records.accrual"=>1
            ],
            "select"=>[
                "s.prefix","s.number","records.type",
                "records.currency","records.rate","p.id",
                "records.amount-records.paid as dif",
                "p.amount as pamount","records.date",
                "records.amount","records.id as accrual",
                "r.amount-r.paid as pdif"
            ]
        ]);
    		//x($data);
    		//x(qd(),7);
        $table=table("table table-bordered table-sm")
            ->attr("style","border-top:1px solid #CCCCCC");
        $table->add(thead()
            ->add(tr()
                ->add(th()->add("Settlement For"))
                ->add(th()->add("Total Amount"))
                ->add(th()->add("Amount Outstanding"))
                ->add(th()->add("Amount Allocated"))
                ->add(th()->add("Action Buttons"))
            )
        );
        $tbody=tbody();$numx="";
        foreach($data as $row)
        {
            $key=$this->serial(
                $row["prefix"],$row["number"],$row["date"]
            );//x($row,8);
            if($numx!=$key)
            {
                $numx=$key;//x($row,9);
                if($row["dif"]>0)//&&$row["pdif"]>0)
                {
                    $tbody->add($this->row($row,$key,true));
                }
            }
            if($row["pamount"]){
                $tbody->add($this->row($row,$key));
            }

        }
        return div(ROW." mt-3")
            ->add(div(C121212." table-responsive")
                ->add($table->add($tbody))
            );
    }
    
    private function row($row,$key,$form=false)
    {
        $a=!$form?"disabled":"data-ignore";
        if($form){
            $b=span("fa fa-save btn-add fa-2x text-primary")
                ->attr(["data-toggle"=>"tooltip","title"=>"Save allocation"]);
        }
        else{
            $b=span("fa fa-trash btn-del fa-2x text-danger")
                ->attr(["data-toggle"=>"tooltip","title"=>"Remove allocation"]);;
        }
        $tr=tr()
            ->add(td()//Accrual Record ref
                ->add(input(NPS)->attr(["value"=>$key,"disabled"=>"disabled"]))
                ->add(input()
                    ->attr([
                        "value"=>$row["accrual"],
                        "name"=>"accrual","type"=>"hidden"
                    ])
                )
            );
            $tr->add(td()//Total Amnt
                ->add(input(NPS)->attr([
                    "disabled"=>"disabled",
                    "value"=>$row["amount"]
                ]))
                ->add(input()
                    ->attr([
                        "value"=>$this->stlmnt,
                        "name"=>"realisation","type"=>"hidden"
                    ])
                )
            )
            ->add(td()->add(input(NPS)
                    ->attr([
                        "disabled"=>"disabled",
                        "value"=>$row["dif"],
                        "name"=>"expected"
                    ])
                )
            )
            ->add(td()->add(input(NPS)
                   ->attr([
                       "type"=>"number",
                       "step"=>"any",$a=>$a,
                       "name"=>"amount",
                       "value"=>$form?"":$row["pamount"]
                   ])
               )
            )
            ->add(td()->add($b));
        return $tr;
    }
    private function val($a)
    {
    		$mod=Lf::app("Record","Base");
    		$data=$mod->read([
    			"join"=>[
    				"join"=>[
    					["sources s","s.record","records.id"]
    				]
    			],
    			"where"=>["records.id"=>$this->stlmnt],
    			"select"=>[
    				"s.prefix","s.number","records.type",
    				"records.currency","records.rate",
    				"records.amount","records.paid",
    				"records.date","records.contact"
    			]
    		]);
    		if(empty($data)){return; }
    		if(!isset($data[0])){return; }
    		if(!isset($data[0][$a])){return; }
    		return $data[0][$a];
    }
}