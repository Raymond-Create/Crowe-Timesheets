<?php

namespace Core\Base\Library;

use Lib\Ig;
use Lib\Csv;
use Lib\Char;
use Lib\Factory;

import("Pdfmake");

class CashBook extends ReportHeader{
    
    public 
        $url="base/reports/show_report/Base/Cashbook",
        $report="Cash Book";
    
    private $count=0,$balance=0,$query;
    
    public function filters()
    {
    		$this->add(div("row")
    			->add(div("col-md-4")
    				->add(\Lib\Combo::init()
    				    ->set_pattern("\d+")
    					->set_model(["CashAccount","Base"])
    				    ->set_meta(['data-type'=>"input"])
    					->set_name("account")
    					->required()
    					->html()
    				)
			    )
    		);
    }
    
    public function dsl($csvfile=false)
    {
        if(isset($this->data["account"]))
        {
            $mod=Factory::app("CashAccount","Base");
            $mod->get($this->data["account"]);
            $this->csv=Csv::init(str_replace(" ", "-", $mod->rep()));
        }
        else{
            $this->csv=Csv::init(Char::gen(4));
        }
        $this->csv->add("DATE");
        $this->csv->add("REF");
        $this->csv->add("CONTACT");
        $this->csv->add("NARRATION");
        $this->csv->add("RECEIPTS");
        $this->csv->add("PAYMENTS");
        $this->csv->add("BALANCE");
        $query=[
            "table"=>"records r",
            "join"=>[
                "join"=>[
                    ["sources s","s.record","r.id",["r.active"=>1]],
                    ["contacts c","c.id","r.contact"],
                    ["doctypes d","d.id","s.doc_type"],
                    ["cashaccounts ca","ca.id","s.method"]
                ]
            ],
            "where"=>[
                "ca.id"=>$this->data["account"]
            ],
            "select"=>[
                "r.id","r.date","r.ref","r.comment","d.type",
                "(case when d.type='Receipt' then r.amount else '0' end) as receipt",
                "(case when d.type='Payment' then r.amount else '0' end) as payment",
                "r.amount>r.paid as pending","c.name"
            ],
            "order"=>["r.date","asc"]
        ];
        $m=Factory::app("Record","Base");
        $results = $m->selectx($this->dates($query,$this->data,"r.date"));//x($results,9);
        //x($results,4);
        $com=Factory::init()->get_model("Org","Authentication");
        $com->fetch([
            "where"=>["db"=>\Lib\Session::get("user_selected_database")]
        ]);
        $this->grid=grid(14);
         $this->head($com);
        $this->blank();
        $this->query=$query;
        $this->tb($results);
        $this->blank();
        if($csvfile==707)
        {
            $this->csv->download();
        }
        return [
            "content"=>[
                $this->grid->rep()," ",
            ],
            "styles"=> [
                "header"=> [
                    "fontSize"=> 10,
                    "bold"=>"true",
                    "fillColor"=>"#DCDCDC"
                ],
                "anotherStyle"=>[
                    "italics"=> true,
                    "alignment"=> 'right'
                ]
            ],
            "images"=>[
                "logo"=>$com->logo
            ],
            "background"=>[
                "image"=>"logo",
                "width"=> 200,"opacity"=>0.4,
                "absolutePosition"=> ["x"=> 170, "y"=> 400]
            ],
        ];
        
    }
    
    public function head($com)
    {
        $ca=Factory::app("CashAccount","Base");
        $ca->get($this->data["account"]);
        $curr=Factory::app("Currency","Base");
        $curr->get($ca->currency);
        $date="";
        if($this->from){
            $date="FROM ".date("d-m-y",strtotime($this->from));
        }
        if($this->to){
            $date=" UP TO ".date("d-m-y",strtotime($this->to));
        }
        if(empty($date)){
            $date=date("d F, y");
        }
        $this->grid->row();
        $this->grid->cell($this->company($com)->rep(),7,[
            "colSpan"=>7,
            "border"=>[1,1,1,1],
            "rowSpan"=>4
        ]);
        $this->grid->cell("CASHBOOK ".date("dmy"),7,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->row();
        $this->grid->cell("",7);
        $this->grid->cell("DATE",3,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->cell($date,4,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->row();
        $this->grid->cell("",7);
        $this->grid->cell("CURRENCY",3,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->cell($curr->rep(),4,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->row();
        $this->grid->cell("",7);
        $this->grid->cell("ACCOUNT",3,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
        $this->grid->cell($ca->rep(),4,[
            "border"=>[1,1,1,1],
            "alignment"=>"center",
            "fontSize"=>8
        ]);
    }
   
    public function client()
    {
        $this->grid->row();
        $com=Factory::app("Contact","BAse");
        //$com->get($this->contact);
        $font=7;
        $align="left";
        $dic=dic()
        ->set("stack",lst()
            ->append(dic()                  //Company name
                ->set("text","Deliver To:")
                ->set("bold","true")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company name
                ->set("text",$com->name)
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company address
                ->set("text",str_replace("\n", "",$com->address) ." ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company email
                ->set("text",$com->email . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            ->append(dic()                  //Company phone
                ->set("text",$com->phone . " ")
                ->set("fontSize",$font)
                ->set("alignment",$align)
                )
            );
        $this->grid->cell($dic->rep(),7,[
            "border"=>[1,1,1,1]
        ]);
        $this->grid->cell($this->logopos(),7,[
            "border"=>[1,1,1,1]
        ]);
    }
    
    public function th()
    {
        $this->grid->row();
        $this->grid->cell("DATE",1,[
            "border"=>[0,0,0,0],
            "fontSize"=>8,
            "bold"=>"true",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("CONTACT",2,[
            "border"=>[0,0,0,0],
            "fontSize"=>8,
            "bold"=>"true",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("REF",2,[
            "border"=>[0,0,0,0],
            "fontSize"=>8,
            "bold"=>"true",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("NARRATION",3,[
            "border"=>[0,0,0,0],
            "fontSize"=>8,
            "bold"=>"true",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("Receipt",2,[
            "border"=>[0,0,0,0],
            "fontSize"=>8,
            "bold"=>"true",
            "alignment"=>"right",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("Payment",2,[
            "border"=>[0,0,0,0],
            "fontSize"=>8,
            "bold"=>"true",
            "alignment"=>"right",
            "fillColor"=>"#EAEAEA"
        ]);
        $this->grid->cell("BALANCE",2,[
            "border"=>[0,0,0,0],
            "fontSize"=>8,
            "bold"=>"true",
            "alignment"=>"right",
            "fillColor"=>"#EAEAEA"
        ]);
    }
    
    public function tr($data)
    { 
        $color=$this->count%2?"#FAFAFA":"#FFFFFF";
        if($data["receipt"]>0)
        {
            $this->balance+=$data["receipt"];
        }
        if($data["payment"]>0)
        {
            $this->balance-=$data["payment"];
        }
        $this->grid->row();
        $this->csv->line();
        $this->grid->cell(date("d-m-y",strtotime($data["date"])),1,[
            "border"=>[0,0,0,0],
            "fontSize"=>6.5,
            "fillColor"=>$color
        ]);
        $this->csv->add(date("d-m-y",strtotime($data["date"])));
        $this->grid->cell($data["name"],2,[
            "border"=>[0,0,0,0],
            "fontSize"=>7,
            "fillColor"=>$color
        ]);
        $this->csv->add($data["name"]);
        $this->grid->cell($data["ref"],2,[
            "border"=>[0,0,0,0],
            "fontSize"=>7,
            "fillColor"=>$color
        ]);
        $this->csv->add($data["ref"]);
        $this->grid->cell($data["comment"],3,[
            "border"=>[0,0,0,0],
            "fontSize"=>7,
            "fillColor"=>$color
        ]);
        $this->csv->add($data["comment"]);
        $this->grid->cell($data["receipt"]>0?num($data["receipt"]):" ",2,[
            "border"=>[0,0,0,0],
            "fontSize"=>7,
            "alignment"=>"right",
            "fillColor"=>$color
        ]);
        $this->csv->add($data["receipt"]>0?num($data["receipt"]):" ");//x($data["payee"],9);
        $this->grid->cell($data["payment"]>0?num($data["payment"]):" ",2,[
            "border"=>[0,0,0,0],
            "fontSize"=>7,
            "alignment"=>"right",
            "fillColor"=>$color
        ]);
        $this->csv->add($data["payment"]>0?num($data["payment"]):" ");
        $this->grid->cell(num($this->balance),2,[
            "border"=>[0,0,0,0],
            "fontSize"=>7,
            "alignment"=>"right",
            "fillColor"=>$color
        ]);
        $this->count++;
        $this->csv->add(currency($this->balance));
    }
    
    public function blank()
    {
        $this->grid->row();
        $this->grid->cell(" ",14,[
            "border"=>[0,0,0,0]
        ]);
    }
    
    public function firstRow($data)
    {
        if(!$this->from)
        {
          $this->from=date("Y-01-01"); 
        }
        $mod=Factory::app("Record","Base");
        $data=$mod->selectx([
            "table"=>$this->query,
            "aka"=>"x",
            "where"=>[
                "date"=>["<",$this->from]
            ],
            "select"=>[
                "sum(receipt) as receipt","sum(payment) as payment","sum(receipt-payment) as balance"
            ]
        ]);
        $this->tr([
            "date"=>$this->from,
            "ref"=>"b/f",
            "comment"=>"balance before ".date("d-m-y",strtotime($this->from)),
            "name"=>"",
            "receipt"=>isset($data[0])&&isset($data[0]["receipt"])&&is_numeric($data[0]["receipt"])?num($data[0]["receipt"]):0,
            "payment"=>isset($data[0])&&isset($data[0]["payment"])&&is_numeric($data[0]["payment"])?num($data[0]["payment"]):0,
            "balance"=>isset($data[0])&&isset($data[0]["balance"])&&is_numeric($data[0]["balance"])?num($data[0]["balance"]):0,
        ]);
        
    }
    
}