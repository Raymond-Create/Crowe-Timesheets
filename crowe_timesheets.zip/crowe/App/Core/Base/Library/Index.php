<?php

namespace Core\Base\Library;

use Lib\Lang;
use Lib\Table;
use Huchi\Classes\Tag;
use Lib\Factory as Lf;
use Core\Authentication\Library\LoginLog;
use Huchi\Classes\Tag as t;
use Lib\Session as Sess;
use Lib\Scripts;
use Lib\ID;

trait Index{
    
    
    public function index($rows=25,$page=1,$extra=null)
    {
        $table=$this->records(is_numeric($rows)?$rows:25, is_numeric($page)?$page:1,$extra);
    }
    
    
}

