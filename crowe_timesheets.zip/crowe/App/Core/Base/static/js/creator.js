
class Creator{
	
    constructor(div,sb){
        this.sb=sb;
        this.icon=div.select('i').use();
        this.select=div.select('select').use();
        var a=this.select.data('model');
        this.btn=div.select('.input-group-prepend').use();
        this.data_url="base/records/combo_data/"+this.select.data('model');
        this.form_url=constants.link("base/records/model_form/"+a+"/0/0/");
        this.in_modal=this.select.lookup({"class":"modal"});
		//console.log(this)
    }
    setup(detach){//console.log(this.in_modal)
        if(this.in_modal){
            this.icon.removeClass("fa-plus-square").addClass("fa-ban");
            return;
        }
        if(this.icon.hasClass("fa-ban"))
            return;
		let btnList=e=>{
            this.sb.stop(e);
			 var data=null,fil=this.select.data("filter");
			 if(fil)
				data={filter:fil.replace(/`/g,'"')}
			 this.sb.notify({
                type:"flash-callback",
                data:s=>{
                    if(s.status)
                        X(this.data_url,o=>{
                            PopCombo.init(this.select,o.message).populate(s.status);
                            this.sb.notify({type:"close",data:"dfmdb"},"popup");
                        },data);
                }
            },"vertical-form");
			//console.log("about to launch");
            this.sb.notify({
                type:"launch",
                data:{
                    modal:"dfmdb",
                    mode:"url",
                    data:this.form_url
                }
            },"popup");
        };
        this.btn.bind()[detach?"_click":"click"](btnList);
    }
    
    fixSelect(){
        if(this.select.data("default-value"))
            this.select.selectOn(this.select.data("default-value"));
    }
}

