CORE.add("money-script-2",x=>{
    let contact,date,method,currency,cur,
    expected,amount,rate,ref,record,btn,
    doc_type,debit,credit,type;
    let redraw=()=>{
        X("base/cash/add/"+record.val(),o=>{
            if(o.status)
                contentRedraw(x,o.message);
        });
    };
    let accounts=()=>{
            var data={};
            x.find('[data-acc="1"]').each(i=>{
                    data[x.use(i).attr("name")]=x.use(i).val();
            });
            let set_account=(node,acc)=>{
                    if(!node)return;
                    X("base/records/combo_data/Account/Base/",o=>{
            PopCombo.init(node,o.message).populate(); 
            node.selectOn(acc);
        }/*,{filter:tS({
                alias:"d",
                select:["d.*"],
                join:{
                    "join":[
                        ["coreaccounts c","d.core","c.id"],
                    ]
                },
                where:{"c.side":node.attr("name")}
            })}*/
        );
            }
            X("base/cash/accounts",o=>{
                    if(o.status){
                            set_account(debit,o.message[0]);
                            set_account(credit,o.message[1]);

                    }
            },data);
    }
    let methodCHList=e=>{
        if(nM(x.me(e).val()))
            X('base/cashaccounts/read',o=>{
                if(o.status){
                    currency.selectOn(o.message[0].currency);
                    currencyCH();
                }

            },{
                filter:tS({where:{id:x.me(e).val()}})
            });
        accounts();
    };
    let currencyCH=()=>{
        X('base/rates/to_base/'+currency.val()+"/"+date.val()+'/'+12,o=>{
            if(o.status){
                rate.selectOn(o.message);
                //console.log(rate.selected().inner());
                //console.log(expected.vl());
                var rt=parseFloat(rate.selected().inner());
                var vl=parseFloat(expected.vl());
                var val=vl*rt;
                expected.val(val.toFixed(2));
                amount.val(0.00);
            }
            currency.vl(currency.val());	
        });
    };
    let currencyCHList=e=>{
            if(nM(x.me(e).val()))
                    currencyCH();
    };
    let amountBLList=e=>{
        //console.log(parseFloat(x.me(e).val()));
        //console.log(parseFloat(expected.val()));
        //console.log(parseFloat(x.me(e).val())>parseFloat(expected.val()));
        if(parseFloat(x.me(e).val())>parseFloat(expected.val()))
                x.me(e).val(expected.val());
    };
    let btnList=e=>{
        x.stop(e);
        var t=constants.test,
        url="base/cash/add/"+record.val();
        data={
            doc_type:doc_type.val(),
            type:type.val()
        };
        if(t(contact))
            data.contact=contact.val();
        else return
        if(t(date))
            data.date=date.val();
        else return
        if(t(method))
            data.method=method.val();
        else return
        if(t(currency))
            data.currency=currency.val();
        else return
        if(t(amount))
            data.amount=amount.val();
        else return
        if(t(rate))
            data.rate=rate.val();
        else return	
        if(t(ref))
            data.ref=ref.val();	
        if(amount.val()==0.00)
            return x.notify({data:"Amount of zero not acceptable",type:"warning"},"notify");
        if(t(debit))
            data.debit=debit.val();
        else return
        if(t(credit))
            data.credit=credit.val();
        else return	
        //return console.log(data);
        X(url,o=>{
            if(o.status){
                if(pK('[data-x-mod="data-grid-module"]'))
                    x.notify({type:"redraw",data:()=>{
                        redraw();
                    }},"data-grid-module");	
            }
            constants.shout(o);
        },data);
    };
    
    let deleteList=e=>{
        x.stop(e);
        //console.log(x.me(e).n);
        X("base/payments/del",o=>{
            constants.shout(o);
        },{payment:x.me(e).data("payment")});
    };
    let viewList=e=>{
        x.stop(e);
        x.notify({
            type:"launch",
            data:{
                modal:"dflgb",
                data:constants.link("base/view/pdf/35"),
                mode:"url",
                post:{_url_:"base/settlements/view/"+x.me(e).vl()}
            }
        },"popup");
    };
    let tableListeners=(detach)=>{
        x.find(".btn-delete").each(d=>{
            var dx=x.use(d);
            //console.log(dx.n)
            if(!detach)
                dx.bind().click(deleteList);
            else
                dx.unbind().click(deleteList);
        });
        x.find(".btn-view").each(d=>{
            var dx=x.use(d);
            //console.log(dx.n)
            if(!detach)
                dx.bind().click(viewList);
            else
                dx.unbind().click(viewList);
        });
    };
    let start=()=>{
            contact=x.named("contact");
            date=x.named("date");
            method=x.named("method");
            currency=x.named("currency");
            cur=x.pick(".cur");
            type=x.named("type");
            expected=x.named("amt");
            debit=x.named("debit");
            credit=x.named("credit");
            amount=x.named("amount");
            rate=x.named("rate");
            ref=x.named("ref");
            doc_type=x.named("doc_type");
            record=x.pick(".record");
            btn=x.pick(".btn-save");
            btn.bind().click(btnList);
            amount.bind().blur(amountBLList);
            method.bind().change(methodCHList);
            currency.bind().change(currencyCHList);
            currencyCH();//console.log(type.val())
            tableListeners();
    };
    let stop=()=>{
            currency.bind().change(currencyCHList);
            method.unbind().change(methodCHList);
            amount.unbind().blur(amountBLList);
            btn.unbind().click(btnList);
            tableListeners(true);
            btn=null;
            record=null;
            ref=null;
            rate=null;
            debit=null;
            credit=null;
            amount=null;
            expected=null;
            cur=null;
            currency=null;
            method=null;
            date=null;
            contact=null;
            doc_type=null;
            type=null;
    };
    return{
            init:()=>{
                    start();
            },
            dump:()=>{
                    stop();
            }
    };
});