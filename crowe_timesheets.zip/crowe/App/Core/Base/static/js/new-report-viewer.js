CORE.add("new-report-viewer",x=>{
    let gen,csv,from,to,frame,inputs,url;
    let genList=e=>{
        x.stop(e);
        let btn=x.tag_look(e,"BUTTON");
        var r = url;
        let data = {};
        let bool = true;
        data.to = to.val();
        data.from = from.val();
        inputs.foreach(input=>{
            if (!bool||!constants.test(x.use(input))) {
                bool=false;
                return;
            }
            data[x.use(input).attr('name')] = input.value;
        });
        if(btn.hasClass("btn-csv"))
            return openWindowWithPost(constants.link(r+"/707"),data);
        if (!bool)
                return;
		X(r,resp=>{
                    try {
                            //alert(resp);
                        let s = rS(resp);
                        if (s.status) {
                            let dsl = s.message;
                            const pg = pdfMake.createPdf(dsl);
                            console.log(pg);
                            pg.getDataUrl(dataUrl=>{
                                const iframe=tag('iframe').element();
                                iframe.src = dataUrl;
                                iframe.width = "100%";
                                iframe.height = "700px";
                                frame.empty().append(iframe);
                            });
                        }
                    } catch (e) {
					if (constants.env==constants.dev) {
						alert(e);
						alert(resp);
					} else {
						console.log(e);
						console.log(resp);
					}
				}
		},data);
	};
	
	let build=()=>{
            gen.bind().click(genList);
            csv.bind().click(genList);
	};
	
	let destroy=()=>{
            gen.unbind().click(genList);
            csv.unbind().click(genList);
	};
	
	return{
		init:()=>{
			frame=x.pick('.iframe');
			to=x.named("date_to");
			gen=x.pick('.btn-pdf');
			csv=x.pick('.btn-csv');
			from=x.named("date_from");
			url=x.pick(".index").data("url");
			inputs=x.find('[data-type="input"]');
			build();
		},
		dump:()=>{
			destroy();
			to=null;
			gen=null;
			csv=null;
			from=null;
			frame=null;
			inputs=null;
		}
	};
});