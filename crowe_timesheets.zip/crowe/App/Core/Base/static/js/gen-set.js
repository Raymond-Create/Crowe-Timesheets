/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
CORE.add('gen-set',x=>{
    let listener=e=>{
		
        var name=x.me(e).attr('name');
        var val=x.me(e).val();
        if(!cons.test(x.me(e)))return;
        X('base/settings/kv/'+name+'/set',o=>{
			cons.shout(o);
		},{value:val});
    };
    return{
        init:()=>{ 
			x.find("select").each(inp=>{
				x.use(inp).bind().change(listener);
			});
			x.find("input, textarea").each(inp=>{
				x.use(inp).bind().blur(listener);
			});
        },
        dump:()=>{
            x.find("select").each(inp=>{
				x.use(inp).unbind().change(listener);
			});
			x.find("input, textarea").each(inp=>{
				x.use(inp).unbind().blur(listener);
			});
        }
    };
});

