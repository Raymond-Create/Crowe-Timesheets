CORE.add('notify',function(x){
    var that;
    function notice(msg,type){//alert('notify');
        var data={
            message:msg,title:type,
            type:type,delay:2500
        };//console.log(data);
        x.notify({type:"pop",data:data},"pnotify-interface");
    }
    return{
        init:function(){
            //notice('notify me when done',"error");
            that=this;
            x.listen({
                info:that.info,
                error:that.error,
                warning:that.warning,
                success:that.success
            });
        },
        info:function(msg){notice(msg,'info');},
        error:function(msg){notice(msg,'error');},
        warning:function(msg){notice(msg,'warning');},
        success:function(msg){notice(msg,'success');},
        dump:function(){that=null;}   	
   };
});