var abstractDocumentModule=x=>{
    let record,mode,url,source,add,next,prev,id,id_list,
    ignore,addAdd;
    let currencyCH=()=>{
        var _mt=x.named("amount");
        var _dt=x.named("date");
        var _rt=x.named("rate");
        var _cy=x.named("currency");
        var _url='base/rates/to_base/';
        _url+=_cy.val();
        if(_dt)
                _url+="/"+_dt.val();
        X(_url,o=>{
            if(o.status){
                _rt.selectOn(o.message);
                if(!nM(record.val()))
                    if(!nM(_mt.val()))
                        _mt.val(0.00);
            }	
        });
    };
    let currencyCHList=e=>{
            if(nM(x.me(e).val()))
                    currencyCH();
    };
    let nextList=e=>{
    x.stop(e);
    if(mode.val()=="view")
            return _next();
    update();
};
    let prevList=e=>{
    x.stop(e);
            if(mode.val()=="view")
                    return _prev();
    x.notify({
            type:"open",
            data:"list"
        },"shared-view");
};
let response=(data)=>{
    if(script)
        x.notify({type:"response",data:data},script);
};
let _prev=()=>{
    if(!nM(id.val()))
            return x.notify({type:"info",data:"Click Next to go to first record"},"notify");
    var index=id_list.indexOf(id.val());
    if((index-1)<0)
            return x.notify({type:"info",data:"No more records before this one"},"notify");
    var ur=url+"/";
    ur+=id_list[index-1];
    ur+="/view";
    X(ur,o=>{
        if(!o.status)return;
        swap(o.message);
    });
};
let _next=()=>{
    var index=id_list.indexOf(id.val());
    if(!nM(id.val()))
            index=-1;
    if((index+1)>=id_list.length)
            return x.notify({type:"info",data:"No more records after this one"},"notify");
    var ur=url+"/";
    ur+=id_list[index+1];
    ur+="/view";
    X(ur,o=>{
            if(!o.status)return;
            swap(o.message);
    });
};
let is_id=()=>{
   return !!id.val()&&cons.test(id,()=>{return false;}); 
};

let get_ids=()=>{
    id_list=[];
    X(url.replace("create","read"),o=>{
        if(iA(o.message))
            o.message.forEach(rw=>{
                id_list.push(rw[id.attr("name")]);
            });
    });
};
    let swap=view=>{
        var rw=x.use(tag(view[0],view[1]).element()).select('[data-x-mod="abstract-document"]').use().inner();
        x.notify({type:"shutdown",data:x.mod().use().useParent().n},"mm");
        x.mod().use().inner(rw);
        x.notify({type:"boot",data:x.mod().use().useParent().n},"mm");
        constants.addons(x.mod().use());
    };
    let load_url=urlx=>{
        X(urlx,o=>{
            if(!o.status)return;
            swap(o.message);
        });
    };
    let load=url2=>{
            load_url(url+"/"+url2);
    };
    let calc=()=>{
            let sub=x.named("sub_total");
            let amt=x.named("amount");
            //let dis=x.named("discount");
            let a=0.0,b=0.0;
            x.find(".x-amount").each(v=>{
                    let w=x.use(v);
                    a+=parseFloat(nM(w.val())?w.val():0);
            });
            sub.val(a.toFixed(2));
            //if(dis)
                //b=parseFloat(nM(dis.val())?dis.val():0);
            addCalc();
    };
    let rowListeners=(tr,detach)=>{
            var rwid=tr.select('[name="lid"]').use();
            var rwdel=tr.select('.btn-del-line').use();
            var rwtog=tr.select('.btn-input-toggle').use();
            var rwite=tr.select('[name="item"]').use();
            var rwdet=tr.select('.x-details').use();
            var rwuni=tr.select('.x-unit').use();
            var rwqua=tr.select('.x-quantity').use();
            var rwpri=tr.select('.x-price').use();
            var rwnum=tr.select('.x-flag').use();
            var rwamo=tr.select('.x-amount').use();
            let sumup=()=>{
                    let a=parseFloat(nM(rwqua.val())?rwqua.val():0);
                    let b=parseFloat(nM(rwpri.val())?rwpri.val():0);
                    let c=a*b;
                    rwamo.val(c.toFixed(2));
            };
    let lo_calc=()=>{
        sumup();
        let lnk="base/sourcelines/put/";
        let data={
            units:rwuni.val(),
            source:source.val(),
            price:rwpri.val(),
            flag:parseInt(rwnum.val()),
            quantity:rwqua.val()
        };
        if(nM(rwite.val()))
            data.item=rwite.val()
        else
            data.details=rwdet.val()
        if(nM(rwid.val()))
            lnk+=rwid.val();
        X(lnk,o=>{
            if(o.status){
                if(!nM(rwid))
                    rwid.val(o.status);
                calc();
            }
        },data);
    };
            //delete line
        let rwdelList=e=>{
            x.stop(e);
            if(nM(rwid.val())){
                X("base/sourcelines/remove",o=>{
                    if(o.status)
                        x.me(e).lookup("TR").remove();

                },{id:rwid.val(),type:"delete"});
            }else{
                    x.me(e).lookup("TR").remove();
            }
            calc();
        };
        let rwiteList=e=>{
            X("base/items/read",o=>{
                if(o.status){//console.log(o.message)
                    let u=o.message[0];
                    if(u&&u.id){
                        rwuni.val(u.units);
                        rwpri.val(u.price);
                        rwnum.val(u.margin);
                        rwamo.val(u.price);
                        lo_calc();
                    }
                }
            },{filter:tS({
                    where:{id:x.me(e).val()}
            })});
        };
            //Switch from combo to input or vise vesa
            let rwtogList=e=>{
                x.stop(e);
                if(rwdet.val()){
                   rwdet.vl(rwdet.val());
                }
                if(rwtog.hasClass("inpt")){
                        rwdet.n.style.display = 'none';
                        rwite.useParent(1).show();
                        rwtog.removeClass("inpt");
                        rwtog.select("i").use().removeClass("mdi-form-select").addClass("mdi-form-textbox");
                }
                else{
                        //rwdet.show();
                    rwdet.n.style.display = 'block';
                    rwdet.val(rwdet.vl());
                    rwite.useParent(1).hide();
                    rwtog.addClass("inpt");
                    rwtog.select("i").use().removeClass("mdi-form-textbox").addClass("mdi-form-select");
                    console.log(rwdet.val());
                    console.log(rwite.useParent().n);
                }
            };
            if(detach){
                    rwqua.unbind().blur(lo_calc);
                    rwpri.unbind().blur(lo_calc);
                    rwite.unbind().change(rwiteList);
                    rwtog.unbind().click(rwtogList);
                    rwdel.unbind().click(rwdelList);
            }else{
                    rwqua.bind().blur(lo_calc);
                    rwpri.bind().blur(lo_calc);
                    rwite.bind().change(rwiteList);
                    rwtog.bind().click(rwtogList);
                    rwdel.bind().click(rwdelList);
                    //constants.addons(tr)
            }
            sumup();
    };
    let update=(cb)=>{
        type_fix();
        var bool=true,data={};
        x.find('[data-for]').each(el=>{
            if(!bool)return;
            if(constants.test(x.use(el),()=>false))
                data[x.use(el).attr("name")]=x.use(el).val()
            else{
                bool=false
                console.log(x.use(el).data("pattern"));
                console.log(x.use(el).attr("name"));
                console.log(x.use(el).val());
            }
        });
        if(next){
            next.hide();
            }
            if(bool){
                var address=url.replace("create","save");
                if(nM(record.val()))
                        address+="/"+record.val();//return console.log(address)
                X(address,o=>{
                    if(o.status){
                        if(!nM(source.val()))
                            source.val(o.message[1]);
                        if(!nM(record.val()))
                            record.val(o.message[0]);
                        if(iF(cb))
                            cb(o);
                        x.notify({type:"redraw",data:()=>{
                                console.log("redrawn");
                        }},"data-grid-module");
                        //type_fix();
                    }else{
                       constants.shout({status:false,message:"Not modified OR error while saving changes"}); 
                    }
                    if(next){
                        next.show();
                    }
                },data);
            }
            else if(next){
                    next.show();
            }
            //console.log(data)
            console.log(bool)
    };
    let update_head=(cb)=>{
            /*
            var rec="base/records/put/";
            var src="base/sources/put/";
            var changed=false;
            put(rec,record,"record",o=>{
                    if(o.status){
                            if(!nM(id.val()))
                                    id.val(o.status);
                            if(!nM(record.val()))
                                    record.val(o.status);
                            changed=true;
                    }

                    put(src,source,"source",o=>{
                            if(o.status&&!nM(source.val())){
                                    source.val(o.status);
                                    changed=true;
                            }
                            if(changed)
                                    x.notify({type:"success",data:"Changed successfully saved"},"notify");	
                            if(nM(id)&&Fn(cb))
                                    cb();
                    })
            })*/
            return update(cb);
    };
    
    let show=()=>{
        console.log("record data");
        console.log("++++++++++++++++++++++++++++++++++++++");
        x.find('[data-for="record"]').each(o=>{
            console.log(x.use(o).attr("name")+" : "+x.use(o).val());
        });
        console.log("source data");
        console.log("++++++++++++++++++++++++++++++++++++++");
        x.find('[data-for="source"]').each(o=>{
            console.log(x.use(o).attr("name")+" : "+x.use(o).val());
        });
    };
    
    let type_fix=()=>{
        X("base/doctypes/read",o=>{
            var mm=o.message,mmm=false;
            if(mm[0]&&mm[0].type)
                mmm=mm[0].type;
            if(o.status&&mm)
                if(nM(id.val()))
                    if(x.named("type").val()!=mmm)
                        x.named("type").val(mmm);
           
        },{filter:tS({
            where:{id:x.named("doc_type").val()},
            select:["doctypes.type"]
        })});
    };
    let accounts=()=>{
            var data={};
            var ur1=url.replace("create","accounts");
            x.find('[data-acc="1"]').each(i=>{
                    data[x.use(i).attr("name")]=x.use(i).val();
            });
            let set_account=(node,acc)=>{
                    if(!node)return;
                    X("base/records/combo_data/Account/Base/",o=>{
            PopCombo.init(node,o.message).populate(); 
            node.selectOn(acc);
        }/*,{filter:tS({
                alias:"d",
                select:["d.*"],
                join:{
                    "join":[
                        ["coreaccounts c","d.core","c.id"],
                    ]
                },
                where:{"c.side":node.attr("name")}
            })}*/
        );
            }
            X(ur1,o=>{
                    if(o.status){
                            set_account(x.named("debit"),o.message[0]);
                            set_account(x.named("credit"),o.message[1]);

                    }
            },data);
    };
    let acc=()=>{
        if(!nM(x.named("debit").val())&&!nM(record.val()))
            accounts();
    };
    let mark=elem=>{
            if(elem.attr("required")){
                    //var col=elem.lookup({"class":"x-x"})
                    //if(col)
                    //	col.n.style.backgroundColor="#ffebea";//light cyan
                    constants.test(elem,()=>false)
            }
    };
	//slet put
	let addList=e=>{
		var ur1=url.replace("create","get_line_row"),
		callback=()=>{
			X(ur1,o=>{
				var tr=_tag(o.message).element();
				rowListeners(x.use(tr));
				x.pick("tbody").append(tr);
			})
		};
		if(!nM(id.val()))
			update_head(callback);
		else
			callback();
	};
	let put=(link,key,type,callback)=>{	//return console.log([link,key,type]);	
		var data={};
		var bool=true;
		if(nM(key.val()))
			link+=key.val();
		x.find('[data-for="'+type+'"]').each(elem=>{
			if(!bool)return;
			//if(x.use(elem).attr("name")=="id")return;
			if(constants.test(x.use(elem)))
				data[x.use(elem).attr("name")]=elem.value;
			else
				bool=false;
		});
		if(!bool)return;
		//return console.log([link,key,type]);
		X(link,o=>{
			if(o.status||!nM(key.val())){
				key.val(o.status);
			}
			if(nM(key.val())){
				callback(o);
			}
			else
				console.log(link + " produced " + o.message)
		},data);
	};
	let redraw=()=>{
		var ur=url;
		if(nM(record.val())&&mode.val()!="")
			ur+='/'+record.val();
		else
			ur+='/0'
		ur+='/'+mode.val();
		X(ur,o=>{
			if(o.status){
				var k=x.use(_tag(o.message).element()).select('[data-x-mod="abstract-document"]').use();
				stop();
				x.mod().use().empty();
				x.mod().use().inner(k.inner());
				constants.addons(x.mod().use());
				start();
				x.mod().use().clear();
			}
		})
	};//prov 19v21
	let docCHList=e=>{
		if(!nM(x.me(e).val()))return;
		X("base/records/combo_data/Category/Base/",o=>{
			if(x.named("category"))
            	PopCombo.init(x.named("category"),o.message).populate();
        },{
			filter:tS({
				"where":{"doc_type":x.me(e).val()}
			})
		});
		var inner=x.me(e).selected().use().inner();
		var j=inner.split(" ");
		x.named("type").val(j[j.length-1])
    };
    let addRowLists=(row,detach)=>{
        var del=row.select(".btn-add-del").use();
        var id=row.select('[name="additionId"]').use();
        var name=row.select('[name="additionName"]').use();
        var effect=row.select('[name="additionEffect"]').use();
        var amount=row.select('[name="additionAmount"]').use();
        let affect=e=>{
            x.stop(e);
            var r=x.me(e).lookup("TR");
            if(!constants.test(name))
                return;
            if(!constants.test(amount))
                return;
            if(nM(record.val()))
            {
                inlineCalc(row);
                var url="base/additions/put";
                if(nM(id.val()))
                    url="/"+id.val();
                X("base/additions/put",o=>{
                    if(o.status){
                        if(!nM(id.val()))
                            id.val(o.status);
                        addCalc();
                    }
                },{
                    name:name.val(),effect:effect.val(),
                    amount:amount.val(),record:record.val()
                });
            }
            else addCalc();
        };
        let delL=e=>{
            x.stop(e);
            var r=x.me(e).lookup("TR");
            if(nM(id.val())){
                X("base/additions/remove",o=>{
                    if(o.status)
                       r.remove(); 
                },{id:id.val(),type:"delete"});
            }else r.remove();
        };
        if(detach){
            effect.unbind().change(affect);
            amount.unbind().blur(affect);
            del.unbind().click(delL);
        }else{
            effect.bind().change(affect);
            amount.bind().blur(affect);
            del.bind().click(delL);
        }
    };
    var inlineCalc=(row)=>{
        var effect=row.select('[name="additionEffect"]').use();
        var amount=row.select('[name="additionAmount"]').use();
        if(amount.val()<0&&effect.val()==1||amount.val()>0&&effect.val()==0){ 
            if(nM(amount.val()))
                amount.val(-1*amount.val());
        }
    };
    let addCalc=()=>{
        var tbd=x.pick("tbody.additions");
        var at=x.named("additionTotal");
        var sub=x.named("sub_total");
        var amt=x.named("amount");
        var sum=parseFloat(nM(sub.val())?sub.val():0);
        tbd.select('[name="additionAmount"]').each(k=>{
            inlineCalc(x.use(k).lookup("TR"));
            if(nM(k.value))
                sum+=parseFloat(k.value);
        });
        console.log(sum);
        at.val(sum);
        amt.val(sum);
        update_head();
    };
    let addAddList=e=>{
        x.stop(e);
        if(nM(record.val()))
            X("base/additions/row",o=>{
                var row=_tag(o.message).element();
                var tbd=x.pick("tbody.additions");
                addRowLists(x.use(row));
                tbd.append(row);
            });
    };
    let start=()=>{
        //select key elements
        url=x.pick('[data-url]').data("url");
        source=x.pick('[data-key="source"]');
        id=x.pick('[data-key="record"]');
        addAdd=x.pick(".btn-add-add");
        add=x.pick(".btn-new-line");
        record=x.named("record");
        next=x.pick(".btn-next");
        prev=x.pick(".btn-prev");
        ignore=x.named("ignore");
        mode=x.named("mode");
		//console.log(constants.test(id))
		//attach tr elements
		if(x.pick('tbody')){
			x.pick('tbody').select("tr").each(tr=>{
				rowListeners(x.use(tr));
			});
			calc();
		}
		//mark out required fields
		x.find('[data-for="source"],[data-for="record"]').each(el=>{
			mark(x.use(el));
			if(x.use(el).name()=="SELECT")
				x.use(el).bind().change(update_head);
			else{
				if(x.use(el).data("addon")=="datepicker")
					x.use(el).bind().change(update_head);
				else
					x.use(el).bind().blur(update_head);
			}
				
		});
		//add relevent listeners
		if(add)
                    add.bind().click(addList);
		if(addAdd)
                    addAdd.bind().click(addAddList);
		//$(x.named("title_1").n).datepicker({dateFormat:"yy-mm-dd"});
		//console.log($(x.named("title_1").n).datepicker)
		get_ids();
		mode.bind().change(redraw);
		next.bind().click(nextList);
		prev.bind().click(prevList);
		x.find('[data-acc="1"]').each(o=>{//console.log(o);
			var node=x.use(o);
			if(node.name()=="SELECT")
				node.bind().change(accounts);
			else
				node.bind().blur(accounts);
		});
        if(x.named("currency")&&x.named("rate")){
                x.named("currency").bind().change(currencyCHList);
                currencyCH();
        }
        x.named("doc_type").bind().change(docCHList);
        x.find('[data-x-mod]').each(mm=>{
            var res;
                if(x.use(mm).data('x-mod')!=x.use(mm).id())
                        x.use(mm).id(x.use(mm).data('x-mod'));
            var ee=x.use(mm).data('x-mod')
            if(ee)
                res=CORE.run(ee);
            else return
                if(constants.env==constants.dev)
                    console.log(res.message);
        });
        acc();
        x.listen({
            load1:load_url,load:load
        });
		//recreate();
    };
    let stop=()=>{
        x.ignore(["load1","load"]);
        //remove listeners
        if(add)
            add.unbind().click(addList);
        if(addAdd)
            addAdd.unbind().click(addAddList);
        if(x.named("currency")&&x.named("rate"))
                x.named("currency").unbind().change(currencyCHList);
        x.find('[data-for="source"],[data-for="record"]').each(el=>{
            if(x.use(el).name()=="SELECT")
                x.use(el).unbind().change(update_head);
            else{
                if(x.use(el).data("addon")=="datepicker")
                    x.use(el).unbind().change(update_head);
                else
                    x.use(el).unbind().blur(update_head);
            }
        });
        x.named("doc_type").unbind().change(docCHList);
        mode.unbind().change(redraw);
        next.unbind().click(nextList);
        prev.unbind().click(prevList);
        x.find('[data-acc="1"]').each(o=>{
                var node=x.use(o);
                if(node.name()=="SELECT")
                        node.unbind().change(accounts);
                else
                        node.unbind().blur(accounts);
        });
        x.find('[data-x-mod]').each(mm=>{
            var res;
                res=CORE.halt(x.use(mm).data('x-mod'));
                if(constants.env==constants.dev)
                    console.log(res.message);
        })
        //remove elements
        id=null;
        add=null;
        url=null;
        next=null;
        prev=null;
        mode=null;
        ignore=null;
        source=null;
        record=null;
	};
    let recreate=()=>{
        x.find('[data-addon="xcreator"]').each(add=>{
            var ig=x.use(add).lookup({"class":"input-group"});
            if(ig){
                var s=new Creator(ig,x);
                s.setup();
            }
        });
    };
    return{
        init:()=>{
            start();
            if(!ignore||!ignore.val())
                redraw();
        },
        dump:()=>{
            stop();	
        }
    }
};
CORE.add("abstract-document",abstractDocumentModule);
CORE.add("_abstract-document",abstractDocumentModule);
CORE.add("_abstract-document_",abstractDocumentModule);
constants=constants||{};
constants._popup=constants._popup||{};
constants._popup["abstract-document"]=true;