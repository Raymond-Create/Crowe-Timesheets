CORE.add("user-control",x=>{
	let lock,logout;
	let lockaction=()=>{
		X("authentication/login/lock",o=>{
			console.log(o);
		});
	}
	let lockList=e=>{
		x.stop(e);
		lockaction();
	};
	let logoutList=e=>{
		x.stop(e);
		X("authentication/login/logout",o=>{
			document.location.href=constants.link(o.message);;
		});
	};
	let start=()=>{
		lock=x.pick(".lock-link");
		logout=x.pick(".logout-link");
		lock.bind().click(lockList);
		logout.bind().click(logoutList);
		x.listen({lock:lockaction});
	};
	let stop=()=>{
		x.ignore(["lock"]);
		lock=null;
		logout=null;
		lock.unbind().click(lockList);
		logout.unbind().click(logoutList);
	};
	return {init:start,dump:stop};
})