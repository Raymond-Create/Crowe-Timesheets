CORE.add("record-support",x=>{
    let id,url;
    let accounts=()=>{
        var data={};
        var ur1=url.replace("create","accounts");
        x.find('[data-acc="1"]').each(i=>{
            data[x.use(i).attr("name")]=x.use(i).val();
        });
        let set_account=(node,acc)=>{
            if(!node)return;
            X("base/records/combo_data/Account/Base/",o=>{
                PopCombo.init(node,o.message).populate(); 
                node.selectOn(acc);
            });
        };
        X(ur1,o=>{
            if(o.status){
                set_account(x.named("debit"),o.message[0]);
                set_account(x.named("credit"),o.message[1]);

            }
        },data);
    };
    let acc=()=>{
        if(!nM(x.named("debit").val())&&!nM(id.val()))
            accounts();
    };
    let start=()=>{
        id=x.named("id");
        url=x.named('url').val();
        x.find('[data-acc="1"]').each(o=>{//console.log(o);
            var node=x.use(o);
            if(node.name()=="SELECT")
                node.bind().change(accounts);
            else
                node.bind().blur(accounts);
        }); 
    };
    let stop=()=>{
        x.find('[data-acc="1"]').each(o=>{//console.log(o);
            var node=x.use(o);
            if(node.name()=="SELECT")
                node.unbind().change(accounts);
            else
                node.unbind().blur(accounts);
        }); 
        id=null;
        body=null;
    };
    return{
        init:start,dump:stop
    }; 
});