/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
CORE.add("contacts-support",x=>{
    let focus=g=>{
		var tr=g.lookup("TR");
		var tb=tr.lookup("TBODY");
		tb.select("tr").each(t=>{
			x.use(t).removeClass("focused-tr");
		});
		tr.addClass("focused-tr");
	};
	let editList=e=>{
		x.stop(e);
		var g=x.me(e);
		if(g.name()!="BUTTON")
			g=g.lookup("BUTTON");
		x.notify({type:"load",data:"gs/contacts/create/"+g.vl()+"/edit"},"contact-form");
		x.notify({type:"open",data:"update"},"shared-view");;
    };
	
	let viewList=e=>{
		x.stop(e);
		var g=x.me(e);
		if(g.name()!="BUTTON")
			g=g.lookup("BUTTON");
		x.notify({type:"load",data:"gs/contacts/create/"+g.vl()+"/view"},"contact-form");
		x.notify({type:"open",data:"update"},"shared-view");;
    };
    let attach=(detach)=>{
        x.find('.btn-view').each(b=>{
            x.use(b)[detach?"unbind":"bind"]().click(viewList);
        });
        x.find('.btn-edit').each(b=>{
            x.use(b)[detach?"unbind":"bind"]().click(editList);
        });
    };
    let build=()=>{
        attach();
    };
    let destroy=()=>{
        attach(true);
    };
    return{
        init:()=>{
            build();
        },
        dump:()=>{
            destroy();
        }
    };
});
