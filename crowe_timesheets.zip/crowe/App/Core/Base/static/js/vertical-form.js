/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
CORE.add('vertical-form',x=>{
    let body,clear,edit,add,_url,url,id,model;
    let submit=e=>{
        x.stop(e);
        //btns();
        var data={},bool=true,inputs=x.find('[name]'),url=_url;
        inputs.each(o=>{
            var input=x.use(o); 
            if(!bool)return;
            if(input.hasClass('pri-key'))return;
            if(cons.test(input))
               data[input.attr('name')]=input.val();
            else bool=false;
        });
		if(nM(id.val()))
			url+="/"+id.val()+"/"
		if(bool)
			X(url,o=>{//console.log(o)
	            var flash=x.get("flash");
	            //console.log(flash);
	            if(iF(flash)){
	                flash(o);
	                x.unset("flash");
	            }
	            else{
	                constants.shout(o);
	                if(o.status&&(!cons.test(id,()=>{return false;})||id.val()==0)){
	                    id.val(o.status);
	                    //btns();
	                }
	            }
	        },data);
    };
    let btns=()=>{
        if(cons.test(id,()=>{return false;})&&id.val()!=0)
        {
            url=cons.link(_url+'/'+id.val()+'/0');
            edit.useParent().show();
            clear.useParent().show();
            add.useParent().hide();
        }
        else{
            url=cons.link(_url+'/0/0');
            edit.useParent().hide();
            clear.useParent().hide();
            add.useParent().show();
        }
    };
    let set_flash=(callable)=>{console.log(callable)
        x.set("flash",callable);
    };
    
    let build=()=>{
        //btns();
        _url='base/records/model_form/';
        _url+=model.split(',').join('/');
        add.bind().click(submit);
        constants.addons(x.mod().use());
    };
    let destroy=()=>{
        add.unbind().click(submit);
    };
    return{
        init:()=>{
            model=x.mod().use().data('model');
            _url=x.mod().use().data('url');
            body=x.pick('.card-body');
            add=x.pick('.btn-add');
            id=x.pick('.pri-key');
            build();
            x.listen({"flash-callback":set_flash});
        },
        dump:()=>{
            x.ignore(["flash-callback"]);
            destroy();
            id=null;
            add=null;
            body=null;
            _url=null;
            model=null;
        }
    };
});


