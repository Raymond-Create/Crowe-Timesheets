CORE.add("money-script-1",x=>{
	return{
		init:()=>{
			
		},
		dump:()=>{
			
		}
	}
});