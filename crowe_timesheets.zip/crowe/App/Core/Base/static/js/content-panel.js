/*** static/js/modules/accounts/my-form.js  ***/
CORE.add('content-panel',function(x){
    let title,card,that,history=[],debug;
    let apply = data => {
		if((data.callback&&iF(data.callback))&&!data.success)
			data.success=data.callback;
		if(data.data&&!data.post)
			data.post=data.data;
		let customise,context;
        if(iO(data)){
            if("customise" in data)
                customise = data.customise;
            if("context" in data)
                context=data.context;
            else
				context=card;
        }else{
            data = {url:data};
        }
		let xhr=jX(data);
		if(!('success' in data)){
			xhr.success(resp=>{
				try{
					let inner;
					let htmlx = /\s*<[0-9\s\w\=\"]>+/;
					let jsonx = /^{.*\"?message\"?\:\[/;
					let msgx = /^{.*\"?message\"?\:[0-9\"]+.*}$/;
					//display message if not html or html
					//representation received
					if(msgx.test(resp)){
                                            let msg = JSON.parse(resp);
                                            return x.notify({
                                                type:msg.status?"error":"success",
                                                data:msg.message
                                            });
					}
					//copy response if its html 
					if(htmlx.test(resp)){
						inner = resp;
					}
					//generate html if response is html
					//representation
					else if(jsonx.test(resp)){
						let json = JSON.parse(resp).message;
						let obj = tag(json[0],json[1]);
						inner = obj.html();
					}
                    if(iO(resp)&&iA(resp.message)){
                        let obj = tag(resp.message[0],resp.message[1]);
						inner = obj.html();
                    }
					cons.display(inner,context,customise);
				}catch(e){
					alert(resp);
					alert(e);
				}
			});
        
		}
		xhr.send();
    };
    function debugList(e){
    		x.stop(e);
    		//x.notify({type:"error",data:"notify test"},"notify")
    		alert(card.inner());
    }
    function init(){
    	cons.addons(card);
    	if(debug)
    		debug.bind().click(debugList);
        var ln=card.inner().replace(/\s+/g,'').length;
        if(ln<1)
			cons.display(Views.html('main'));
    }
    
    return{
        init:function(){
            that=this;
            title = x.pick('#content-title');   
            debug = x.pick('.debug') ;       
            card = x.pick('#card');                       
            init();
            x.listen({add:apply});
            x.set("caller",apply);
            constants.query=apply;
        },
        back:num=>{
            num = isNum(num)?num:1;
            let index = history.length - num;
            if(index>0){
                that.add(history[index]);
            }
        },
        dump:function(){
           x.ignore(['add']);
           if(debug)
           x.detach([debug,'click',debugList]);
           title=null;
           card=null;
           that=null,
           debug=null;
        }
    };
});
    