CORE.add("user-enterprises",x=>{
	let activate=e=>{
		x.stop(e);
		var btn=x.tag_look(e,"BUTTON");
		X("authentication/login/activate",o=>{
			console.log(o)
		},{database:btn.vl()});
	};
	let start=()=>{
		x.find(".activate").each(btn=>{
			x.use(btn).bind().click(activate);
		})
	}
	let stop=()=>{
		x.find(".activate").each(btn=>{
			x.use(btn).unbind().click(activate);
		})
	}
	return{init:start,dump:stop};
});