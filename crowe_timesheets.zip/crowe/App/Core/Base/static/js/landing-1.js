CORE.add("landing-1",x=>{
    let search;
    let start=()=>{
        search=x.named("search");
    };
    let stop=()=>{
        search=null;
    };
    return{
        init:start,dump:stop
    };
});