CORE.add("contact-form",x=>{
	let name;
	let nameInputList=e=>{
		x.pick("#name-list").select("option").each(opt=>{
			if(opt.value==x.me(e).val()){
				var url="base/contacts/create/"+x.use(opt).vl()+"/view";
				x.notify({type:"load1",data:url},"editor");
			}
		});
	};
  	let build=()=>{
		name=x.named("name");
		name.bind().input(nameInputList);
	};
	let destroy=()=>{
		name.unbind().input(nameInputList);
		name=null;
	}
	return{
		init:()=>{
            build();
		},
		dump:()=>{
			destroy();
		}
	}
})