CORE.add("report-viewer",x=>{
    let gen,method,base,period,from,to,frame,inputs,url;
    let genList=e=>{
        x.stop(e);
        let data = {};
        let bool = true;
        data.to = to.val();
        data.from = from.val();
        data.period = period.val();
        data.date_method = method.val();
        inputs.foreach(input=>{
            if(!bool||!constants.test(x.use(input)))
            {
                bool=false;
                return;
            }
            data[x.use(input).attr('name')] = input.value;
        });
        if(!bool)return;
        jX({
            url:constants.link(url),
            form_data:data,
            response:'text',
            success:resp=>{
                try{//alert(resp);
                    let s = rS(resp);
                    if(s.status){
                        let dsl = s.message;
                        const pg = pdfMake.createPdf(dsl);
                        console.log(pg);
                        pg.getDataUrl(dataUrl=>{
                            const iframe=tag('iframe').element();
                            iframe.src = dataUrl;
                            iframe.width = "100%";
                            iframe.height = "700px";
                            frame.empty().append(iframe);
                        });
                    }
                }catch(e){
                    if(constants.env==constants.dev)
                    {
                        alert(e);
                        alert(resp);
                    }
                    else{
                        console.log(e);
                        console.log(resp);
                    }
                }
            }
        }).send();
    };
    let methodChList=e=>{
       return (x.me(e).val()=="period")?hide():show();
    };
    let baseChList=e=>{
            if(!isNum(x.me(e).val()))return;
            periodPopulate(x.me(e).val());
    };
    
    let periodPopulate=id=>{
        X(
           "base/reports/combo_data/Period/Base",
           o=>{
               PopCombo.init(period,o.message).populate();
           },
           {
                filter:tS({
                    where:{type:id}
                })
            }
        );return;
            x.get("caller")({
                url:constants.link("start/login/selector/periods"),
                callback:resp=>{
                    try{
                        let s = JSON.parse(resp);
                        if(s.status){
                            let dl = period.useParent().select("datalist").use();
                            let opt = period.select("option").use().n;
                            period.empty().append(opt);
                            dl.empty();
                            s.message.forEach(row=>{
                                dl.append(x.create("option",{
                                    value:row.name,"data-value":row.id
                                }));
                                period.append(x.create("option",{
                                    text:row.name,value:row.id
                                }));
                                //alert(JSON.stringify(row));
                            });
                        }
                    }catch(e){
                        alert(resp);
                        alert(e);
                    }
                }
            });
    };
    
    let show=bool=>{
        if(bool){
            to.useParent(1).hide();
            from.useParent(1).hide();
            base.useParent(1).show();
            period.useParent(1).show();
        }
        else{
            to.useParent(1).show();
            from.useParent(1).show();
            base.useParent(1).hide();
            period.useParent(1).hide();
        }
    };
    let hide=()=>{
        show(true);
    };
    let build=()=>{
        hide();
        gen.bind().click(genList);
        base.bind().change(baseChList);
        method.bind().change(methodChList);
    };
    let destroy=()=>{
        gen.bind()._click(genList);
        base.bind()._change(baseChList);
        method.bind()._change(methodChList);
    };
    return{
        init:()=>{
            frame=x.pick('.iframe');
            to=x.pick('[name="to"]');
            gen=x.pick('.generate-btn');
            from=x.pick('[name="from"]');
            method=x.pick('[name="method"]');
            period=x.pick('[name="period"]');
            url=x.pick(".index").data("url");
            base=x.pick('[name="baseperiod"]');
            inputs=x.find('[data-type="input"]');
            build();
        },
        dump:()=>{
            destroy();
            to=null;
            gen=null;
            base=null;
            from=null;
            frame=null;
            method=null;
            inputs=null;
            period=null;
        }
    };
});