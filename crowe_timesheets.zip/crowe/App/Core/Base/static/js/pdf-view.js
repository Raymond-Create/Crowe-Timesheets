var pdfViewer=x=>{
    let iframe,print,email,download,logo,huchi,url;
	let display=(dsl)=>{
		const pg = pdfMake.createPdf(dsl);
        pg.getDataUrl((dataUrl) => {
            const frame = tag('iframe').element();
            frame.src = dataUrl;
            frame.width = "100%";
            frame.height = "700px";
            iframe.empty().append(frame);
            //attach(dataUrl,pg);
        }); 
	}
    let cb = o =>{//console.log(o)
        try{
            let SE=rS(o);
            if(SE.status){
                display(SE.message);
            }
        }catch(e){
            console.log(o);
            console.log(e);
        }
    };
    let start=()=>{
        if(url.val())
            X(url.val(),o=>{
                //console.log(o.message);
                if(o.status)
                    display(o.message);
            });
        //console.log(x.mod().use().inner());
    };
    return{
	init:()=>{
            url=x.named("url");
            print=x.pick(".print");
            email=x.pick(".email");
            iframe=x.pick(".iframe");
            download=x.pick(".download");
            x.listen({pdf:cb});
            start();
        },
        dump:()=>{
            //x.detachAll();
            x.ignore(["pdf"]);
            url=null;
            logo=null;
            huchi=null;
            print=null;
            email=null;
            iframe=null;
            download=null;
        }
    };
};
CORE.add("pdf-view",pdfViewer);
CORE.add("pdf-view-2s",pdfViewer);