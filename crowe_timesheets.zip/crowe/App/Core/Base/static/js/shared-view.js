CORE.add("shared-view",x=>{
	let indexes;
	let open=(index)=>{
		indexes.each(i=>{
			x.use(i).hide();
		});
		var tt=x.pick('[data-index="'+index+'"]');
		if(tt)
			tt.show();
	};
	let btnList=e=>{
		x.stop(e);
		var b=x.me(e);
		if(b.name()!="BUTTON")
			b=b.lookup("BUTTON");
		var op=b.vl();
		var urlv=x.pick(".form-url");
		if(op=="update"&&urlv){
			x.notify({type:"fetch",data:{url:urlv.vl()}},"url-loader");
			x.notify({type:"open",data:"url_loader"},"shared-view");
		}
		else
			open(b.vl());
	};
	let itemList=e=>{
		x.stop(e);
		var r=x.me(e).vl();
		if(r)
		    constants.query(cons.link(r));
	}
	let build=()=>{//alert(x.find('.x-b'));
		open('x');
		x.find('.x-b').each(b=>{
                    x.use(b).bind().click(btnList);
		});
		var s=x.pick(".init");
		if(s)s.click();
		x.find('.dropdown-item,.reload-link').each(ii=>{
                    x.use(ii).bind().click(itemList);
		});
	}
	let destroy=()=>{
		x.find('.x-b').each(b=>{
			x.use(b).unbind().click(btnList);
		})
		x.find('.dropdown-item').each(ii=>{
			x.use(ii).unbind().click(itemList);
		});
	};
	return{
		init:()=>{
			indexes=x.find('[data-index]');
			x.listen({open:open});
			build();
		},
		dump:()=>{
			destroy();
			x.ignore(["open"]);
			indexes=null;
		}
	}
});