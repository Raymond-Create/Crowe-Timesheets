CORE.add("bread-crumb",x=>{
	return{
		init:()=>{
			
		},
		dump:()=>{
			
		}
	};
})