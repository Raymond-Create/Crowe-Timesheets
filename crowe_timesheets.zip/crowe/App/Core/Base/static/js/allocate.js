/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/javascript.js to edit this template
 */


CORE.add("allocate",x=>{
    let btnList=e=>{
        x.stop(e);
        let tr = x.me(e);
        if(tr.name() != "TR")
            tr = tr.lookup("TR");
        //trFocus(tr);
        x.notify({type:"focus",data:tr},"data-grid-module");
        let id = tr.select('input[name="_key_"]').use().val();
        x.notify({type:"fetch",data:{url:"base/settlements/allocate/"+id}},"url-loader");
        x.notify({type:"open",data:"url_loader"},"shared-view");
    };
    return{
        init:()=>{
           x.find(".btn-allocate").each(o=>{
               x.use(o).bind().click(btnList);
           });
        },
        dump:()=>{
           x.find(".btn-allocate").each(o=>{
               x.use(o).unbind().click(btnList);
           });
        }
    };
});