CORE.add("ages",x=>{
	let boxList=e=>{
		x.stop(e);
		var me=x.me(e);
		if(!me.hasClass("ms-infographics-widget"))
			me=me.lookup({"class":"ms-infographics-widget"});
		console.log(me.inner())
	};
	let start=stop=>{
		x.find(".ms-infographics-widget").each(e=>{
			var ee=x.use(e);
			if(stop)
				ee.unbind().click(boxList);
			else
				ee.bind().click(boxList);
		})
	};
	return{init:start,dump:()=>start(true)};
})