CORE.add("editor-lines",x=>{
    let body,add,sum;
    let save=record=>{
        body.select("tr").each(xtr=>{
            let tr=x.use(xtr);
            let id=tr.select('[name="exid"]').use();
            let item=tr.select('[name="item"]').use();
            let desc=tr.select('[name="description"]').use();
            let price=tr.select('[name="price"]').use();
            let qty=tr.select('[name="quantity"]').use();
            let uni=tr.select('[name="unit"]').use();
            let amt=tr.select('[name="amt"]').use();
            var url=tr.vl()+"/put";
            if(nM(id.val()))
                url+="/"+id.val();
            if(!nM(record))
                return x.notify({type:"error",data:"A valid main record has to be created first"},"notify");
            var t=constants.test;
            var data={record:record};
            if(t(item))
                data.item=item.val();
            if(t(desc))
                data.details=desc.val();
            if(!t(item)&&!t(desc))
                return x.notify({type:"error",data:"Add or select valid line item"},"notify");
            if(t(price))
                data.price=price.val();
            if(t(qty))
                data.quantity=qty.val();
            if(uni&&t(uni))
                data.units=uni.val();
            console.log(data);
            X(url,o=>{
                console.log(o);
                if(!o.status){
                    x.notify({type:"error",data:"Record NOT created or modified"},"notify");
                }
            },data);
        });
    };
    let calc=()=>{
        var sub=0;
        var amount=pK('[name="amount"]');
        body.select('[name="amt"]').each(f=>{
            var vl=x.use(f).val();
            var val=parseFloat(nM(vl)?vl:0);
            sub+=val;
        });
        sum.val(sub.toFixed(2)); 
        if(amount){
            amount.val(sub.toFixed(2));
            x.notify({type:"update",data:null},"editor");
        }
    };
    let addList=e=>{
        x.stop(e);
        var url=body.data("lineurl");
        //return console.log(url);
        X(url,o=>{
            var rw=_tag(o.message).element();
            //return console.log(rw);
            row(x.use(rw));
            body.append(rw);
        });
    };
    let row=(tr,detach)=>{
        let url=tr.vl();
        let btn=tr.select('.btn-dl').use();
        let swp=tr.select('.btn-tgl').use();
        let id=tr.select('[name="exid"]').use();
        let item=tr.select('[name="item"]').use();
        let desc=tr.select('[name="description"]').use();
        let price=tr.select('[name="price"]').use();
        let qty=tr.select('[name="quantity"]').use();
        let uni=tr.select('[name="unit"]').use();
        let amt=tr.select('[name="amt"]').use();
        let list=tr.select('[id="description-list"]').use();
        let preCalc=()=>{
            let q=parseFloat(nM(qty.val())?qty.val():0);
            let p=parseFloat(nM(price.val())?price.val():0);
            let a=p*q;
            amt.val(a.toFixed(2));
            calc();
        };
        let swap=e=>{
            if(item.hasClass("hid"))
            {
                item.show().removeClass("hid");
                desc.hide();
            }
            else{
                desc.show();
                item.hide().addClass("hid");
            }
        };
        let delL=e=>{
            x.stop(e);
            let r=x.me(e).lookup("TR");
            if(nM(id.val())){
                X(url+"/remove",o=>{
                    if(o.status)
                       r.remove(); 
                },{id:id.val(),type:"delete"});
            }else r.remove();
            calc();
        };
        let itemSelected=e=>{
            if(nM(item.val())){
                desc.n.value="";
                //read database for item details
                X("base/items/read",o=>{
                        if(o.status){//console.log(o.message)
                            let u=o.message[0];
                            if(u&&u.id){
                                if(uni)
                                    uni.val(u.units);
                                price.val(u.price);
                                //rwnum.val(u.margin);
                                amt.val(u.price);
                                qty.val(1.00);
                                preCalc();
                            }
                        }
                },{filter:tS({
                    where:{id:item.val()}
                })});
            }
        };
        let descAdded=e=>{
            if(desc.val()!="")
                item.selectOn("");
        };
        let descKu=e=>{
            let val=x.me(e).val();
            X("base/sourcelines/read",o=>{
                if(o.status){//console.log(o.message)
                    let u=o.message[0];
                    if(u&&u.id){
                        console.log(u);
                    }
                }
            },{filter:tS({
                where:{details:["%like%",item.val()]}
            })});
        };
        let descInput=e=>{
            return;
            X("base/items/read",o=>{
                        if(o.status){//console.log(o.message)
                        let u=o.message[0];
                        if(u&&u.id){
                            if(uni)
                                uni.val(u.units);
                            price.val(u.price);
                            //rwnum.val(u.margin);
                            amt.val(u.price);
                            qty.val(1.00);
                            preCalc();
                        }
                    }
                },{filter:tS({
                    where:{id:item.val()}
                })});
        };
        if(detach){
            if(swp)
                swp.unbind().click(swap);
            btn.unbind().click(delL);
            qty.unbind().blur(preCalc);
            desc.unbind().keyup(descKu);
            price.unbind().blur(preCalc);
            desc.unbind().blur(descAdded);
            desc.unbind().input(descInput);
            item.unbind().change(itemSelected);
        }
        else{
            if(swp)
                swp.bind().click(swap);
            btn.bind().click(delL);
            qty.bind().blur(preCalc);
            desc.bind().keyup(descKu);
            price.bind().blur(preCalc);
            desc.bind().blur(descAdded);
            desc.bind().input(descInput);
            item.bind().change(itemSelected);
        }
    };
    let start=()=>{
        body=x.pick(".lines-body");
        add=x.pick(".btn-nl");
        sum=x.named("subtotal");
        add.bind().click(addList);
        body.select("tr").each(tr=>{
            row(x.use(tr));
        });
        x.listen({saveall:save});
    };
    let stop=()=>{
        x.ignore(["saveall"]);
        add.unbind().click(addList);
        body.select("tr").each(tr=>{
            row(x.use(tr),true);
        });
        body=null;
        add=null;
        sum=null;
    };
    return{
        init:start,
        dump:stop
    };
});
