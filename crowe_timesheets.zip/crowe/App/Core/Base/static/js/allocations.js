/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/javascript.js to edit this template
 */


CORE.add("allocations",x=>{
    let available,realisation;
    let redraw=(real)=>{
        X("base/settlements/allocate/"+real,o=>{
            if(o.status)
                contentRedraw(x,o.message);
        });
    };
    let btnSave=e=>{
        x.stop(e);
        var tr=x.me(e).lookup("TR");
        var amt=tr.select('[name="amount"]').use();
        var req=tr.select('[name="expected"]').use();
        var accr=tr.select('[name="accrual"]').use();
        var real=tr.select('[name="realisation"]').use();
        var availv=parseFloat(nM(available.val())?available.val():0);
        var amtv=parseFloat(nM(amt.val())?amt.val():0);
        var reqv=parseFloat(nM(req.val())?req.val():0);
        console.log([availv,amtv,reqv]);
    };
    let btnDel=e=>{
        x.stop(e);
        
    };
    return{
        init:()=>{
            //realisation=x.named("realisation");
            available=x.named("available");
            x.find(".btn-add").each(o=>{
                x.use(o).bind().click(btnSave);
            });
            x.find(".btn-del").each(o=>{
                x.use(o).bind().click(btnDel);
            });
            
        },
        dump:()=>{
            x.find(".btn-add").each(o=>{
                x.use(o).unbind().click(btnSave);
            });
            x.find(".btn-del").each(o=>{
                x.use(o).unbind().click(btnDel);
            });
            available=null;realisation=null;
        }
    };
});