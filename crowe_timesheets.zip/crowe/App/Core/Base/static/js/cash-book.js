CORE.add("cash-book",x=>{
	let from,to,run,xls,index,pdf,receipt,payment,
	account,currency,showing,page;
	let receiptList=e=>{
		prepaid("Receipt");
	};
	let paymentList=e=>{
		prepaid("Payment");
	};
	let prepaid=type=>{
		if(!constants.test(account))return;
		if(!constants.test(currency))return;
		x.notify({
			type:"launch",
			data:{
				data:"fin/prepaid/add/"+type+"/"+account.val()+"/"+currency.val(),
				modal:"dfmdb",
				mode:"url"
			}
		},"popup");
	};
	let edit=e=>{
		var id=btn(e).vl();
		x.notify({
			type:"launch",
			data:{
				data:"fin/prepaid/edit/"+id,
				modal:"dfmdb",
				mode:"url"
			}
		},"popup");
	};
	let runList=e=>{
		x.stop(e);
		redraw();
	};
	let xlsList=e=>{
		x.stop(e);
		redraw(true);
	};
	let redraw=(xl)=>{
		index.css("opacity",0.1);
		if(!constants.test(account))return;
		if(!constants.test(currency))return;
		var ur="fin/cashbook/index",data={
			from:from.val(),
			to:to.val(),
			account:account.val(),
			currency:currency.val()
		};
		if(showing&&nM(showing.val()))
			ur+="/"+showing.val();
		else if(xl)
			ur+="/25";
		if(nM(page&&page.val()))
			ur+="/"+page.val();
		else if(xl)
			ur+="/1";
		if(xl){
			ur+="/100";
			return openWindowWithPost(ur,data)
		}
		X(ur,o=>{
			if(o.status){
				var dex=x.use(_tag(o).element());
				b2();
				bindIndex(true);
				index.empty();
				index.inner(dex.inner());
				bindIndex(false);
				b1();
				index.css("opacity",1);
			}
		},data);
	};
	let recon=e=>{
		var id=btn(e).vl();
		x.notify({
            type:"launch",
            data:{
                modal:"dflgb",
                mode:"url",
                data:constants.link("fin/prepaid/recon/"+id)
            }
        },"popup");
	};
	let del=e=>{
		var id=btn(e).vl();
		var tr=btn(e).lookup("TR");
		x.notify({
            type:"launch",
            data:{
                post:{
					url:"fin/prepaid/remove",
					data:tS({
						id:id,type:"delete",notify:"cash-book"
					}),
					action:"delete"
				},
				modal:"dfmdb",
                mode:"url",
                data:constants.link("gs/landing/confirm_box")
            }
        },"popup");
	}
	let btn=e=>{
		x.stop(e);
		var b=x.me(e);
		if(b.name()!="BUTTON")
			b=b.lookup("BUTTON");
		return b;
	}
	let bindIndex=z=>{
		index.select(".btn-recon").each(b=>{
			x.use(b)[z?"unbind":"bind"]().click(recon);
		});
		index.select(".btn-edit").each(b=>{
			x.use(b)[z?"unbind":"bind"]().click(edit);
		});
		index.select(".btn-delete").each(b=>{
			x.use(b)[z?"unbind":"bind"]().click(del);
		});
	};
	let pageList=()=>{
		redraw();
	};
	let showingList=()=>{
		redraw();
	};
	let b1=()=>{
		page=x.pick('[name="page"]');
		showing=x.pick('[name="showing"]');
		if(page)
			page.bind().change(pageList);
		if(showing)
			showing.bind().change(showingList);
	};
	
	let b2=()=>{
		page=x.pick('[name="page"]');
		showing=x.pick('[name="showing"]');
		if(page)
			page.unbind().change(pageList);
		if(showing)
			showing.unbind().change(showingList);
	};
	
	let build=()=>{
		run.bind().click(runList);
		xls.bind().click(xlsList);
		receipt.bind().click(receiptList);
		payment.bind().click(paymentList);
		bindIndex();//index.opacity(20)
	};
	let destroy=()=>{
		run.unbind().click(runList);
		xls.unbind().click(xlsList);
		receipt.unbind().click(receiptList);
		payment.unbind().click(paymentList);
		bindIndex("unbind");
	};
	return{
		init:()=>{
			payment=x.pick('.btn-payment');
			receipt=x.pick('.btn-receipt');
			account=x.pick('[name="account"]');
			currency=x.pick('[name="currency"]');
			from=x.pick('[name="from"]');
			to=x.pick('[name="to"]');
			run=x.pick('.btn-run');
			pdf=x.pick('.btn-pdf');
			xls=x.pick('.btn-xls');
			index=x.pick('.index');
			build();
			x.listen({"redraw":redraw});
		},
		dump:()=>{
			x.ignore(["redraw"]);
			destroy();
			from=null;
			xls=null;
			pdf=null;
			run=null;
			to=null;
			currency=null;
			account=null;
		}
	};
});