CORE.add("contact-support",x=>{
	let creditorList=e=>{
		x.stop(e);
		open(e,"creditor");
	}
	let debtorList=e=>{
		x.stop(e);
		open(e,"debtor");
	}
	let open=(e,type)=>{
		let tr = x.me(e);
        if(tr.name() != "TR")
            tr = tr.lookup("TR");
		//TODO use a notifier
        //trFocus(tr);
        let id = tr.select('input[name="_key_"]').use().val();
		/*
			x.notify({
				type:"fetch",
				data:{url:"base/statement/pdf",post:{contact:id,type:type}}
			},"url-loader");
			x.notify({type:"open",data:"url_loader"},"shared-view");
		*/
		X("base/statement/pdf",resp=>{
			x.notify({type:"pdf",data:resp},"pdf-view");
			x.notify({type:"open",data:"viewer"},"shared-view");
		},{contact:id,type:type});
	};
	let start=detach=>{
		x.pick("tbody").select('tr').foreach(tr=>{
            var _tr=x.use(tr);//console.log(_tr.select(".btn-edit").use())
            let cbtn = _tr.select(".btn-cstat").use();
            let dbtn = _tr.select(".btn-dstat").use();
			if(detach){
				cbtn.unbind().click(creditorList);
				dbtn.unbind().click(debtorList);
			}
			else{
				cbtn.bind().click(creditorList);
				dbtn.bind().click(debtorList);
			}
		});
	};
	let stop=()=>{
		start(true);
	}
	return{init:start,dump:stop};
})