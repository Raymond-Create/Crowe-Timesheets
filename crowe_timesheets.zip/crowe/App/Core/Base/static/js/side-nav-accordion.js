CORE.add("side-nav-accordion",x=>{
	let aList=e=>{
		x.stop(e);
		let a=x.tag_look(e,"A");
		constants.query(cons.link(a.vl()));
		X("base/menus/track",o=>false,{menu:a.data("menu")});
	};
	return{
            init:()=>{
                x.find('[data-toggle="collapse"]').each(a=>{
                        var parent=x.use(a).useParent();
                        var tid=x.find(x.use(a).data("target"));
                        var len=tid.use().child().length;
                        if(len<1)parent.hide();
                });
                x.find(".anchor-link").each(a=>{
                        x.use(a).bind().click(aList);
                });
            },
            dump:()=>{
                x.find(".anchor-link").each(a=>{
                        x.use(a).unbind().click(aList);
                });
            }
	};
});