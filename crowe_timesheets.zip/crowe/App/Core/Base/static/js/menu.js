CORE.add("menu",x=>{
	let get_user_menus=()=>{
		
	}
	let start=()=>{
		
	};
	let stop=()=>{
		
	}
	return {init:start,dump:stop};
})

//Nelson Mandela Square 5th St, Sandown, Sandton, 2031, South Africa