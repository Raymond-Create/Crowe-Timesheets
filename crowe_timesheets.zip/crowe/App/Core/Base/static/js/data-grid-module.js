CORE.add("data-grid-module",x=>{
    let url,submit,rows,page,pages,body,
    inactive,areas,inputs,selects,search;
    let submitList=e=>{
        x.stop(e);
        let data=new FormData();
        let bool = true;
        let tr = x.me(e).lookup("TR");
        let inputs = tr.select('[name]');
        //check data in in all inputs
        inputs.foreach(m=>{
            var inpt=x.use(m);
            //once one input is invalid we nolonger waste time checking others
            if(!bool)
                return;
            if(x.use(m).attr('type')=="hidden"){
                //console.log(m)
                var regx=new RegExp(inpt.data('pattern').replace(/\//,''));//console.log(regx.test(x.use(m).val()));
                if(!regx.test(inpt.val()))
                    return;
                else
                    data.append(inpt.attr('name'),x.use(m).val());
            }//check validity of input data
            if(cons.test(inpt)){
            	//check if data pk is not empty
            	if(inpt.val()=="")
                    return;
                data.append(inpt.attr('name'),inpt.val());
            }
            else bool = false;
        });
        //if any input has an invalid value do nothing further
        if(!bool)
            return;
	try{
            let xurl = getUrl("put");
            let id = x.pick('[name="id"]');
            if(isNum(id.val()))
                xurl += "/"+id.val()+"/edit";
            x.get("caller")({
                url:constants.link(xurl),
                form_data:data,
                //response:'text',
                callback:resp=>{
                    try{
                        //alert(resp);
                        cons.shout(resp);
                        if(resp.status)
                            redraw(!isNum(id.val()));
                    }catch(e){
                        report(e,resp);
                    }
                }
            });
        }catch(e){
            report(e,null);
        }
    };
    let redraw=lastpage=>{
	//console.log("drawing");
        //return console.log(getFilters());
        let src = getUrl();
        //number of rows
        src += "/";
        src += isNum(rows.val())?rows.val():10;
        //view page
        src += "/";
        if(lastpage&&!iF(lastpage)){
            let q = isNum(pages.val())?pages.val():1;
            src += q+1;
        }
        else src += isNum(page.val())?page.val():1;
        if(inactive){
            //inactive records
            src += "/";
            src += inactive.val();
        }
        X(
            src,
            o=>{
                if(!o.status)
                    x.notify({type:"error",data:"Redraw failure"},"popup");
                var inner='',m=x.use(_tag(o.message).element());
                if(m.data("x-mod")==x.module()){
                        inner=m.inner();
                }
                else{
                    var m2=m.select('[data-x-mod="'+x.module()+'"]').use();
                    if(m2)
                        inner=m2.inner();
                }
                dump();
                start(100);
                x.mod().use().inner(inner);
                init();
                start();
                constants.addons(x.mod().use());
                if(iF(lastpage))lastpage();
            },{
                search_filter:getFilters(),
                //col_filter:getColFilters(),
                //order_filter:getOrderFilters(),
            } 
        );
    };

    let getOrderFilters=()=>{

    };

    let getColFilters=()=>{
            data={};
            if(selects)
                    selects.each(s=>{

                            if(s.value&&constants.test(x.use(s),()=>false))
                                    data[x.use(s).attr('name')]=s.value
                    });
            if(inputs)
                    inputs.each(s=>{

                            if(s.value&&constants.test(x.use(s),()=>false))
                                    data[x.use(s).attr('name')]=["like%",s.value]
                    });
            if(areas)
                    areas.each(s=>{

                            if(s.value&&constants.test(x.use(s),()=>false))
                                    data[x.use(s).attr('name')]=["like%",s.value]
                    });
            return tS({where:data});
    };
		
    let start=(stop)=>{
        if(pK('[data-x-mod="payment-s"]')){
            if(stop)
                            x.notify({type:"destroy",data:null},"payment-s");
                    else
                        x.notify({type:"build",data:null},"payment-s");
        }
            x.find('[data-x-mod]').each(mm=>{
                var res;
                    if(stop)
                    {
                            res=CORE.halt(x.use(mm).data('x-mod'));

                    }

                    else
                    {
                            if(x.use(mm).data('x-mod')!=x.use(mm).id())
                                    x.use(mm).id(x.use(mm).data('x-mod'));
                        res=CORE.run(x.use(mm).data('x-mod'));
                    }
                    if(constants.env==constants.dev){
                        console.log(res.message);
                    }
            })
    };
    let delList=e=>{//return console.log(e);
        x.stop(e);
        var aa=x.me(e).lookup("TD").select('input[name="_key_"]').use();
        var b=x.me(e),src=getUrl("remove");
        if(b.name()!="A")
            b=b.lookup("A");
        let data = {id:aa.val(),type:b.data("action")};
        if(b.data("action")=="delete"){
			x.notify({
                type:"launch",
                data:{
                    post:{
                            url:src,
                            data:tS(data),
                            action:"delete"
                        },
                    modal:"dfmdb",
                    mode:"url",
                    data:constants.link("base/docs/confirm_box")
                }
            },"popup");
        }
        else{
            
           X(src,o=>{
                redraw();
                constants.shout(o);
            },data);
        }
    };
    let getUrl=(last)=>{//console.log(url.vl())
        let a = url.split("/");
        if(last)
            a[a.length-1] = last;
        return a.join("/");
    };
    let openList=e=>{
        let tr = x.me(e);
        if(tr.name() != "TR")
            tr = tr.lookup("TR");
        trFocus(tr);
        let id = tr.select('input[name="_key_"]').use().val();
		X(getUrl("view")+"/"+id,resp=>{
			x.notify({type:"pdf",data:resp},"pdf-view");
			x.notify({type:"open",data:"viewer"},"shared-view");
		});
	};
	
    let viewList=e=>{
        let tr = x.me(e);
        if(tr.name() != "TR")
            tr = tr.lookup("TR");
        trFocus(tr);
        let id = tr.select('input[name="_key_"]').use().val();
        let modem = tr.select('[data-edit]').use();
        if(modem){
			var sv=tr.lookup({"data-x-mod":"shared-view"});
			var ur;
			if(sv){
				ur=getUrl("create");
				var ad=sv.select("#abstract-document").use();
				var ed=sv.select("#editor").use();
				//console.log([ad,ed]);
				if(ad)
					x.notify({type:"load1",data:getUrl("create")+"/"+id+"/view"},"abstract-document");
				if(ed)
					x.notify({type:"load1",data:getUrl("create")+"/"+id+"/view"},"editor");
				x.notify({type:"open",data:"update"},"shared-view");
			}
			else{
				x.notify({
					type:"launch",
					data:{
						data:constants.link(getUrl("add")+"/"+id+"/view"),
						mode:"url",
						modal:"dflgb"
					}
				},"popup");
			}
		}else{
			X(getUrl("head")+"/"+id+"/view",resp=>{
				let s = resp;
                let u = s.message;
                let th = tag(u[0],u[1]).element();
                let table = x.pick("table");
                formDump();
                table.select("thead").use().remove();
                body.before(th);
                formInit();
                constants.addons(x.use(th));
			});
		}
	};
    let trList=(e)=>{
        let tr = x.me(e);
        if(tr.name() != "TR")
            tr = tr.lookup("TR");
        trFocus(tr);
        let id = tr.select('input[name="_key_"]').use().val();
        let mode,m = tr.select('[data-edit]').use();
        mode=m?m.data('edit'):false;
        if(!isNum(id))
            return;
        let link = getUrl(mode?"create":"head");
        link += "/" + id + "/edit";
		if(m){
			var sv=tr.lookup({"data-x-mod":"shared-view"});
			var ur;
			if(sv){
				ur=getUrl("create");
				var ad=sv.select("#abstract-document").use();
				var ed=sv.select("#editor").use();
				//console.log([ad,ed]);
				if(ad)
					x.notify({type:"load1",data:getUrl("create")+"/"+id+"/edit"},"abstract-document");
				if(ed)
					x.notify({type:"load1",data:getUrl("create")+"/"+id+"/edit"},"editor");
				x.notify({type:"open",data:"update"},"shared-view");
			}
			else{
				x.notify({
					type:"launch",
					data:{
						data:constants.link(getUrl("add")+"/"+id),
						mode:"url",
						modal:"dflgb"
					}
				},"popup");
			}
		}else{
			X(getUrl("head")+"/" + id + "/edit",resp=>{
				let s = resp;
                let u = s.message;
                let th = tag(u[0],u[1]).element();
                let table = x.pick("table");
                formDump();
                table.select("thead").use().remove();
                body.before(th);
                formInit();
                constants.addons(x.use(th));
			});
		}
    };
    let trFocus=tr=>{
        body.select("tr").foreach(row=>{
            x.use(row).removeClass("focused-tr");
        });
        tr.addClass("focused-tr");
    };
    let extraList=e=>{
        var btn=x.me(e);
        if(btn.name()!="BUTTON")
            btn=btn.lookup("BUTTON");
        var url=getUrl(btn.data('call'));
        url+="/"+btn.vl();
        window.open(constants.link(url),'_blank');
    };
	let deleteList=(e)=>{
		delList(e);
	};
    let declineList=(e)=>{
		delList(e);
	};
    let cancelList=(e)=>{
		delList(e);
	};
    let requestList=(e)=>{
		delList(e);
	};
    let acceptList=(e)=>{
		delList(e);
	};
	let payList=e=>{
		x.stop(e);
		let tr = x.me(e);
        if(tr.name() != "TR")
            tr = tr.lookup("TR");
        trFocus(tr);
        let id = tr.select('input[name="_key_"]').use().val();
		x.notify({type:"fetch",data:{url:"base/cash/add/"+id}},"url-loader");
		x.notify({type:"open",data:"url_loader"},"shared-view");
	};
    let bodyBinders=unbind=>{
        body.select('tr').foreach(tr=>{
            var _tr=x.use(tr);//console.log(_tr.select(".btn-edit").use())
            let pay = _tr.select(".btn-pay").use();
            let open = _tr.select(".btn-open").use();
            let view = _tr.select(".btn-view").use();
            let edit = _tr.select(".btn-edit").use();
            let del = _tr.select(".btn-delete").use();
            let accept = _tr.select(".btn-accept").use();
            let cancel = _tr.select(".btn-cancel").use();
            let request = _tr.select(".btn-request").use();
            let decline = _tr.select(".btn-decline").use();
            let extra=_tr.select(".extra-control");
			//console.log([edit,del,cancel,decline,request,accept]);
            if(unbind){
                if(pay)
                    pay.unbind().click(payList);
				if(open)
                    open.unbind().click(openList);
				if(view)
                    view.unbind().click(viewList);
				if(edit)
                    edit.unbind().click(trList);
                if(del)
                    del.unbind().click(deleteList);
                if(accept)
                    accept.unbind().click(acceptList);
                if(decline)
                    decline.unbind().click(declineList);
                if(request)
                    request.unbind().click(requestList);
                if(cancel)
                    cancel.unbind().click(cancelList);
                extra.each(btn=>{
                    x.use(btn).unbind().click(extraList);
                });
            }
            else{
				if(pay)
                    pay.bind().click(payList);
				if(open)
                    open.bind().click(openList);
				if(view)
                    view.bind().click(viewList);
                if(edit)
                    edit.bind().click(trList);
                if(del)
                    del.bind().click(deleteList);
                if(accept)
                    accept.bind().click(acceptList);
                if(decline)
                    decline.bind().click(declineList);
                if(request)
                    request.bind().click(requestList);
                if(cancel)
                    cancel.bind().click(cancelList);
                extra.each(btn=>{
                    x.use(btn).bind().click(extraList);
                });
            }
        });
    };
    let repaint=e=>{
        x.stop(e);
        redraw();
    };
    let searchList=e=>{
    	x.stop(e);/*
        var b=false;
        x.find('[data-search]').foreach(op=>{
            let opt = x.use(op);
            console.log(op.value)
            if(opt.val()=="")return;
            b=true;
        });
        if(b)*/
            redraw();
    };
    let getFilters=()=>{
        let data={};
        x.find('[data-search]').foreach(op=>{
            let opt = x.use(op);
            var di=opt.data("input");//console.log(ds)
            if(opt.val()=="" || di )return;
            data[opt.attr("name")]=opt.val();
        });
        return tS(data);
    };
    let focus=arg=>{
            var aa;
            x.find('[name="'+arg.key+'"]').each(inp=>{
                if(inp.value==arg.val)
                    aa=x.use(inp);
            });
            if(aa){
                var tr=aa.lookup("TR");
                var tb=tr.lookup("TBODY");
                tb.select("tr").each(t=>{
                        x.use(t).removeClass("focused-tr");
                });
                tr.addClass("focused-tr");
                x.notify({type:"collapse",data:true},"view-layer-1");
        }
    };
	
    let init=()=>{
        body=x.pick('tbody');
        inactive=x.pick('.inactive');
        page=x.pick('[name="page"]');
        search=x.pick(".btn-search");
        pages=x.pick('[name="pages"]');
        rows=x.pick('[name="showing"]');
        if(x.pick('.search-form'))
        {
            inputs=x.pick('.search-form').select('input[name]');
            selects=x.pick('.search-form').select('select[name]');
            areas=x.pick('.search-form').select('textarea[name]');
        }
        formInit();	
        bodyBinders();
        search.bind().click(searchList);
        //x.keyup(rows,searchList);
        page.bind().change(repaint);
        //x.input(rows,searchList);
        rows.bind().change(repaint);
		//
	x.listen({redraw:redraw,focus:focus});
    };
    let formInit=()=>{
        submit=x.pick(".btn-send");
        if(submit)
            submit.bind().click(submitList);
    };
    let formDump=()=>{
        if(submit)
            submit.unbind().click(submitList);
        submit=null;
    };
    let dump=()=>{
        x.ignore(["focus"]);
        formDump();
        bodyBinders(true);
        search.unbind().click(searchList);
        page.unbind().change(repaint);
        //x.input(rows,searchList);
        rows.unbind().change(repaint);
		//fixSearches(true);
        inputs=null;
        areas=null;
        selects=null;
        inactive=null;
        search=null
        column=null;
        filter=null;
        search=null;
        pages=null;
        page=null;
        rows=null;
        body=null;
    };
    return{
        init:()=>{
            url=x.pick("tbody").data("url");	
            init();
        },
        dump:()=>{
            dump();
			x.ignore(["redrawer","focused"]);
            url=null;
        }
    };
});