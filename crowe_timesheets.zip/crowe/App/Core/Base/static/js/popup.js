CORE.add("popup",x=>{
    let sm,md,lg,smb,mdb,lgb,onBeforeClear;
    let lst={
        dflg:["lg",false],                  //DEFAULT
        dflgb:["lg-b",false],
        dfmd:["md",false],
        dfmdb:["md-b",false],
        dfsm:["sm",false],
        dfsmb:["sm-b",false],
        dglg:["lg","bg-danger"],            //DANGER
        dglgb:["lg-b","bg-danger"],
        dgmd:["md","bg-danger"],
        dgmdb:["md-b","bg-danger"],
        dgsm:["sm","bg-danger"],
        dgsmb:["sm-b","bg-danger"],
        sclg:["lg","bg-secondary"],        //SECONDARY
        sclgb:["lg-b","bg-secondary"],
        scmd:["md","bg-secondary"],
        scmdb:["md-b","bg-secondary"],
        scsm:["sm","bg-secondary"],
        scsmb:["sm-b","bg-secondary"],
        pmlg:["lg","bg-primary"],           //PRIMARY
        pmlgb:["lg-b","bg-primary"],
        pmmd:["md","bg-primary"],
        pmmdb:["md-b","bg-primary"],
        pmsm:["sm","bg-primary"],
        pmsmb:["sm-b","bg-primary"],
        wnlg:["lg","bg-warning"],           //WARNING
        wnlgb:["lg-b","bg-warning"],
        wnmd:["md","bg-warning"],
        wnmdb:["md-b","bg-warning"],
        wnsm:["sm","bg-warning"],
        wnsmb:["sm-b","bg-warning"],
        iflg:["lg","bg-info"],              //INFO
        iflgb:["lg-b","bg-info"],
        ifmd:["md","bg-info"],
        ifmdb:["md-b","bg-info"],
        ifsm:["sm","bg-info"],
        ifsmb:["sm-b","bg-info"],
        sslg:["lg","bg-success"],           //SUCCESS
        sslgb:["lg-b","bg-success"],
        ssmd:["md","bg-success"],
        ssmdb:["md-b","bg-success"],
        sssm:["sm","bg-success"],
        sssmb:["sm-b","bg-success"]
    };
    let getModal=type=>{console.log(type);
        let modal;
        if(type=="lg" || type=="lg-b"){
            modal = lg;
            if(type=="lg-b"){
                bare(modal);
            }	
        }
        if(type=="sm" || type=="sm-b"){//onsole.log("sm-b");
            modal = sm;
            if(type=="sm-b"){
                bare(modal);
            }	
        }
        if(type=="md" || type=="md-b"){
            modal = md;
            if(type=="md-b"){
                bare(modal);
            }	
        }
        modal.data("type",type);
        return modal;
    };
    let close=type=>{
        let modal = getModal(lst[type][0]);
        modal.select(".close").use().click();
    };
    let launch=(type,html,app,custom)=>{
    		
        //console.log(html)
        let modal = getModal(type);
        //ingore modal buttons
        btn(modal,true);
        //Stop whatever module was running in modal if any
        start(modal,true);
        //remove custom listeners if any
        if(isFn(onBeforeClear)){
            onBeforeClear();
            onBeforeClear=null;
        }
        //Add new content to modal
        modal.select(".modal-body-content").use().inner(html);
        //Set appearance for modal
        appearance(modal,app,custom);
		var xm=modal.select('[data-x-mod]').use().data('x-mod');
		if(constants._popup&&constants._popup[xm]){
			modal.select('[data-x-mod]').use().data('x-mod',"_"+xm)
		}
        //Start whatever module is required in modal if any
        start(modal);
        //listen modal buttons
        //button(modal);
        //Display modal
        
        
        open(type);
    };
    let bare=(modal)=>{
        var h=modal.select(".modal-header").use()
		if(h)
			h.hide();
        var f=modal.select(".modal-footer").use()
		if(f)
			f.hide();
    };
    let open=type=>{
        if(type=="sm" || type=="sm-b"){//console.log(1);
            smb.click();
        }
        if(type=="lg" || type=="lg-b"){//console.log(12);
            lgb.click();
        }
        if(type=="md" || type=="md-b"){//console.log(123);
            mdb.click();
        }
    };
    let start=(modal,stop)=>{
        x.notify({
            type:stop?'shutdown':'boot',
            data:modal.n
        },"mm");
    };
    let getHtmlFromUrl=(url,post,type,app,custom)=>{
        if(!post)
            post={};//console.log()
		
        X(url.replace(constants.call,""),resp=>{
            try{
                //is response html
                if(iO(resp)&&iA(resp.message)){
                    var g=(new Tag(resp.message[0],resp.message[1]));
                    launch(type,g.html(),app,custom);
                }
                else if(/^\<[a-zA-Z0-9\=\'\"\-\/ ]+\>.*$/.test(resp)){
                    launch(type,resp,app);
                }
                else if(/^{.*\"?message\"?\:\[/.test(resp)){
                    let json = JSON.parse(resp).message;
                    let obj = x.create(json[0],json[1]),div = x.use(x.create("div"));
                    div.append(obj);
                    launch(type,div.inner(),app,custom);
                }
                
            }catch(e){
                alert(resp);
                console.log(e);
            }
        },post);//alert(JSON.stringify(data))
       
    };
    let appearance=(modal,type,custom)=>{
        let cl = "modal-content ";
        cl += type?type:"";
        let div = modal.select(".modal-content").use();
        div.n.className = cl;//console.log(modal.id());
        if(isFn(custom)){
            custom(modal);
            onBeforeClear=()=>{
                custom(modal,true);
            };
        }
    };
    //Modal buttons
    let btn=(modal,ignore)=>{
	/*
        let left = modal.select(".btn-default").use();
        let right = modal.select(".btn-primary").use();
        let rightDefaultList=e=>{
            console.log("kill modal");
            left.click();
        };
        if(ignore)
            x.detach([right,"click",rightDefaultList]);
        else
            x.click(right,rightDefaultList);
	*/
    };
    let ml=m=>{//console.log(m);
      try{
      		
      	  //data=[modal,data,mode,custom,post]
        let cust,app,mode,type,post;
        if("custom" in m)
            cust=m.custom;
        mode="mode" in m ?m.mode:"data";
        post="post" in m ?m.post:false;
        //console.log(lst);
        //console.log(lst[m.modal]);
        type=lst[m.modal][0];
        app=lst[m.modal][1];
        return ("mode" in m && m.mode=="url")?getHtmlFromUrl(m.data,post,type,app,cust):launch(type,m.data,app,cust);
      }catch(e){
      	alert("Popup Error");alert(e);alert(e.stack);
      }
    };
    return{
        init:()=>{
            sm=x.pick("#modal-3");
            lg=x.pick("#modal-2");
            md=x.pick("#modal-1");
            smb=x.pick('[data-target="#modal-3"]');
            lgb=x.pick('[data-target="#modal-2"]');
            mdb=x.pick('[data-target="#modal-1"]');
            //var modal = x.pick(".modal");
            //alert(modal.n.style.display)
            //modal.show()
            x.listen({
                launch:ml,
                close:close
            });
        },
        dump:()=>{
            x.ignore(["launch","close"]);
            sm=null;
            md=null;
            lg=null;
            smb=null;
            mdb=null;
            lgb=null;
        }
    };
});