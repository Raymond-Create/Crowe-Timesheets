CORE.add("com-logo",x=>{
    let submit,file,preview,url,imgBase64;
    let	submitList=e=>{
        x.stop(e);
        let img = imgBase64.split(",");//console.log(img.length);
        jX({
            url:constants.link(url),
            form_data:{avatar:imgBase64,prefix:img[0]},
            success:ss=>{
                try{
                    cons.shout(ss); 

                }catch(e){
                    alert(ss);alert(e);
                }
            }
        }).send();
    };
    let fileChList= e =>{
        if(file.n.files[0]){
            let r = new FileReader();
                r.onload=()=>{
                    imgBase64 = r.result;
                    drawImage(imgBase64);
                    submit.show();
                };
                r.readAsDataURL(file.n.files[0]);
        }
    },
    drawImage=dUrl=>{
        preview.empty().append(tag("img",{src:dUrl}).element());
    },
    preload=()=>{
        jX({
            url:constants.link("authentication/orgs/current_logo"),
            //response:"text",
            success:s=>{//console.log(s);
                try{
                    if(s.status)
                        drawImage(s.message);
                }catch(e){

                }
            }
        }).send();
    },
    init=()=>{
    	preload();
        submit.hide();
        submit.bind().click(submitList);
        file.bind().change(fileChList);
    },
    destroy=()=>{
        submit.bind()._click(submitList);
        file.bind()._change(fileChList);
    };
    return{
        init:()=>{
            submit=x.pick(".submit");
            preview=x.pick(".preview");
            file=x.pick('[type="file"]');
            url="authentication/orgs/logo";
            //console.log([submit,file,preview,url,imgBase64]);
            init();
        },
        dump:()=>{
            destroy();
            url=null;
            file=null;
            submit=null;
            preview=null;
        }
    };
});