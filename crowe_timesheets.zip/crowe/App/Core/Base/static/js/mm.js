/*** static/js/modules/main-module.js  ***/
var fireEvent=(element,event)=>{
    if (document.createEventObject){
    // dispatch for IE
    var evt = document.createEventObject();
    return element.fireEvent('on'+event,evt)
    }
    else{
    // dispatch for firefox + others
    var evt = document.createEvent("HTMLEvents");
    evt.initEvent(event, true, true ); // event type,bubbling,cancelable
    return !element.dispatchEvent(evt);
    }
}
var openWindowWithPost= (url, data) =>  {
    var form = document.createElement("form");
    form.target = "_blank";
    form.method = "POST";
    form.action = url;
    form.style.display = "none";

    for (var key in data) {
        var input = document.createElement("input");
        input.type = "hidden";
        input.name = key;
        input.value = data[key];
        form.appendChild(input);
    }

    document.body.appendChild(form);
    form.submit();
    document.body.removeChild(form);
}
var report=(e,resp)=>{
    console.log(e);
    console.log(e.stack);
    console.log(resp);
    if(iD()){
        alert(e);
        console.log(e);
        alert(e.stack);
        console.log(e.stack);
        alert(resp);
        console.log(resp);
    }
};
var _tag=o=>{
	if(o.message)
		return _tag(o.message);
	return tag(o[0],o[1]);
}
var iD=()=>{
   return constants.env==constants.dev; 
};
var X=(url,callable,post)=>{
    if(iS(url)&&iF(callable)){
        url={
           url:cons.link(url),
           success:callable
        };
    }
    if(iO(post)){
        url.form_data=post;
    }
    var suc=url.success;
    var wrapper=o=>{
        try{
        	//alert(o);
           	suc(rS(o)); 
        }catch(e){
            console.log(e);
            console.log(o);
        }
    };
    url.success=wrapper;
    if(!url.response)
        url.response='text';
    jX(url).send();
};
var rS=data=>{
    return iS(data)?fS(data):data;
}
var response=(resp)=>{
    if(iD()&&!iO(resp)){
        try{
            return fS(resp);
        }
        catch(e){
            console.log(resp);
            console.log(e);
        }
    }
    return resp;
};
var responseType=()=>{//console.log(iD());
    return iD()?'text':'json';
};

CORE.add('mm',function(x){
    var that;
	let test=(input,onError)=>{
    	let val = input.val();
        let pattern = input.data("pattern");
        let required = input.attr("required");
        if(pattern.replace){
            let regx = new RegExp(pattern.replace(/^(\/)/,"").replace(/(\/)$/,""));
			//console.log(val)
            if(val=="" && !required)
                return input.addClass('is-valid').removeClass('is-invalid');					
            if(regx.test(val))
                return input.addClass('is-valid').removeClass('is-invalid');					
        }
        else{
            console.log([input.attr("name"),pattern]);
        }
        input.removeClass('is-valid').addClass('is-invalid');
        if(isFn(onError)){
            onError(input);
            return false;
        }
        let id=input.attr('name');
        if(input.name()=="INPUT" && input.attr("placeholder")){
            id=input.attr("placeholder");
        }
        if(input.name()=="SELECT"){
            let opt=input.select("option").use();
            if(opt&&opt.val()=="")
                id=opt.inner();
        }
        x.notify({type:"error",data:id + " is invalid"},"notify");
        //console.log(regx);
        //console.log(required);
        //console.log(val);
        return false;
    };
    let init_addons = (context) => {
        let adds = context?context.select('[data-addon]'):x.find('[data-addon]');
        adds.foreach(add => {//console.log(add);
            let elem = x.use(add);
            if(elem.data('addon')=="datepicker")
                datepicker(elem);
            else if(elem.data('addon')=="datetimepicker")
                datetimepicker(elem);
            else
                gen_addon(elem,elem.data('addon'));
			elem.data("addons",1);
        });
        let ads = context?context.select('[data-add]'):x.find('[data-add]');
        ads.foreach(add => {
            let s,elem = x.use(add),type=elem.data('add');
            //console.log(type);
            //alert(tS(constants.add_lib))
            if(constants.add_lib&&constants.add_lib[type]){
                s=new constants.add_lib[type](elem,x);
                s.setup();
            }
			elem.data("adds",1);
        });
    };
    let datepicker = element =>{
        if($ && $.fn && $.fn.datepicker)
            $(element.n).datepicker({dateFormat:"yy-mm-dd"});
    };
    let datetimepicker = element => {//console.log($(element.n).datetimepicker);
        if($ && $.fn && $.fn.datetimepicker)
            var val = element.val();
            var format = 'YYYY-MM-DD HH:mm';
            $(element.n).datetimepicker({
                format: format,
                userCurrent: false,
                date: moment(val, format)
            });
    };
    let select=element=>{
        let ig = element.lookup({"class":"input-group"});
        if(ig){
            let s =new Selector(ig,x);
            s.setup();
            s.fixSelect();
        }
    };
    let suggest = element =>{
        let ig = element.lookup({"class":"input-group"});
        if(ig){
            let s=new Suggest(ig,x);
            s.setup();
            s.fixSelect();
        }
    };
    let gen_addon=(el,type)=>{
        let ig=el.lookup({"class":"input-group"}),s;//console.log(ig);
        if(ig){
            if(type=='selector')
                s=new Selector(ig,x);
            if(type=='suggest')
                s=new Suggest(ig,x);
            if(type=='creator'){
                s=new Creator(ig,x);
				//console.log(el.n)
			}
			if(s){
				s.setup();
            	s.fixSelect();
			}
            
        }
    };
    let display=(html,context,customise)=>{
        if(iA(html)){
            if(html[2]&&iF(html[2]))
                customize=html[2];
            if(html[1])
                context=html[1];
            html=html[0];
        }
        context=context||pK('#card');
        //x.notify({type:"shutdown",data:context.n },"main-module");
        task(context.n,true);
        context.fade();
        context.empty();
        context.inner(html);
        context.clear();
        //x.notify({type:"boot",data:context.n},"main-module");
        task(context.n);
        if(iF(customise))
            customise(context);
        init_addons(context);
    };
	let run=(module,stop)=>{
		let rsp;
		if(!module)
			return;
		if(stop)
                    rsp=module?CORE.halt(module):module;
		else
                    rsp=module?CORE.run(module):module;
		if(constants.env==constants.dev){
                    console.log(rsp&&rsp.message?rsp.message:module+' failure');
		}
		return rsp;
	};
	let task=(cxt,stop)=>{
            let context=x.use(cxt);//console.log(cxt)
            let modules=context.use().select('.scripts,[data-x-mod]');
            modules.foreach(module=>{//console.log(module);
                try{
                    let mod=x.use(module),md;
                    if(mod.hasClass('scripts'))
                        md=mod.vl();
                    else if(mod.data('x-mod')){
                        mod.id(mod.data('x-mod'));
                        md=mod.data('x-mod');
                    }
                    run(md,stop);
                }catch(e){
                        console.log(e);
                }
            });
	};
	
	let msg=(s)=>{
		x.notify({
            type:s.status?"success":"error",
            data:s.message
        },"notify");
	};
	let header_exists=()=>{
		return;/*
		var hd=x.pick('header');
		if(!hd){
			var not=x.pick('div[data-x-mod="notify"]');
			var bd=x.use(dom('div',{text:Views.html('nav-2')}));
			not.before(bd.child(0));
		}
		//alert('mm.js@156')
		*/
	};
	let modules={};
	let get_name=name=>{
		if(modules.hasOwnProperty(name)){
			name=+'-1';
			return get_name(name);
		}
		return name;
	};
	let no_conflict=()=>{
		x.mod().use().select('[data-x-mod]').each(ele=>{
			var e=x.use(ele);
			var name=e.data('x-mod');
			var newname=get_name(name);
			if(newname!=name){
				e.data('x-mod',newname);
				CORE.copy(newname,name);
			}
		});
	};
    let init=()=>{
        constants.test=test;
        constants.loader=task;
        constants.shout = msg;
        constants.report=report;
        constants.display=display;
        constants.addons=init_addons;
        header_exists();
        task(x.mod());
    };
    return{
        init:function(){
            that=this;
            init();
			X(constants.logout+"/finger",o=>{},{finger:(new Fingerprint()).get()});
            x.listen({
                boot:that.boot,
                shutdown:that.shutdown,
                restart:that.restart,
                start:that.start,
                stop:that.stop,
                addons:init_addons,
                display:display
            });
        },
        boot:function(context){
            return task(context);
        },
        shutdown:function(context){
            return task(context,true);
        },
        restart:function(context){
            if(task(context,true)){
                return task(context);
            }
        },
        start:function(module){
            return CORE.run(module);
        },
        stop:function(module){
            var bn = CORE.stop(module); 
            //console.log(bn.message);
            return bn;
        },
        dump:function(){
            x.ignore([
            	'boot','shutdown','restart',
            	'get','run','addons','display'
            ]);
            that=null;
        }
    };
});