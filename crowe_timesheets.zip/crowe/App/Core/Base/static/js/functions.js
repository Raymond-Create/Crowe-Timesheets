var contentRedraw=(/*sandbox object*/x,o)=>{
    let dv=x.use(div().element());
    dv.append(tag(o[0],o[1]).element());
    let selector='[data-x-mod="'+x.module()+'"]';
    x.notify({type:"shutdown",data:x.mod().use().useParent().n},"mm");
    x.mod().use().inner(dv.select(selector).use().inner());
    x.notify({type:"boot",data:x.mod().use().useParent().n},"mm");
    constants.addons(x.mod().use());
};
