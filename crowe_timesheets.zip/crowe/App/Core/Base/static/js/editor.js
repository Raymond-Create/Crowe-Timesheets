var editorModule=x=>{
	let id,url,mode,prev,next,id_list,script;
	let nextList=e=>{
        x.stop(e);
        if(mode.val()=="view")
        	return _next();
        update(e);
    };
	let prevList=e=>{
        x.stop(e);
        if(mode.val()=="view")
            return _prev();
        x.notify({
            type:"open",
            data:"list"
        },"shared-view");
    };
    let response=(data)=>{
        if(script)
            x.notify({type:"response",data:data},script);
    };
    let update=e=>{
        x.stop(e);
        //next.hide();
        var data={},bool=true,ur=url.val();
        x.find('[data-type="input"]').each(o=>{
            if(!bool)return;
            if(constants.test(x.use(o)))
                data[x.use(o).attr("name")]=o.value;
            else
                bool=false;
        });
        if(!bool)return;
        if(is_id())
                ur+="/"+id.val();
        //return console.log(ur);
        X(ur,o=>{
            //next.show();
            o=rS(o);
            cons.shout(o);
            if(o.status&&!is_id())
               id.val(o.status);
            if(o.status){
                if(pK('[data-x-mod="data-grid-module"]'))
                    x.notify({type:"redraw",data:null},"data-grid-module");
                if(pK('[data-x-mod="editor-lines"]'))
                    x.notify({type:"saveall",data:id.val()},"editor-lines");
            }
            response(data);
        },data);
	};
	let _prev=()=>{
		if(!nM(id.val()))
			return x.notify({type:"info",data:"Click Next to go to first record"},"notify");
		var index=id_list.indexOf(id.val());
		if((index-1)<0)
			return x.notify({type:"info",data:"No more records before this one"},"notify");
		var ur=url.val()+"/";
		ur+=id_list[index-1];
		ur+="/view";
		X(ur,o=>{
			if(!o.status)return;
			swap(o.message);
		});
	};
	let _next=()=>{
		var index=id_list.indexOf(id.val());
		if(!nM(id.val()))
			index=-1;
		if((index+1)>=id_list.length)
			return x.notify({type:"info",data:"No more records after this one"},"notify");
		var ur=url.val()+"/";
		ur+=id_list[index+1];
		ur+="/view";
		X(ur,o=>{
			if(!o.status)return;
			swap(o.message);
		})
	};
	let is_id=()=>{
       return !!id.val()&&cons.test(id,()=>{return false;}); 
    };
	let mark=elem=>{
		if(elem.attr("required")){
			constants.test(elem,()=>false)
		}
	};
	let draw=ur=>{
		X(ur,o=>{
			if(o.status){
				var k=x.use(_tag(o.message).element()).select('[data-x-mod="'+x.module()+'"]').use();
				stop();
				if(script)
				 x.notify({data:null,type:stop},script);
				x.mod().use().empty();
				x.mod().use().inner(k.inner());
				start();
				if(script)
				 x.notify({data:null,type:start},script);
				constants.addons(x.mod().use());
				x.mod().use().clear();
			}
		});
	};
	let swap=view=>{
		var row=x.use(tag(view[0],view[1]).element()).select('[data-x-mod="editor"]').use().inner();
		x.notify({type:"shutdown",data:x.mod().use().useParent().n},"mm");
		x.mod().use().inner(row);
		x.notify({type:"boot",data:x.mod().use().useParent().n},"mm");
		constants.addons(x.mod().use());
	};
	let load_url=urlx=>{
		X(urlx,o=>{
			if(!o.status)return;
			swap(o.message);
		});
	};
	let load=url2=>{
		load_url(url+"/"+url2);
	};
	let redraw=()=>{
		var ur=url.val();//.replace("create","put");
		//var mod=mode.val();
		if(nM(id.val())&&mode.val()!="")
			ur+='/'+id.val();
		else
			ur+='/0'
		ur+='/'+mode.val();
		draw(ur);
	};
	let get_ids=()=>{
		id_list=[];
		X(url.val().replace("create","read"),o=>{
			o.message.forEach(rw=>{
				id_list.push(rw[id.attr("name")]);
			});
		});
	}
	let start=()=>{
		id=x.pick('[data-pk="1"]');
		next=x.pick(".btn-next");
		prev=x.pick(".btn-prev");
		mode=x.named("mode");
		url=x.named("url");
		get_ids();
		x.find('[data-type="input"]').each(o=>{
			mark(x.use(o));//console.log(o)
		});
		mode.bind().change(redraw);
		next.bind().click(nextList);
		prev.bind().click(prevList);
		var xx=x.pick('[data-x-mod]');
		if(xx)
			script=xx.data("x-mod");
		x.listen({
			load1:load_url,load:load
		});
		//console.log(id.val());
		//console.log(constants.test(id,()=>{return false;}));
	};
	let stop=()=>{
		x.ignore(["load1","load"]);
		mode.unbind().change(redraw);
		next.unbind().click(nextList);
		prev.unbind().click(prevList);
		id=null;
		url=null;
		mode=null;
		prev=null;
		next=null;
		id_list=null
	}
	return {init:start,dump:stop};
};
CORE.add("editor",editorModule);
CORE.add("_editor",editorModule);
CORE.add("_editor_",editorModule);
constants=constants||{};
constants._popup=constants._popup||{};
constants._popup["editor"]=true;