CORE.add('exchange-rate',x=>{
	let btn,date;
	let save=(data,rp)=>{
		X("base/rates/insert",o=>{//console.log(o);
			var c;
			if(o.status==0)
				c=".text-danger";
			if(o.status==1)
				c=".text-success";
			if(o.status==2)
				c=".text-info";
			if(o.status==3)
				c=".text-warning";
			rp.empty().append(span(c).add(o.message).element());
		},data);
	};
	let submit=e=>{
		x.stop(e);
		 x.pick('tbody').select('tr').each(t=>{
			save_pair(x.use(t));
		}); 
	};
	let save_pair=tr=>{
		var currency=tr.select('[name="currency"]').use();
		var base=tr.select('[name="base"]').use();
		var date=tr.select('[name="date"]').use();
		var rate=tr.select('[name="rate"]').use();
		var report=tr.select('.report').use();
		var t=constants.test;
		var s=span('.text-danger');
		if(!t(currency))
			return report.inner(s.add('Invalid currency').html());
		if(!t(base))
			return report.inner(s.add('Invalid base').html());
		if(!t(date,o=>false))
			return report.inner(s.add('Invalid date').html());
		if(!t(rate,o=>false))
			return report.inner(s.add('Invalid rate').html());
		save({
			currency:currency.val(),
			base:base.val(),
			date:date.val(),
			rate:rate.val()
		},report);
	};
	let attach=(tr,dt)=>{
		var date=tr.select('[name="date"]').use();
		var rate=tr.select('[name="rate"]').use();
	};
	let build=()=>{
		x.pick('tbody').select('tr').each(t=>{
			attach(x.use(t),false);
		}); 
		btn.bind().click(submit);
	};
	let destroy=()=>{
		x.pick('tbody').select('tr').each(t=>{
			attach(x.use(t),true);
		});
		btn.unbind().click(submit);
	};
	return{
		init:()=>{
			btn=x.pick(".save");
			date=x.pick(".m-d");
			build();
		},
		dump:()=>{
			destroy();
			date=null;
			btn=null;
		}
	};
});