CORE.add("pnotify-interface",x=>{
	let show=(message,title,icon,delay,type)=>{
		var data={
			text:message
		};
		if(!title)
			title="NOTICE"
		data.title=title
		if(icon)
			data.icon=icon
		if(delay&&nM(delay))
			data.delay=delay
		if(!type)
			type="notice";
		//console.log(PNotify[type]);
		PNotify[type](data);
	};
	let pop=data=>{
            show(
                data.message,
                data.title||null,
                data.icon||null,
                data.delay||null,
                data.type||null
            );
	};
	let start=()=>{
            x.listen({pop:pop});
	};
	let stop=()=>{
            x.ignore(["pop"]);
	};
	return{
            init:start,dump:stop
	};
});