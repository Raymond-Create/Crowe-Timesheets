<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */
/***************************************************************
            DATABASE ALTERATIONS TO ACCOMMODATE MODULE
 * 
 * 
 
ALTER TABLE `employees` ADD `phone_code` INT NULL DEFAULT NULL AFTER `designation`; 
ALTER TABLE `employees` ADD `phone` INT NULL DEFAULT NULL AFTER `designation`; 
ALTER TABLE `employees` ADD `email` VARCHAR(255) CHARACTER SET utf8mb4 NULL DEFAULT NULL AFTER `designation`; 

 *******************************************************************/
return[
    //module ref
    "ref"=>"Base",
    //external dependencies
    "dependencies"=>[
        "Authentication"=>[
            "Role","User",
        ],
        "Base"=>[
            "Doc","CoreAccount","DocType","Category","Currency",
            "Location","ContactType","Contact","Account","Rate",
            "CashAccount","Record","Source","ItemType","Item"
        ]
    ],
    //models in order of dependency
    "models"=>[
        "Record","Source","SourceLine","Payment"
    ],
    //links
    "links"=>[
        [
            'url'=>'address',
            'title'=>'Address Book',
            'icon'=>'fa fa-address-book',
            'cluster'=>'root',
            'type'=>"MENU",
            'active'=>1,
            'module'=>"Base",
            'allowed'=>[
                'Manager','Supervisor','Clerk'
            ]
        ],
        [
            'url'=>'base/contacts',
            'title'=>'Contacts',
            'icon'=>'fa fa-address-card',
            'cluster'=>'address',
            'type'=>"LINK",
            'active'=>1,
            'module'=>"Base",
            'allowed'=>[
                'Manager','Supervisor','Clerk'
            ]
        ],
        /*[
            'url'=>'base/contacttypes',
            'title'=>'Contact Types',
            'icon'=>'fa fa-users-cog',
            'cluster'=>'address',
            'type'=>"LINK",
            'active'=>1,
            'module'=>"Base",
            'allowed'=>[
                'Manager','Supervisor','Clerk'
            ]
        ],*/
        [
            'url'=>'misc',
            'title'=>'Configurations',
            'icon'=>'mdi mdi-gradient-horizontal',
            'cluster'=>'root',
            'type'=>"MENU",
            'active'=>1,
            "ranking"=>20,
            'module'=>"Base",
            'allowed'=>[
                'Manager','Supervisor','Clerk'
            ]
        ],
        [
            'url'=>'base/cashaccounts',
            'title'=>'Cashflow Types',
            'icon'=>'fa fa-wallet',
            'cluster'=>'misc',
            'type'=>"LINK",
            'active'=>1,
            'module'=>"Base",
            'allowed'=>[
                'Manager','Supervisor','Clerk'
            ]
        ],
        [
            'url'=>'base/currencies',
            'title'=>'Currencies',
            'icon'=>'mdi mdi-currency-usd',
            'cluster'=>'misc',
            'type'=>"LINK",
            'active'=>1,
            'module'=>"Base",
            'allowed'=>[
                'Manager','Supervisor','Clerk'
            ]
        ],
        [
            'url'=>'base/rates',
            'title'=>'Rates',
            'icon'=>'mdi mdi-swap-horizontal',
            'cluster'=>'misc',
            'type'=>"LINK",
            'active'=>1,
            'module'=>"Base",
            'allowed'=>[
                'Manager','Supervisor','Clerk'
            ]
        ],
        [
            'url'=>'base/categories',
            'title'=>'Categories',
            'icon'=>'mdi mdi-grid',
            'cluster'=>'misc',
            'type'=>"LINK",
            'active'=>1,
            'module'=>"Base",
            'allowed'=>[
                'Manager','Supervisor','Clerk'
            ]
        ],
        [
            'url'=>'authentication/orgs',
            'title'=>'My Company',
            'icon'=>'mdi mdi-office-building-marker-outline',
            'cluster'=>'misc',
            'type'=>"LINK",
            'active'=>1,
            'module'=>"Base",
            'allowed'=>[
                'Manager','Supervisor','Clerk'
            ]
        ],
        [
            'url'=>'authentication/orgs/logo',
            'title'=>'Company Logo',
            'icon'=>'mdi mdi-file-image',
            'cluster'=>'misc',
            'type'=>"LINK",
            'active'=>1,
            'module'=>"Base",
            'allowed'=>[
                'Manager','Supervisor','Clerk'
            ]
        ],
        [
            'url'=>'base/bases',
            'title'=>'Bases',
            'icon'=>'mdi mdi-moon-full',
            'cluster'=>'misc',
            'type'=>"LINK",
            'active'=>1,
            'module'=>"Base",
            'allowed'=>[
                'Manager','Supervisor','Clerk'
            ]
        ],
        [
            'url'=>'base/periods',
            'title'=>'Periods',
            'icon'=>'mdi mdi-moon-waxing-crescent',
            'cluster'=>'misc',
            'type'=>"LINK",
            'active'=>1,
            'module'=>"Base",
            'allowed'=>[
                'Manager','Supervisor','Clerk'
            ]
        ],
        [
            'url'=>'base/locations',
            'title'=>'Locations',
            'icon'=>'mdi mdi-map-marker',//mdi-wrench
            'cluster'=>'misc',
            'type'=>"LINK",
            'active'=>1,
            'module'=>"Base",
            'allowed'=>[
                'Manager','Supervisor','Clerk'
            ]
        ],
        [
            'url'=>'base/settings',
            'title'=>'General',
            'icon'=>'mdi mdi-wrench',//mdi-wrench
            'cluster'=>'misc',
            'type'=>"LINK",
            'active'=>1,
            'module'=>"Base",
            'allowed'=>[
                'Manager','Supervisor','Clerk'
            ]
        ]
    ]
];