<?php

namespace Core\Base\Controllers;

use Core\Base\Library\Controller;

use Core\Base\Library\ContactsView as Ev;

class Contacts extends Controller{
	
	use \Core\Base\Library\Index;
	
	public function __table($rows,$page):\Huchi\Classes\Tag
	{
	    $this->table["script"]="contact-support";
	    $this->table["action"]=[
	        ["icon"=>"fa fa-eye mr-2","text"=>"View","act"=>"btn-view"],
	        ["icon"=>"fa fa-file-invoice","text"=>"Creditor Statement","act"=>"btn-cstat"],
	        ["icon"=>"fa fa-file-invoice","text"=>"Debtor Statement","act"=>"btn-dstat"],
	        ["icon"=>"fa fa-edit mr-2","text"=>"Edit","act"=>"btn-edit"],
	        ["icon"=>"fa far fa-trash-alt mr-2","text"=>"Delete","act"=>"btn-delete"]
	    ];//_
	    $this->table["widths"]=[
	        'type'=>'100px',"code"=>"60px","phone"=>"75px"
	    ];
            $this->table["search_forms"]=[
	        "name","type","code"
	    ];
	    $table=parent::__table($rows, $page);
	    return Ev::init($table)->html();
	}
	
        public function fix()
        {
            $mod= \Lib\Factory::app("Contact","Base");
            $mod2= \Lib\Factory::app("Contact","Base");
            $data=$mod2->read([
                "select"=>["contacts.*","contacttypes.type as ct"],
                "join"=>[
                    "join"=>[
                        ["contacttypes","contacttypes.id","contacts.type"]
                    ]
                ],
                "where"=>["contacts.name"=>["NOT LIKE","CLIENT%"]],
                "_and"=>["contacts.name"=>["NOT LIKE","CREDITOR%"]]
            ]);
            $k=10;
            foreach($data as $row){x($data,8);
                $mod->clear();
                $mod->get($row["id"]);
                $mod->name=$row["ct"]=="supplier"?"CREDITOR":"CLIENT";
                $mod->name.=$k;
                $mod->email= strtolower($mod->name)."@huchi.demo";
                x($mod->data(),9);
                $k++;
                
            }
        }
        
        
        
	public
	   $_lib=["Contact",'Base'],
	   $_model=["Contact",'Base'];
}