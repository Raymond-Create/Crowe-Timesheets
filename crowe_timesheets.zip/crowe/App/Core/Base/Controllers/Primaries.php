<?php

namespace Core\Base\Controllers;

use Core\Base\Library\Controller;

class Primaries extends Controller{
		
    public 
        $show_form=1,
        $_model=["Primary","Base"],
        $_left=["Primaries",'configurations'];
   
   //puvlic            
}