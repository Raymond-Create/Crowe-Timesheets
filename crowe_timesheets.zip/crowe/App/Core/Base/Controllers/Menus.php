<?php

namespace Core\Base\Controllers;

use Core\Authentication\Library\User;
use Core\Base\Library\Controller;
use Core\Base\Library\MenusView;
use Lib\Session;
use Lib\Factory;

class Menus extends Controller{
	
	use \Core\Base\Library\Index;
	
	public function __table($rows,$page):\Huchi\Classes\Tag
	{
            $this->table["search_forms"]=["title","cluster","module","category"];
	    return MenusView::init(parent::__table($rows, $page))->html();
	}
	
	public function track(){
	    $p=$this->post();
	    $mod=Factory::app("MenuTrack","Base");
	    $mod->tableExists();
	    $mod->date=date("Y-m-d H:i:s");
	    $mod->user=User::id();
	    $mod->menu=$p["menu"];
	    $mod->save();//x($mod,9);
	    $this->json(1,1);
	}
	
    public 
        $show_form=1,
        $_model=["Menu","Base"],
        $_left=["Menu",'configurations'];
}