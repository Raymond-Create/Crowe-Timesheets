<?php

namespace Core\Base\Controllers;

use Core\Base\Library\CashView as Cv;
use Core\Base\Library\Payment as Form;

class Cash extends Records{
	
    use \Core\Base\Library\Index;

    public function __table($rows,$page):\Huchi\Classes\Tag
    {
        $this->table["hide"]=[
            "due"=>1
        ];
        $this->table["action"]=[
            ["icon"=>"fa fa-eye mr-2","text"=>"View","act"=>"btn-view"],
            ["icon"=>"fa fa-credit-card mr-2","text"=>"Allocation","act"=>"btn-alloc"],
            ["icon"=>"fa fa-edit mr-2","text"=>"Edit","act"=>"btn-edit"],
            ["icon"=>"fa far fa-trash-alt mr-2","text"=>"Delete","act"=>"btn-delete"]
        ];
        return Cv::init(parent::__table($rows, $page))->html();
    }

    public function add($record)
    {
        $lib=Form::init($record);
        //$lib->set_url(implode('/', $this->page));
        if($this->post())
        {
            $returnValue=$lib->save($this->post);
            $this->json($returnValue[1],$returnValue[0]);
        }
        $this->ajax($lib->html());
    }
    public 
        //$show_form=1,
        $_lib=["Settlement",'Base'];
}