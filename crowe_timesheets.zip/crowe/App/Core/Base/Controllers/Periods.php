<?php

namespace Core\Base\Controllers;

class Periods extends \Core\Base\Library\Controller{
		
	use \Core\Base\Library\Index;
		
    public 
        $show_form=1,
        $_model=["Period","Base"];
		
}