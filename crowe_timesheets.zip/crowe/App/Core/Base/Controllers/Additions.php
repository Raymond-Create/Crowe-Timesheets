<?php

namespace Core\Base\Controllers;

use  Core\Base\Library\Controller;

class Additions extends Controller{
		
    use \Core\Base\Library\Index;
		
    public 
        $show_form=1,
        $_model=["Addition","Base"];
   
    public function row() {
        $ad=new \Core\Base\Library\AbstractDocument();
        $this->ajax($ad->additionRow());
    }           
}