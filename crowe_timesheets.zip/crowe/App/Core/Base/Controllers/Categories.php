<?php

namespace Core\Base\Controllers;

use Core\Base\Library\Controller;
use Core\Base\Library\CategoriesView;

class Categories extends Controller{
		
    use \Core\Base\Library\Index;
    
    public function __table($rows,$page):\Huchi\Classes\Tag
    {
        return CategoriesView::init(parent::__table($rows, $page))->html();
    }
    
    public 
        $show_form=1,
        $_model=["Category","Base"],
        $_left=["Categories",'configurations'];
   
        
}