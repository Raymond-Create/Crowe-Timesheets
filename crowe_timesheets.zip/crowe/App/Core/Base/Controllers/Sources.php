<?php

namespace Core\Base\Controllers;

use  Core\Base\Library\Controller;

class Sources extends Controller{
		
    use \Core\Base\Library\Index;
		
    public 
        $show_form=1,
        $_model=["Source","Base"],
        $_left=["Sources",'books'];
   
   public function fix_prefixes()
   {
       $res=$this->model->update([
           "sources.prefix"=>"{prefixes.prefix}"
       ],[
           //"where"=>["sources.prefix"=>"prefixes.prefix"],
           "join"=>[
               "join"=>[
                   ["prefixes","prefixes.doc_type","sources.doc_type"]
               ]
           ]
       ]);
       $this->json($res,$res);
   }           
}