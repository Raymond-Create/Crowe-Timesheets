<?php

namespace Core\Base\Controllers;

use Core\Base\Library\Controller;

use Core\Base\Library\ReportsView as Rv;
use Core\Base\Library\Ages;
use Lib\Factory;

class Reports extends Controller{
	
	use \Core\Base\Library\Index;
	
	public function __table($rows,$page):\Huchi\Classes\Tag
	{
	    $ages=new Ages();//x($ages->html(),9);
	    return Rv::init($ages)->html();
	}
	
	public function show_report($mod,$report,$csv=false,$debug=false){
        $report_lib= Factory::lib($report,$mod);
        if($debug==3900){
            $this->json($report_lib->dsl($csv));
        }
        if($this->post()){
            $report_lib->set_post($this->post);
            $this->json($report_lib->dsl($csv));
        }
        $this->ajax($report_lib->html());
    	
   }
   
	public
	   $_lib=["Ages",'Base'],
	   $_model=["Record",'Base'];
}