<?php

namespace Core\Base\Controllers;

use Lib\Factory as Fac;
use Core\Base\Library\Allocation as Atn;
use Core\Base\Library\SettlementView as Sv;
use Core\Base\Library\SettlementsView as Ssv;

class Settlements extends Records{
		
    use \Core\Base\Library\Index,\Lib\Recid, \Core\Base\Library\View;
		
    public 
        //$show_form=1,
        $_model=["Record","Base"],
        $_lib=['Settlement','Base'];
   
    function __table($rows,$page):\Huchi\Classes\Tag
   {
        $this->table["action"]=[
            ["icon"=>"fa fa-eye mr-2","text"=>"View","act"=>"btn-view"],
            ["icon"=>"fa fa-file-pdf mr-2","text"=>"View PDF","act"=>"btn-open"],
            ["icon"=>"mdi mdi-tray-alert mr-2","text"=>"Allocation","act"=>"btn-allocate"],
            ["icon"=>"fa fa-edit mr-2","text"=>"Edit","act"=>"btn-edit"],
            ["icon"=>"fa far fa-trash-alt mr-2","text"=>"Delete","act"=>"btn-delete"]
        ];
        $this->table["script"]="allocate";
        $this->table["filter"]=[
                "join"=>[
                    "join"=>[
                        ["sources","records.id","sources.record"]
                    ]
                ],
                "select"=>["records.*"],
                "order"=>["records.date","DESC"],
                "where"=>["records.accrual"=>0]
            ];
        $this->table["search_forms"]=[
        		"date","type","contact","ref","amount"
        ];
        $this->table["widths"]=[
                "date"=>"72px",
                "due"=>"72px",
                "type"=>"72px",
                "ref"=>"72px",
                "currency"=>"65px",
                "amount"=>"70px",
                "paid"=>"70px"
            ];
        
        $this->table["transformation"]=[
                "amount"=>function($d){return num($d);},
                "paid"=>function($d){return num($d);}
            ];
        
       return Ssv::init(parent::__table($rows, $page))->html();
   }
   
   public function view($id)
   {
        $doc=new Sv;
        //$this->json(12);
        $this->json($doc->dsl($id),9);
   }
   
   
   public function allocate($id)
   {
        $doc=new Atn($id);
        $this->ajax($doc->html(),9);
   }
}