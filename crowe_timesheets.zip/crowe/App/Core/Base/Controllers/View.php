<?php

namespace Core\Base\Controllers;

use Core\Base\Library\Controller;
use Core\Base\Library\PdfViewer;

class View extends Controller{
	
    public function pdf($txt=null)
    {
        $p=$this->post();
        $lib=new PdfViewer($txt==35);
        $lib->set_url($p["_url_"]);
        $this->ajax($lib->html());
    }
    public 
        //$show_form=1,
        $_lib=["Settlement",'Base'];
}