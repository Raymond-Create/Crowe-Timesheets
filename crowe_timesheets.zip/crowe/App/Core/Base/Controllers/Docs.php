<?php

namespace Core\Base\Controllers;

use Core\Base\Library\Controller;

class Docs extends Controller{
	
	use \Core\Base\Library\Index;
	
    public 
        $show_form=1,
        $_model=["Doc","Base"],
        $_left=["Docs",'configurations'];
}