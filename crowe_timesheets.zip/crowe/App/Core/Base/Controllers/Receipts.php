<?php

namespace Core\Base\Controllers;

use Lib\Factory as Fac;
use Core\Base\Library\Receipts as Rec;

class Receipts extends Records{
		
    use \Core\Base\Library\Index,\Lib\Recid, \Core\Base\Library\View;
		
    public 
        //$show_form=1,
        $_model=["Record","Base"];
   
    function __table($rows,$page):\Huchi\Classes\Tag
   {
        $lib=Fac::lib(...$this->_lib);
        $ids=[];
        if(!isset($this->table["filter"])){
            $this->table["filter"]=[
                "join"=>[
                    "join"=>[
                        ["sources","records.id","sources.record"]
                    ]
                ],
                "select"=>["records.*"],
                "order"=>["records.date","DESC"],
				"where"=>["records.type"=>"Receipt","records.accrual"=>0]
            ];
        }//x($this->table["filter"],9);
        if(!isset($this->table["widths"])){
            $this->table["widths"]=[
                "date"=>"72px",
                "due"=>"72px",
                "type"=>"72px",
                "ref"=>"72px",
                "currency"=>"72px",
                "amount"=>"100px",
                "paid"=>"100px"
            ];
        }
        if(!isset($this->table["transformation"])){
            $this->table["transformation"]=[
                "amount"=>function($d){return num($d);},
                "paid"=>function($d){return num($d);}
            ];
        }
       $docs=$lib->doc_type;
       if(!$lib->multiple_doc){
           $docs=[$docs];
       }//x($docs,8);
       if(!empty($docs)&&$docs[0]){
           foreach($docs as $doc){//x($doc,7);
               $ids[]=$this->idOf($doc);
           }
       }
       if(!empty($ids)){
           $this->table["filter"]["where"]=["sources.doc_type"=>["in"=>$ids]];
       }
       return parent::__table($rows, $page);;
   }
}
