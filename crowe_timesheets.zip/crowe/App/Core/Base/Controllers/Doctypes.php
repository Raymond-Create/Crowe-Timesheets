<?php

namespace Core\Base\Controllers;

use Core\Base\Library\Controller;

class Doctypes extends Controller{
	
	use \Core\Base\Library\Index;
	
    public 
        $show_form=1,
        $_model=["DocType","Base"],
        $_left=["DocTypes",'configurations'];
}