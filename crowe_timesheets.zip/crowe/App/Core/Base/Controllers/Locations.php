<?php

namespace Core\Base\Controllers;

use Core\Authentication\Library\User;
use Core\Base\Library\Controller;
use Lib\Session;
use Lib\Factory;
use Core\Base\Library\LocationsView;
use Lib\Data;

class Locations extends Controller{
	
	use \Core\Base\Library\Index;
	
	public function __table($rows,$page):\Huchi\Classes\Tag
	{
	    return LocationsView::init(parent::__table($rows, $page))->html();
	}
	
	public function data()
	{
	    $config=[
	        'type'=>'mysql_db',
	        'settings'=>[
    	        'user'=>'root',
    	        'host'=>"localhost",
    	        'port'=>3306,
    	        'password'=>isset($_SERVER['ANDROID_ROOT'])?"":"huchiworks",
    	        //'database'=>'auth',
    	        'database'=>'lines',
    	        'type'=>'mysql_db'
    	    ]  
	    ];
	    $obj=new Data();
	    $obj->set_config($config);
	    $obj->set_model("Role","Authentication");
	    $obj->read();
	}
	
    public 
        $show_form=1,
        $_model=["Location","Base"],
        $_left=["Menu",'configurations'];
}