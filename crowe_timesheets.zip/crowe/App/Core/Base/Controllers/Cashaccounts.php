<?php

namespace Core\Base\Controllers;


class Cashaccounts extends \Core\Base\Library\Controller{
	
	use \Core\Base\Library\Index;
	
	
	public
    	$show_form=1,
    	$_model=["CashAccount","Base"];
}

//0732400156.
//DSTV.