<?php

namespace Core\Base\Controllers;

use  Core\Base\Library\Controller;

class Sourcelines extends Controller{
		
    use \Core\Base\Library\Index;
		
    public 
        $show_form=1,
        $_model=["SourceLine","Base"],
        $_left=["Sourcelines",'books'];
   
   //puvlic            
}