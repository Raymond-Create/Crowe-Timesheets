<?php

namespace Core\Base\Controllers;

use Core\Base\Library\RatesView;
use Core\Base\Library\Rate;
use Lib\Lang;

class Rates extends \Core\Base\Library\Controller{
		
    use \Core\Base\Library\Index;
		
    public 
        $show_form=1,
        $_lib=["ExchangeRates","Base"],
        $_model=["Rate","Base"],
        $_left=['Rates List','rates'],
        $_left_2=['Update Rates','rates'];
    
    public function __table($rows,$page):\Huchi\Classes\Tag
    {
        $this->table["action"]=[
            ["icon"=>"fa far fa-trash-alt mr-2","text"=>"Delete","act"=>"btn-delete"]
        ];
        return RatesView::init(parent::__table($rows, $page))->html();
    }
    
    public function to_base($currency,$date=null,$inverse=null){
        if(!$date){
            $date=date("Y-m-d");
        }
        $e=Rate::init()->base($currency,$date,is_numeric($inverse));
        if($e){
            $this->json($e,!!$e);
        }
        $this->json(null,0);
    }
    
    public function get_rate($new,$base)
    {
        $r=Rate::pair($new,$base);
        if($r)
        {
            $this->model->get($r);
            $this->json($this->model->rate,$this->model->rate);
        }
        $this->json(null,0);
    }
    
    public function tobase($id){
        $data=$this->model->read([
            "where"=>[
                "currency"=>$id,
                "base"=>\Core\Base\Library\Config::init()->defaultcurrency
            ],
            "order"=>["date","desc"],
            "limit"=>[1,0]
        ]);
        $x=0;
        if(!empty($data)&&isset($data[0])&&isset($data[0]["id"])){
            $x=$data[0]["id"];
        }
        $this->json($x,$x);
    }
    
    public function insert()
	{
		$mod=$this->model;
		$mod1=$this->model;
		$post=$this->post();
		if(!$post)
		{
			return $this->json("No data supplied",0);
		}
		$mod->fetch([
			"where"=>[
				"currency"=>$post["currency"],
				"base"=>$post["base"],
				"date"=>["<=",$post["date"]]
			],
			"limit"=>[1,0],
			"order"=>["date","DESC"]
		]);
		if($mod->rate == $post["rate"])
		{
			return $this->json("Same as previous rate",2);
		}
		try{
			$mod1->currency=$post["currency"];
			$mod1->base=$post["base"];
			$mod1->date=$post["date"];
			$mod1->rate=$post["rate"];
			$a=$mod1->save();
			return $this->json($a?"Saved":"Not Saved",!!$a);
		}catch(\Exception $ex){
			return $this->json($ex->getMessage(),0);
		}
	}
	
    public function save()
    {
        if(!$this->post()){
            $this->json('Empty request',false);
        }
        $rate=Rate::init();
        $resp=$rate->save($this->post);
        $message=$resp===true?Lang::get("record-modified"):$resp;
        $this->json($message,$resp===true);
    }
    
    public function  customize_table(\Lib\Grid $table)
    {	
        $table->set_transform("_action_", function($data){
            $span=span();
			$model=$this->model;
			$model->get($data["id"]);
			$btn=\Lib\DeleteBtn::init($model)->html();
			$span->add($btn);
            $span->add(input()
               ->attr("value",$data["id"])
               ->attr("type","hidden")
               ->attr("name","_key_")
            );
			return $span;
        });
		$table->set_filter([
            "order"=>["date","DESC"]
        ]);
        $con=div('m-5')
            ->attr('data-x-mod','data-display');
        $table->hide_form();
        $table->set_title("Rates List");
        $table->edit_create();
        return $con
            ->add(div('row')
                ->add($this->right($table->html()))
            );
    }
    
}