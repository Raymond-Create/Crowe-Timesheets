<?php

namespace Core\Base\Controllers;

use Core\Authentication\Library\User;
use Core\Base\Library\Controller;
use Lib\Session;
use Lib\Factory;

class Menutracks extends Controller{
	
	use \Core\Base\Library\Index;
	
    public 
        //$show_form=1,
        $_model=["MenuTrack","Base"];
}