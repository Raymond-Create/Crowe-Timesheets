<?php

namespace Core\Base\Controllers;

use  Core\Gs\Library\Crud;

class Transactions extends Crud{
		
    use \Core\Gs\Library\Index;
		
    public 
        $show_form=1,
        $_model=["Record","Base"],
        $_left=["Transactions",'books'];
   
   //puvlic            
}