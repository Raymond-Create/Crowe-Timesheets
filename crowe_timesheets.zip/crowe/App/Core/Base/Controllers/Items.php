<?php

namespace Core\Base\Controllers;

use Core\Base\Library\Controller;

class Items extends Controller{
		
    use \Core\Base\Library\Index;
		
    public 
        $show_form=1,
        $_model=["Item","Base"],
        $_left=["Items",'books'];
   
   //puvlic            
}