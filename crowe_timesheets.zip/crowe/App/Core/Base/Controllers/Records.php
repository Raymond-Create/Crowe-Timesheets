<?php

namespace Core\Base\Controllers;

use Lib\Factory as Fac;
use  Core\Base\Library\Controller;

class Records extends Controller{
		
    use \Core\Base\Library\Index,\Lib\Recid, \Core\Base\Library\View;
		
    public 
        //$show_form=1,
        $_model=["Record","Base"],
        $_lib=["Record","Base"],
        $_left=["Records",'books'];
   
    
    public function get_line_row()
    {
        $lib=Fac::lib(...$this->_lib);
        $this->ajax($lib->row());
    }
    
    public function accounts(){
        $lib=Fac::lib(...$this->_lib);
        $this->ajax($lib->det_accounts($this->post()));
    }

    public function save($id=null){
        $lib=Fac::lib(...$this->_lib);
        $res=$lib->save($this->post(),$id);
        $this->json(...$res);
    }

   public function __table($rows,$page):\Huchi\Classes\Tag
   {
        $lib=Fac::lib(...$this->_lib);
        $ids=[];
        if(!isset($this->table["filter"])){
            $this->table["filter"]=[/*
                "join"=>[
                    "join"=>[
                        ["sources","records.id","sources.record"]
                    ]
                ],
                "select"=>["records.*"],
                "order"=>["records.date","DESC"]
            */];
        }//x($this->table["filter"],9);
        if(!isset($this->table["widths"])){
            $this->table["widths"]=[
                "date"=>"72px",
                "due"=>"72px",
                "type"=>"72px",
                "ref"=>"72px",
                "currency"=>"72px",
                "prefix"=>"70px",
                "number"=>"70px",
                //"subtotal"=>"90px",
                "amount"=>"90px",
                "paid"=>"90px"
            ];
        }
        if(!isset($this->table["transformation"])){
            $this->table["transformation"]=[
                "amount"=>function($d){return num($d);},
                "paid"=>function($d){return num($d);}
            ];
        }
       $docs=$lib->doc_type;
       if(!$lib->multiple_doc){
           $docs=[$docs];
       }//x($docs,8);
       if(!empty($docs)&&$docs[0]){
           foreach($docs as $doc){//x($doc,7);
               $ids[]=$this->idOf($doc);
           }
       }
       if(!empty($ids)){
           $this->table["filter"]["where"]["records.doc_type"]=["in"=>$ids];
       }//x($this->table["filter"],7);
       return parent::__table($rows, $page);;
   }
   
   public function fixrecords()
   {
        $mod= Fac::app("Record","Base");
        $exec=$mod->modifyx(
            [
                "records.category"=>"{s.category}",
                "records.doc_type"=>"{s.doc_type}",
                "records.method"=>"{s.method}",
                "records.business"=>"{records.location}",
                "records.prefix"=>"{s.prefix}",
                "records.number"=>"{s.number}",
                "records.subtotal"=>"{s.sub_total}",
                "records.cha1"=>"{s.title_1}",
                "records.cha2"=>"{s.title_2}",
                "records.cha3"=>"{s.attention}",
                "records.txt1"=>"{s.note_1}",
                "records.txt2"=>"{s.note_2}",
                "records.cluster"=>"{s.cluster}"
            ],
            [
                "join"=>[
                    "join"=>[
                        ["sources s","s.record","records.id"]
                    ]
                ]
            ]
        );
        $this->json($exec);
   }
    
    public function fixlines()
   {
        $mod= Fac::app("SourceLine","Base");
        $exec=$mod->modify(
            [
                "sourcelines.record"=>"{s.record}"
            ],
            [
                "join"=>[
                    "join"=>[
                        ["sources s","sourcelines.source","s.id"]
                    ]
                ]
            ]
        );
        $this->json($exec);
    }
}
