<?php

namespace Core\Base\Controllers;

use Core\Base\Library\Controller;
use Core\Base\Library\AgeSupport;
use Core\Base\Library\Statement as State;

class Statement extends Controller{
	
	use \Core\Base\Library\Index;
	
	public function pdf()
	{
	    $post=$this->post();
	    //$post=["contact"=>3,"type"=>"Debtor"];
	    if(!empty($post))
	    {
	        $lib=new State();
	        $lib->set_post($post);
	        $dsl=$lib->dsl();
	        $this->json($dsl,!!$dsl);
	    }
	}
	
	public function age(){
	    $age=new AgeSupport();
	    $age->read();
	}
	
    public 
        $show_form=1,
        $_model=["Doc","Base"],
        $_lib=["Statement",'Base'];
    
     
}