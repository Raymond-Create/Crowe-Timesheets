<?php

namespace Core\Base\Controllers;

use Core\Base\Library\Controller;

class Accounts extends Controller{
	
	use \Core\Base\Library\Index;
	
    public 
        $show_form=1,
        $_model=["Account","Base"],
        $_left=["Accounts",'configurations'];
}