<?php

namespace Core\Base\Controllers;

use Core\Base\Library\Controller;

class Dashboard extends Controller{
		
    //use \Core\Gs\Library\Index;
		
    public 
        $show_form=1,
        $_model=["Category","Base"];
   
   public function index()
   {
       $this->ajax(div());
   }
   
   
}