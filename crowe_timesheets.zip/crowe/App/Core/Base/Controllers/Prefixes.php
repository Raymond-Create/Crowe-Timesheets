<?php

namespace Core\Base\Controllers;

use Core\Base\Library\Controller;
use Core\Base\Library\PrefixesView;

class Prefixes extends Controller{
	
    use \Core\Base\Library\Index;

    public function __table($rows,$page):\Huchi\Classes\Tag
    {
        return PrefixesView::init(parent::__table($rows, $page))->html();
    }
	
    public 
        $show_form=1,
        $_model=["Prefix","Base"];
    
    public function prefix($model,$module)
    {
        
    }
}