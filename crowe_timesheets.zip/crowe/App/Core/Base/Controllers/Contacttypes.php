<?php

namespace Core\Base\Controllers;

use  Core\Base\Library\Controller;

use Core\Base\Library\ContacttypesView as Ev;

class Contacttypes extends Controller{
		
    use \Core\Base\Library\Index;

    public 
        $show_form=1,
        $_model=["ContactType","Base"];

        public function __table($rows,$page):\Huchi\Classes\Tag
	{
	    $this->table["search_forms"]=[
	        "name","type"
	    ];
            $table=parent::__table($rows, $page);
	    return Ev::init($table)->html();
	}

}