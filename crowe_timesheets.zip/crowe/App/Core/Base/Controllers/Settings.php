<?php

namespace Core\Base\Controllers;
use Core\Base\Library\SettingsView as Sv;

use Core\Base\Library\Controller;

class Settings extends Controller{
	
	use \Core\Base\Library\Index;
	
    public 
        //$show_form=1,
        $_model=["Setting","Base"],
        $_lib=["Settings",'Base'];
		
	public function __table($rows,$page):\Huchi\Classes\Tag
	{
	    $this->table["action"]=[
	       ["icon"=>"fa far fa-trash-alt mr-2","text"=>"Delete","act"=>"btn-delete"]
	    ];//_
	    $this->table["widths"]=[
	        'type'=>'100px',"code"=>"60px","phone"=>"75px"
	    ];
            $this->table["search_forms"]=[
	        "name","type"
	    ];
	    $table=parent::__table($rows, $page);
	    return Sv::init($table)->html();
	}
	
	public function kv($key,$method='get'){
        $this->model->fetch(['where'=>['name'=>$key]]);
        if($method=='set')
        {
            if($this->post()&&isset($this->post['value']))
            {;
				$this->model->name=$key;
				$this->model->value=$this->post['value'];
				$a=$this->model->save();
				$message=$a?"Setting Updated":"NO Change";
				$this->json($message,$a);
            }
            else{
                $this->json("NO DATA",0);
            }
        }else{
            $this->json($this->model->value,1);
        }
    }
}