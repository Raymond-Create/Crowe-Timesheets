<?php

namespace Core\Base\Controllers;

use  Core\Gs\Library\Crud;

class Itemtypes extends Crud{
		
    use \Core\Gs\Library\Index;
		
    public 
        $show_form=1,
        $_model=["ItemType","Base"],
        $_left=["Itemtypes",'books'];
   
   //puvlic            
}