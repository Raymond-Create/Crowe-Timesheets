<?php

namespace Core\Base\Controllers;

use Core\Base\Library\Controller;
use Core\Base\Library\Landing as Land;

class Landing extends Controller{
		
    use \Core\Base\Library\Index;
		
    public 
        $show_form=1,
        $_model=["Location","Base"];
   
   public function index($rows=6,$page=1)
   {
       $land=new Land($rows,$page);
       $this->ajax(/*$land->html()*/"");
   }
}