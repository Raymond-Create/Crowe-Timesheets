<?php

namespace Core\Base\Controllers;

use Core\Base\Library\PayLink;

use Core\Base\Library\Controller;

class Payments extends Controller{
	
	use \Core\Base\Library\Index;
	
    public 
        //$show_form=1,
        $_model=["Payment","Base"];
    
    public function del()
    {
        $p=$this->post();
        $pl=new PayLink();
        $res=$pl->unlink($p["payment"]);
        $this->json($res[0]?"Record Disassociated":"NOT DONE",$res[0]);
    }
}