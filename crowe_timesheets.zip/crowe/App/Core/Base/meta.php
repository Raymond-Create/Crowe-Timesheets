<?php

return [
	'path'=>'Base',
	'version'=>'1.0',
	'publication'=>'01-12-21',
	'restriction'=>'Open',
	'notes'=>'Module has the core functions of all system wide accounting capabilities, it is a core module all other modules rely on it and cannot be removed',
	'icon'=>"fa fa-",
	'name'=>'Core',
	'flag'=>1
 ];