<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Base\Models;

use Core\Authentication\Library\User as Usr;

class Contact extends \Lib\Model{

    public $_rep_=["name"];    

	public $_group_=["type"];  
	
    public function _setup(){    
    	return [
            'user'=>_foreign([
            	'model'=>["User","Authentication"],
            	"verbose"=>"Introducer","null"=>1,"hide"=>1
            ]),
            'type'=>_foreign([
            	'model'=>["ContactType","Base"]//,"disabled"=>1
            ]),
            'code'=>_char(['null'=>1]),
            'name'=>_char(['index'=>1,"pattern"=>'/^[0-9A-Za-z\'\_\,\.\-\(\) ]+$/']),
            'sector'=> _char(["null"=>1]),
            'contact_person'=>_char(['null'=>1]),
            'position'=>_char(['null'=>1]),
            'email'=>_email(['null'=>1]),
            'phone'=>_char(['null'=>1,"pattern"=>"/^[0-9\+\,\.\-\/ ]+$/"]),
    	    'address'=>_text(['null'=>1]),
            //'cluster'=>_char(['default'=>"original","hide"=>1]),
    	    'bp'=>_char(['null'=>1,"pattern"=>"/^[a-zA-Z0-9\-\/ ]+$/","hide"=>1]),
    	    'vat'=>_char(['null'=>1,"hide"=>1]),
    	    'active'=>_integer([
    	        "default"=>1,"hide"=>1
    	    ])
        ];
    }
    
    public function setName($name)
    {
    	return strtoupper($name);
    }
	
	public function setAddress($name)
    {
    	return strtoupper($name);
    }
	
    public function insert(array $data, $table = false) {
        $data['user']=isset($data['user'])?$data['user']:Usr::id();
        return parent::insert($data,$table);
    }
}
/*
ALTER TABLE `contacts` ADD `sector` VARCHAR(200) NULL AFTER `name`, ADD `contact_person` VARCHAR(200) NULL AFTER `sector`, ADD `position` VARCHAR(200) NULL AFTER `contact_person`; 
*/