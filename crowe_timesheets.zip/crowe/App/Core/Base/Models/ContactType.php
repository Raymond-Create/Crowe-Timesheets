<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Base\Models;



class ContactType extends \Lib\Model{

    public $_rep_=["name"];    

    public $_group_=["type"];  
	
    public function _setup(){    
    	return [
            'type'=>_char(['choices'=>[
		'Supplier','Customer','Other'
            ],"default"=>'customer']),
            'name'=>_char(['index'=>1])        
      ];
    }
    
    public function setName($name)
    {
    	return strtoupper($name);
    }
}
//ALTER TABLE `contacttypes` CHANGE `type` `type` ENUM('Supplier','Customer','Other') NOT NULL DEFAULT 'Customer';
