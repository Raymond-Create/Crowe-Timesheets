<?php

namespace Core\Base\Models;

use Lib\Model as B;

class Trail extends B{
    
    public $_rep_=['type','action'];
    
	public $_group_ = ['action'];
	
    public function _setup(){
        return [
            'user'=>_integer([
               "model"=>["User","Authentication"],"null"=>1
            ]),
            'type'=>_char(["index"=>1]),
            'record'=>_integer(["index"=>1]),
            'ip'=>_char(["pattern"=>"/^[a-zA-Z0-9\.\:]+$/"]),
            'action'=> _char([
                "choices"=>[
                    "insert","modify","remove",
                    "request","decline","cancel"
                ]
            ]),
            "device"=>_foreign([
            	"model"=>"Sys\Classes\Device","hide"=>1
            ]),
            "finger"=>_char(["default"=>-1]),
            "request" => _char([
            	"pattern"=>'/^[a-zA-Z0-9\.\_\-\+\=\?\&\:\%\/\~\!\|\(\)\"\'\[\]\{\}\,\:]+$/',
				"null"=>1
            ]),
            'action_time'=> _datetime()
        ];        
    }
}