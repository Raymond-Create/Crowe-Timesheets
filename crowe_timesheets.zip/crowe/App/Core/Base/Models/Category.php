<?php

namespace Core\Base\Models;


class Category extends \Lib\Model
{
    
    public $_rep_=['name'];
    
    public $_group_=['type'];
    
    public function _setup()
    {
        return [//doc_type 
            'doc_type'=>_foreign([
                'model'=>['DocType','Base'],"null"=>1
            ]),
            'type'=>_char([
                'default'=>"GENERAL",
                'autosuggest'=>1
            ]),
            'name'=>_char(),
            'flag'=>_integer([
                'default'=>0,'hide'=>1,
                'options'=>["No","Yes"]
            ])
        ];
    }
    
    public function setName($name)
    {
    		return strtoupper($name);
    }
    
    public function setType($name)
    {
    		return strtoupper($name);
    }
    
}