<?php

namespace Core\Base\Models;

use Lib\Model as B;

class Period extends B{
    
    public $_rep_ = ['name'];   
    
    public $_group_ = ['type'];   
    
    public function _setup(){    
    	return [
            'type'=>_foreign([
               "model"=>["Base","Base"]
            ]),
            'name'=>_char(["pattern"=>"/[a-zA-Z0-9\/\-\,\. ]+/"]),
            'start'=>_date(["null"=>1]),
            'finish'=>_date(["null"=>1]),
            'accounting'=>_integer(['default'=>0])
        ];
    }
}