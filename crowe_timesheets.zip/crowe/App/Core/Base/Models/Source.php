<?php

namespace Core\Base\Models;

use Core\Authentication\Library\User;
use Core\Base\Library\Prefix;
use Core\Base\Library\Number;


class Source extends \Lib\Model
{
    
    public $_rep_=['prefix','number'];
    
    public $_prefix="DOC";
    
    public function _setup()
    {
        return [
            'record'=>_foreign([
                'model'=>['Record','Base'],
            ]),
            'record_ref'=>_integer([
                'model'=>['Record','Base'],
                'null'=>1
            ]),
            'record_ref_2'=>_integer([
                'model'=>['Record','Base'],
                'null'=>1
            ]),
            'category'=>_foreign([
                'model'=>['Category','Base'],"null"=>1
            ]),
            'doc_type'=>_foreign([
                'model'=>['DocType','Base'],
            ]),
            'method'=>_foreign([
                'model'=>['CashAccount','Base'],
                'null'=>1
            ]),
            'business'=>_foreign([
                'model'=>['Location','Base'],
                'null'=>1
            ]),
            'slocation'=>_foreign([
                'model'=>['Location','Base'],
                'null'=>1
            ]),
            'prefix'=>_char(["null"=>1]),
            'number'=>_integer([
                'null'=>1,'hide'=>1,'index'=>1
            ]),
            'creator'=>_foreign([
                'model'=>['User','Authentication']
            ]),
            'authoriser'=>_foreign([
                'model'=>['User','Authentication'],'null'=>1
            ]),
            'discount'=>_decimal(['null'=>1]),
            'sub_total'=>_decimal(['null'=>1]),
            'total'=>_decimal(['null'=>1]),
            'support'=>_char(['null'=>1]),
            'support_id'=>_integer(['null'=>1]),
            'adopted'=>_integer([
                'default'=>0,'hide'=>1,
                'options'=>["No","Yes","Never"]
            ]),
            'attention'=>_char([
                'null'=>1,'hide'=>1
            ]),
            'order_no'=>_char([
                'null'=>1,'hide'=>1
            ]),
            'extra_comment'=>_char([
                'null'=>1,'hide'=>1
            ]),
            'title_1'=>_char([
                'null'=>1,'hide'=>1
            ]),
            'note_1'=>_char([
                'null'=>1,'hide'=>1,"pattern"=>"/^[0-9A-Za-z'\_\,\.\s\r\% ]+$/",
            ]),
            'title_2'=>_char([
                'null'=>1,'hide'=>1
            ]),
            'note_2'=>_char([
                'null'=>1,'hide'=>1,"pattern"=>"/^[0-9A-Za-z'\_\,\.\s\r\% ]+$/",
            ]),
            'sint_1'=>_integer(['null'=>1,'hide'=>1]),
            'sint_2'=>_integer(['null'=>1,'hide'=>1]),
            'sint_3'=>_integer(['null'=>1,'hide'=>1]),
            'sdec_1'=>_decimal(['null'=>1,'hide'=>1]),
            'sdec_2'=>_decimal(['null'=>1,'hide'=>1]),
            'sdec_3'=>_decimal(['null'=>1,'hide'=>1]),
            'date_1'=>_date(['null'=>1,'hide'=>1]),
            'cluster'=>_char([
                'default'=>"original","null"=>1
            ]),
            'flag'=>_integer([
                'default'=>0,'hide'=>1,
                'options'=>["No","Yes"]
            ])
            ,'flag1'=>_integer([
                'default'=>0,'hide'=>1,
                'options'=>["No","Yes"]
            ]),
            'flag2'=>_integer([
                'default'=>0,'hide'=>1,
                'options'=>["No","Yes"]
            ]),
            'active'=>_integer([
                'default'=>0,'hide'=>1,
                'options'=>["No","Yes"]
            ])
        ];
    }
    public function insert(array $crit,$table=false)
    {
        $num=new Number($this);
        $prefix=Prefix::init($this,$crit);
        $num->date="date";
        $num->field="number";
        $num->group="doc_type";
        $crit['creator']=User::id();
        $num->value=$crit["doc_type"];
        $num->init=$prefix->get_initial();
        $crit["prefix"]=$prefix->get_prefix();
        $crit['number']=$num->getNext();
        return parent::insert($crit,$table);
    }
    
    public function update(array $data=[], $cr=[], $table=false)
    {
        //if($this->isLocked($data)){
        //    return false;
        //}
        return parent::update($data, $cr, $table);
    }
    
    public function isLocked($data){
        return $this->locked($data)&&$this->isNotEntry($data);
    }

    public function setPrefix($crit)
    {
        $mod= \Lib\Factory::app("DocType","Base");
        $mod->get($crit["doc_type"]);
        $raw=$mod->name;
        $str="";
        if(preg_match("/[a-zA-Z]+\s+[a-zA-Z]+/", $raw))
        {
            $raw2= explode(" ", $raw);
            foreach ($raw2 as $word) {
                $str.= substr($word, 0, 1);
            }
        }
        else{
            $str= substr($raw, 0, 3);
        }
        return $str;
    }
}