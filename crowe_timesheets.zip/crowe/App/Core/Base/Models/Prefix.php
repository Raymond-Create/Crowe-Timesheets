<?php

namespace Core\Base\Models;

use Core\Base\Library\Trail as Model;

class Prefix extends Model
{
    
    public $_rep_=['prefix'];
    //public $_group_=['doc_type'];
    
    public function _setup()
    {
        return [
            'doc_type'=>_foreign([
                'model'=>['DocType','Base'],"null"=>1
            ]),
            'description'=>_char(['null'=>1]),
            'prefix'=>_char(),
            'yearly_rest'=>_integer([
                'options'=>['No','Yes'],"default"=>1
            ]),
            'start'=>_integer(["default"=>1]),
            'decrement'=>_integer([
                "default"=>0,
                "options"=>["No","Yes"]
            ])
        ];
    }
    
}