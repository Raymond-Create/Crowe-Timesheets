<?php

namespace Core\Base\Models;



class Addition extends \Lib\Model{

    public $_rep_=["name"];    

    public $_group_=['record'];
    
    public function _setup(){    
    	return [
    	    'record'=>_foreign([
    	        'model'=>['Record','Base'],
    	    ]),
            'effect'=>_char([
                "options"=>[
                    "Decrease","Increase"
                ],"defualt"=>1
            ]),
    	    'name'=>_char(),
    	    'amount'=>_currency(["default"=>0.00]),
            'active'=>_char([
             	"pattern"=>"/^(no|yes)$/",
             	"default"=>'yes',
             	"choices"=>['no','yes']
            ])
        ];
    }
    
    public function setName($name)
    {
        return strtoupper($name);
    }
    
}