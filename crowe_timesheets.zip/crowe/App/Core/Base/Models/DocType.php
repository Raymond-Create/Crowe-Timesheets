<?php

namespace Core\Base\Models;

use Lib\Model;

class DocType extends Model
{
    
    public $_rep_=['name',"type"];
    public $_group_=['doc'];
    public function _setup()
    {
        return [
            'name'=>_char(),
            'doc'=>_foreign([
                'model'=>['Doc','Base'],
            ]),
            'postable'=>_integer([
                'options'=>['No','Yes']
            ]),
            'type'=>_char([
                'choices'=>["Receipt","Payment","Other"],"default"=>"Other"
            ]),
            'debit_core'=>_foreign([
                'model'=>['CoreAccount','Base']
            ]),
            'debit_notes'=>_char([
                'null'=>1,
            ]),
            'credit_core'=>_foreign([
                'model'=>['CoreAccount','Base']
            ]),
            'credit_notes'=>_char([
                'null'=>1,
            ]),
            'library'=>_char([
                'hide'=>1,"null"=>1
            ])
        ];
    }
    
    public function setName($name)
    {
        return strtoupper($name);
    }
    
}