<?php

namespace Core\Base\Models;


class ItemType extends \Lib\Model
{
    
    public $_rep_=['name'];
    
    public $_group_=['nature'];
    
    public function _setup()
    {
        return [
            'category'=>_foreign([
                'model'=>['Category','Base'],
                'null'=>1
            ]),
            'nature'=>_char(["choices"=>["PRODUCT","SERVICE"]]),
            'name'=>_char(["unique"=>1,"index"=>1]),
            'flag'=>_integer([
                'default'=>0,'hide'=>1,
                'options'=>["No","Yes"]
            ])
        ];
    }
    
    public function setName($name)
    {
    		return strtoupper($name);
    }
    
    
}