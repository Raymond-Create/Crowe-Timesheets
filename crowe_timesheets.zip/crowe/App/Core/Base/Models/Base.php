<?php

namespace Core\Base\Models;

use Lib\Model as B;

class Base extends B{
    
    public $_rep_ = ['name'];
    
    public function _setup(){
        return [
            'name'=>_char(['unique'=>1,'index'=>1]),
            'duration'=>_integer([
            	'null'=>1,
            	"Verbose"=>"Number of months"
            ]),
            'auto'=>_integer(['default'=>0])
        ];        
    }
	
	public function setName($name)
    {
    	return strtoupper($name);
    }
	
}