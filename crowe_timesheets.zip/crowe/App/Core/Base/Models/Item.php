<?php

namespace Core\Base\Models;


class Item extends \Lib\Model
{
    
    public $_rep_=['name'];
    
    public $_group_=['type'];
    
    public function _setup()
    {
        return [
            'type'=>_foreign([
                'model'=>['ItemType','Base'],
                'null'=>1
            ]),
            'units'=>_char([
                'default'=>"unit",
                'autosuggest'=>1
            ]),
            'code'=>_char(["null"=>1,"index"=>1,"pattern"=>"/[a-zA-Z0-9\/\- ]+/"]),
            'name'=>_char(["unique"=>1,"index"=>1]),
            'inventory'=>_integer([
                'default'=>0,'options'=>["No","Yes"]
            ]),
            'price'=>_currency(),
            'margin'=>_decimal([
                'default'=>0
            ]),
            'inventory'=>_integer([
                'default'=>0,'options'=>["No","Yes"]
            ]),
            'flag'=>_integer([
                'default'=>0,'hide'=>1,
                'options'=>["No","Yes"]
            ]),
            'flag2'=>_integer([
                'default'=>0,'hide'=>1,
                'options'=>["No","Yes"]
            ])
        ];
    }
    
    public function setName($name)
    {
        return strtoupper($name);
    }
    
    
}