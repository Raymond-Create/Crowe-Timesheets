<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Base\Models;


class Currency extends \Lib\Model{

    public $_rep_=["name"];    

    public function _setup(){    
    	return [
            'name'=>_char(['index'=>1,'unique'=>1]),
            'description'=>_text(['null'=>1])
        ];
    }
    
    public function setName($name)
    {
        return strtoupper($name);
    }
    
    public function setDescription($name)
    {
        return $this->setName($name);
    }
}