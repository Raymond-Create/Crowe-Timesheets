<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Base\Models;

use Core\Base\Library\Trail as Model; 

class Location extends Model{

    public $_rep_=["name"];    

    public $_group_=["type"];    

    public function _setup(){    
    	return [
            'type'=>_char(['choices'=>[
                'StockLocation','BusinessUnit',"OtherLocation"
            ],"null"=>1]),
            'name'=>_char(['index'=>1]),
            'description'=>_char(['null'=>1]),
    	    //week reference to an asset
            'link'=>_integer([
                'null'=>1
            ]),
            'value'=>_decimal(),
            'cluster'=>_char(['index'=>1,'hide'=>1]),
            'flag'=>_integer([
                'default'=>0
            ]),
            'flag2'=>_integer([
                'default'=>0
            ]),
            'flag3'=>_integer(['null'=>1,"hide"=>1]),
            'flag4'=>_integer(['null'=>1,"hide"=>1]),
            'flag5'=>_integer(['null'=>1,"hide"=>1])
            
        ];
    }
    
    public function insert(array $data, $table = false) 
    {
        $data['link']=$data['link']??0;//x($data);
        $data['flag']=$data['flag']??0;//x($data,9);
        $data['flag2']=$data['flag2']??0;
        $data['flag3']=$data['flag3']??0;
        $data['flag4']=$data['flag4']??0;
        $data['flag5']=$data['flag5']??0;
        $data['value']=$data['value']??0;
        $data['name']=$data['name']??rand(0,1000000);
        $data['cluster']=$data['cluster']??($this->_cluster??"original");
        return parent::insert($data, $table);
    }
    
    public function table()
    {
        return "locations";
    }
    
}