<?php

namespace Core\Base\Models;

class CoreAccount extends \Lib\Model{

    public $_rep_=["name"];    

    public $_group_=['type'];
    
    public function _setup(){    
    	return [
    	    'type'=>_char([
    	        "choices"=>[
    	            "Assets","Expenses","Liabilities","Income","Equity"
    	        ]
    	    ]),
    	    'side'=>_char([
    	        "choices"=>["debit","credit"]
    	    ]),
            'name'=>_char()
        ];
    }
}