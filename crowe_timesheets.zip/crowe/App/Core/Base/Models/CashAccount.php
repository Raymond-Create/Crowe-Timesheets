<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Base\Models;


class CashAccount extends \Lib\Model{

    public $_rep_=["name","number"];    
    
    public $_cluster="original";    
    
    public function _setup(){    
    	return [
            'type'=>_char(['choices'=>[
                'Bank','Wallet','Cash',"Other"
            ],"null"=>1]),
            'currency'=>_foreign([
            	'model'=>["Currency","Base"],"null"=>1
            ]),
            'name'=>_char(['index'=>1]),
            'company'=>_char(['null'=>1]),
            'branch'=>_char(['null'=>1]),
            'number'=>_char(['null'=>1]),
            'swift'=>_char(['null'=>1]),
            'cluster'=>_char(['null'=>1,'hide'=>1]),
            'flag'=>_integer([
                'default'=>0,'hide'=>1
            ]),
            'flag1'=>_integer([
                'default'=>0,'hide'=>1
            ]),
            'flag2'=>_integer([
                'default'=>0,'hide'=>1
            ])
        ];
    }
    
    public function insert(array $data, $table = false) 
    {
        $data['flag1']=$data['flag']??0;
        $data['flag2']=$data['flag2']??0;
        $data['cluster']=$data['cluster']??($this->_cluster??"original");
        return parent::insert($data, $table);
    }
}