<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Base\Models;

class Setting extends \Lib\Model{

    public $_rep_=["name"];    

    public function _setup(){   
        //$connection=$this->getConnection();
        //$database=$connection->getDatabase(); 
    	return [
    	    'name'=>_char(['index'=>1]),
    	    'value'=>_char(),
    	    'user'=>_foreign([
    	        "model"=>["User","Authentication"],"null"=>1
    	    ])
        ];
    }
    
    public function setName($name)
    {
        return strtoupper($name);
    }
    
}