<?php
	
/**
 * Description of Acl
 *
 * @author bchaumba
 */
 
namespace Core\Base\Models;

use \Lib\Model;

class MenuTrack extends Model{

    public $_rep_=["title"];    
	  
	//public function update_struct(array $array){return $array;}
	
    public function _setup(){    
    	return [
            'date'=>_datetime(),
    	    'user'=>_foreign([
    	        'model'=>["User","Authentication"]
    	    ]),
    	    'menu'=>_foreign([
    	        'model'=>["Menu","Base"]
    	    ])
        ];
    }
}