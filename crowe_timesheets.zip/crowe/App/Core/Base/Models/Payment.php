<?php
	
/**
 * Description of Acl
 *
 * @author bchaumba
 */
 
namespace Core\Base\Models;


class Payment extends \Lib\Model{

    public $_rep_=["date"];    
	  
	//public function update_struct(array $array){return $array;}
	
    public function _setup(){    
    	return [
            'date'=>_datetime(),
    	    'accrual'=>_foreign([
    	        'model'=>["Record","Base"],
    	        "filter"=>["where"=>["int_3"=>null]]
    	    ]),
    	    'realisation'=>_foreign([
    	        'model'=>["Record","Base"],
    	        "filter"=>["where"=>["int_3"=>1]]
    	    ]),
    	    'amount'=>_currency()
        ];
    }
    public function insert(array $crit,$table=false)
    {
        $crit['date']=date("Y-m-d");
        return parent::insert($crit,$table);
    }
}