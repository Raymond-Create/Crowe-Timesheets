<?php

namespace Core\Base\Models;

use Core\Base\Library\Number;

class Account extends \Lib\Model{

    public $_rep_=["name","code"];    

    public $_group_=['active'];
    
    public function _setup(){    
    	return [
    	    'name'=>_char(["unique"=>1,"index"=>1,"pattern"=>'/^[a-zA-z0-9\.\&\-\_\(\) ]+$/']),
    	    'core'=>_foreign([
    	        'model'=>['CoreAccount','Base'],
    	    ]),
            'code'=>_integer(["index"=>1]),
            'official_code'=>_char(["null"=>1]),
            'active'=>_char([
             	"pattern"=>"/^(no|yes)$/",
             	"default"=>'yes',
             	"choices"=>['no','yes']
            ])
        ];
    }
    public function insert(array $crit,$table=false)
    {
        if(!isset($crit["code"])||$crit["code"]<100)
        {
            $num=new Number($this);
            $num->init=100;
            $num->field="code";
            $num->group="core";
            $num->value=$crit["core"];
            $crit['code']=$num->getNext();
        }//x($crit,8);
        return parent::insert($crit,$table);
    }
    
    public function setName($name)
    {
        $nm=strtoupper($name);
        $mod= \Lib\Factory::app("Account","Base");
        $nnm=$nm." ".$this->k;//x($nnm,8);
        if($mod->read(["where"=>["name"=>$nm]])){
            if($mod->read(["where"=>["name"=>$nnm]])){
                $this->k++;
                return $this->setName($nm);
            }
            return $nnm;
        }
        return $nm;
    }
    
    private $k=1;
}