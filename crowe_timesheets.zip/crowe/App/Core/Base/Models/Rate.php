<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Base\Models;


class Rate extends \Lib\Model{

    public $_rep_=["rate"];
    
    public $_group_=["date"];
    
    public function _setup(){    
    	return [
            'date'=>_date(),
            'base'=>_foreign([
            	'model'=>['Currency','Base']
            ]),
            'currency'=>_foreign([
            	'model'=>['Currency','Base']
            ]),
            'rate'=>_decimal(['default'=>1]),
            'reciprocal'=>_decimal([
            	'default'=>1,'verbose'=>'Factor'
            ])
        ];
    }
    
    public function insert(array $crit,$table=false)
    {
        if($crit['rate']==0||$crit['rate']<0)
        {
        		throw new \Exception($crit['rate']==0?'Rate cannot be zero':'Rate cannot be less than zero');
        }
        $crit['reciprocal']=1/$crit['rate'];//x($crit,9);
        return parent::insert($crit,$table);
    }
}