<?php

namespace Core\Base\Models;

use Lib\Model;

class Doc extends Model
{
    
    public $_rep_=['name'];
    
    public function _setup()
    {
        return [
            'name'=>_char(['null'=>1])
        ];
    }
    
    public function setName($name)
    {
        return strtoupper($name);
    }
    
}