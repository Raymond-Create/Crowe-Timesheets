<?php
	
/**
 * Description of Acl
 *
 * @author bchaumba
 */
 
namespace Core\Base\Models;

use Core\Authentication\Models\Menu as Mn;

class Menu extends Mn{}