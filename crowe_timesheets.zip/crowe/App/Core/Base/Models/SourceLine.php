<?php

namespace Core\Base\Models;


class SourceLine extends \Lib\Model
{
    
    public $_rep_=['details'];
    
    //public $_group_=['type'];
    
    public function _setup()
    {
        return [
            'record'=>_foreign([
                'model'=>['Record','Base'],"null"=>1
            ]),
            'source'=>_integer(["null"=>1]),
            'item'=>_foreign([
                'model'=>['Item','Base'],"null"=>1
            ]),
            'details'=>_char([
                'default'=>"unit","null"=>1,'autosuggest'=>1,
                "pattern"=>"/^[a-zA-Z0-9\,\.\-\#\(\)\[\]\+\:\/ ]+$/"
            ]),
            'quantity'=>_decimal([
                'default'=>0
            ]),
            'units'=>_char(["null"=>1,"index"=>1]),
            'note'=>_char(["null"=>1]),
            'price'=>_currency(),
            'tax'=>_currency(["null"=>1]),
            'remainder'=>_integer([
                'default'=>0,'hide'=>1
            ]),
            'flag'=>_integer([
                'default'=>0,'hide'=>1
            ]),
            'flag2'=>_integer([
                'null'=>1,'hide'=>1
            ]),
            //ALTER TABLE `sourcelines` ADD `cluster` VARCHAR(200) NOT NULL DEFAULT 'Base.Record' AFTER `flag2`; 
            'cluster'=>_char([
                'null'=>1,'hide'=>1,"default"=>'Base.Record',
                "pattern"=>"/^[a-zA-Z0-9\,\.\-\+\:\/ ]+$/"
            ])
        ];
    }
    
    public function setName($name)
    {
        return strtoupper($name);
    }
    
    
}