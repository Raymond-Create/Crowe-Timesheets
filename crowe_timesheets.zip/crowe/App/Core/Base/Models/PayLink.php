<?php

namespace Core\Base\Library;
use Lib\Factory;
//php_ini_loaded_file()

class PayLink{
    
    public $accrual,$realisation;
    
    public static function init($realisation=null,$accrual=null)
    {
        return new self($realisation,$accrual);
    }
    
    public function __construct($realisation=null,$accrual=null)
    {
       if($realisation)
       {
           $this->set_realisation($realisation);
       }
       if($accrual)
       {
           $this->set_accrual($accrual);
       }
    }
    
    public function set_realisation($realisation)
    {
        $this->realisation=$realisation;
    }
    
    public function set_accrual($accrual){
        $this->accrual=$accrual;
    }
    
    public function unlink($id=null){
        $real=Factory::app("Record","Base");
        $accr=Factory::app("Record","Base");
        try{
            if($id){
                $pay=Factory::app("Payment","Base");
                $pay->get($id);
                if(!$pay->id)
                {
                    throw new \Exception("Payment Link not found");
                }
                $this->set_realisation($pay->realisation);
                $this->set_accrual($pay->accrual);
            }
            //find accrual rate
            $ac=$accr->read([
                "join"=>[
                    "join"=>[
                        ["rates","records.rate","rates.id"]
                    ]
                ],
                "select"=>["rates.rate"],
                "where"=>["records.id"=>$this->accrual]
            ]);
            $mytrans=!$real->trans();
            if($mytrans){
                $real->begin();
            }
            if(empty($ac))
            {
                throw new \Exception("Accrual record not found");
            }
            $accr->get($this->accrual);
            $payData=$pay->read([
                "where"=>[
                    "realisation"=>$this->realisation,"accrual"=>$this->accrual
                ]
            ]);
            if(empty($payData))
            {
                throw new \Exception("Payment record not found");
            }
            $payDel=$pay->remove($payData[0]["id"]);
            if(empty($payDel))
            {
                throw new \Exception("Payment record not deleted");
            }
            $amount=currency($payData[0]["amount"]/$ac[0]["rate"]);
            //TODO
            //check if payment decrementation does not exceed zero
            //if(($acc->paid-$amount)<0)
            $accr->paid-=$amount;
            $accrId=$accr->save();
            if(!$accrId){
                throw new \Exception("Payment change not saved");
            }
            if($mytrans){
                $real->commit();
            }
            return [true,$payDel];
        }
        catch(\Exception $ex)
        {
            if($mytrans){
                $real->rollback();
            }
            return [false,$ex->getMessage()];
        }
    }
        
    public function link(){
        $real=Factory::app("Record","Base");
        $accr=Factory::app("Record","Base");
        $acFilter=[
            "join"=>[
                "join"=>[
                    ["rates","records.rate","rates.id"]
                ]
            ],
            "select"=>[
                /*
                "records.id","records.amount",
                "records.paid","rates.rate",
                "records.paid*rates.rate as basePaid",
                "records.amount*rates.rate as baseAmount"*/
                "records.amount*rates.rate as baseAmount","rates.rate"
            ],
            "where"=>["records.id"=>$this->accrual]
        ];
        $reFilter=$acFilter;
        $reFilter["where"]["records.id"]=$this->realisation;
        //find accrual rate
        $ac=$accr->read($acFilter);
        //find realisation base amount
        $re=$real->read($reFilter);
        
        try{
            $mytrans=!$real->trans();
            if($mytrans){
                $real->begin();
            }
            if(empty($re))
            {
                throw new \Exception("Realisation record not found");
            }
            if(empty($ac))
            {
                throw new \Exception("Accrual record not found");
            }
            //Create Payment
            $pay=Factory::app("Payment","Base");
            $accr->get($this->accrual);
            $pay->realisation=$this->realisation;
            $pay->accrual=$this->accrual;
            $pay->amount=currency($re[0]["baseAmount"]);
            $payId=$pay->save();
            //Update accrual paid
            if($payId){
                $amount=currency($re[0]["baseAmount"]/$ac[0]["rate"]);
                //TODO
                //check if payment incrementation does not exceed amount
                //if($acc->amount>=($acc->paid+$amount))
                $accr->paid+=$amount;
                $accrId=$accr->save();
                if(!$accrId){
                    throw new \Exception("Payment change not saved");
                }
            }
            else{
                throw new \Exception("Payment not saved");
            }
            if($mytrans){
                $real->commit();
            }
            return [true,$payId];
        }
        catch(\Exception $ex)
        {
            if($mytrans){
                $real->rollback();
            }
            return [false,$ex->getMessage()];
        }
    }
}
