<?php

return [
	//first gen setting
	[
		// key, label, desctiption
		["Default Currency","The default currency used by the system"],
		//combo/field/area, name,  meta,datasource,  filter,
		["combo","defaultCurrency",["data-pattern"=>"/\d+/"],["Currency","Base"]]
	]

];