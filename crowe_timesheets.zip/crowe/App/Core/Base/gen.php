<?php

return [
	//first gen setting
	[
		// key, label, desctiption
		["Default Currency","The default currency used by the system"],
		//type(combo/field/area),        name,              meta,               model,               filter, data
		["combo",                "defaultCurrency",["data-pattern"=>"/\d+/"],["Currency","Base"]]
	],//second gen setting
	[
		// key, label, desctiption
		["Default Business Unit","The default business unit used by the system"],
		//type(combo/field/area),        name,              meta,               model,               filter, data
		["combo",                "defaultBusinessUnit",["data-pattern"=>"/\d+/"],["Location","Base"],["where"=>["type"=>"BusinessUnit"]]]
	],
	//fourth gen setting
	[
		// key, label, desctiption
		["Default Password","The default password to set when you reset password in the system"],
		//type(combo/field/area),        name,              meta,               model,               filter, data
		["field",                "defaultPassword",["data-pattern"=>"/.{8,20}/","placeholder"=>"Enter Password 8-20 characters"]]
	]

];