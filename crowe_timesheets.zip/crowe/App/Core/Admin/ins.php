<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */
/***************************************************************
            DATABASE ALTERATIONS TO ACCOMMODATE MODULE
 * 
 * 
 
ALTER TABLE `employees` ADD `phone_code` INT NULL DEFAULT NULL AFTER `designation`; 
ALTER TABLE `employees` ADD `phone` INT NULL DEFAULT NULL AFTER `designation`; 
ALTER TABLE `employees` ADD `email` VARCHAR(255) CHARACTER SET utf8mb4 NULL DEFAULT NULL AFTER `designation`; 

 *******************************************************************/
return[
    //module ref
    "ref"=>"Admin",
    //external dependencies
    "dependencies"=>[
        "Authentication"=>[
            "Authentication","Org","Db",
        ]
    ],
    //models in order of dependency
    "models"=>[
        //"Employee","Assignment"
    ],
    //links
    "links"=>[
        [
            'url'=>'admin',
            'title'=>'Admin',
            'icon'=>'mdi mdi-account-star-outline',
            'cluster'=>'root',
            'category'=>[
                ["Category","Base"],
                [
                    "name"=>"LINK GROUP",
                    "type"=>"MENUS"
                ]
            ],
            'active'=>1,
            'module'=>"Admin",
            'allowed'=>[
                'Manager','Supervisor'
            ]
           
        ],
        [
            'url'=>'admin/users',
            'title'=>'Users',
            'icon'=>'mdi mdi-account-supervisor',
            'cluster'=>'admin',
            'category'=>[
                ["Category","Base"],
                [
                    "name"=>"LINK",
                    "type"=>"MENUS"
                ]
            ],
            'active'=>1,
            'module'=>"Admin",
            'allowed'=>[
                'Manager','Supervisor'
            ]
        ],
        [
            'url'=>'admin/orgs',
            'title'=>'Organisations',
            'icon'=>'mdi mdi-equalizer',
            'cluster'=>'admin',
            'category'=>[
                ["Category","Base"],
                [
                    "name"=>"LINK",
                    "type"=>"MENUS"
                ]
            ],
            'active'=>1,
            'module'=>"Admin",
            'allowed'=>[
                'Manager','Supervisor'
            ]
        ],
        [
            'url'=>'admin/dbs',
            'title'=>'Org Access',
            'icon'=>'mdi mdi-human-scooter',
            'cluster'=>'admin',
            'category'=>[
                ["Category","Base"],
                [
                    "name"=>"LINK",
                    "type"=>"MENUS"
                ]
            ],
            'active'=>1,
            'module'=>"Admin",
            'allowed'=>[
                'Manager','Supervisor'
            ]
        ]
    ]
];