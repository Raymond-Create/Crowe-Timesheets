<?php

namespace Core\Admin\Controllers;

use Core\Admin\Library\Password;
use Core\Admin\Library\UsersView as Ov;

class Users extends \Core\Admin\Library\AdminController{
    
    use \Core\Base\Library\Index;
    public 
        $root_db=1,
        $show_form=1,
        $_model=["Authentication","Authentication"];
    
    public function __table($rows,$page):\Huchi\Classes\Tag
    {
        $this->table["widths"]=[
            "admin"=>"72px",
            "due"=>"72px",
            "block"=>"72px",
            "active"=>"72px",
            "code"=>"72px",
            "name"=>"110px",
            "surname"=>"110px"
        ];
        $this->table["script"]="user-password";
        $this->table["search_forms"]=[
            "name","surname","email","mobile"
        ];
        $this->table["action"]=[
            ["icon"=>"fa fa-eye mr-2","text"=>"View","act"=>"btn-view"],
            ["icon"=>"fa fa-lock mr-2","text"=>"Password","act"=>"btn-pass"],
            ["icon"=>"fa fa-edit mr-2","text"=>"Edit","act"=>"btn-edit"],
            ["icon"=>"fa far fa-trash-alt mr-2","text"=>"Delete","act"=>"btn-delete"]
        ];
        return Ov::init(parent::__table($rows, $page))->html();
    }
    
    public function password($user){
        $lib=new Password($user);
        if($this->post()){
            $k=$lib->save($this->post);
            $this->json($k?"Password changed":"Password NOT changed",$k);
        }
        $this->ajax($lib->html());
    }
    
}