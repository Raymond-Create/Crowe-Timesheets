<?php

namespace Core\Admin\Controllers;

use Core\Admin\Library\Mod;
use Core\Admin\Library\ModsView as Mv;


class Admin extends \Core\Admin\Library\AdminController{
    
    use \Core\Base\Library\Index;
    
    public function index()
    {
    	 redirect("Authentication/Login");
    }
    
    public function db() {
        unset($_SESSION["user_selected_database"]);
        $this->json(1,!!1);
    }
    public 
        $show_form=1,
        $_model=["Db","Authentication"];
    
    public function modules($rows = 25, $page = 1, $extra = null) {
        $page=is_numeric($page)?$page:1;
        $rows=is_numeric($rows)?$rows:25;
        $lib=new Mod($rows,$page);
        $this->ajax(Mv::init($lib->html())->html());
    }
    
} 