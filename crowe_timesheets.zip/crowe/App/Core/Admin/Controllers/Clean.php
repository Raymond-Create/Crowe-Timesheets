<?php

namespace Core\Admin\Controllers;

class Clean extends \Huchi\Classes\Controller{
    
    
    
    public function on_init() {
        
    }
    
    public function db() {
        \Lib\Session::remove("user_selected_database");
        redirect(config("logout"));
    }
    
} 