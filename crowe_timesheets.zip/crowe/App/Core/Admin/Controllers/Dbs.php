<?php

namespace Core\Admin\Controllers;

use Core\Admin\Library\DbsView as Ov; 

class Dbs extends  \Core\Admin\Library\AdminController{
    
    use \Core\Base\Library\Index;
    public 
        $show_form=1,
        $_model=["Db","Authentication"];
    
    public function __table($rows,$page):\Huchi\Classes\Tag
    {
        $this->table["search_forms"]=[
            "user","org"
        ];
        return Ov::init(parent::__table($rows, $page))->html();
    }
    
} 