<?php

namespace Core\Admin\Controllers;

use Core\Admin\Library\Installation as Mi;
use Core\Admin\Library\InstallationsView as Ov;
use Core\Authentication\Library\User;
use Lib\Access as Ax;


class Installations extends \Core\Admin\Library\AdminController{
    
    use \Core\Base\Library\Index;
    public 
        $root_db=1,
        //$show_form=1,
        $_lib=["Installation","Admin"],
        $_model=["Installation","Admin"];
    
    public function on_init(){
        $this->check_request();
        if($this->isLoggedIn())
        {
            $this->setcom();
        }else{
            redirect(config("logout"));
        }
        if(!User::isTheAdmin())
        {
        	redirect("admin/admin");
        }
        
        if(isset($this->_model))
        {
            $this->model = \Lib\Factory::init()->get_model($this->_model);
            $this->model->tableExists();
        }
        $this->view->MENUS="";
        $this->view->noHeader();
        $this->view->assets=SERVER_URL ."/App/Core/Authentication/static";
        //LoginLog::init()->activity();
        
    }
    
   
    
    public function install($org,$module,$unistall=false) {
        $lib=new Mi();
        $lib->setOrg($org);
        if($unistall)
        {
            $lib->setUninstall();
        }
        $e=$lib->install($module);
        $this->json($e,is_array($e));
    }
    
    public function __table($rows,$page):\Huchi\Classes\Tag
    {
        $this->table["struct"]=[
            "id"=>_foreign([
                "model"=>["Org","Authentication"],"verbose"=>"Organisation"
            ]),
            "module"=>_integer([
                "verbose"=>"Installed Modules",
                "null"=>1
            ])
       	];//
       	$this->table["filter"]=[
            "table"=>"orgs",
            "join"=>[
                "left join"=>[
                    ["installations i","i.organisation","orgs.id"]
                ]
            ],
            "select"=>[
                "orgs.id",
                "sum(case when i.module is null then 0 else 1 end) as module",
                "'1' as active"
            ],
            "group"=>["orgs.id"]
       	];
       	$this->table["action"]=[
	        [
	        "icon"=>"mdi mdi-archive-sync mr-2",
	        "text"=>"Manage",
	        "act"=>"btn-edit"]
	    ];
        return Ov::init(parent::__table($rows, $page))->html();
    }
    
    public function tab($org=null) {//x(config("update_database"),8);
        $table=new Mi;
        if($org){
            $table->setOrganisation($org);
        }
        $this->ajax($table->html());
    }
}