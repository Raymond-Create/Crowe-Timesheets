<?php

namespace Core\Admin\Controllers;

class Modules extends \Core\Base\Library\Controller{
    
    use \Core\Base\Library\Index;
    
    public 
        $_lib=["ModuleManager","Admin"],
        $_model=["OrgModLicense","Admin"];
    
    public function __table($rows,$page):\Huchi\Classes\Tag 
    {
        $this->table["rows"]=$rows;
        $this->table["page"]=$page;
        return Hv::init(parent::__table($rows, $page))->html();
    }
    
    
} 