<?php

namespace Core\Admin\Controllers;

use Core\Admin\Library\DbsView as Ov; 
use Core\Admin\Library\ErrorLog;

class Errors extends  \Core\Base\Library\Controller{
    
    use \Core\Base\Library\Index;
    public 
        //$show_form=1,
        $_model=["ErrorLog","Admin"];
    
    public function __table($rows,$page):\Huchi\Classes\Tag
    {
        $this->table["search_forms"]=[
            "code","time"
        ];
        return Ov::init(parent::__table($rows, $page))->html();
    }
    
    public function view($id)
    {
        $this->ajax(ErrorLog::view($id));
    }
    
} 