<?php

namespace Core\Admin\Controllers;

use Core\Admin\Library\Logo;
use Core\Admin\Library\OrgsView as Ov;

class Orgs extends \Core\Admin\Library\AdminController{
    
    use \Core\Base\Library\Index;
    public 
        $root_db=1,
        //$show_form=1,
        $_model=["Org","Authentication"],
        $_lib=["Orgn","Admin"];
    
    public function get_lib($id)
    {
        $lib=\Lib\Factory::lib($this->_lib[0], $this->_lib[1], $id);
        $lib->main_db=true;
        return $lib;
    }
    
    public function __table($rows,$page):\Huchi\Classes\Tag
    {
        $this->table["search_forms"]=[
            "name"
        ];
        $this->table["widths"]=[
            "admin"=>"72px",
            "due"=>"72px",
            "bp"=>"72px",
            "db"=>"72px",
            "vat"=>"72px",
            "email"=>"110px",
            "surname"=>"110px"
        ];
        $this->table["action"]=[
            ["icon"=>"fa fa-eye mr-2","text"=>"View","act"=>"btn-view"],
            ["icon"=>"fa fa-file-image mr-2","text"=>"Logo","act"=>"btn-logo"],
            ["icon"=>"fa fa-edit mr-2","text"=>"Edit","act"=>"btn-edit"],
            ["icon"=>"fa far fa-trash-alt mr-2","text"=>"Delete","act"=>"btn-delete"]
        ];
        $this->table["script"]="org-logo";
        return Ov::init(parent::__table($rows, $page))->html();
    }
    
    public function logo($org)
    {
        if($this->post()){
            $this->model->fetch(["where"=>["id"=>$org]]);   		
            $this->model->logo =  str_replace('[removed]', $this->post["prefix"] .",", $this->post["avatar"]);
            $s = $this->model->save();
            $this->json($s?"Record successfully modified":"Record NOT modified",$s);
        }
        $lib=new Logo($org);
        $this->ajax($lib->html());
    }
}