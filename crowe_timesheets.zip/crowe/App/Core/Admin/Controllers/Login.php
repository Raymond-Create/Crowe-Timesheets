<?php

namespace Core\Admin\Controllers;

class Login extends \Huchi\Classes\Controller{
    
   
    
    public function index() {
       redirect("authentication/login/index") ;
    }
    
    public function on_init() {}
    
} 