<?php
	
/**
 * Description of Acl
 *
 * @author bchaumba
 */
 
namespace Core\Admin\Models;

use Lib\Model;

class License extends Model{

    public $_rep_=["users","expiry"];    
	 
	 	public $_group_=["module"];
	//public function update_struct(array $array){return $array;}
	
    public function _setup(){    
    	return [
    		'module'=>_foreign([
    			'model'=>["Module","Admin"]
    		]),
    	    'users'=>_integer(['default'=>3]),
    	    'duration'=>_integer(['default'=>0]),
    	    'notes'=>_char(['null'=>1]),
    	    'txt'=>_char(['null'=>1]),
    	    'flag'=>_integer(['null'=>1])
        ];
    }
}