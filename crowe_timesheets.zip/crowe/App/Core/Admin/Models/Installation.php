<?php
	
/**
 * Description of Acl
 *
 * @author bchaumba
 */
 
namespace Core\Admin\Models;

use Lib\Model;

//import("Sys");

class Installation extends Model{

    public $_rep_=["install_date"];    
	  

    public function _setup(){    
    	return [
            'install_date'=>_date(),
            'update_date'=>_date(["null"=>1]),
            'module'=>_foreign([
                "model"=>["Module","Admin"]
            ]),
    	    'organisation'=>_foreign([
                "model"=>["Org","Authentication"]
            ]),
    	    'admin'=>_foreign([
                "model"=>[
                    "Authentication","Authentication"
                ]
            ]),
    	    'txt'=>_char(["null"=>1]),
    	    'flag'=>_integer(["null"=>1])
        ];
    }
    
    public function insert($crit,$table=false)
    {
        $crit["update_date"]=date('Y-m-d');
        $crit["install_date"]=date('Y-m-d');
        return parent::insert($crit,$table);
    }
    
    public function getModule($var)
    {
        x($var,9);
    }
}