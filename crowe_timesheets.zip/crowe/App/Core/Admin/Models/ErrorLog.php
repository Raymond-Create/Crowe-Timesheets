<?php
	
/**
 * Description of Acl
 *
 * @author bchaumba
 */
 
namespace Core\Admin\Models;

use Lib\Model;

//import("Sys");

class ErrorLog extends Model{

    public $_rep_=["install_date"];    
	  

    public function _setup(){    
    	return [
            'time'=>_datetime(),
            'code'=>_char(["null"=>1]),
            'last_query'=>_char(["null"=>1]),
            'line'=>_text(["null"=>1]),
            'file'=>_text(["null"=>1]),
            'message'=>_text(["null"=>1]),
            'stack'=>_text(["null"=>1]),
        ];
    }
    
    public function insert($crit,$table=false)
    {
        $crit["time"]=date('Y-m-d H:i:s');
        return parent::insert($crit,$table);
    }
    
    public function getModule($var)
    {
        x($var,9);
    }
}