<?php
	
/**
 * Description of Acl
 *
 * @author bchaumba
 */
 
namespace Core\Admin\Models;

use Lib\Model;
use Lib\Factory;

class OrgModLicense extends Model{

    public $_rep_=["expiry"];    
	  
	//public function update_struct(array $array){return $array;}
	
    public function _setup(){    
    	return [
            'org'=>_foreign([
				'model'=>["Org","Authentication"]
			]),
    	    'license'=>_foreign([
				'model'=>["License","Admin"]
			]),
    	    'installed'=>_date(),
    	    'renewed'=>_date(),
    	    'expiry'=>_date(['null'=>1]),
    	    'txt'=>_char(['null'=>1]),
    	    'flag'=>_integer(['null'=>1]),
    	    'active'=>_integer(['default'=>1])
        ];
    }
    
    public function insert(array $crit,$table=false)
    {
    		$crit['renewed']=date('Y-m-d');
    		$crit['installed']=date('Y-m-d');
    		$license=Factory::init()->get_module("License","Admin");
    		$license->get($crit["license"]);
    		if($license->duration!=0)
    		{
    			$crit['expiry']=date('Y-m-d',time()+(60*60*24*30));
    		}
    		return parent::insert($crit,$table);    	
    }

}