<?php
	
/**
 * Description of Acl
 *
 * @author bchaumba
 */
 
namespace Core\Admin\Models;

use Lib\Model;

//import("Sys");

class Module extends Model{

    public $_rep_=["name","version"];    
	  

    public function _setup(){    
    	return [
    			 'path'=>_char(),
    	    'name'=>_char([
    	        'index'=>1
    	    ]),
    	    'notes'=>_text([
    	        "null"=>1
    	    ]),
    	    'version'=>_char([
    	        "default"=>"1.0"
    	    ]),
    	    'publication'=>_date([
    	        "null"=>true
    	    ]),
    	    'restriction'=>_char([
    	    	"choices"=>[
    	    		"Open"=>"Open",
    	    		"Licensed"=>"Licensed",
    	    		"Private"=>"Private"
    	    	],"default"=>"Open"
    	    ]),
    	    'icon'=>_char(["null"=>1]),
    	    'txt'=>_char(["null"=>1]),
    	    'flag'=>_integer(["default"=>0])
        ];
    }
}