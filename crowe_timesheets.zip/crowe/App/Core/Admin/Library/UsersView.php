<?php
namespace Core\Admin\Library;

use Core\Base\Library\AbView;


class UsersView extends AbView
{
    use \Lib\Init;
    
    public function form(){
        return false;
    }
    
    public
        $_title="Users",
        $url="admin/users/create",
        $types="Users",
        $type="User",
        $drop=[
            "Users"=>"admin/users",
            "Organisations"=>"admin/orgs",
            "Org Access"=>"admin/dbs",
            "Modules"=>"admin/admin/modules"
        ];
    
}