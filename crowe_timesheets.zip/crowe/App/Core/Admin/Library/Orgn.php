<?php
namespace Core\Admin\Library;

use Lib\Factory as Fac;
use Lib\Connect;
use Core\Base\Library\Editor;

class Orgn extends Editor{
    
    public
        $id,
        $attr,
        $mode="edit",
        $title="Organisation Editor",
        $model=["Org","Authentication"],
        $main_db=true;
    
    public function rows(){
        $div=div();
        $div->add($this->row1());
        $div->add($this->row2());
        $div->add($this->row3());
        $div->add($this->row4());
        return $div->add($this->row5());
    }
    
    protected function row5()
    {
        return;
        return div("row mt-2")
        ->add(div("col-md-6 col-lg-6")
            ->add(button("btn btn-light btn-sm btn-block btn-location mt-0 mb-0")
                ->add("Business Unit")
                ->attr([
                    "data-value"=>$this->val("location")
                ])
                )
            )
            ->add(div("col-md-6 col-lg-6")
                ->add(button("btn btn-dark btn-sm btn-block btn-asset mt-0 mb-0")
                    ->add("Asset Register")
                    ->attr([
                        "data-value"=>$this->val("asset")
                    ])
                    )
                );
    }
    protected function row1()
    {
        $this->connection=Connect::init();
        global $FALLBACK;
        //x($FALLBACK);
     //x($FALLBACK["app_db"],8)  ;
      $this->connection->addConfig($FALLBACK["app_db"], 0);    $a=$this->connection->mod("Org","Authentication")->getConnection();//x($a,8);
        return div("row")
        ->add(div(C4412)
            ->add($this->label("Owner"))
            ->add(\Lib\Combo::init()
                ->set_connection($a)
                ->set_model(["Authentication","Authentication"])
                ->set_default($this->val("admin"))
                ->set_pattern(INTEGER_RGX)
                ->set_placeholder("Owner")
                ->set_name("admin")
                ->html()
            )
        )
        ->add(div(C8812)
            ->add($this->label("Organisation"))
            ->add(input("form-control form-control-sm")
                ->attr([
                    "name"=>"name","placeholder"=>"ORGANISATION NAME (Required)",
                    "value"=>$this->val("name"),"data-pattern"=>CHAR_RGX,
                    $this->attr=>$this->attr,
                    "required"=>"required","data-type"=>"input"
                ])
            )
        );
    }
    protected function row2()
    {
        return div("row")
            ->add(div(C6612)
                ->add($this->label("Email"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"email","placeholder"=>"Email Address (Not Required)",
                        "value"=>$this->val("email"),"data-type"=>"input",
                        "data-pattern"=>EMAIL_RGX
                    ])
                )
            )
            ->add(div(C6612)
                ->add($this->label("Phone"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"phone","placeholder"=>"Phone Numder (Not Required)",
                        "value"=>$this->val("phone"),"data-type"=>"input",
                        "data-pattern"=>"/[0-9\+\, ]+/"
                    ])
                )
            );
    }
    
    protected function row3()
    {
        return div("row mt-2")
            ->add(div(C121212)
                ->add($this->label("Address"))
                ->add(textarea("form-control form-control-sm")
                    ->attr([
                        "name"=>"address","placeholder"=>"Address (Not Required)",
                        "value"=>$this->val("address"),"data-type"=>"input",
                        "data-pattern"=>TEXT_RGX
                    ])
                )
            );
    }
    
    
    protected function row4()
    {
        return div("row mt-2")
            ->add(div(C4412)
                ->add($this->label("VAT"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"vat","placeholder"=>"Address (Not Required)",
                        "value"=>$this->val("vat"),"data-type"=>"input",
                        "data-pattern"=>CHAR_RGX
                    ])
                )
            )
            ->add(div(C4412)
                ->add($this->label("BP"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"address","placeholder"=>"Address (Not Required)",
                        "value"=>$this->val("bp"),"data-type"=>"input",
                        "data-pattern"=>CHAR_RGX
                    ])
                )
            )
            ->add(div(C4412)
                ->add($this->label("DB"))
                ->add(input("form-control form-control-sm")
                    ->attr([
                        "name"=>"db","placeholder"=>"Address (Required)",
                        "value"=>$this->val("db"),"data-type"=>"input",
                        "data-pattern"=>CHAR_RGX,"required"=>"required"
                    ])
                )
            );
    }
}