<?php

namespace Core\Admin\Library;

use Core\Authentication\Library\User;
use Core\Base\Library\Menu;

class AdminController extends \Core\Base\Library\Controller{
		
    //use \Core\Gs\Library\Index;
    //pub
		
    public function on_init(){
        $this->check_request();
        if($this->isLoggedIn())
        {
            $this->view->MENUS=Menu::init()
            		->html();
            $this->setcom();
        }else{
            redirect(config("logout"));
        }
        if(!User::isTheAdmin())
        {
        	redirect("admin/admin");
        }
        
        if(isset($this->_model))
        {
            $this->model = \Lib\Factory::init()->get_model($this->_model);
        }
        $this->view->MENUS="";
        $this->view->noHeader();
        $this->view->assets=SERVER_URL ."/App/Core/Authentication/static";
        //LoginLog::init()->activity();
        
    }
}