<?php

namespace Core\Admin\Library;

use Lib\Connect;
use Lib\Factory as Fac;
use Lib\TableFixer as Tf;
use Lib\Page;

class Mod
{
	
    use \Lib\Recid, \Lib\PageHtml;
    
    public $page,$rows,$filter=[],$mod,$uninstall,
        $connection,$index,$con,$result;

    public function __construct($rows = 25, $page = 1)
    {
        $this->connection=Connect::init();
        global $FALLBACK;
        $this->connection->addConfig($FALLBACK["app_db"], 0);
        Tf::model(Fac::init()->get_model(
        		"Installation","Admin"
        ));
        $this->page=$page;
        $this->rows=$rows;
    }
    
    
    public function html()
    {
        $orgs=$this->connection->mod("Org","Authentication");
        $this->con=$orgs->getConnection();
        $c=div("card");
        $c->attr("data-x-mod","module-inst");
        $c->add(div("card-header")
            ->add(h3()->add("Module Installer"))
        );
        $c->add(div("card-body")
            ->add($this->row1())
            ->add($this->row2())
            ->add($this->row3())
        );//x($c,7);
        return div("row")
            ->add(div("col-md-12 col-lg-12")
                ->add($c)
            );
    }
    
    public function row1()
    {
        return  div("row")
            ->add(div(C4412)
                ->add(\Lib\Combo::init()
                    ->set_connection($this->con)
                    ->set_model(["Org","Authentication"])
                    ->set_placeholder("Choose Organisation")
                    ->set_name("organisation")
                    ->html()
                )
            )
            ->add(div(C4412)
                ->add(\Lib\Combo::init()
                    ->set_placeholder("Choose Module")
                    ->set_connection($this->con)
                    ->set_data($this->modules())
                    ->set_name("module")
                    ->html()
                )
            )
            ->add(div(C4412)
                ->add(button(BNPS." btn-block btn-save mt-0")
                    ->add("Add Module")
                )
            );
    }
    
    public function row2()
    {
        $mod=Fac::init()->get_model("Installation","Admin");
        $table=table("table table-sm table-bordered mt-2");
        $table->attr("style","border-top: .3em solid gray");
        $md=Fac::init()->get_model("Module","Admin");
        $pages=new Page($mod,[
            "join"=>[
                "join"=>[
                    ["modules m","m.id","installations.module"],
                    ["orgs o","o.id","installations.organisation"],
                ]
            ],
            "select"=>[
                "installations.id","installations.install_date",
                "installations.update_date","m.name as module",
                "o.name as organisation","o.id as org"
            ],
            "order"=>[
                ["installations.update_date","installations.install_date"],
                "DESC"
            ]
        ],$this->rows,$this->page);
        $res=$pages->read();//x(qd(),8);
        $this->result=$res;
        $table->add(thead()
            ->add(tr()
                ->add(th()->add("Installed"))
                ->add(th()->add("Organisation"))
                ->add(th()->add("Module"))
                ->add(th()->add("Updated"))
                ->add(th()->add("Action"))
            )
        );
        $bd=tbody();
        foreach ($res["data"] as $row)
        {
            $bd->add(tr()
                ->add(td()->add($row["install_date"]))
                ->add(td()->add($row["organisation"]))
                ->add(td()->add($row["module"]))
                ->add(td()->add($row["update_date"]))
                ->add(td()->add($this->btn($row)))
            );
        }
        return  div("row")
            ->add(div(C121212 . " table-responsive")
                ->add($table->add($bd))
            );
    }
    
    public function row3()
    {
        return $this->pages();
    }
	
    private function isMod($path){
        return is_dir($path)&&is_file($path.DS."ins.php")&&
            is_file($path.DS."meta.php")&&!is_file($path.DS."skip.php");
    }
    
    private function modules()
    {
        $arr=[];
        $d=ls(APP.DS."Core");
        foreach ($d as $a)
        {
            if($this->isMod(APP.DS."Core".DS.$a)){
                $arr[$a]=$a;
            }
        }
        $d2=ls(APP.DS."Modules");
        foreach ($d2 as $a)
        {
            if($this->isMod(APP.DS."Modules".DS.$a)){
                $arr[$a]=$a;
            }
        }
        return $arr;
    }
    
    private function btn($row)
    {
        $span=span();
        $span->add(i("mdi mdi-autorenew text-success btn-reload")
            ->attr([
                "data-module"=>$row["module"],
                "data-value"=>$row["id"],
                "data-org"=>$row["org"]
            ])
        );
        $span->add(i("fa fa-trash text-danger btn-delete")
            ->attr([
                "data-module"=>$row["module"],
                "data-value"=>$row["id"],
                "data-org"=>$row["org"]
            ])
        );
        return $span;
    }
}