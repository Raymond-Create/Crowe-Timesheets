<?php

namespace Core\Admin\Library;

use Lib\Factory;
use Core\Authentication\Library\User;

class LicenseLib
{
	public $mod,$module;
	public function __construct(ModuleLib $mod)
	{
            $this->mod=$mod;
            $this->set_meta();
	}
	
	private function set_meta()
	{
		$this->module=Factory::init()
			->get_model("License","Admin");
		$this->module->tableExists();
		$this->module->fetch([
                    "where"=>[
                        'module'=>$this->mod->meta("id")
                    ]
		]);
		if(!$this->module->id)
		{
			$this->module->module=$this->mod->meta("id");
			$this->module->user=3;
			$this->module->duration=$this->mod->meta("restriction")=="Open"?0:12;
			$this->module->notes=$this->mod->meta("restriction");
			
			$this->module->id=$this->module->save();
		}
	
	}
	
	public function access()
	{
            new Org;
            $org=Factory::init()
                ->get_model("Org","Authentication");
            $mod=Factory::init()
                ->get_model("OrgModLicense","Admin");
            $mod->tableExists();
            $org->fetch([
                "where"=>[
                    "db"=>\Lib\Session::get("user_selected_databasebase")
                ]
            ]);
		if(!\Lib\Session::get(\Lib\ID::get()))
		{
			return 1;
		}
		//if(User::isTheAdmin())
		//	return 1;
		$mod->fetch([
			"where"=>[
				"org"=>$org->id,
				"license"=>$this->module->id
			]
		]);
		
	}
}