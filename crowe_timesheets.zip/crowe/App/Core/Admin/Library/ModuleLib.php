<?php

namespace Core\Admin\Library;

use Lib\Factory;



class ModuleLib
{
	
	public $mod,$dir,$_meta=[],$module;
	
	public function __construct($mod)
	{
            $this->mod=$mod;
            $this->dir=$this->path();
            //x($this->dir,9);
            if($this->dir)
            {
                    $this->set_meta();
            }
	}
	
	public function exists():bool
	{
		return !!$this->path();
	}
	
	public function meta($name)
	{
		return $this->module->$name;
	}
	
	private function set_meta()
	{
		$data=require $this->path() .DS. 'meta.php';
		$this->module=Factory::init()->get_model("Module","Admin");
		$this->module->tableExists();
		$this->module->fetch([
			"where"=>[
				'path'=>$data["path"],'name'=>$data['name']
			]
		]);//x($data['flag'],7);
		$this->module->name=$data['name'];
		$this->module->flag= is_int($data['flag'])?$data['flag']:0;
		$this->module->version=$data['version'];
		$this->module->notes=$data['notes'];
		$this->module->restriction=$data['restriction'];
		$this->module->publication=$data['publication'];
		$this->module->path=$data['path'];
		$this->module->icon=$data['icon'];//x($this->module->data(),9);
		$id=$this->module->save();
		if(!$this->module->id)
		{
			$this->module->id=$id;
		}
	}
	
	
	
	private function path():string
	{
	    $core=APP .DS. 'Core' .DS. $this->mod;
	    $mod=APP .DS. 'Modules' .DS. $this->mod;
	    //x(is_dir($core),9);
	    //x(is_dir($core),9);
	    if(!is_dir($core)&&!is_dir($mod)){
	        return false;
	    }
	    if(is_dir($core)){
	        return $core;
	    }
	    return $mod;
	}
}