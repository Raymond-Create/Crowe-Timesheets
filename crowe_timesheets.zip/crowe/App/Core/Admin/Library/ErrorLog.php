<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of billionaire
 *
 * @author blessing
 */
namespace Core\Admin\Library;

use Lib\Factory as Fa;

class ErrorLog {
    
    public $exception;
    
    public static function log(\Exception $ex)
    {
        $obj=new self();
        $obj->setExeception($ex);
        $obj->gc();
        $obj->save();
    }
    
    public static function view($ex)
    {
        $obj=new self();
        $obj->gc();
        return $obj->_view($ex);
    }
    
    public function setExeception(\Exception $ex)
    {
        $this->exception=$ex;
    }
    
    public function save()
    {
        $mod=Fa::app("ErrorLog","Admin");
        $mod->last_query=qd()?:"";
        $mod->code=$this->exception->getCode();
        $mod->file=$this->exception->getFile();
        $mod->line=$this->exception->getLine();
        $mod->message=$this->exception->getMessage();
        $mod->stack=$this->exception->getTraceAsString();
        $mod->save();
    }
    
    public function gc()
    {
        $mod=Fa::app("ErrorLog","Admin");
    }
    
    public function _view($id)
    {
        $mod=Fa::app("ErrorLog","Admin");
        $mod->get($id);
        return div("card")
            ->add(div("card-header")
                ->add(h3()->add("Error Viewer"))
            )
            ->add(div("card-body")
                ->add(div(ROW)
                    ->add(div(C666)
                        ->add($mod->time)
                    )
                    ->add(div(C666)
                        ->add($mod->code)
                    )
                )
                ->add(div(ROW)
                    ->add(div(C121212)
                        ->add($mod->message)
                    )
                )
                ->add(div(ROW)
                    ->add(div(C121212)
                        ->add($mod->last_query)
                    )
                )
                ->add(div(ROW)
                    ->add(div(C121212)
                        ->add("<pre>".$mod->stack."</pre>")
                    )
                )
            );
    }
}
