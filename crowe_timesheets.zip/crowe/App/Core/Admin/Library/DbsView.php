<?php
namespace Core\Admin\Library;

class DbsView extends UsersView
{
    use \Lib\Init;
    
    public function form()
    {
        return false;
    }
    public
    $_title="Org Access",
    $open_title="Org",
    //$url="admin/orgs/create",
    $types="Org Access",
    $type="Org Access";
    
    
}