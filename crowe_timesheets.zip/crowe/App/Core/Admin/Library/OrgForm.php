<?php

namespace Core\Admin\Library;

use Lib\Factory as Lf;
use Core\Base\Library\Editor;

class OrgForm extends Editor
{
    
    public
    //$script="contact-form",
    $title="Organisation Editor",
    $model=["Org","Authentication"];
    
    public function mod()
    {
        return Lf::init()->get_model($this->model);
    }
    
    public function rows(){
        $div=div();
       /*
        $div->add($this->row1());
        $div->add($this->row2());
        $div->add($this->row3());
        $div->add($this->row4());
        */
        return $div;
    }
	
	
}