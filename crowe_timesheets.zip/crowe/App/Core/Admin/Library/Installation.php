<?php

namespace Core\Admin\Library;


use Lib\Connect;
use Lib\Factory as Fac;
use Lib\TableFixer as Tf;

class Installation
{
	
    use \Lib\Recid;
    
    public $org,$id,$db,$mod,$uninstall,$connection,$index,$con;

    public function __construct($id=null)
    {
        $this->connection=Connect::init();
        global $FALLBACK;
        $this->connection->addConfig($FALLBACK["app_db"], 0);
        $this->id=$id;
    }
    
    public function setUninstall()
    {
        $this->uninstall=true;
    }
    
    public function setOrganisation($org)
    {
        $this->org=$org;
    }
    
    public function setOrg($org)
    {
        $orgs=$this->connection->mod("Org","Authentication");
        $orgs->get($org);
        if($orgs->db)
        {
            $this->connection->updatedConfig($orgs->db, "active");
            $this->index=$orgs->db;
        }
        $this->con=$orgs->getConnection();
        $this->setOrganisation($org);
    }
  
    private $meta;
    
    public function install($mod)
    {
        $this->mod=$mod;
        $file=$this->getFile();
        if(!$file)
        {
            return "module not found";
        }
        $data=require($file);
        //$file2=str_replace("ins","meta",$file);
        //x(file_exists($file2));
        //x(is_dir(dirname($file2)));
        //x(is_dir(dirname(dirname($file2))));
        //x(str_replace("ins","meta",$file),8);
        $this->meta=require(str_replace("ins.php","meta.php",$file));
        $m=Tf::model(Fac::app("User","Authentication"));
        try{
            $m->begin();
            $this->set_dep($data["dependencies"]);
            $this->set_models($data["ref"], $data["models"]);//x($data["links"],8);
            $this->menus($data["links"]);
            $this->record();
            $m->commit();//x($this->result,8);
            return $this->result;
        }catch(\Exception $er)
        {	x($er,8);
                return $er->getMessage();
        }
        
    }
	 
    private function set_dep($deps)
    {
        foreach($deps as $module=>$models)
        {
            $this->set_models($module,$models);
        }
    }
	 
    private function set_models($module,$models)
    {
        //$this->use_update_db();
        foreach($models as $model)
        {
            Tf::model($this->connection->mod($model,$module,$this->index));
        }//x($module,7);
        //$this->restore_db();
    }
    private function record()
    {
        $model=Tf::model($this->connection->mod(
            "Installation","Admin"
        ));
        $user=\Lib\Session::get(\Lib\ID::get());
        $model->fetch([
            "where"=>[
                'admin'=>$user,
                'module'=>$this->modl(),
                'organisation'=>$this->org,
            ]
        ]);//x($this->org);
        $model->install_date=$model->install_date?:date('Y-m-d');
        $model->update_date=date('Y-m-d');
        $model->organisation=$this->org;
        $model->module=$this->modl();
        $model->admin=$user;//x($model->data(),9);
        $model->save();
    }
    
    private function modl()
    {
        $model=Tf::model($this->connection->mod(
              "Module","Admin"
        ));
        $model->fetch([
            "where"=>["path"=>$this->mod]
        ]);
        if(!$model->id)
        {
            $model->append($this->meta);
            $model->id=$model->save();
        }
        return $model->id;
    }
    
    private $result=[];
    private function menus(array $array)
    {
        Tf::model($this->connection->mod("Category","Base",$this->index));
        foreach($array as $link)
        {
            $model=Tf::model($this->connection->mod("Menu","Base",$this->index));
            $model->fetch([
                "where"=>["title"=>$link["title"]]
            ]);
            //x($model,9);
            $model->url=$link['url'];
            $model->icon=$link['icon'];
            $model->type=$link['type'];
            $model->title=$link['title'];
            $model->active=$link['active'];
            $model->cluster=$link['cluster'];
            $model->module=$link['module'];
            if(isset($link['category']))
            {
                 $model->category=$this->idOf($link['category'],$model->getConnection());
            }//x($model->data());
            $id=$model->save();
            $this->result[$model->url]=$id;
            $this->perm($model->id?:$id,$link);
        }
    }
    
    private function perm($link,$setup)
    {
        $model=Tf::model($this->connection->mod(
            "MenuAccess","Authentication", $this->index
        ));
        foreach($setup['allowed'] as $role)
        {
            $model->fetch([
                "where"=>[
                    "role"=>$this->role($role),
                    "menu"=>$link
                ]
            ]);
            $model->role=$this->role($role);
            $model->menu=$link;
            $model->save();
        }
    }
    
    private function role($name)
    {
        $model=Tf::model($this->connection->mod("Role","Authentication", $this->index));
        //$model=Tf::model(Fac::app("Role","Authentication"));
        $model->fetch([
            "where"=>["name"=>strtoupper($name)]
        ]);
        $model->name=strtoupper($name);
        $id=$model->save();
        return $model->id?:$id;
    }
    
    private function getFile()
    {
        $file1=APP .DS. 'Core' .DS. $this->mod .DS. 'ins.php';
        $file2=APP .DS. 'Modules' .DS. $this->mod .DS. 'ins.php';
        return file_exists($file1)?$file1:(file_exists($file2)?$file2:false);
    }
    
}