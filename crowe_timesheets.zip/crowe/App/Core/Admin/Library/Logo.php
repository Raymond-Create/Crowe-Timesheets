<?php

namespace Core\Admin\Library;

use Lib\Factory as Fa;

class Logo
{
    
    public $org;
    
    public function __construct($org){
        $mod=Fa::init()->get_model("Org","Authentication");
        $mod->get($org);
        if($mod->id){
            $this->org=$mod;
        }
    }

    
    public function html(){
        return div('card')
            ->attr("data-x-mod","logo-uploader")
            ->add(div('card-header')
                ->add(i('fa fa-file-img'))
                ->add(h4()->add(' Company Logo'))				
            )
            ->add(div('card-body')
                ->add(div('row')
                    ->add(div(C121212)
                       ->add(input(NPS)
                            ->attr("type","file")
                        )     
                    )
                    ->add(div(C121212)
                       ->add(hr())
                    )
                    ->add(div(C121212)
                        ->add(div("preview")
                            ->attr("style","margin:auto;")
                            ->add(center()->add($this->img()))
                        )
                    )
                )
            )
            ->add(div('card-footer')
                ->add(div('row')
                    ->add(div(C121212)
                        ->add(input()
                            ->attr([
                                "type"=>"hidden","name"=>"org",
                                "value"=> $this->org->id
                            ])
                        )
                        ->add(button(BNPS ." btn-block submit" )
                            ->add(span("fa fa-cloud-upload-alt"))
                            ->add(span()->add(" Submit"))
                        )
                    )
                )
            );
    }

    private function img(){
        if($this->org && $this->org->logo){
            return img()
                ->attr([
                    "src"=>$this->org->logo
                ]);
        }
        return "";
    }
}