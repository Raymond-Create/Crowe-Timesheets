<?php

namespace Core\Authentication\Library;

use Lib\ID;
use Lib\Factory as Lf;
use Lib\Session as Sess;
use Lib\Init;

class Installer
{
	
    use Init;
    
    public $update=false;
    
	public function setup()
	{
		if(!Sess::get(ID::get()))return;
		if($this->user_installed())
		{
			$this->modules([
				"Authentication","Base"
			]);
		}
	}
	
	public function user_installed()
	{
		$usr=Lf::app("User","Authentication");
		$rol=Lf::app("Role","Authentication");
		$rol->fetch([
			"where"=>[
				"name"=>"Administration"
			]
		]);
		if(!$rol->id)
		{
			$rol->name="Administration";
			$rol->priority=1;
			$rol->id=$rol->save();
		}
		$data=$usr->read();
		if(empty($data))
		{
			$usr->user_id=Sess::get(ID::get());
			$usr->role=$rol->id;
			$usr->admin=1;
			return $usr->save();
		}
		return $data[0]["id"];
	}
	
	public function modules($modules=[])
	{
	    $men=Lf::app("Menu","Authentication");
	    $doc=Lf::app("Doc","Base");
	    $doct=Lf::app("DocType","Base");
	    $cat=Lf::app("Category","Base");
	    try{
	        $men->begin();
	        $doc->tableExists();
	        $doct->tableExists();
	        $cat->tableExists();
	        $men->tableExists();
	        foreach($modules as $module)
    		{
    			$this->module($module);
    		}
    		$men->commit();
	    }catch(\Exception $ex)
	    {
	        $men->rollback();
	        x($ex,8);
	    }
	}
	
	public function module($module)
	{
		if(!Sess::get("user_selected_database"))
		{
		    return;
		}
		$org=Lf::init()->get_model("Org","Authentication");
		$md=Lf::init()->get_model("OrgModule","Authentication");
		$mdl=Lf::init()->get_model("Module","Authentication");
		$lisence=Lf::init()->get_model("License","Authentication");
		$mdl->tableExists();
		$md->tableExists();
		$lisence->tableExists();
		$org->tableExists();
		$org->fetch([
		    "where"=>[
		        "db"=>Sess::get("user_selected_database")
		    ]
		]);
		$fold=$this->module_exists($module);	
		if(!$fold){
		    return;
		}
		$file=$fold .DS. 'setup.php';
		$ver=$fold .DS. 'ver.php';
		if(file_exists($file))
		{
    		if(file_exists($ver))
    		{
    		    $vers=require $ver;
    		}
    		else{
    		    $vers="1.0.0";
    		}
    		//x($vers,8);
    		$mdl->fetch([
    		    "where"=>[
    		        "name"=>$module,
    		        "version"=>$vers
    		    ]
    		]);
    		if(!$mdl->id){
    		    $mdl->name=$module;
    		    $mdl->version=$vers;
    		    $mdl->id=$mdl->save();
    		}
    		$md->fetch([
    		    "where"=>[
    		        "org"=>$org->id,
    		        "module"=>$mdl->id
    		    ]
    		]);
    		if($md->id)
    		{
    		    $lisence->fetch([
    		        "where"=>[
    		            "org_mudule"=>$md->id,
    		            "active"=>1
    		        ]
    		    ]);
    		    if(!$lisence->id)
    		    {
    		        $lisence->org_mudule=$md->id;
    		        $lisence->active=1;
    		        $lisence->expiry=date("Y-m-d");
    		        $lisence->id=$lisence->save();
    		    }
    		    if($this->update)
    		    {
    		        $md->last_update=date("Y-m-d H:i:s");
    		        $md->save();
    		    }
    		}
    		else{
    		    $md->module=$mdl->id;
    		    $md->org=$org->id;
    		    $md->id=$md->save();
    		    $lisence->org_mudule=$md->id;
    		    $lisence->active=1;
    		    $lisence->expiry=date("Y-m-d");
    		    $lisence->id=$lisence->save();
    		}
    		
    		config("install",true);
		    require $file;
		   config("install",false);
		}
		else x($file,9);
	}
	
	private function was_installed($module):bool
	{
	    
	}
	
	private function now_installed($module):void
	{
	    
	}
	
	private function module_exists($module):string
	{
	    $core=APP .DS. 'Core' .DS. $module;
	    $mod=APP .DS. 'Modules' .DS. $module;
	    if(!is_dir($core)&&!is_dir($core)){
	        return false;
	    }
	    if(is_dir($core)){
	        return $core;
	    }
	    return $mod;
	}
}