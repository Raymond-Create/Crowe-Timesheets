<?php
namespace Core\Admin\Library;

class ModsView extends UsersView
{
    use \Lib\Init;
    
    public function form()
    {
        return false;
    }
    public
        $_title="Modules",
        $open_title="Modules",
        //$url="admin/orgs/create",
        $types="Modules",
        $type="Modules";
    
    
}