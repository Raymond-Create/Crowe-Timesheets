<?php

namespace Core\Authentication\Library;


class Controller extends \Core\Base\Library\Controller{
		
    //use \Core\Gs\Library\Index;
    
		
    public function on_init(){
        $this->check_request();
        if(isset($this->_model))
        {
            $this->model = \Lib\Factory::init()->get_model($this->_model);
        }
        $this->view->MENUS="";
        $this->view->noHeader();
        $this->view->assets=SERVER_URL ."/App/Core/Authentication/static";
        LoginLog::init()->activity();
    }
}