<?php

namespace Core\Admin\Library;

use Lib\Session as Sess;
use Lib\Factory as Lf;


class Org
{
    use \Lib\Init;

    public $org;

    public function __construct()
    {
        Lf::init()
            ->get_model("Authentication","Authentication")
            ->tableExists();
        Lf::init()
            ->get_model("Industry","Authentication")
            ->tableExists();
        $this->org=Lf::init()
            ->get_model("Org","Authentication");
        $this->org->tableExists();
        $this->org->fetch([
                "where"=>[
                        "db"=>Sess::get("user_selected_databasebase")
                ]
        ]);
    }
    public function __get($k)
    {
            return $this->org->$k;
    }
	
}