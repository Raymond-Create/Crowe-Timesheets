<?php
namespace Core\Admin\Library;

class InstallationsView extends \Core\Base\Library\AbView
{
    use \Lib\Init;
    
    public
    $_title="Organisations",
    $open_title="Org",
    $url="admin/installation/create",
    $types="Installations",
    $type="Installation";
    //$script="dd-menu";
    
    public function form()
    {
    		return (new Installation())->html();
    }
    
    public function other_buttons()
    {
    		$this->div->add(div("dropdown")
    			->add(button("btn btn-light dropdown-toggle btn-sm float-right mr-2")
    				->attr([
    					"type"=>"button",
    					"id"=>"dropdownMenuButton",
    					"data-toggle"=>"dropdown",
    					"aria-haspopup"=>"true",
    					"aria-expanded"=>"false"
    				])
    				->add("Go To")
    			)
    			->add(div("dropdown-menu")
    				->attr(
    					"aria-labelledby","dropdownMenuButton"
    				)
    				->add(a("dropdown-item active")
    					->attr([
    						"href"=>"#",
    						"data-value"=>"admin/orgs"
    					])
    					->add("Organisations")
    				)
    				->add(a("dropdown-item")
    					->attr([
    						"href"=>"#",
    						"data-value"=>"admin/useracces"
    					])
    					->add("User Access")
    				)
    			)
    			
    			
    		);
    }
    /*
    	<div class="dropdown">
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Dropdown button
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" href="#">Action</a>
    <a class="dropdown-item" href="#">Another action</a>
    <a class="dropdown-item" href="#">Something else here</a>
  </div>
</div>
    */
}