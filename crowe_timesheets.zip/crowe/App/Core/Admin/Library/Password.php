<?php

namespace Core\Admin\Library;

use Lib\Factory as Lf;

class Password{
    
    public $userId,$_m=["Authentication","Authentication"];
    
    public function __construct($user){
        $this->userId=$user;
    }
    
    public function save($post)
    {
        $mod=\Lib\Factory::init()->get_model($this->_m);
        $mod->fetch([
            "where"=>[
                "id"=>$this->userId
            ]
        ]);
        $mod->password=$post["password"];
        return $mod->save();
    }
    
    public function html()
    {
        return div("card")
            ->attr("data-x-mod","pass")
            ->add(div("card-header")
                ->add(h3()->add("Password Updater"))
            )
            ->add(div("card-body")
                ->add(div(ROW)
                    ->add(div(C121212)
                        ->add(label(LB)->add("Add new password"))
                        ->add(input(NPS)
                            ->attr([
                                "name"=>"password","data-pattern"=>"/.{6,}/"
                            ])
                        )
                        ->add(input()
                            ->attr([
                                "name"=>"user","value"=>$this->userId,
                                "type"=>"hidden"
                            ])
                        )
                    )     
                )
            )->add(div("card-footer")
                ->add(div(ROW)
                    ->add(div(C121212)
                        ->add(button(BNPS . " btn-block btn-save")
                            ->add("UPDATE")
                        )
                    )
                )
            );
    }

}