<?php
namespace Core\Admin\Library;

class OrgsView extends UsersView
{
    use \Lib\Init;
    
    public function form()
    {
        return new Orgn();
    }
    public
    $_title="Organisations",
    $open_title="Org",
    $url="admin/orgs/create",
    $types="Organisations",
    $type="Organisation";
    
    
}