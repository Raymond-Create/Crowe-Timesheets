CORE.add("user-password",x=>{
    let btnList=e=>{
        x.stop(e);
        let tr = x.me(e);
        if(tr.name() != "TR")
            tr = tr.lookup("TR");
        //trFocus(tr);
        x.notify({type:"focus",data:tr},"data-grid-module");
        let id = tr.select('input[name="_key_"]').use().val();
        x.notify({type:"fetch",data:{url:"admin/users/password/"+id}},"url-loader");
        x.notify({type:"open",data:"url_loader"},"shared-view");
    };
    let start=()=>{
        x.find(".btn-pass").each(o=>{
            x.use(o).bind().click(btnList);
        });
    };
    let stop=()=>{
        x.find(".btn-pass").each(o=>{
            x.use(o).unbind().click(btnList);
        });
    };
    return{
        init:()=>{
            start();
            x.listen({start:start});
        },
        dump:()=>{
            x.ignore(["start"]);
            stop();
        }
    };
});