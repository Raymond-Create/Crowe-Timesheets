CORE.add("module-inst",x=>{
    let org,mod,btn,rows,pages;
    
    let ch=e=>{
        x.stop(e);
        var link=constants.link("admin/admin/modules/"+rows.val()+"/"+pages.val());
        constants.query(link);        
    };
    let process=o=>{
        var len=Object.keys(o.message).length;
        var link=constants.link("admin/admin/modules/");
        if(o.status&&len)
            constants.query(link);
    };
    let btnList=e=>{
        x.stop(e);
       if(org.val()&&mod.val())
       {
            X("admin/installations/install/"+org.val()+"/"+mod.val(),o=>{
                process(o);
            });
       }
             
    };
    let trList=(tr,detach)=>{
        var del=tr.select(".btn-delete").use();
        var rel=tr.select(".btn-reload").use();
        var lineBtn=e=>{
            x.stop(e);
            var val=x.me(e).vl();
            var org=x.me(e).data("org");
            var mod=x.me(e).data("module");
            var isDel=x.me(e).hasClass("btn-delete");
            X("admin/installations/install/"+org+"/"+mod+"/"+isDel,o=>{
                process(o);
            },{id:val});
        };
        if(detach){
            rel.unbind().click(lineBtn);
            del.unbind().click(lineBtn);
        }else{
            rel.bind().click(lineBtn);
            del.bind().click(lineBtn);
        }
    };
    let start=()=>{
            org=x.named("organisation");
            mod=x.named("module");
            btn=x.pick(".btn-save");
            rows=x.named("showing");
            pages=x.named("pages");
            x.pick("tbody").select("tr").each(tr=>{
                trList(x.use(tr));
            });
            btn.bind().click(btnList);
            rows.bind().change(ch);
            pages.bind().change(ch);
            
    };
    let stop=()=>{
            x.pick("tbody").select("tr").each(tr=>{
                trList(x.use(tr),true);
            });
            rows.unbind().change(ch);
            pages.unbind().change(ch);
            btn.unbind().click(btnList);
            org=null;
            mod=null;
            btn=null;
    };
    return{
            init:start,dump:stop
    };
});