/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/javascript.js to edit this template
 */
CORE.add("module-installer",x=>{
    let organisation,container;
    let redraw=()=>{
        var url="admin/installations/tab/";
        if(organisation.val())
            url+=organisation.val()
        else
            url+="0";
        X(url,o=>{
            if(o.status)
                contentRedraw(x,o.message);
        });
    };
    let organisationChList=e=>{
        redraw();
    };
    let adList=e=>{
        x.stop(e);
        var m=x.me(e);
        List(m.vl(),0);
    };
    let List=(module,unistall)=>{
        var msg=unistall?"Choose Organisation for uninstallation":"Choose Organisation for installation",
        org=organisation.val();
        if(org)
            X("admin/installations/install/"+org+"/"+module+"/"+unistall,o=>{
                if(o.status)
                    redraw();
            });
        else x.notify({type:"error",data:msg},"notify");
    };
    let delList=e=>{
        x.stop(e);
        var m=x.me(e);
        List(m.vl(),100);
    };
    let start=()=>{
        organisation=x.named("organisation");
        container=x.pick(".table-responsive");
        organisation.bind().change(organisationChList);
        x.find(".b-et").each(a=>{
            x.use(a).bind().click(adList);
        });
        x.find(".b-dt").each(a=>{
            x.use(a).bind().click(delList);
        });
        x.find(".b-ad").each(a=>{
            x.use(a).bind().click(adList);
        });
    };
    let stop=()=>{
        x.find(".b-et").each(a=>{
            x.use(a).unbind().click(adList);
        });
        x.find(".b-dt").each(a=>{
            x.use(a).unbind().click(delList);
        });
        x.find(".b-ad").each(a=>{
            x.use(a).unbind().click(adList);
        });
        organisation.unbind().change(organisationChList);
        organisation=null;
        container=null;
    };
    return{init:start,dump:stop};
});

