CORE.add("pass",x=>{
    let btn,pass,user;
    let btnList=e=>{
        x.stop(e);
        var data={};
        if(!constants.test(pass))return;
        X("admin/users/password/"+user.val(),o=>{
            constants.shout(o);
        },{password:md5(pass.val())});
    };
    return{
        init:()=>{
           user=x.named("user");
           btn=x.pick(".btn-save");
           pass=x.named("password");
           btn.bind().click(btnList);
        },
        dump:()=>{
           btn.unbind().click(btnList);
           user=null;
           pass=null;
           btn=null;
        }
    };
});