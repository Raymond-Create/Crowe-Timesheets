CORE.add("logo-uploader",x=>{
    let submit,file,preview,org,imgBase64;
    let	submitList=e=>{
        x.stop(e);
        let img = imgBase64.split(",");//console.log(img.length);
        X("admin/orgs/logo/"+org.val(),ss=>{
            try{
                cons.shout(ss); 

            }catch(e){
                alert(ss);alert(e);
            }
        },{avatar:imgBase64,prefix:img[0]})
        /*jX({
            url:constants.link(url),
            form_data:{avatar:imgBase64,prefix:img[0]},
            success:ss=>{
                try{
                    cons.shout(ss); 

                }catch(e){
                    alert(ss);alert(e);
                }
            }
        }).send();
         * 
         */
    };
    let fileChList= e =>{
        if(file.n.files[0]){
            let r = new FileReader();
                r.onload=()=>{
                    imgBase64 = r.result;
                    drawImage(imgBase64);
                    //submit.show();
                };
                r.readAsDataURL(file.n.files[0]);
        }
    };
    drawImage=dUrl=>{
        preview.empty().append(tag("img",{src:dUrl}).element());
    };
    init=()=>{
        submit.bind().click(submitList);
        file.bind().change(fileChList);
    },
    destroy=()=>{
        submit.bind()._click(submitList);
        file.bind()._change(fileChList);
    };
    return{
        init:()=>{
            submit=x.pick(".submit");
            preview=x.pick(".preview");
            file=x.pick('[type="file"]');
            org=x.named("org");
            //console.log([submit,file,preview,url,imgBase64]);
            init();
        },
        dump:()=>{
            destroy();
            url=null;
            file=null;
            submit=null;
            preview=null;
        }
    };
});