<?php

return [
	'path'=>'Admin',
	'version'=>'1.0',
	'publication'=>'2022-03-29',
	'restriction'=>'Open',
	'notes'=>'Module is strickly for developer level administrators',
	'icon'=>"fa fa-lock",
	'name'=>'Admin',
	'flag'=>1
 ];