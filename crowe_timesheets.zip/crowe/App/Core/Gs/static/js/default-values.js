/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
CORE.add('default-values',x=>{
    let currBtn,locBtn,location,currency;
    let changeList=e=>{
        var name=x.me(e).attr('name');
        var val=x.me(e).val();
        if(val=="")return;
        jX({
            url:cons.link('gs/landing/kv/'+name+'/set'),
            form_data:{value:val},
            success:c=>{
                cons.shout(c);
            }
        }).send();
    };
    let btnList=e=>{
        x.stop(e);
        var btn=x.tag_look(e,'button');
        var url=cons.link(btn.vl());
        var key=btn.data('key');
        x.notify({
            type:"launch",
            data:{
                mode:"url",
                data:url,
                modal:"dfmdb"
            }
        },"popup");
        x.notify({
            type:"flash-callback",
            data:o=>{
                jX({
                    url:cons.link('gs/landing/kv/'+key+'/set'),
                    form_data:{value:o.status},
                    success:c=>{
                        if(c.status){
                            x.notify({type:'close',data:"dfmdb"},"popup");
                            cons.query(cons.link('gs/landing/settings/DefaultValues'));
                        }
                        cons.shout(c);
                    }
                }).send();
            }
        },"vertical-model-form");
    };
    let currencyChList=e=>{
        
    };
    let locationChList=e=>{
        
    };
    let build=()=>{
        
        if(locBtn)
            locBtn.bind().click(btnList);     
        if(currBtn)
            currBtn.bind().click(btnList);       
        if(location)
            location.bind().change(changeList);
        if(currency)
            currency.bind().change(changeList);
    };
    let destroy=()=>{
         if(locBtn)
            locBtn.bind()._click(btnList);     
        if(currBtn)
            currBtn.bind()._click(btnList);       
        if(location)
            location.bind()._change(changeList);
        if(currency)
            currency.bind()._change(changeList);
    };
    return{
        init:()=>{ 
            location=x.pick('[name="defaultLocation"]');
            currency=x.pick('[name="defaultBaseCurrency"]');
            currBtn=x.pick('.btn-currency');
            locBtn=x.pick('.btn-location');
            build();
        },
        dump:()=>{
            destroy();
            locBtn=null;
            currBtn=null;
            location=null;
            currency=null; 
        }
    };
});

