CORE.add('data-display',x=>{
	let expand;
	let btnList=e=>{
		x.stop(e);
		var me=x.me(e);
		if(!me.hasClass('left-link'))
			me=me.lookup({'class':'left-link'});
		cons.query(cons.link(me.data('href')));
	};
	let btn=detach=>{
		x.find('.left-link').each(b=>{
			if(detach)
				x.use(b).bind()._click(btnList);
			else
				x.use(b).bind().click(btnList);
		});
	};
	let build=()=>{
		btn();
	};
	let destroy=()=>{
		btn(true);
	};
	return{
		init:()=>{
			expand=x.pick('.expand');
			console.log(expand);
			build();
		},
		dump:()=>{
			destroy();
		}
	};
});