class Uploader{
  
    constructor(rawinput,container,sb){
        sb.pick('.progress-bar').attr("style","display:none");
	this.container=container;
        this.input=rawinput;
        this.form=null;
        this.sb=sb;
    } 
    read() {
        var that=this;
        var x=this.sb;
        var input=this.input;
        var fsize=this.input.files[0].size;
        var fname=this.input.files[0].name;
        var ftype=this.input.files[0].type;
        var fielArray=["image/png", "image/jpeg", "image/gif", "image/jpg"];
        var fileTrue = fielArray.indexOf(ftype);
        var set_form=data=>{
            this.form=data;
        };
        if(fileTrue>=0){
            var reader=new FileReader();
            reader.element=x.pick(".thumb");
            reader.onload=function(e) {
                var div =x.pick(".thumb");
                div.inner("<img class='thumb' src='" + e.target.result + "'" +
                "title='" + fname + "'/>");
                var formData = new FormData();
                for (var i = 0;i<input.files.length; i++) {
                    var fileup=input.files[i];
                    // Check the file type.
                    if (!fileup.type.match('image.*')) 
                            continue;
                    // Add the file to the request.
                    formData.append('filename[]', fileup, fileup.name);                   
                }
                //that.uploadajax(formData,url);
                set_form(formData);
            };
            reader.onerror=function(e) {
                alert("error: " + e.target.error.code);
            };
            reader.readAsDataURL(input.files[0]);
        }else{
            x.pick(".error").inner("Incorrect file format, Please select an image file format..");
        }
    }


    uploadajax(url){
        var xhr = new XMLHttpRequest();
        var imageprogress=event=>{
            var x=this.sb;
            x.pick('.complete').attr("style","display:none");
            var bar=x.pick('.progress-bar');
            bar.attr("style","display:block");
            var percent = (event.loaded / event.total) * 100;
            bar.attr("style","width:"+Math.round(percent)+"%");
		//document.getElementById("status").value = Math.round(percent);
		//$("#progressbar").progressbar({value: document.getElementById("status").value});
		//document.getElementById("status").innerHTML = Math.round(percent)+"%";
	};
        xhr.open('POST', url, true);
        xhr.onload = function () {
            if (xhr.status === 200) {
                constants.shout(fS(xhr.responseText));
            } else {
                alert('An error occurred!');
            }
        };
        xhr.upload.addEventListener("progress",imageprogress, false);
        //xhr.addEventListener("load", Completed, false);
        //xhr.addEventListener("error", failstatus, false);
        //xhr.addEventListener("abort", Abortedstatus, false);
        xhr.send(this.form);
    }
	
}

/*


<div id="fupload">
 <h2>Ajax Image upload</h2>
<form action="upload.php" method="post" enctype="multipart/form-data" name="fileupload" id="fileupload">
<input onchange="fileread(this)" name="filename[]" id="filename" type="file" multiple />
<input type="submit" id="submit" value="Upload" />
</form>
<div id="progress_status">
<div id="progressbar" class='progress'></div><div id="status"></div></div>
<div id="complete"></div>
<div id="thumb"></div>
<div id="error"></div>
</div>



if(isset($_FILES['filename']))
{
 $Dest = dirname(__FILE__).'/upload/';
 if(!isset($_FILES['filename']) || !is_uploaded_file($_FILES['filename']['tmp_name'][0]))
 {
 die('Something went wrong with Upload!');
 }
 $RandomNum = rand(0, 9999999999);

 $ImageName = str_replace(' ','-',strtolower($_FILES['filename']['name'][0]));
 $ImageType = $_FILES['filename']['type'][0]; //"image/png", image/jpeg etc.

 $ImageExt = substr($ImageName, strrpos($ImageName, '.'));
 $ImageExt = str_replace('.','',$ImageExt);

 $ImageName = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);

 //Create new image name (with random number added).
 $NewName = $ImageName.'-'.$RandomNum.'.'.$ImageExt;

 move_uploaded_file($_FILES['filename']['tmp_name'][0], "$Dest/$NewName");

 $base_path="http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);
 $base=$base_path.'/'.'upload/'.$NewName;
 //echo '<img src="'.$base.'">';
 echo "<div id='sucess' class='sucess' > Successfully uploaded.</div>";
 }

*/