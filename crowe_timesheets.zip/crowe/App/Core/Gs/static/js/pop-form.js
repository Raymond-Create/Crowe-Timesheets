CORE.add("pop-form",x=>{
	
    let redraw=()=>{
        X(url + "/pop/"+record+"/table",o2=>{
            if(o2.status){
                destroy();
                var table=tag(o2.message[0],o2.message[1]).element();
                x.pick('table').hide().before(table).remove();
                build();
            }
        });
    };
	
    let url,record,submitList=e=>{
        x.stop(e);
        var data={},bool=true;
        x.me(e).lookup("TR").select('[data-type="input"]').each(put=>{
            if(!bool)return;
            if(!constants.test(x.use(put))){
                bool=false;
                return;
            }
            data[x.use(put).attr('name')]=x.use(put).val();
        });
        if(!bool)return;
        //console.log(data);
        X(url + "/put",o=>{
            if(o.status)
                redraw();
            constants.shout(o);
        },data);
    };
    let delList=e=>{
        x.stop(e);
        var id=x.me(e).lookup("TD").select("input").use();
        X(url + "/remove",o=>{
            if(o.status)
                x.me(e).lookup("TR").remove();
            constants.shout(o);
        },{id:id.val(),type:"delete"});
    };
    
    let btnList=e=>{
        x.stop(e);
        var btn=x.me(e);
        if(btn.attr('name')!='BUTTON')
            btn=btn.lookup('BUTTON');
        var id=btn.lookup("TD").select("input").use();
        X(url + "/"+btn.data('action')+"/"+id,o=>{
            if(o.status)
                redraw();
            constants.shout(o);
        });
    };
    let build_notice=()=>{
        var u=x.pick('[data-x-mod]');
        if(u&&u.data('x-mod'))
            x.notify({type:"rebuild",data:null},u.data('x-mod'));
    };
    let build=()=>{
        record=x.pick('tbody').data("record");
        url=x.pick('tbody').data("link-url");
        var submit=x.pick(".btn-submit");
        var del=x.find(".btn-delete");
        var btn=x.find(".btn-extra");
        if(submit)
            submit.bind().click(submitList);
        if(btn)
            btn.bind()._click(btnList);
        del.each(o=>{
            x.use(o).bind().click(delList);
        });
        build_notice();
    };
    let destroy=()=>{
        url=null;
        record=null;
        var submit=x.pick(".btn-submit");
        var del=x.find(".btn-delete");	
        var btn=x.find(".btn-extra");
        if(submit)
            submit.bind()._click(submitList);
        if(btn)
            btn.bind()._click(btnList);
        del.each(o=>{
            x.use(o).bind()._click(delList);
        });
    };
    return{
        init:()=>{
            build();
            var dp=x.pick('.d-p');
            if(dp)
                $(dp.n).datetimepicker();
        },
        dump:()=>{
            destroy();
        }
    };
});

