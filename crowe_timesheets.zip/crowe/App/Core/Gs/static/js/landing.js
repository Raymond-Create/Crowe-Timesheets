CORE.add('landing',x=>{
	let row,access,j=0;
	let block=(icon,name,url,num)=>{
		num=num||i(".fas fa-link");
		var d1=div(".info-box"),
		d2= div(".info-box-content").attr("data-url",url);
		d1.add(span(".info-box-icon bg-info elevation-1 l-k")
			.attr({
				"data-value":url,
				'style':'color:#fff'
			})
			.add(i('.'+icon))
		);
		d2.add(span(".info-box-text")
				.add(h5().add(name))
		)
		.add(span(".info-box-number")
			.add(num)
			.add(input({
					'type':'hidden',
					'value':url
				})
			)
		);
		return d1.attr('id','info-box-'+(j++)).add(d2);
	};
	let btnList=e=>{
		x.stop(e);
		var m=x.me(e);
		if(!m.hasClass('info-box'))
			m=m.lookup({'class':'info-box'});
		var url=m.select('input[type="hidden"]').use().val();
		AppCom.init().show(x,url);
	};
	let build=()=>{
		x.find('.info-box').foreach(b=>{
			x.click(x.use(b),btnList);
		});
	};
	let populate=()=>{
		if(!access||!access.token)
			return alert('Fatal Error anticipated, system took neccessary steps to avoid catastrophy contact support on admin@huchi.co.zw');
		var xhr=jX({url:cons.link('api/links/index')});
		xhr.header('X-Token',access.token);
		xhr.success((a0)=>{
			try{//console.log(a0);
				each(a0.message,o=>{
					var col=div('.col-xs-6 col-md-3');
					col.add(block(o.icon,o.title,o.link));
					row.append(col.element());
				});
				build();
			}catch(e){
				alert(e);
				alert(e.stack);
			}
		});
		xhr.failure(a0=>{
			console.log('failed');
			console.log(a0);
		});
		xhr.send();
	};
	let destroy=()=>{
		x.find('.info-box').foreach(b=>{
			x.detach(x.use(b),'click',btnList);
		});
	};
	return{
		init:function(){
			row=x.pick('.row-links');
			access=LStorage.access();
			populate();
		},
		dump:function(){
			destroy();
			access=null;
			row=null;
		}
	};
});
Views.html('landing',()=>{
	return div(".container mt-5?landing")
		.add(div('.row row-links'))
		.html();
});