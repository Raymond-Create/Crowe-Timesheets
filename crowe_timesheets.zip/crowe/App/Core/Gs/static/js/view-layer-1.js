CORE.add("view-layer-1",x=>{
	let ls,fm,lsBtn,fmBtn,add;
	let addList=e=>{
		var o=fm.select('[data-x-mod]').use().data("x-mod");
		x.notify({type:"load2",data:"0/edit"},o);
		collapse();
	};
	let l=e=>{
		x.stop(e);
		var b=x.tag_look(e,"BUTTON");
		if(b.data("set")=="collapse"){
			b.select("i").use().removeClass("fa-caret-up").addClass("fa-caret-down");
			b.data("set","expand");
			ls.hide();
		}else{
			b.select("i").use().addClass("fa-caret-up").removeClass("fa-caret-down");
			b.data("set","collapse");
			ls.show();
		}
	};
	let f=e=>{
		x.stop(e);
		var b=x.tag_look(e,"BUTTON");
		if(b.data("set")=="collapse"){
			b.select("i").use().removeClass("fa-caret-up").addClass("fa-caret-down");
			b.data("set","expand");
			fm.hide();
		}else{
			b.select("i").use().addClass("fa-caret-up").removeClass("fa-caret-down");
			b.data("set","collapse");
			fm.show();
		}
	};
	let collapse=(form)=>{
		if(form)
		{
			ls.show();
			fm.hide();
		}else{
			ls.hide();
			fm.show();
		}
	};
	let build=()=>{
		lsBtn.bind().click(l);
		fmBtn.bind().click(f);
		if(add)
			add.bind().click(addList);
		collapse(true);	
	};
	let destroy=()=>{
		
		lsBtn.unbind().click(l);
		fmBtn.unbind().click(f);
		if(add)
			add.unbind().click(addList);
	};
	return{
		init:()=>{
			add=x.pick(".btn-add");
			ls=x.pick(".list-body");
			fm=x.pick(".form-body");
			lsBtn=ls.lookup({"class":"card"}).select(".btn-toggle").use();
			fmBtn=fm.lookup({"class":"card"}).select(".btn-toggle").use();
			x.listen({collapse:collapse});
			build();
		},
		dump:()=>{
			destroy();
			x.ignore(["collapse"]);
			ls=null;fm=null;lsBtn=null;fmBtn=null;add=null;
		}
	}
	
});