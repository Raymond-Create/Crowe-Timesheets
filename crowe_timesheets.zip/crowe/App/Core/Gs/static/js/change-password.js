CORE.add("change-password",x=>{
    let submit,pass_old,pass_new,match;
    let	submitList=e=>{
        x.stop(e);
        let data = {};
        if(!constants.test(pass_old))return;
        data.current = md5(pass_old.val());
        if(!constants.test(pass_new))return;
        if(!constants.test(match))return;
        if(pass_new.val() != match.val()){
            return x.notify({type:"error",data:"Passwords dont match"},"notify");
        }
        data.password = md5(match.val());
        X("gs/users/password",o=>{constants.shout(o);},data);
    },
    build=()=>{
        submit.bind().click(submitList);
        setTimeout(()=>{
            pass_old.n.value="";
        },100);
        
    },
    destroy=()=>{
        submit.bind()._click(submitList);
    };
    return{
        init:()=>{
            submit=x.pick(".submit");
            match=x.pick('[name="confirm"]');
            pass_old=x.pick('[name="old"]');
            pass_new=x.pick('[name="new"]');
            build();
        },
        dump:()=>{
            destroy();
            match=null;
            submit=null;
            pass_new=null;
            pass_old=null;
        }
    };
});