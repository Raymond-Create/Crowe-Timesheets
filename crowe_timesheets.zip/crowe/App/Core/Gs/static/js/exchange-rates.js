/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


CORE.add('exchange-rates',x=>{
    let i=0;
    let rateKuList=e=>{
        var rate=x.me(e);
        var currency=x.me(e).lookup({'class':'form-group'}).select('[name="currency"]').use();
        var base=x.me(e).lookup({'class':'form-group'}).select('[name="base"]').use();
        var date=x.me(e).lookup({'class':'form-group'}).select('[name="date"]').use();
        if(base.val()==currency.val())
            rate.val(1);
        if(date.val()=="")
            console.log('add date');
    };
    let dateChange=(date)=>{
        console.log(date.val());
    };
    let build=()=>{
        x.find('[name="rate"]').each(as=>{
            x.use(as).bind().keyup(rateKuList);
        });
        x.find('[name="date"]').each(as=>{
            x.use(as).bind().change(dateChange);
            x.use(as).bind().input(dateChange);
           
            /*
            var g=x.use(as);
            var timer = setInterval(()=>{
                
                var k=g.data('change-value');
                var l=g.val();
                if(k===false){
                    g.data('change-value',l); 
                    return;
                }
                
                if(k!=l){alert('diff detectec')
                    g.data('change-value',l);
                    dateChange(g);
                }
            },50);
            g.data('value-change',timer);
            */
        });
    };
    let destroy=()=>{
        x.find('[name="rate"]').each(as=>{
            x.use(as).bind()._keyup(rateKuList);
        });
        x.find('[name="date"]').each(as=>{
            //clearInterval(x.use(as).data('value-change'));
        });
    };
    return{
        init:()=>{
            build();
        },
        dump:()=>{
            destroy();
        }
    };
});