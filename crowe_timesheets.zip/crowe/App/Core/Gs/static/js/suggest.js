
class Suggest{
	
    constructor(div,sb){
        this.sb=sb;
        this.input_group=div;
        this.toggle=div.select(".input-group-text").use();
        this.select=div.select("select").use();
        this.chooser();
        this.menu=div.select(".dropdown-menu").use();
        this.a=div.select(".dropdown-toggle").use();
        this.drop=div.select(".dropdown").use();
        this.input=div.select("input").use();
        this.pop_data();
        this.add_data(this.data);
    }
	
    chooser(){
        var inp=this.input_group.select('input').use();
        if(!inp){
            inp = input('.form-control@'+this.select.attr('name'));
            if(!!this.select.val())
                inp.attr('value',this.select.selected().inner());
            else
                inp.attr('placeholder',this.select.selected().inner());
            var d=div(".dropdown form-control")
                .attr("style","width:100%!important")
                .attr("style","display:none")
                .add(inp)
                .add(div(".dropdown-menu")
                    .attr("style","width:100%!important;max-height:400px;overflow-y:scroll")
                );
            this.select.before(d.element());
        }
    }
    
    pop_data(){
        var m=list();
        this.select.select('option').each(opt=>{
            var v=pK(opt);
            if(v.val()=="")return;
                m.push({value:v.val(),text:v.inner()});
        });
        this.data=m.raw();
    }
    
    add_data(data){
        var n;
        this.select.select('option').each(opt=>{
            var v=pK(opt);
            if(v.val()=="")
                n={value:v.val(),text:v.inner()};
        });
        this.select.empty();
        this.select.append(option(n).element());
        list(data).each(da=>{this.select.append(option(da).element());});
        this.pop_menu(data);
    }
    
    pop_menu(data){
        this.menu_list(true);
        this.menu.empty();
        this.menu.addClass('hide');
        list(data).each(da=>{
            this.menu.append(li('.dropdpown-item itm')
                .attr('data-value',da.value)  
                .add(span('.ml-3').add(da.text))
                .element()
            );
        });
        this.menu.append(li('.dropdown-divider').element());
        this.menu.append(li('.dropdpown-item')
            .add(span('.btn-plus ml-3 danger')
                .add(i('.fa fa-plus-circle'))
                .add(' Create New')
            )
            .element()
        );
        this.menu_list();
    }
    
    menu_list(detach){
        var liList=e=>{
            var l=this.sb.me(e);
            if(l.name()!="LI")
                l=l.lookup("LI");
            console.log(l.vl());
        };
        var liMovList=e=>{
            this.sb.me(e).attr('style','color:blue');
        };
        var liMotList=e=>{
            this.sb.me(e).attr('style','color:black');
        };
        var newList=e=>{
            this.sb.stop(e);
            var url=constants.link('gs/landing/model_form/'+this.select.data('model'));
            console.log(url);
        };
        this.menu.select('li').each(o=>{
            var oo=this.sb.use(o);
            if(oo.hasClass('itm'))
            {
                if(detach){
                    oo.bind()._click(liList); 
                    oo.bind()._mouseout(liMotList); 
                    oo.bind()._mouseover(liMovList);
                }
                else
                {
                    oo.bind().click(liList); 
                    oo.bind().mouseout(liMotList); 
                    oo.bind().mouseover(liMovList);
                }
            }
        });
        var c=this.menu.select('.danger').use();
        if(c){
            if(detach)
                c.bind()._click(newList);
            else
                c.bind().click(newList);
        }
    }
    
    setup(detach){
        let swap=e=>{
            var tg=this.sb.me(e);
            if(!tg.hasClass('input-group-text'))
                tg.lookup({'class':'input-group-text'});
            if(tg.hasClass('hide'))
            {
                this.drop.show();
                this.select.hide();
                tg.removeClass('hide');
            }
            else
            {
                this.drop.hide();
                this.select.show();
                tg.addClass('hide');
            }
        };
        let inputKuList=e=>{
            this.menu.show();
        };
        if(detach)
        {
            this.toggle.bind()._click(swap);
            this.input.bind()._keyup(inputKuList);
        }
        else
        {
            this.toggle.bind().click(swap);
            this.input.bind().keyup(inputKuList);
        }
        
    }
    
    fixSelect(){
        if(this.select.vl())
            this.select.selectOn(this.select.vl());
    }
}