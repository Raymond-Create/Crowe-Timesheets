/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


CORE.add('setting-manager',x=>{
    let aList=e=>{
        var val=x.me(e).vl();
        constants.query(constants.link('gs/landing/settings/'+val))
    };
    let build=()=>{
        x.find('.set').each(as=>{
            x.use(as).bind().click(aList);
        });
    };
    let destroy=()=>{
        x.find('.set').each(as=>{
            x.use(as).bind()._click(aList);
        });
    };
    return{
        init:()=>{
            build();
        },
        dump:()=>{
            destroy();
        }
    };
});