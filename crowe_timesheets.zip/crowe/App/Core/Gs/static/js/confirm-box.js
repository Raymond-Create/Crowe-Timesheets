CORE.add("confirm-box",x=>{
	let url,confirm,cancel;
	let confirmList=e=>{
		x.stop(e);
        console.log(typeof(url));
		return console.log(url);
		if(iF(url)){
		  url();
          cancel.click();
		}
	};
    let callback=a=>{
		console.log(a);
        if(iF(a)){
		  url=a;
		}
    };
	let cancelList=e=>{
		x.stop(e);
        var mod=x.me(e).lookup({"class":"modal"});
		if(mod)
            mod.select(".close").use().click();
	};
	let build=()=>{
		url=x.pick('[name="url"]');
		cancel=x.pick('.btn-cancel');
		confirm=x.pick('.btn-confirm');
		cancel.unbind().click(cancelList);
		cancel.bind().click(cancelList);
		confirm.unbind().click(confirmList);
		confirm.bind().click(confirmList);
	};
	let destroy=()=>{
		confirm.unbind().click(confirmList);
		cancel.unbind().click(cancelList);
		confirm=null;
		cancel=null;
		url=null;
	};
	return{
		init:()=>{
			build();
			x.listen({callback:callback});
		},
		dump:()=>{
            x.ignore(['callback']);
			destroy();
		}
	};
});