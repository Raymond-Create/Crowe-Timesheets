CORE.add('pos',x=>{
	let type;
	return{
		init:()=>{
			
		},
		dump:()=>{
			type=null
		}
	}
})
Views.html('pos',()=>{
	var d=div('.row?pos');
	var col1=div('.')
	return d.html()
});