CORE.add('signup-form',x=>{
	var code,name,surname,email,password,confirm,
	company,value,get_code,access,img,submit;
	let build=()=>{
		alert([
		 code,name,surname,email,password,confirm,
	company,value,get_code,access
		]);
		
	};
	return{
		init:()=>{
			img=x.pick('img');
			submit=x.pick('.submit');
			code=x.pick('[name="code"]');
			name=x.pick('[name="name"]');
			get_code=x.pick('.get-code');
			email=x.pick('[name="email"]');
			value=x.pick('[name="value"]');
			access=x.pick('[name="access"]');
			confirm=x.pick('[name="confirm"]');
			surname=x.pick('[name="surname"]');
			password=x.pick('[name="password"]');
			build();
		},
		dump:()=>{
			
		}
	}
});