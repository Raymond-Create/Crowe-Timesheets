CORE.add("configs",x=>{
    let btnList=e=>{
        x.stop(e);
        var b=x.tag_look(e,"A");
        var c=b.vl().split(",").join("/");;
        var d=constants.link("gs/config/show/"+c);
        constants.query(d);
    };
    let attach=detach=>{
        x.find(".btn-app").each(b=>{
            var aa=x.use(b);
            if(detach)
                aa.unbind().click(btnList);
            else
                aa.bind().click(btnList);
        });
    };
    return{
        init:()=>{
            attach();
        },
        dump:()=>{
            attach(true);
        }
    };
});