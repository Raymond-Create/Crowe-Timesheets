/*** static/js/modules/accounts/my-table.js  ***/
CORE.add('confirm',x=>{
    let html = `
        <div class="row">
            <div class="col-xs-12 col-lg-12">
                <p>Are you sure you want to delete this record? 
                Press Ok to delete.
                Press Cancel to abandon deletion</p>
            </div>
        </div>
    `;
    let deleteDialogue=mod=>{
        x.notify({type:"launch",data:
            {
                data:html,
                mode:"html",
                modal:"dgsm",
                custom:modal=>{
                    let cancelBtn = modal.select(".cancel").use();
                    let okBtn = modal.select(".ok").use();
                    let okBtnList=e=>{
                        x.stop(e);
                        if(isFn(mod.callback))
                            mod.callback();
                        cancelBtn.click();
						x.me(e).bind()._click(okBtnList);
                    };
                    x.click(okBtn,okBtnList);
                }
            }
        },"popup");
    };
    return{
        init:()=>{
            x.listen({del:deleteDialogue});
        },
        dump:()=>{
            x.ignore(["del"])
        }
    };
});