CORE.add("setting-form",x=>{
    let inputs=detach=>{
        x.find("input").each(o=>{
            if(!detach) 
               x.use(o).bind().blur(inputList);
            else
               x.use(o).bind()._blur(inputList); 
        });
        x.find("select").each(o=>{
            if(!detach) 
               x.use(o).bind().change(selectList);
            else
               x.use(o).bind()._change(selectList); 
        });
        x.find("button").each(o=>{
            if(!detach) 
               x.use(o).bind().click(buttonList);
            else
               x.use(o).bind()._click(buttonList); 
        });
        x.find(".st-mn").each(o=>{
            if(!detach) 
               x.use(o).bind().click(re);
            else
               x.use(o).unbind().click(re); 
        });
    };
    let buttonList=e=>{
        var url=x.tag_look(e,"BUTTON").data('link');
        constants.query(constants.link(url));
    };
    let re=e=>{
        x.stop(e);
        constants.query(constants.link("gs/config/index/"));
    };
    let selectList=e=>{
        updateVal(e);
    };
    let inputList=e=>{
        updateVal(e);
    };
    let updateVal=e=>{
        var id=x.me(e).vl();
        var val=x.me(e).val();
        var url="gs/config/put";
        var name=x.me(e).attr("name");
        var data={
            name:name,
            value:val
        };
        if(nM(id))
            url+="/"+id;
        X(url,o=>{
            if(o.status)
            {
                x.me(e).addClass("is-valid").removeClass("is-invalid");
                if(!nM(id))
                  x.me(e).vl(o.status);
            }
            else
                x.me(e).addClass("is-invalid").removeClass("is-valid");
        },data);
    };
    return{
        init:()=>{
            inputs();
        },
        dump:()=>{
            inputs(true);
        }
    };
});