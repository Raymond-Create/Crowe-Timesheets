/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
CORE.add("role-menu",x=>{
    let role,component,menus;
    let change=e=>{
        reload(); 
    };
    let reload=()=>{
    		detach();
    		menus.empty();
    		if(role.val()==""||component.val()=="")return;
       X("gs/rolelinks/menus/"+component.val()+"/"+role.val(),o=>{
           if(o.status){
                var u=o.message[0];
                var v=o.message[1];
                menus.append(tag(u,v).element());
                attach();
           }
       });
    };
    let btnList=e=>{
        x.stop(e);
        var td=x.me(e).lookup("TD");
        var id=td.select('[name="id"]').use().val();
        var link=td.select('[name="link"]').use().val();
        var btn=td.select('button').use().vl();
        //return console.log(btn);
        if(nM(id)&&btn=="delete")
            X("gs/rolelinks/remove",o=>{
                constants.shout(o);
                reload();
            },{id:id,type:'delete'});
        else{//return console.log({role:role.val(),link:link});
            X("gs/rolelinks/put",o=>{
                constants.shout(o);
                reload();
            },{role:role.val(),link:link});
        }
    };
    let build=()=>{
        role.bind().change(change);
        component.bind().change(change);
    };
    let destroy=()=>{
        role.unbind().change(change);
        component.unbind().change(change);
        //role.bind()._change(change);
        //component._bind().change(change);
    };
    let attach=unbind=>{
    	x.find('.btn-action').each(b=>{
    		if(unbind)
    			x.use(b).unbind().click(btnList);
    			//x.use(b).bind()._click(btnList);
    		else
    			x.use(b).bind().click(btnList);
    	});
    };
    let detach=()=>{return attach(true);};
    return{
        init:()=>{
            menus=x.pick('.menus'); 
            role=x.pick('[name="role"]'); 
            component=x.pick('[name="component"]'); 
            build();
        },
        dump:()=>{
            destroy();
            role=null;
            menus=null;
            component=null;
        }
    };
});
