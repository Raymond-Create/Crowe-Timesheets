CORE.add("rate-form",x=>{
    let date,body,submit,inModal;
    let save=(data,tr)=>{
        X(
            'gs/rates/save',
            o=>{
                o=rS(o);
                if(o.status)
                    tr.attr("style","border:1px solid green;");
                else
                    tr.attr("style","border:1px solid red;");
                constants.shout(o);
            },data
        );
    };
    let submitList=e=>{
        x.stop(e);
        body.select('tr').each(tr=>{
            var data={};
            var t=x.use(tr);
            //if(t.hasClass('saved'))
            var r=t.select('[name="rate"]').use();
            var b=t.select('[name="base"]').use();
            var c=t.select('[name="currency"]').use();
            if(!cons.test(date))
                return;
            data.date=date.val();
            if(!cons.test(b))
                return;
            data.base=b.val();
            if(!cons.test(r))
                return;
            data.rate=r.val();
            if(!cons.test(c))
                return;
            data.currency=c.val();
            save(data,t);
        });
    };
    let build=()=>{//console.log(submit)
        submit.bind().click(submitList);
    };
    let destroy=()=>{
        submit.bind()._click(submitList);
    };
    return{
        init:()=>{
            body=x.pick('tbody');
            submit=x.pick('.submit');
            date=x.pick('[name="date"]');
            inModal=x.mod().use().lookup({"class":"modal"});
            build();
        },
        dump:()=>{
            destroy();
            date=null;
            body=null;
            submit=null;
            inModal=null;
        }
    }
    
});