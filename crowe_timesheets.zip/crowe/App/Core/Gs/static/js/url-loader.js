CORE.add("url-loader",x=>{
	let inner;
	let fetch=data=>{
		X(data.url,o=>{
			var y=o.message[0],z=o.message[1];
			var tb=tag(y,z).element();
			x.notify({
	            type:'shutdown',
	            data:inner.n
	        },"mm");
			inner.empty().append(tb);
			x.notify({
	            type:'boot',
	            data:inner.n
	        },"mm");
			constants.addons(inner);
		},data.post||false);
	};
	return{
		init:()=>{
			inner=x.pick(".inner");
			x.listen({fetch:fetch})
		},
		dump:()=>{
			x.ignore(["fetch"]);
			inner=null;
		}
	};
	
});