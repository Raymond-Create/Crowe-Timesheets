/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


class PopCombo{
    static init(combo,data){
        return new PopCombo(combo,data);
    }
    constructor(combo,data){
        this.data=data;
        this.combo=combo;
    }
    populate(select){
        this.combo.empty();
        var g=null;
        each(this.data,obj=>{
            var opt=option().attr({
                value:obj.id,text:obj.title
            });
            if(obj.group&&obj.group!==""){
                if(!g){
                    g=hT(optgroup().attr("label",obj.group).element());
                }
				if(g.attr("label")!=obj.group){
                    this.combo.append(g.n);
					g=g=hT(optgroup().attr("label",obj.group).element());
					g.append(opt.element());
                }else{
					g.append(opt.element());
				}
            }
            else{
                this.combo.append(opt.element());
            }
        });
        if(g)
            this.combo.append(g.n);
        if(select){
            this.combo.selectOn(select);
            var event=new Event("change");
            this.combo.n.dispatchEvent(event);
          }
    }
}