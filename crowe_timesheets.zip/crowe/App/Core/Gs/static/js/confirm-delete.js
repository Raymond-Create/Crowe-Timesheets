CORE.add("confirm-delete",x=>{
	let id,url,type,confirm,cancel,notifyType,
	notifyParam,notify,info;
	let confirmList=e=>{
		x.stop(e);
		X(url.val(),o=>{
			constants.shout(o);
			if(o.status){
				x.notify({type:"redraw",data:null},notify);
				cancel.click();
			}
		},{id:id.val(),type:type.val()});
	};
	let cancelList=e=>{
		x.stop(e);
        var mod=x.me(e).lookup({"class":"modal"});
		if(mod)
            mod.select(".close").use().click();
	};
	let build=()=>{
		info=x.pick(".info")
		var y=info.select('[name="notify"]').use();
		var z=x.pick('[name="notifyType"]');
		var zz=x.pick('[name="notifyParam"]');
		notify=y?y.val():"data-grid-module";
		notifyType=z?z.val():"redraw";
		notifyParam=z?z.val():null;
		id=x.pick('[name="id"]');
		url=x.pick('[name="url"]');
		type=x.pick('[name="type"]');
		cancel=x.pick('.btn-cancel');
		confirm=x.pick('.btn-confirm');
		cancel.unbind().click(cancelList);
		cancel.bind().click(cancelList);
		confirm.unbind().click(confirmList);
		confirm.bind().click(confirmList);
	};
	let destroy=()=>{
		confirm.unbind().click(confirmList);
		cancel.unbind().click(cancelList);
		id=null;
		url=null;
		info=null;
		type=null;
		confirm=null;
		cancel=null;
		notify=null;
		notifyType=null;
		notifyParam=null;
	};
	return{
		init:()=>{
			build();
		},
		dump:()=>{
      destroy();
		}
	};
});