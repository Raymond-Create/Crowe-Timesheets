<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Gs\Models;

use Lib\BaseModel as Model; 

class Linkaccess extends Model{

    public $_rep_=["title"];    

    public function _setup(){    
    	return [
            'link'=>_char(['index'=>1,'pattern'=>'/^[a-zA-Z0-9\/\-\.]+$/']),
			'title'=>_char(),
			'icon'=>_char(['pattern'=>'/^[a-z\- ]+$/']),
			'role'=>_foreign([
				'model'=>["Role","Gs"]
			])			
        ];
    }
    
}