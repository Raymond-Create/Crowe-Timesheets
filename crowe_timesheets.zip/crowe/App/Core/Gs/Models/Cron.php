<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Gs\Models;

use \Core\Gs\Library\Trail as Model; 

class Cron extends Model{

    public $_rep_=["library"];    

    public function _setup(){    
    	return [
            'module'=>_char(),
    	    'library'=>_char(),
    	    'next'=>_integer(),
    	    'wait'=>_integer()
        ];
    }
    
}