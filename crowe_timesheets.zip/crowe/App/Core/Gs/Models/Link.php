<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Gs\Models;

use Core\Gs\Library\Trail as Model; 

class Link extends Model{

    public $_rep_=["title"];    

    public function _setup(){    
    	return [
            'link'=>_char(['index'=>1,'pattern'=>'/^[a-zA-Z0-9\/\-\.\_\&\=\+\?\:]+$/']),
            'title'=>_char(['index'=>1,'unique'=>1,'pattern'=>'/^[a-zA-Z0-9\+\-\|\. ]+$/']),
            'icon'=>_char(['pattern'=>'/^[a-z0-9\- ]+$/']),
            'component'=>_char(['null'=>1]),
            'active'=>_integer([
             	"default"=>1,
             	"options"=>['no','yes']
            ])
        ];
    }
    
}