<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Gs\Models;

use Core\Gs\Models\Sync as Model; 

class Preferrence extends Model{

    public $_rep_=["name"];    

    public function _setup(){    
        return [
            'user'=>_foreign(['model'=>['User','Gs']]),
            'name'=>_char(['index'=>1]),
            'value'=>_char()
        ];
    }
    
}