<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Gs\Models;

use Core\Gs\Library\Trail as Model; 

class RoleLink extends Model{

    public $_rep_=["role","link"];    

    public function _setup(){    
    	return [
            'role'=>_foreign([
                'model'=>["Role","Gs"]
            ]),
            'link'=>_foreign([
                'model'=>["Link","Gs"]
            ])
						
        ];
    }
    
}