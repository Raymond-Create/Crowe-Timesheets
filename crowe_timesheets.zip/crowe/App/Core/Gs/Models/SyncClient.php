<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Gs\Models;

use Lib\Model as Model;

class SyncClient extends Model{

    public $_rep_=["identity"];    

    public function _setup(){    
    	return [
            'identity'=>_char(["unique"=>1]),
            'approved'=>_integer([
            	"options"=>[
            		"No","Yes"
            	],
            	"default"=>0
            ])
        ];
    }
    
}