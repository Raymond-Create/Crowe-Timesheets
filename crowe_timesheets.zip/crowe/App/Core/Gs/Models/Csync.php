<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Gs\Models;

use Lib\BaseModel as Model;

class Csync extends Model{

    public $_rep_=["party"];    

    public function _setup(){    
    	return [
            'recorded_as'=>_char(),
            'party'=>_char(),
            'sync'=>_foreign([
            	'model'=>['Sync','Gs']
            ]),
            'created'=>_datetime(['hide'=>1])
        ];
    }
    public function insert(array $data,$table=false){
    		$data['created']=date('Y-m-d H:i:s');
    		parent::insert($data,$table);
    }
}