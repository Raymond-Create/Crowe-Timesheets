<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Gs\Models;

use Core\Gs\Library\Trail as Model; 

class Location extends Model{

    public $_rep_=["name"];    

    public function _setup(){    
    	return [
            'name'=>_char(['index'=>1,'unique'=>1]),
            'notes'=>_text(['null'=>1])
        ];
    }
    
}