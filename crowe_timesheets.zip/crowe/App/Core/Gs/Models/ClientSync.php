<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Gs\Models;

use Lib\Model as Model;

class ClientSync extends Model{

    public $_rep_=["created"];    

    public function _setup(){    
    	return [
            'client'=>_foreign([
            	'model'=>['SyncClient','Gs']
            ]),
            'trail'=>_foreign([
            	'model'=>['Trail','Gs']
            ]),
            'created'=>_datetime(['hide'=>1])
        ];
    }
    
    public function insert(array $data,$table=false){
    		$data['created']=date('Y-m-d H:i:s');
    		parent::insert($data,$table);
    }
}