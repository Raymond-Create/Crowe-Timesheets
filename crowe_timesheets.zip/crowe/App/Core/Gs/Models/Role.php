<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Gs\Models;

use Core\Gs\Library\Trail as Model; 

class Role extends Model{

    public $_rep_=["name","access"];    

    public function _setup(){    
        return [
            'name'=>_char(['index'=>1,'unique'=>1]),
            'access'=>_char([
                'choices'=>[
                    "FULL","UPDATE","WRITE","NONE"
                ],'default'=>"NONE"
            ])
        ];
    }
    
}