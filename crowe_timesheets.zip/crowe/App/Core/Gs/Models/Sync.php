<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Gs\Models;

use Lib\BaseModel as Model; 
use Core\Gs\Library\User as o;

class Sync extends Model{

    public $_rep_=["type","record","action"];    

    public function _setup(){    
    	return [
            'type'=>_char(),
            'record'=>_char(),
            'action'=>_char([
            	'choices'=>['insert','delete','update'],
            	'pattern'=>'/[a-zA-Z\/]+/',
            	'default'=>'insert'
            ]),
            'created'=>_datetime(['hide'=>1]),
            'creator'=>_foreign([				//ratified
                'model'=>['User','Gs'],
                'hide'=>1
            ])
        ];
    }
    public function insert(array $data,$table=false){
    	$data['created']=date('Y-m-d H:i:s');
    	$data['creator']=o::id();
    	parent::insert($data,$table);
    }
}