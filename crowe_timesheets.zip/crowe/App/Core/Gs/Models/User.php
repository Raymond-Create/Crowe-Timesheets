<?php
	
/**
 * Description of Acl
 *
 * @author bchaumba
 */
 
namespace Core\Gs\Models;

use Lib\Password;
use Core\Gs\Library\Config;
use Core\Gs\Library\Trail as Model; 

class User extends Model{

    public $_rep_=["username"];    
	  
	  public function update_struct(array $array){return $array;}
    public function _setup(){    
    	return [
            'name'=>_char(['null'=>1]),
            'surname'=>_char(['null'=>1]),
            'email'=>_email(["unique"=>1,'index'=>1]),
            'username'=>_char([
            	'index'=>1,'unique'=>1
            ]),
            'role'=>_foreign([
            	"model"=>["Role","Gs"],"null"=>1
            ]),
            'password'=>_char([
            	"pattern"=>'/^.+$/',"hide"=>1
            ]),
            'block'=>_integer([
             	"default"=>0,
             	"options"=>['No','Yes']
            ])
        ];
    }
    
    public function insert(array $data,$table=false)
    {
        if(isset($data["password"])||empty($data['password']))
        {
            $data["password"]=md5(Config::init()->defaultPassword);
        }
        return parent::insert($data,$table);
    }
    	
    public function setPassword($k)
    {//x($k,9);
        if(preg_match('/^sha256\:\d.+/',$k) || preg_match('/\$2y\$11\$.{50,55}/',$k))
        {
           return $k;
        }
        return Password::hash($k);
    }
	
    public function is_valid($password)
    {
        return Password::verify($password,$this->password,preg_match('/^sha256\:\d.+/',$this->password));
    }
   
}