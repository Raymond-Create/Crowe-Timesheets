<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Gs\Models;

use Lib\BaseModel as Model; 

class Payment extends Model{

    public $_rep_=["name"];    

    public function _setup(){    
    	return [
            'type'=>_char(['choices'=>[
				'cash','bank','mobile'
			]]),
            'name'=>_char(['index'=>1]),
            'number'=>_char(['null'=>1]),
            'holder'=>_char(['null'=>1]),
            'is_active'=>_integer([
             		'length'=>1,
             		"pattern"=>"/^(0|1)$/",
             		"default"=>1,
             		"choices"=>[1,0]
             ])
        ];
    }
    
}