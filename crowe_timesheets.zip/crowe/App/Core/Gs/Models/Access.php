<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Gs\Models;

use Lib\BaseModel as Model; 

class Link extends Model{

    public $_rep_=["title"];    

    public function _setup(){    
    	return [
            'role'=>_foreign([
                    'model'=>["Role","Gs"]
            ]),
            'link'=>_foreign([
                    'model'=>["Access","Gs"]
            ])
        ];
    }
    
}