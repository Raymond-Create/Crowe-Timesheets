<?php

namespace Core\Gs\Library;

class Manager{
	
	use \Lib\Init;
	
	protected 
		$id,
		$url,
		$btn=[
			'Edit'=>[
				'btn btn-primary btn-edit',
				'fa fa-pencil'
			],
			'Delete'=>[
				'btn btn-danger btn-delete',
				'fa fa-trash'
			]
		];
	public function __construct($id)
	{
		$this->id=$id["id"];
		$this->url=$id["url"]
	}	
	
	public function html()
	{
		return div("container")
			->attr('data-x-mod','manager')
			->add(div("row")
				->add(div("card")
					->add(div("card-header")
						->add(h4()
							->add(i('fa fa-link'))
							->add(span()->add("Manage Record"))
						)
					)
					->add(div("card-body")
						->add($this->buttons())
						->add(input()
							->attr([
								"name"=>"_key_",
								"type"=>"hidden",
								"value"=>$this->id
							])
						)
						->add(input()
							->attr([
								"name"=>"url",
								"type"=>"hidden",
								"value"=>$this->url
							])
						)
					)
				)
			);
	}
	
	public function buttons()
	{	
		$row=div("row");
		foreach($this->btns as $title=>$btn)
		{
			$bt=button($btn[0]);
			if(isset($btn[1]))
			{
				$bt->add(i($btn[1]));
			}
			$bt->add(span()->add($title));
			if(isset($btn[2]))
			{
				$bt->attr($btn[2]);
			}
			$row->add(div("col-xs-12 col-md-12 mt-3")->add($bt));
		}
		return $row;
	}
}