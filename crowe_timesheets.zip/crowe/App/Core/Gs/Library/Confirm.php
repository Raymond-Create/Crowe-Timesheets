<?php

namespace Core\Gs\Library;

class Confirm
{
	use \Lib\Init;
    
	public function __construct($url=null)
	{
		$this->url=$url;
	}
    public function html($data)
    {
        $this->url=$data["url"];
        if($data["action"]=="delete")
        {
            return $this->delete_prompt(json_decode($data["data"]));
        }
    }
	public function delete_prompt($data)
	{  
	    $span=span("info");
	    $span->add(input()
	        ->attr('name','url')
	        ->attr('type','hidden')
	        ->attr('value',$this->url)
	        );
	    foreach($data as $key=>$value)
	    {
		    	$span->add(input()
		        ->attr('name',$key)
		        ->attr('type','hidden')
		        ->attr('value',$value)
		        ->attr('data-type',"input")
	        );
	    }
	    return div("card")
			->attr('data-x-mod','confirm-delete')
			->add(div("card-body")
				->add(div("row")
					->add(div("col-12")
						->add(p()
							->add(
								"Are you sure you want to perform this irreversible action?"
							)
						)
						->add($span)
					)
				)
			)
			->add(div("card-footer")
				->add(div("row")
					->add(div("col-6")
					    ->add(button("btn btn-warning btn-block btn-cancel")
					        ->attr("id","can-".time())
					        ->add("Cancel")
						)
					)
					->add(div("col-6")
					    ->add(button("btn btn-danger btn-block btn-confirm")
					        ->attr("id","con-".time())
					        ->add("Confirm")
						)
					)
				)
			);
			
	}
}