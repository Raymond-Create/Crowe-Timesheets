<?php

namespace Core\Gs\Library;

class ServerSync
{
    use \Lib\Loader;

    protected 
        $client,
        $approved;
		
    public function __construct($clientID)
    {
        $trail=$this->model("Trail","Gs");
        $mod=$this->model("SyncClient","Gs");
        $data=$trail->select([
                "where"=>["identity"=>$clientID]
        ]);
        if(!empty($data))
        {
            if($data[0]["active"]==0)
            {
                $mod->id=$data[0]["id"];
                $mod->approved=0;
                $mod->active=1;
                $mod->save();
            }
            $this->client=$data[0]["id"];
            $this->set_approved();
        }		
    }	
	
    private function set_approved()
    {
        $mod=$this->model("SyncClient","Gs");
        $mod->get($this->client);
        $this->approved=$mod->approved;	
    }
	
	
}