<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Gs\Library;

class Password
{
	
    use \Lib\Init;

     public function html(){
        return div("container")
            ->attr("data-x-mod","change-password")
            ->add(div("row")
                ->add(div("col-12")
                    ->add($this->card(
                        $this->body(), $this->title(), $this->footer()
                    ))   
                )
            );
    }
    
    public function title()
    {
        return h4()
            ->add(i("fa fa-key"))
            ->add(span()->add(" Change Password"));
    }
    private function footer(){
        $row=div("row");
        return $row->add(div("col-12")
            ->add(button("btn btn-primary btn-block submit")
                ->add("Submit")
            )
        );
    }
    private function body(){
        $row=div("row");
        $row->add(div("col-12 mt-1")
            ->add(\Lib\Ig::init()
                ->set_prepend(span("input-group-text")->add(" Old Password "))
                ->set_input(input("form-control")
                    ->attr([
                        "name"=>"old",
                        "type"=>"password",
                        "required"=>"required",
                        "data-pattern"=>"/^.{6,20}$/"
                    ])
                )
                ->tag()
            )
        );
        $row->add(div("col-12 mt-1")
            ->add(\Lib\Ig::init()
                ->set_prepend(span("input-group-text")->add("New Password "))
                ->set_input(input("form-control")
                    ->attr([
                        "name"=>"new",
                        "type"=>"password",
                        "required"=>"required",
                        "autofill"=>"off",
                        "autocomplete"=>"off",
                        "data-pattern"=>"/^.{6,20}$/"
                    ])
                )
                ->tag()
            )
        );
        $row->add(div("col-12 mt-1")
            ->add(\Lib\Ig::init()
                ->set_prepend(span("input-group-text")->add("Confirm Password"))
                ->set_input(input("form-control")
                    ->attr([
                        "name"=>"confirm",
                        "type"=>"password",
                        "required"=>"required",
                        "data-pattern"=>"/^.{6,20}$/"
                    ])
                )
                ->tag()
            )
        );
        return form()
            ->add($row)
            ->attr("autocomplete","off");
    }
}