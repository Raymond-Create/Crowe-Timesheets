<?php

namespace Core\Gs\Library;

class Landing
{
	use \Lib\Init;
	
	private function infoBox($icon,$name,$url){
        $div = div("info-box");
        $div2 =  div(["class"=>"info-box-content","data-url"=>$url]);
        $div->add( span([
            "class"=>"info-box-icon bg-info elevation-1 l-k",
            "data-value"=>$url,
            'style'=>'color:#fff'
        ])->add( i($icon)));
        $div2->add( span("info-box-text")
            ->add(h5()->add($name))
        );
        $div2->add( span("info-box-number")->add(i("fas fa-link")));
        return $div->add($div2);
    }
    
    private function tab($num,$text,$icon,$mod,$type="bg-success"){
        $div = h\div("small-box ".$type);
        $inner = h\div("inner");
        $inner->add(h\h3()->add($num));
        $inner->add(h\p()->add($text));
        $div->add($inner);
        $div->add(h\div("icon")->add(h\i($icon)));
        $a = g::init("a");
        $a->cl("small-box-footer");
        $a->value($mod);
        return $div->add($a->add(h\span()->add("Module Links ")->add(h\i("fas fa-link"))));
    }
    
    public function html()
    {
        $c=div('cont')->attr('data-x-mod','landing');
        $a=div('row');
        $b=div('col-xs-6 col-md-3')
            ->add($this->infoBox(
                'fas fa-book','CashBook','gs/cashbook/index'
            )
        );
        $d=div('col-xs-6 col-md-3')
            ->add($this->infoBox(
                'fas fa-cog','Settings','config/settings/index'
            )
        );
        return $c->add($a
            ->add($b)
            ->add($d)
        );
    }
}