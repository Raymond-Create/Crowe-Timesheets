<?php

namespace Core\Gs\Library;

//use Lib\Factory as Lf;

class Set
{
    use \Lib\Init;
    
    public 
        $page; 
    
    public function __construct()
    {
        $this->page=\Lib\Set::init();
        $this->require_all();
    }
    
    public function html($key)
    {
        $container=div('container mt-5'); 
        $_ui=$this->page->{$key};
        $ui=$_ui&&isset($_ui[0])?$_ui[0]:null;
        $container->add(div('row')
            ->attr('data-x-mod','setting-manager')
            ->add(div('col-ms-12 col-md-4')
                ->add($this->sections($key))   
            ) 
            ->add(div('col-ms-12 col-md-8')
                ->add($ui)
            )   
        );
        return $container;
    }
    
    public function require_all()
    {
        $mods = ls(APP . DS . "Modules");
        foreach($mods as $mod)
        {
            $file=APP .DS. "Modules" .DS. $mod .DS. 'Setup.php';
            if(file_exists($file))
            {
                require $file;
            }
        }
    }
    
    public function add($tag,$link,$shortcut="fa fa-tab")
    {
        $name= str_replace(" ", "", $link);
        $this->page->{$name}=[$tag,$link,$shortcut];
    }
    
    private function sections($key)
    {
        $ul=div('list-group')
            ->add(li('list-group-item list-group-header list-group-item-warning')
                    ->add(h3()->add('Sections'))
            );
        
        $this->page->each(function($page,$ignore)use($ul,$key){
            $class=$page==$key?'list-group-item list-group-item-primary':'list-group-item';
            $ul->add(li($class)
                ->add(a('set')
                    ->attr('data-value',$page)
                    ->add($ignore[1])
                )     
            );  
        });
        return $ul;
    }
}