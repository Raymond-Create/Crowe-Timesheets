<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Gs\Library;

/**
 * Description of Link
 *
 * @author Hp
 */

use Lib\Factory as Lf;

class Link {
    //put your code here
    use \Lib\Init;
    public static function find($url,$search="link",$field=false){
		$links=Lf::app("Link","Gs");
        $links->get($url,$search);
		if($field)
		{
			return $links->$field;
		}
		return $links->title;
	}
    public function __construct($param) {
        $this->title=$param;
    }
    
    public function allowed()
    {
        
    }
    
    public function __get($name)
    {
        return $this->get($name);
    }
    
    private function get($key)
    {
        $links=Lf::app("Link","Gs");
        $links->get($this->title,"title");
        return $links->{$key}?:"";
    }
}
