<?php

namespace Core\Gs\Library;

class Cron
{
	use \Lib\Loader;
	
	public static $_inst=null;
	private $model;
	
	public static function init()
	{
	    self::$_inst = new self();
	    return self::$_inst;
	}
	public function __construct()
	{
	    $this -> model = $this->model('Cron','Gs');
	}
	
	public function load($cont){
	    return 	$this -> cont -> model($cont);
	}
	
	public function run(){
	    $data = $this -> model -> read();
	    if($data)
	    {
	        foreach($data as $cron)
	        {
	            $this->exec($cron);
	        }
	    }
	}
	
	public function exec($cron){
	    if( $cron['next'] <= time()){
	        $cn = $this->library($cron['library'],$cron['module']);//x($cn,8);
	        $ret = $cn->cron();
	        if($ret){
	            $time = time() + $cron['wait'];
	            //$this -> model -> update(['next'=>$time],['id'=>$cron['id']]); //x($r);
	        }
	    }
	}
	
	
}