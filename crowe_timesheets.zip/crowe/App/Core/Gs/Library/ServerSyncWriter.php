<?php

namespace Core\Gs\Library;

class ServerSyncWriter extends ServerSync{
	
    use \Lib\Init;
	
    public function synced($record)
    {
        if(!$this->approved)
        {
            return [0,'Client not yet approved'];
        }
        if(is_array($record))
        {
            $i=null;
            foreach($record as $rec)
            {
                $j=$this->synced($rec);
                $i=$j[0];
            }
            return [$i,"Ok"];
        }
        $mod=$this->model("ClientSync","Gs");
        $mod->client=$this->client;
        $mod->trail=$record;	
        $e=$mod->save();
        return [$e,$e?"Ok":"Error"];
    }
	
    public function insert($data,$table,$user)
    {
        $mod=$this->model("Trail","Gs");
        $id=$mod->insert($data,$table);
        if($id){
            $mod->user=$user;
            $mod->type=$table;
            $mod->record=$id;
            $mod->ip=ip();
            $mod->action="insert";
            $mod->action_time=date("Y-m-d H:i:s");
            $mod->save();
        }
        return [$id,$id?"Ok":"Error"];
    }
}