<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Gs\Library;


abstract class AbstractSettingForm {
    
    use \Lib\Init;
    
    public
    	$body;
	protected 
		$array=[
			"General Settings"=>[
				["DefaultSetting","Gs"],"fa fa-cog"
			],
			"Finance Settings"=>[
				["FinanceSettings","Fin"],"fa fa-chart-line"
			]
		],
		$_setup=[],
		$script;
	
	
    public function __construct()
    {
    	$this->setup();
		$set=Config::init()->settingForms;
		$this->_setup=$set?unserialize($set):$this->array;
		$this->body=div("card-body");
		if($this->script)
		{
			$this->body->attr("data-x-mod",$this->script);
		}
    }
    public function html() 
    {
        $this->add_body();
        return div("container")
            ->attr("data-x-mod","setting-form")
            ->add(div("row")
                ->add(div("col-xs-12 col-md-12")
                    ->add(div("card")
                        ->add(div("card-header")
                            ->add(h4()
                                ->add(i("fa fa-cogs"))
                                ->add(span()->add(" Settings"))
                            )     
                        ) 
                        ->add($this->body)
						->add(div("card-footer")
                            ->add(div("row")
                                ->add(div("col-12")
									->add(span("btn btn-sm btn-block btn-light st-mn")
										->add(i("fa fa-cogs"))
										->add(span()->add("Go To Settings Menu"))
									
									)
								)
                            )     
                        )
                    )
                )
             );
                        
        
    }
    
    abstract public function add_body();
	
    abstract public function setup();
    
    public function add($html)
    {
    		$this->body->add($html);
    }
    
    public function row12($html)
    {
    	$this->add(div("row mt-2")
    		->add(div("col-xs-12 col-md-12")
				->add($html)
			 )
    	);
    }
}