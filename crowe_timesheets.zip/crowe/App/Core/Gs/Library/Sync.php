<?php

namespace Core\Gs\Library;

class Sync extends Trail
{
}
/*
namespace Core\Gs\Library;

use Lib\Factory as Lf;
use Lib\BaseModel as Model;


class Sync extends Model
{
    public function _setup(){

    }

    public function insert(array $data,$table=false)
    {
        $value=parent::insert($data,$table);
        if($value){
            $this->record($table?:$this->table(),$value,'insert');
        }
        return $value;
    }
    
    public function modify(array $data=[],$cr=[],$table=false)
    {
        $value=parent::modify($data,$cr,$table);
        if($value){
            $this->record($table?:$this->table(),$value,'modify');
        }
        return $value;
    }
	public function remove($cr=[],$table=false)
    {
        $value=parent::remove($cr,$table);
        if($value){
            $this->record($table?:$this->table(),$value,'remove');
        }
        return $value;
    }
    
    private function record($type,$record,$action)
    {
        $sync=Lf::app("Sync","Gs");
        $sync->tableExists();
        $sync->fetch([
            'where'=>[
                'record'=>$record,
                'type'=>$type
            ]
        ]);
        $sync->record=$record;
        $sync->action=$action;
        $sync->type=$type;
        return $sync->save();
    }
}
*/