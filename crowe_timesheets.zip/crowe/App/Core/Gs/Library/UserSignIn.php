<?php

namespace Core\Gs\Library;


use Lib\ID;
use Lib\Session as Ss;
use Lib\Factory as Lf;
use Core\Gs\Models\User as Usr;

class UserSignIn{
	
    public $user;

    public function __construct(Usr $object)
    {
        $this->user = $object;
    }
    
    public function forget()
    {
        Ss::remove(ID::get());
        Ss::remove(USER_KEY);
        Ss::remove("role");
        //Ss::remove("database");
    }

    public function store($request=null)
    {
        Ss::set("role",$this->user->role);
        Ss::set(ID::get(),$this->user->id);
        Ss::set(USER_KEY,$this->user->id);
        //x(Ss::init()->state(),9);user_id
        //Ss::set("database",$this->user->db);
    }
    private function token($xclient)
    {
        $client=Lf::app('Clientaccess','Gs');
        $client->tableExists();
        $client->fetch([
            'where'=>[
                'client'=>$xclient,
                'session'=>Ss::id()
            ]
        ]);
        $client->token=md5($xclient.time().Ss::id());
        $client->session=Ss::id();
        $client->client=$xclient;
        $client->user=User::id();
        $sv=$client->save();
        if($sv)
        {
            return $client->token;
        }
        return false;
    }
	
    public function client($request)
    {
        $client=Lf::app('Client','Gs');
        $client->tableExists();
        $client->fetch([
            'where'=>[
                'thumb'=>$request->httpXRequestor,
                'user'=>$this->user->id
            ]
        ]);
        if($client->id)
        {
            return $client->id;
        }
        $client->thumb=$request->httpXRequestor;
        $client->user=$this->user->id;
        $client->database=$this->user->db;
        return $client->save();
    }
	//public function exists()
}
/*
Multi companies app

1. create company details table in .main.db
2. create a users table in .main.db
3. when you register a user
	a. a database name will be created from the md5 combination of user + company + time()
	b. a users, roles table is created in the new database
	c. user will contain main field for the users main.db users primary key
	d. a new adiministrator roll is created for the user
*/