<?php

namespace Core\Gs\Library;

class RoleLinks
{
	
	use \Lib\Init;
	
	public function __construct()
	{
		//x($this,9);
	}
	
	public function html()
	{
		return div('container mt-5')
			->add(div('row')
				->add(div('col-xs-12 col-lg-12')
					->add(div('card')
						->add(div('card-header')
							->add(i('fa fa-user-setting'))
							->add(h3()->add(' Role Privileges'))
						)
						->add(div('card-body')
							->add(div('row')
								->add(div('col-xs-12 col-lg-6 mt-2')
									->add($this->role())
								)
								->add(div('col-xs-12 col-lg-6 mt-2')
									->add($this->table())
								)
							)
							->add(div('row st'))
						)
					)
				)
			)
			->attr('data-x-mod','role-privileges');
	}
	
	public function form($role,$table)
	{
		
	}
	
	private function role()
	{
		return \Lib\BootSelect::init()
			->set_model(['Role','Gs'])
			->set_name('role')
			->html();
	}
	
	private function table()
	{
		$in=\Lib\Factory::app('User','Gs');
		$tables=$in->select([
			'table'=>'sqlite_master',
			'select'=>['name'],
			'where'=>[
				['name'=>['notin'=>['sqlite_sequence']]]
			],
			'order'=>['name','ASC']
		]);
		$select=select('form-control')
			->add();
		x($tables,8);
		return \Lib\BootSelect::init()
			->set_model(['Role','Gs'])
			->set_name('role')
			->html();
	}
	
	
}