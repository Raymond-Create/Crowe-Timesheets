<?php

namespace Core\Gs\Library;

trait Index{
	
    protected 
        $leftDiv="col-md-4 col-lg-3 col-xs-12 left",
        $rightDiv="col-md-12 col-lg-12 col-xs-12";
    public function index($a=10,$b=1,$c=0)
    {
        if(!is_numeric($a))
        {
            $a=10;
        }
        if(!is_numeric($b))
        {
            $b=1;
        }
        if(!is_numeric($c))
        {
            $c=0;
        }
        $this->table($a,$b,$c);
    }
	
    protected function right($inner)
    {
        return div(\Lib\Session::get("rightDiv")?:$this->rightDiv)
            ->add(div('row')
                ->add(div('col-md-12 col-xs-12 card')
                    ->add(div("card-body")
                        ->add(div("row")
                            ->add(div("col-12")->add($this->left()))    
                        )
                        ->add($inner)
                    )
                )
            );
    }
	
    public function  customize_table(\Lib\Grid $table)
    {
        $con=div('m-5')
            ->attr('data-x-mod','data-display');
        $left=div('col-md-4 col-lg-3 col-xs-12 left');
        if(!isset($this->show_form)||!$this->show_form)
        {
            $table->hide_form();
            $table->edit_create();
        }
        if(method_exists($table,"set_title"))
        {
            $table->set_title($this->_left[0]);
        }
        return $con
            ->add(div('row')
                //->add($left->add($this->left()))
                ->add($this->right($table->html()))
            );
    }
		
    protected function blockBtn($name,$link,$icon,$class='primary')
    {
        return a('btn btn2 btn-labeled btn-'.$class)
            ->attr('data-href',$link)
            ->add(span('btn-label')
                ->add(i('fa fas '.$icon))           
            )
            ->add(span()
                ->add($name)
            );
    }

    public function left(){
        $span=span();return $span;
        if(!isset($this->_left)){
            return $span;
        }
		$drop=div("dropdown");
        $menu=div("dropdown-menu")
			->attr("aria-labelledby","dropdownMenuButton")
			->attr("style","min-width:300px");
		$drop->add(button("btn btn-link btn-sm dropdown-toggle float-left")
			->attr("type","button")
			->attr("aria-haspopup","true")
			->attr("aria-expanded","false") 
			->attr("data-toggle","dropdown")
			->attr("id","dropdownMenuButton")
			->add("Menu")
		);
		$links=$this->side_links();
        $link= Link::init(".Home");
		$menu->add(span("dropdown-item")
			->add(button("btn btn-primary btn-sm btn-block left-link")
				->add(i($link->icon))
				->attr("type","button")
				->attr("data-href",$link->link)
				->add(span()->add(" "))
				->add(span()->add($link->title))
			)
		);
		$url="gs/landing/links/".$this->_left[1];
		$com=Link::find($url,"link","component");
		$url2="gs/landing/links/".$com;
		$tt=Link::find($url2);
		if($com!="landing"&&$tt!=".Home")
		{
			$link= Link::init($tt);
			$menu->add(span("dropdown-item")
				->add(button("btn btn-primary btn-sm btn-block left-link")
					->add(i($link->icon))
					->attr("type","button")
					->attr("data-href",$link->link)
					->add(span()->add(" "))
					->add(span()->add($link->title))
				)
			);
		}
		$menu->add(span("dropdown-divider"));
        foreach($links as $l){
            $link=Link::init($l);//x([$l,$this->_left[0]]);
            $btn=$l==$this->_left[0]?"btn-secondary":"btn-info";
            if(!User::hasAccess($link->id))
            {
               continue; 
            }
            $menu->add(span("dropdown-item")
                ->add(button("btn left-link btn-sm btn-block ".$btn)
                    ->add(i($link->icon))
                    ->attr("type","button")
                    ->attr("data-href",$link->link)
                    ->add(span()->add(" "))
                    ->add(span()->add($link->title))
                )
            );
        }
        return $drop->add($menu);
    }
    
    private function side_links()
    {
        $model= \Lib\Factory::app("Link","Gs");
        $arr=[];
        $data=$model->select([
            "where"=>["component"=>$this->_left[1],"active"=>1],
            "order"=>['title',"ASC"]    
        ]);
        foreach($data as $row)
        {
            if(!User::hasAccess($row["id"]))
            {
               continue; 
            }
            $arr[]=$row["title"];
        }
        return $arr;
    }
    
}