<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Gs\Library;

/**
 * Description of Access
 *
 * @author C Mapurisa
 */
class Access {
    //put your code here
    use \Lib\Init;
    
    public function html()
    {
        //if last rate was not set today
        $card=div('card')
            ->add(div('card-header')
                ->add(i('fa fa-key'))
                ->add(span()->add(' Role Permissions'))
            )
            ->add(div('card-body')
                ->add(div("row")
                    ->add(div("col-xs-6 col-md-6")
                        ->add(label("control-label")
                            ->add("Select Role")
                        )
                    )
                   ->add(div("col-xs-6 col-md-6")
                        ->add(\Lib\BootSelect::init()
                            ->set_placeholder("Choose")
                            ->set_model(["Role","Gs"])
                            ->set_pattern('/^\d+$/')
                            ->set_name("role")
                        )
                    )
                )
                ->add(div("row links"))
            );
        
	return div("row")
            ->attr("data-x-mod","role-permissions")
            ->add(d1212()->add($card));
    }
    public function perms($role){
        
    }
    public function update($post){
        
    }
}
