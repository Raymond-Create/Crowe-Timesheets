<?php

namespace Core\Gs\Library;


class Deleted extends \Lib\Model
{
    public function remove(array $data,$table=false)
    {   
        $d=[];
        if(isset($this->_struct_["deletor"]))
        {
            $d["deletor"]=User::id();
        }
        if(isset($this->_struct_["deleted"]))
        {
            $d["deleted"]=1;
        }
        return parent::modify($d,$data,$table);
    }
    public function _setup() {}
}