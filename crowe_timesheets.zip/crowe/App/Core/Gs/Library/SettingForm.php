<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Gs\Library;


class SettingForm extends AbstractSettingForm
{
    
    use \Lib\Init,\Lib\Loader;
	
	protected $script="configs";
	
    public function setup() 
	{
		
	}
	
    public function add_body() 
	{
		foreach($this->_setup as $key=>$value)
		{
			$this->add(a("btn btn-app")
				->add(i($value[1]))
				->add(span()->add($key))
				->attr("data-value",implode(',',$value[0]))
			);
		}
	}
	
	/*
		<a class="btn btn-app"><i class="fa fa-edit"></i> Edit</a>
	*/
	
}