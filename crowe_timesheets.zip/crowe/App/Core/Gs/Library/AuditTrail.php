<?php

namespace Core\Gs\Library;

class AuditTrail
{
	
    public function __construct(Trail $model)
    {
        $this->model=$model;
    }

    private
        $action,
        $model,
        $table,
        $crit;
	
    public static function delete($model,$crit,$table)
    {
        if(is_array($crit))
        {
            $i=false;
            foreach($crit as $key)
            {	
                $i=$i||self::delete($model,$key,$table);
            }
            return $i;
        }
        return self::add(
            $crit,"remove",
            $table?:$model->table()
        );
    }
    
    public static function update($model,$crit,$table)
    {
        if(is_array($crit))
        {
            $i=false;
            foreach($crit as $key)
            {	
                $i=$i||self::update($model,$key,$table);
            }
            return $i;
        }
        return self::add(
            $crit,"modify",
            $table?:$model->table()
        );
    }
    
    public static function create($model,$crit,$table)
    {
        if(is_array($crit))
        {
            $i=false;
            foreach($crit as $key)
            {	
                $i=$i||self::create($model,$key,$table);
            }
            return $i;
        }
        return self::add(
            $crit,"insert",
            $table?:$model->table()
        ); 
    }
	
    public static function cancel($model,$crit,$table)
    {
        return self::add(
            $crit,"cancel",
            $table?:$model->table()
        ); 
    }
    public static function decline($model,$crit,$table)
    {
        return self::add(
            $crit,"decline",
            $table?:$model->table()
        ); 
    }
    
    public static function request($model,$crit,$table)
    {
        return self::add(
            $crit,"request",
            $table?:$model->table()
        ); 
    }
    
    public static  function add($id,$type,$table)
    {
        if(!AUDIT_TRAIL)
		{
			return false;
		}
		global $VISITOR;
		$obj=\Lib\Factory::app("Trail","Gs");
		if(ENV==DEV)
		{
			$obj->tableExists();
		}
        $obj->ip=ip();
        $obj->record=$id;
        $obj->type=$table;
        $obj->action=$type;
        $obj->user=User::id();
        $obj->visit=$VISITOR->id;
        $obj->session=session_id();
        $obj->action_time=date("Y-m-d H:i:s");
        return $obj->save(); 
    }
    
}