<?php

namespace Core\Gs\Library;

//use Core\Setup\Library\Wizard;
use Lib\Lang;
use Lib\Combo;
use Lib\Factory as Lf;
use Lib\VerticalModelForm as Form;
use Core\Gs\Library\ModelData as Md;

class Crud extends  \Core\Authentication\Library\Controller{
	
    
    
    public function options()
    {
        $filter=[];
        if($this->post() && isset($this->post['filter']))
        {
            $filter=jsonToArray(json_decode($this->post['filter']));//x($filter)
        }
        $opt=[["id"=>"","title"=>"Select ".$this->model->table()]];
        $selexn=$this->model->select($filter);
        $combo=Combo::opts($selexn,$this->model);
        $return=array_merge($opt,$combo);//x($return,9);
        $this->json($return);
    }
	
    public function combo_data($model,$module)
    {
	   $this->model=Lf::app($model,$module);
	   $this->options();
    }
	
    public function confirm_box()
    {
        $lib=\Core\Gs\Library\Confirm::init();
        $this->ajax($lib->html($this->post()));
    }
    
    public function remove()
    {
        if($this->post())
        {   
            if($this->post["type"]=="delete")
            {
                $state=$this->model->delete($this->post['id']);
                $message=$state?"Delete successiful":"Delete NOT successiful";
            }
            if($this->post["type"]=="decline")
            {
                $state=$this->model->decline_request($this->post['id']);
                $message=$state?"Decline request delete successiful":"Decline request delete NOT successiful";
            }
            if($this->post["type"]=="request")
            {
                $state=$this->model->delete_request($this->post['id']);
                $message=$state?"Request for delete successiful":"Request for delete NOT successiful";
            }
            if($this->post["type"]=="cancel")
            {
                $state=$this->model->cancel_request($this->post['id']);
                $message=$state?"Cancellation of delete request successiful":"Cancellation of delete request NOT successiful";
            }
            $this->json($message,$state);
        }
        $this->json("No data supplied",0);
    }
    
    public function table($a=10,$b=1,$inactive=0)
    {
    	$this->view->noHeader();
        $lib = new \Lib\Grid($this->model);
        $lib->set_rows(is_numeric($a)?$a:10);
        $lib->set_page(is_numeric($b)?$b:1);
        //x($this->post(),9);
        $lib->set_url(implode("/",$this->page));
        if($this->post() && isset($this->post['sort_filter']))
        {
            $lib->set_sort_filters($this->post['sort_filter']);	
        }
        $struct = $this->model->_setup();
        if(isset($struct["is_active"])){
            $lib->set_filter([
                "where"=>["is_active"=>$inactive?0:1]
            ]);
            if($inactive)
            {
                $lib->set_inactivate(1);	
            }
        }
        if(isset($this->form_config))
        {
            $lib->set_form_config($this->form_config);
        }
        $oBj=new \Core\Home\Library\Window($this->customize_table($lib),"Window");
        $this->ajax($oBj->html());
        $this->view->pageTitle =  "Table of Records";
    }
    
    public function inactive($a=10,$b=1)
    {
    	$this->table($a,$b,1);
    }
    
    public function head($id=null){
        $lib = new \Lib\Grid($this->model);
        if(isset($this->form_config))
        {
        		$lib->set_form_config($this->form_config);
        }
        if($id)
        {
            $lib->set_id($id);	
        }
        $this->ajax($lib->table_head());
    }
    
    public function put($id=null){
        if($this->post())
        {
           $this->_put($id);
        }//x($this->post,9);
        $this->json("No data supplied",0);
    }
    
    
	
    public function customize_table(\Lib\Grid $table)
    {
        return section("ftco-section ftco-degree-bg")
        ->add(div("container")
            ->add(div("row justify-content-center mb-5 pb-5")
                ->add($table->html())
            )
        );
    }
	
    public function read()
    {
        $filter=[];
        if($this->post() && isset($this->post['filter']))
        {
            $filter=jsonToArray(json_decode($this->post['filter']));
        }
        $data=$this->model->select($filter);
        //x(qd(),9);
        $this->json($data);
    }
    
    public function vertical_form($id=0,$bare=0){
        $this->model_form($this->_model[1], $this->_model[0], $id, $bare);
    }
    
    public function model_form($module,$model=0,$id=0,$bare=0)
    {
        $mod=Lf::app($module,$model);
        if($mod->table())
        {
            $this->model=$mod;
        }
        if(!$this->model->_struct_[$this->model->pk()]->is_valid($id))
        {
            $id=0;
        }
        $form= Form::init($this->model);
        $form->set_id($id);
        $form->set_model_name($model?[$module,$model]:str_replace("+",NS,$module));
        if($this->post()){
            $this->_put($id,$form->get_model());
        }
        $this->ajax($bare?$form->form():$form->html());
    }
    private function _table($a=10,$b=1)
    {   
        $lib = new \Lib\Table($this->model);
        $lib->addRecordNum($a);
        $lib->addPageNum($b);
        $lib->addUrl(implode("/",$this->page));
        if($this->post() && isset($this->post['filter']))
        {
            $lib->addClientFilter($this->post['filter']);	
        }
        return $this->customize_table($lib);
    }
	
    private function _put($id,$model=null)
    {        
        $lib=Md::init($this->model);
        $lib->set_data($this->post);
        $lib->set_id($id);
        $resp=$lib->save();
        $this->json($resp[0],$resp[1]);        
    }
    public function create($id=null,$mode="edit"){//x(7,9);
        if(!is_numeric($id))
        {
            $id=null;
        }
        $lib=Lf::lib($this->_lib[0], $this->_lib[1], $id);
        if(method_exists($lib, "set_url"))
        {
            $lib->set_url(implode('/', $this->page));
        }
        if(method_exists($lib, "set_mode"))
        {
            $lib->set_mode($mode);
        }
        if($this->post())
        {//x($this->post,9);
            $e=$lib->save($this->post);
            if(!isset($lib->message))
            {
                $message=Lang::get($e?"record-modified":"record-created");
            }
            else{
                $message=$lib->message;
                $e=$lib->status;
            }
            $this->json($message,$e);
        }//x(5,9);
        $this->_left=$this->_left_2;
        if(method_exists($lib,"set_title"))
        {
            $lib->set_title($this->_left[0]);
        }
        $this->ajax((div('row m-5')
                ->attr('data-x-mod','data-display')
                ->add($this->right($lib->html()))
            )
    	);
    }
    
    protected function _wrap($html,$left=null,$script=null)
    {
        $row=div('row m-5')->attr('data-x-mod','data-display');
        $col=div("col-12");
        if($script)
        {
           $col->attr('data-x-mod',$script);
        }
        if($script)
        {
           $this->_left=$this->_left_2;
        }
        $this->ajax($row->add($col->add($this->right($html))));
    }
}