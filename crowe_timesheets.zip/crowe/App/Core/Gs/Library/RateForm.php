<?php

namespace Core\Gs\Library;
use Lib\Factory as Lf;
use Core\Gs\Library\Config;

class RateForm
{
    use \Lib\Init;

    private $prev,$base;

    public function __construct($previous=false)
    {
        $this->prev=$previous;
        $this->model=Lf::app("Rate","Gs");
        $this->base=Config::init()->defaultBaseCurrency;
    }
    public function set_url($url){}
    public function todaysRecords()
    {
        $rat=Lf::app("Rate","Gs");
        $rat->fetch([
            "where"=>["date"=>date('Y-m-d')]
        ]);
        return !$rat->isEmpty();
    }
    public function html()
    {
        //if last rate was not set today
        $card=div('card')
            ->add(div('card-header')
                ->add(i('fa fas fa fa-window-restore'))
                ->add(span()->add(' Set Exchange Rates'))
            )
            ->add(div('card-body')
                ->add(div("row")
                    ->add(div("col-xs-12 col-lg-12")
                        ->add($this->table())
                    )
                )
            )
            ->add(div('card-footer')
               ->add(div("row")
                    ->add(div("col-xs-6 col-md-6")
                        ->add(button("btn btn-secondary previous btn-block")
                            ->add("Previous Values")
                        )
                    )
                   ->add(div("col-xs-6 col-md-6")
                        ->add(button("btn btn-primary submit btn-block")
                            ->add("Submit Values")
                        )
                    )
                )
            );
        
	return div("row")
            ->attr("data-x-mod","rate-form")
            ->add(d1212()->add($card));
    }
    
    public function save($post)
    {
        $rat=Lf::app("Rate","Gs");
        $invRat=Lf::app("Rate","Gs");
        if($post["base"]==0||$post['currency']==0)
        {
            return false;
        }
        $rat->date=$post["date"];
        $invRat->date=$post["date"];
        $rat->base=$post["base"];
        $invRat->currency=$post["base"];
        $rat->date=$post["rate"];
        $invRat->date= number_format(1/$post["rate"],5);
        $rat->currency=$post["currency"];
        $invRat->base=$post["currency"];
        try
        {
            $rat->begin();
            $id=$rat->save();
            if($id){
                $invId=$invRat->save();
                if(!$invId)
                {
                    throw new \Exception("Rate invers not saved");
                }
            }
            $rat->commit();
            return $id;
        } catch (\Exception $exp){
            $rat->rollback();
            return false;
        }
    }
    
    private function table()
    {
        $table=table("table table-bordered")
            ->add(thead()
                ->add(tr()
                    ->add(th()
                        ->add("Date")
                    ) 
                    ->add(td()
                        ->add(input("form-control")
                            ->attr("name","date") 
                            ->attr("required","required")   
                            ->attr("value",date("Y-m-d")) 
                            ->attr("data-pattern",DATE_RGX) 
                            ->attr("data-addon","datepicker")
                        )
                    ) 
                )  
                ->add(tr()
                    ->add(th()
                        ->add("Base")
                    ) 
                    ->add(th()
                        ->add("Currency")
                    ) 
                )   
            );
        $currency=Lf::app("Currency","Gs");
        $data=$currency->select([
            "where"=>[
                "id"=>["<>",$this->base],
                "active"=>"yes"
            ]
        ]);
        $tb=tbody();
        foreach($data as $row)
        {
            $tb->add($this->form($row["id"]));
        }
        return $table
            ->add($tb)/*
            ->add(tfoot()
                ->add(tr()
                    ->add(td()
                        ->attr("colspan",2)
                        ->add(button("btn btn-primary btn-submit btn-block")
                            ->add("Submit")
                        )
                    )
                )    
            )*/;
    }
    private function updated()
    {
        $rates=Lf::app("Rate","Gs");
        $rates->fetch([
            "where"=>[
                "date"=>date('Y-m-d')
            ]
        ]);
        return !$rates->isEmpty();
    }
    private function currency($id)
    {
    		
        $rates=Lf::app("Currency","Gs");
        $rates->get($id);
        return $rates->rep();
    }
    
    public function form($counter)
    {
        return tr()
            ->add($this->_base())
            ->add($this->_counter($counter));
    }
    
    private function _base()
    {
        return td()
            ->add(div('input-group')
                ->add(div('input-group-addon input-group-prepend')
                    ->add(div('input-group-text')
                        ->add($this->currency($this->base))
                    )
                )
                ->add(input('form-control')
                    ->attr('data-pattern',CURRENCY_RGX)
                    ->attr('disabled','disabled')
                    ->attr('value','1.00')
                )
                ->add(input()
                    ->attr('value',$this->base)
                    ->attr('data-pattern','/^\d+$/')
                    ->attr('required','required')
                    ->attr('name','base')
                    ->attr('type','hidden')
                )
            );
    }
    private function _counter($id)
    {
        return td()
            ->add(div('input-group')
                ->add(div('input-group-addon input-group-prepend')
                    ->add(div('input-group-text')
                        ->add($this->currency($id))
                    )
                )
                ->add(input()
                    ->attr('data-pattern','/^\d+$/')
                    ->attr('required','required')
                    ->attr('name','currency')
                    ->attr('type','hidden')
                    ->attr('value',$id)
                )
                ->add(input('form-control')
                    ->attr('data-pattern',CURRENCY_RGX)
                    ->attr('required','required')
                    ->attr('type','number')
                    ->attr('name','rate')
                    ->attr('step','any')
                )
            );
    }
}