<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Gs\Library;

/**
 * Description of RportCommons
 *
 * @author Hp
 */

use Lib\Factory as Lf;

trait ReportCommons {
    
    protected function line($width=1){
        return dic()
            ->set("canvas",lst()
                ->append(dic()
                    ->set("type",'line')
                    ->set("x1",0)
                    ->set("y1",5)
                    ->set("x2",595-2*40)
                    ->set("y2",5)
                    ->set("lineWidth",$width)
                )     
            );
    }
    
    protected function logoRow(){
        $row=dic();
        $row->columnGap=10;
        $cols=lst();
        $cols->append(dic()
            ->set("image","logo")
            ->set("width",125)
        );
        $cols->append(" ");
        $cols->append($this->company_details());
        $row->columns=$cols;        
        return $row;
    }
     
    private function company_details()
    {
        $com=Lf::app("Company","Gs");
        $com->fetch();
        return $this->com($com);
    }
    
    private function com($com,$font=9,$align="right")
    {
        return dic()
            ->set("stack",lst()
                ->append(dic()                  //Company name
                    ->set("text",$com->name)
                    ->set("style","header")
                    ->set("alignment",$align)     
                )
                ->append(dic()                  //Company address
                    ->set("text",$com->address ." ")
                    ->set("fontSize",$font)
                    ->set("alignment",$align)       
                )
                ->append(dic()                  //Company email
                    ->set("text",$com->email . " ")
                    ->set("fontSize",$font)
                    ->set("alignment",$align)        
                )
                ->append(dic()                  //Company phone 
                    ->set("text",$com->phone . " ")
                    ->set("fontSize",$font)
                    ->set("alignment",$align)        
                )
                ->append(dic()                  //Company vat 
                    ->set("text","VAT Number: ".$com->vat . " ")
                    ->set("fontSize",$font)
                    ->set("alignment",$align)     
                )
                ->append(dic()                  //Company bp 
                    ->set("text","BP Number: ".$com->bp . " ")
                    ->set("fontSize",$font)
                    ->set("alignment",$align)     
                )
            );
    }
    //put your code here
}
