<?php

namespace Core\Gs\Library;

use Lib\Factory as Lf;

class Config
{
    use \Lib\Init;

    private $model=null,$user=false;

    public function __construct($user=false){
        $this->model=Lf::app('Setting','Gs');
        $this->user=$user;
    }

    public function __set($key,$value){
        $this->model->fetch([
            "where"=>[
                "name"=>$key,
                "user"=>$this->user?User::id():null
            ]
        ]);
        $this->model->name=$key;
        $this->model->value=$value;
        if($this->user)
        {
            $this->model->user=User::id();
        }
        return $this->model->save();
    }

    public function __get($key){
        $this->model->fetch([
            "where"=>[
                "name"=>$key,
                "user"=>$this->user?User::id():null
            ]
        ]);
        return $this->model->value;
    }

    public function id($key){
        $this->model->fetch([
            "where"=>[
                "name"=>$key,
                "user"=>$this->user?User::id():null
            ]
        ]);
        return $this->model->id;
    }
}