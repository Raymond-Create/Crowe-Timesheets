<?php

namespace Core\Gs\Library;

use Lib\Factory as Lf;
use Core\Gs\Library\User;
use Lib\Session;

class Trailedmodel extends Sync
{
    public function insert(array $data,$table=false)
    {
        $data['creator']=User::id();
        $data['created']=date('Y-m-d H:i:s');
        return parent::insert($data,$table);
    }

    public function _setup()
    {
        return[
            'deleted'=>_foreign([				//ratified
                'model'=>['Trail','Gs'],
                'hide'=>1,'null'=>1
            ]),
            'created'=>_foreign([				//ratified
                'model'=>['Trail','Gs'],
                'hide'=>1,'null'=>1
            ]),
            'updated'=>_foreign([				//ratified
                'model'=>['Trail','Gs'],
                'hide'=>1,'null'=>1
            ])
        ];
    }
    
    private function create_trail($rec)
    {
        if(!$rec)
        {
            return;
        }
        $this->get($rec);
        $this->created=$this->trail();
        if($this->created)
        {
            Session::set("INGORE_NEXT_EDIT_TRAIL",true);
            $this->save();
        }
    }
    private function edit_trail($rec)
    {
        if(!$rec||Session::get("INGORE_NEXT_EDIT_TRAIL"))
        {
            Session::remove("INGORE_NEXT_EDIT_TRAIL");
            return;
        }
        if(!Session::get("EDIT_TRAIL_REASON"))
        {
            return;
        }
        $this->get($rec);
        $this->updated=$this->trail(
            Session::get("EDIT_TRAIL_REASON"),
            Session::get("TRAIL_USER"),
            $this->updated
        );
        if($this->updated)
        {
            Session::remove("EDIT_TRAIL_REASON");
            Session::remove("TRAIL_USER");
            $this->save();
        }
    }
    
    private function delete_trail($rec)
    {
        if(!$rec)
        {
            return;
        }
        if(!Session::get("DELETE_TRAIL_REASON"))
        {
            return;
        }
        $this->get($rec);
        $this->deleted=$this->trail(Session::get("DELETE_TRAIL_REASON"),Session::get("TRAIL_USER"));
        if($this->deleted)
        {
            Session::remove("DELETE_TRAIL_REASON");
            Session::remove("TRAIL_USER");
            $this->save();
        }
    }
   
    private function trail($reason=false,$user=false,$trailId=null)
    {
        $trail=Lf::app("Trail","Gs");
        if(!$trailId)
        {
            $trail->get($trailId);
        }
        $trail->stamp=time();
        $trail->user=$user?:User::id();
        $trail->time=date('Y-m-d H:i:s',$trail->stamp);
        if(!$reason)
        {
            $trail->reason=$reason;
        }
        $id=$trail->save();
        return $trail->id?:$id;
    }
}