<?php

namespace Core\Gs\Library;

use Lib\BaseModel as Model;

class ModelData
{
    
    use \Lib\Init;
    
    private
        $model,
        $data;
        
    public function __construct(Model $model){
        $this->model=$model;
    }
    
    public function set_data($data){
        $this->data=$data;
    }
    
    public function set_id($id){
        $this->id=$id;
    }
    
    public function save(){
        try{
            $struct=$this->model->struct();
            if($struct[$this->model->pk()]->isValid($this->id))
            {
                $this->model->get($this->id);
            }else{
                $this->model->fetch([
                    "where"=>$this->data    
                ]);
            }
            foreach($this->data as $field=>$value)
            {
                if(isset($struct[$field]))
                {
                    $this->model->{$field}=$value;
                }
            }
            $id=$this->model->save();
            if($id){
                return [
                    $this->model->{$this->model->pk()}?"Record successifully modified":"Record successifully created",
                    $this->model->{$this->model->pk()}?:$id
                ];
            }else
            {
                return [
                    $this->model->{$this->model->pk()}?"Record NOT modified":"Record NOT created",
                    false
                ];
            }
        }catch(\PDOException $ex){
            $error=$ex->getMessage();
            if(preg_match('/Duplicate/', $error))
            {
                $a=explode("Duplicate", $error);
                return [
                    "Duplicate ".$a[1],false
                ];
                
            }//x($error,9);
            return [
                "Duplicate record detected or some other error has occurred",false
            ];
        }catch(\Exception $ex){
            x($ex,7);
            return [
                "Duplicate record detected or some other error has occurred",false
            ];
        }
    }
}