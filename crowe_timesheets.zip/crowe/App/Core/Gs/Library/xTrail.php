<?php
	
/**
 * Description of Setting
 *
 * @author bchaumba
 */
 
namespace Core\Gs\Library;

use Lib\Access; 

class Trail extends \Core\Base\Library\Trail{}