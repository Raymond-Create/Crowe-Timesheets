<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Gs\Library;

/**
 * Description of Periods
 *
 * @author bchaumba
 */

//use Lib\Factory as Lf;

class Periods {
    
    use \Lib\DataLoader,\Lib\Init;
    
    public function __construct(){
        $this->p["Month"]["All"]["February"][1] = date("Y")%4?"02-28":"02-29";
        
    }
    
    public function update_periods(){
        $affected = 0;
        foreach($this->p as $base=>$settings){
            $this->period($this->base($base,$settings["months"]),$settings);
        }
        $this->each_module($this->data);
        //return $this->adddata($this->data);
    }
    
    private function each_module($data)
    {
        foreach($data as $module=>$data){
            $this->each_model($data,$module);
        }
    }
    
    private function each_model($data,$module)
    {   
        foreach($data as $model=>$data){
            $this->each_record($data,$model,$module);
        }
    }
    private function each_record($data,$model,$module)
    {
        foreach($data as $data){
            $this->save_record($data,$model,$module);
        }
    }
    private function save_record($data,$model,$module)
    {
        $mod=\Lib\Factory::app($model,$module);
        foreach($data as $field=>$value){
            if(is_array($value)){
                $data[$field]=$this->save_record($value[2], $value[1], $value[0]);
            }
        }
        $mod->fetch([
            "where"=>$data
        ]);
        if(!$mod->isEmpty())
        {
            return $mod->id;
        }
        $mod->append($data);
        return $mod->save();
    }
    private $p=[
        "Year"=>[
            "months"=>12,
            "all"=>[
                "Year"=>["01-01","12-31"]
            ]
        ],
        "Semi"=>[
            "months"=>6,
            "all"=>[
                "Half 1"=>["01-01","06-30"],
                "Half 2"=>["07-01","12-31"]
            ]
        ],
        "Term"=>[
            "months"=>4,
            "all"=>[
                "Term 1"=>["01-01","04-30"],
                "Term 2"=>["05-01","08-31"],
                "Term 3"=>["09-01","12-31"]
            ]
        ],
        "Quater"=>[
            "months"=>3,
            "all"=>[
                "Quater 1"=>["01-01","03-31"],
                "Quater 2"=>["04-01","06-30"],
                "Quater 3"=>["07-01","09-30"],
                "Quater 4"=>["10-01","12-31"]
            ]
        ],
        "Month"=>[
            "months"=>1,
            "all"=>[
                "January"=>["01-01","01-31"],
                "February"=>["02-01","02-28"],
                "March"=>["03-01","03-31"],
                "April"=>["04-01","04-30"],
                "May"=>["05-01","05-31"],
                "June"=>["06-01","06-30"],
                "July"=>["07-01","07-31"],
                "August"=>["08-01","08-31"],
                "September"=>["09-01","09-30"],
                "October"=>["10-01","10-31"],
                "November"=>["11-01","11-30"],
                "December"=>["12-01","12-31"]
            ]
        ]
    ],$data=['Gs'=>["Period"=>[]]];
    
    private function base($name,$months){
        return ["Gs","Base",["name"=>$name,"duration"=>$months,"auto"=>1]];
    }
    
    public function period($base,$settings)
    {
        foreach($settings["all"] as $pd=>$bounds)
        {
            $start = date("Y") . "-" . $bounds[0];
            $end = date("Y") . "-" . $bounds[1];
            $startts = strtotime($start);
            $endts = strtotime($end);
            if(time()<$startts||$endts<time()){continue;}
            $this->data["Gs"]["Period"][] = [
                "type"=>$base,
                "start"=>$start,
                "finish"=>$end,
                "name"=>$pd . " " . date("Y")
            ];
        }
    }
    
}