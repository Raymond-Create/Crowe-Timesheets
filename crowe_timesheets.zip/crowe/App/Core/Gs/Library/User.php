<?php

namespace Core\Gs\Library;

use Lib\ID;
use Lib\Session as Sess;
use Core\Gs\Models\User as U;
use Lib\Factory as Lf;

class User
{
	
    use \Lib\Init,\Lib\Loader;
	
    public static function id(){
        return self::init()->userExists();
    }
    
    public static function is($role)
    {
    		return self::init()->hasRole($role);
    }
    
    public static function hasAccess($link)
    {
    		return self::init()->link_access($link);
    }

    public function __construct(U $model = null)
    {
        $mod=["Authentication","Authentication"];
        if(Sess::get("activated_database")){
        	 $mod=["User","Gs"];
        }
        $this->model=Lf::app($mod);
        if($model)
        {
            $this->model=$model;
        }
    }
	
    public function isValid(){
        return $this->userExists()&&$this->isActive();
    }
	
	
    public function userExists()
    {
        return $this->val('id');
    }
    
    
  
    public function hasRole($name)
    {
        $model=$this->model('Role','Gs');
        $model->fetch([
           'where'=>[
     		'id'=>$this->val('role'),
     		'name'=>$name
            ]
        ]);
        return !$model->isEmpty();
    }
	
    public function role()
    {
        return $this->val("role");
    }
    
    public function username()
    {
        return $this->val("username");
    }
	
    public function email()
    {
        return $this->val("email");
    }
	
    public function isActive()
    {
        return $this->val("active"); 
    }

    public function link_access($link)
    {
        $actual=$this->model('RoleLink','Gs')->select([
        	"table"=>"rolelinks",
        	"join"=>[
        		"join"=>[
        			["users u","u.role","rolelinks.role"],
        			["roles r","rolelinks.role","r.id"]
        		]
        	],
        	"where"=>[
        		"u.id"=>Sess::get(ID::get()),
        		"rolelinks.link"=>$link,
        		"r.active"=>1
        	]
        ]);
        $privelege=$this->model('Role','Gs')->select([
        	"table"=>"roles",
        	"join"=>[
        		"join"=>[
        			["users u","u.role","roles.id"]
        		]
        	],
        	"where"=>[
        		"u.id"=>Sess::get(ID::get()),
        		"roles.access"=>"FULL",
        		"roles.active"=>1
        	]
        ]);//x(qd(),7);
        return !empty($actual)||!empty($privelege);
    }
        
    private function user_model(){
        $this->model->fetch([
            "where"=>["email"=>$this->email()]
	]);
        return $this->model;
    }
    
    private function val($field)
    {
        $this->model->get(Sess::get(ID::get()));//x($this->model->data(),9);
        return $this->model->$field;
    }
    
    
}