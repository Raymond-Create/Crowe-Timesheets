<?php

namespace Core\Gs\Library;

use Huchi\Classes\View;
use Lib\Session;

class Controller extends \Lib\Controller{	

    public function on_init()
    {
	if(\Lib\Session::get(\Lib\ID::get()))
        {
            $this->server_valid();
        }
        
        parent::on_init();
	$this->model->tableExists();
	$this->view->noHeader();
    }
    
    protected function isLoggedIn()
    {
    	return User::init()->userExists();
    }

    public function request(){
        return $this->view->application->request;
    }
    
    private function server_valid()
    {
        if(\Lib\ID::server()!=Config::init()->dbID)
        {
            $code= \Lib\Char::gen(200);
            Config::init()->dbID=$code;//x(Config::init()->dbID,8);
            $file=ROOT .DS. 'Files' .DS. '.thumb';
            file_put_contents($file,$code);
        }
    }
}