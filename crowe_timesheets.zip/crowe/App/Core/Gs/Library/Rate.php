<?php

namespace Core\Gs\Library;

use Lib\Factory as Lf;
use Core\Gs\Library\Config;

class Rate
{
    use \Lib\Init;
	
    private
    $model;

    public function __construct(){
        $this->model=Lf::app('Rate','Gs');
    }
    
    
    public function form($date){
        $filter=$date?['where'=>['date'=>$date]]:[];
        $_base=Config::init()->defaultBaseCurrency;
        $all=$this->model->select([
            'table'=>'currencies'
        ]);
        $base=$this->model->select([
            'table'=>'currencies',
            'where'=>[
                'id'=>$_base
            ]
        ]);
        $a=$this->model->select($filter);
        $form=form();
        foreach($all as $row)
        {
            $a=$this->model->select([
                "where"=>[
                    "base"=>$_base,
                    "currency"=>$row["id"]
                ],
                "order"=>['date','desc'],
                "limit"=>[0,1]
            ]);
            $form->add(div('row form-group')
                ->add(div('col-md-12 col-xs-12')
                    ->add(label('control-label')
                        ->add($row['name'] .' / '.$base[0]['name'])    
                    )
                    ->add(input() 
                        ->attr('type','hidden')
                        ->attr('value',($a&&isset($a[0]))?$a[0]['id']:'')
                        ->attr('name','id')
                    )
                    ->add(input() 
                         ->attr('type','hidden')
                        ->attr('value',$_base)
                        ->attr('name','base')
                    )
                    ->add(input() 
                         ->attr('type','hidden')
                        ->attr('value',$row["id"])
                        ->attr('name','currency')
                    )
                )
                ->add(div('col-md-6 col-xs-6 mt-2')
                    ->add(input('form-control') 
                        ->attr('data-addon','datepicker')
                        ->attr('value',($a&&isset($a[0]))?$a[0]['date']:'')
                        ->attr('placeholder','Date')
                        ->attr('name','date')
                    )
                )
                ->add(div('col-md-6 col-xs-6  mt-2')
                    ->add(input('form-control') 
                        ->attr('value',($a&&isset($a[0]))?$a[0]['rate']:'')                        
                        ->attr('placeholder','Rate')
                        ->attr('name','rate')
                    ) 
                )
            );
        }
        return $form;
    }
    public static function pair($base,$currency)
    {
        $model=self::init()->model;
        $v=$model->select([
            'where'=>[
                //'date'=>'{max(date)}',
                'currency'=>$currency,
                'base'=>$base
            ]
        ]);
        $u=$model->select([
            'where'=>[
                //'date'=>'{max(date)}',
                'currency'=>$base,
                'base'=>$currency
            ]
        ]);
        if(empty($v)&&!empty($u))
        {
            $model->date=$u[0]['date'];
            $model->base=$u[0]['currency'];
            $model->currency=$u[0]['base'];
            $model->rate= number_format(1/$u[0]['rate'],4);
            $model->save();
            return self::pair($currency,$base);
        }
        if(empty($v)||!isset($v[0])||!isset($v[0]['rate']))
        {
            return false;
        }
        return $v[0]['id']; 
    }
    public function rates(){
        $curr=Lf::app('Currency','Gs');
        $currencies=$curr->select([
            'where'=>[
                'active'=>'yes'
            ]
        ]);
        $data=['rates'=>[]];
        foreach($currencies as $currency){
            if($currency['id']==Config::init()->defaultBaseCurrency)
            {
                $data['base']=[$currency['id'],$currency['name']];
                continue;
            }
            $data['base']=[
                $currency['id'],
                $currency['name'],
                Rate::pair($currency['id'],Config::init()->defaultBaseCurrency)
            ];
        }
        return $data;
    }
    
    public function save($data){
        try{
            if($data["rate"]<=0){
                throw new \Exception('Rate cannot be less or equal to zero');
            }
            $data2=$data;
            $data2["base"]=$data["currency"];
            $data2["currency"]=$data["currency"];
            $data2["rate"]=1;
            $data3=$data;
            $data3["base"]=$data["base"];
            $data3["currency"]=$data["base"];
            $data3["rate"]=1;
            $data4=$data;
            $data4["base"]=$data["currency"];
            $data4["currency"]=$data["base"];
            $data4["rate"]= number_format(1/$data["rate"],4);
            $this->model->begin();
            $this->_save($data);
            $this->_save($data2);
            $this->_save($data3);
            $this->_save($data4);
            $this->model->commit();
            return true;
        } catch (\Exception $ex) {
            $this->model->rollback();
            return $ex->getMessage();
        }
       
        return $this->_save($data);
    }
    private function _save($data)
    {
        //check if record exists
        $this->model->clear();
        $this->model->fetch([
            "where"=>[
                "date"=>$data["date"],
                "base"=>$data["base"],
                "currency"=>$data["currency"]
            ]
        ]);
        $this->model->rate=$data["rate"];
        $this->model->date=$data["date"];
        $this->model->base=$data["base"];
        $this->model->currency=$data["currency"];
        return $this->model->save();
    }
   	
   	public function get($b,$c,$d=null)
   	{
   		if(!$d)
   		{
   			$d=date("Y-m-d");
   		}
   		return $this->near($b,$c,$d);
   	} 
   	
    public function near($base,$currency,$date=null)
    {
        //AT Given date
        if(!preg_match(DATE_RGX,$date))
        {
           throw new \Exception("Date ($date) is invalid"); 
        }
        $cur=Lf::app("Currency","Gs");
        $bas=Lf::app("Currency","Gs");
        $def=Config::init()->defaultBaseCurrency;
        $cur->get($currency);
        $bas->get($base);
        if($base==$currency)
        {
            return 1;
        }
        if($base!=$def&&$currency!=$def)
        {
            $brate=$this->near($base,$def,$date);
            $crate=$this->near($def,$currency,$date);
            return $brate*$crate;
        }
        $ordinary=$this->model->select([
            "where"=>[
                "date"=>["<=",$date],
                "base"=>$base,
                "currency"=>$currency
            ],
            "order"=>["date","DESC"],
            "limit"=>[1,0]
        ]);
        $inverted=$this->model->select([
            "where"=>[
                "date"=>["<=",$date],
                "base"=>$currency,
                "currency"=>$base
            ],
            "order"=>["date","DESC"],
            "limit"=>[1,0]
        ]);
        $pair=$cur->rep()."/".$bas->rep();
        if(empty($ordinary)&&empty($inverted))
        {
            throw new \Exception("Rate for ". $pair ." has not been set any time on or before $date");
        }
        return $this->det($ordinary,$inverted,$pair);
    }
    
    private function det($ordinary,$inverted,$pair)
    {
        if(isset($inverted[0])&&!isset($ordinary[0]))
        {
            return 1/$inverted[0]["rate"];
        }
        if(!isset($inverted[0])&&isset($ordinary[0]))
        {
            return $ordinary[0]["rate"];
        }
        if(isset($inverted[0])&&isset($ordinary[0]))
        {
            
            if($inverted[0]["date"]>$ordinary[0]["date"])
            {
                return 1/$inverted[0]["rate"];
            }
            return $ordinary[0]["rate"];
        }
        throw new \Exception("Rate for ".$pair." has not been set");
    }
    
}