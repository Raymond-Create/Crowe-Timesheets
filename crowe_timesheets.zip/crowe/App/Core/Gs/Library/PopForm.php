<?php

namespace Core\Gs\Library;

use Lib\Factory as Lf;

abstract class PopForm
{

    private 
        $mod;

    protected 
        $url,
        $field,
        $model,
        $filter,
        $module,
        $record,
        $support;

    public function __construct($record)
    {
        $this->record=$record;
        $this->mod=Lf::app($this->model,$this->module);
    }


    public function html()
    {
        return div("row")
            ->attr("data-x-mod","pop-form") 	
            ->add(div("col-md-12 col-xs-12")
                ->add(div('container')
                    ->attr(
                        $this->support?'data-x-mod':'data-ignore',
                        $this->support?:'data-ignore'
                    )
                    ->add(div('row')
                        ->add(div('col-xs-12 col-md-12')
                            ->add(div('card')
                                ->add(div('card-header')
                                    ->add($this->get_title())
                                )
                                ->add(div('card-body')
                                    ->add(div("row")
                                        ->add(div("col-xs-12 col-md-12 table-responsive")
                                            ->add($this->table())
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            );
    }

    public function table()
    {
        $table=table('table table-bordered');
        $table->add($this->thead());
		$table->add($this->body());
		$footer=$this->footer();
		if($footer)
		{
			$table->add($footer);
		}
        return $table;
    }
	
	public function footer()
	{
		
	}
	
    abstract protected function row($row);

    abstract protected function get_title();

    abstract protected function thead();

    protected function hidden()
    {
        return input()
            ->attr('value',$this->record)
            ->attr('data-url',$this->url)
            ->attr('required','required')
            ->attr(
                "data-pattern",
                $this->mod->struct()[$this->mod->pk()]->getPattern()
            )
            ->attr("data-type","input")
            ->attr('name',$this->field)
            ->attr('type','hidden');
    }
    
    protected function del_btn($id)
    {
        return td()
            ->add(button("btn btn-danger btn-delete btn-sm")
                ->add(i("fa fa-trash"))
        		
            )
            ->add(input()
                ->attr("type","hidden")
                ->attr("name","ln_id")
                ->attr("value",$id)
            ) ;
    }

    protected function del()
    {
        return button()
            ->attr('value',$this->record)
            ->attr('data-url',$this->url)
            ->attr('name',$this->field)
            ->attr('type','hidden');
    }
    
    private function body()
    {
        $tbody=tbody();
        $tbody->attr("data-link-url",$this->url);
        $tbody->attr("data-record",$this->record);
        $data=$this->mod->select($this->get_filter());//x($data,9);
        foreach($data as $row)
        {
            $tbody->add($this->row($row));
        }
        return $tbody;
    }

    private function get_filter()
    {
        $where=isset($this->filter['where'])?$this->filter['where']:[];
        $where[$this->mod->table().'.'.$this->field]=$this->record;
        $filter['where']=$where;
        return $filter;
    }
}