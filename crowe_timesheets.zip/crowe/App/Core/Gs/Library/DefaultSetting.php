<?php

namespace Core\Gs\Library;

class DefaultSetting extends AbstractSettingForm
{
	use \Lib\Init;
	
	public function setup()
	{
		$this->array["Default Values"]=[
			["DefaultSetting","Gs"],"fa fa-cog"
		];
	}
	
	public function add_body() 
	{
		$this->row12(label("control-label")->add("Default Password"));
		$this->row12(input("form-control")
			->attr("data-value",Config::init()->id('defaultPassword'))
			->attr("value",Config::init()->defaultPassword)
			->attr("data-pattern","/^.{6,18}$/")
			->attr("name","defaultPassword")
			->attr("required","required")
		);
		$this->row12(label("control-label")->add("Default Location"));
		$this->row12(\Lib\BootSelect::init()
			->set_default(Config::init()->defaultLocation)
			->set_meta(["data-value"=>Config::init()->id('defaultLocation')])
			->set_model(["Location","Gs"])
			->set_name("defaultLocation")
			->required()
			->html()
		);
		$this->row12(label("control-label")->add("Default Currency"));
		$this->row12(\Lib\BootSelect::init()
			->set_default(Config::init()->defaultBaseCurrency)
			->set_meta(["data-value"=>Config::init()->id('defaultBaseCurrency')])
			->set_model(["Currency","Gs"])
			->set_name("defaultBaseCurrency")
			->required()
			->html()
		);
	}
}