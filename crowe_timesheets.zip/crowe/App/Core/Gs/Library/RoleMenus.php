<?php

namespace Core\Gs\Library;

class RoleMenus{
	
    use \Lib\Init,\Lib\Loader;

    public function html()
    {
        return div("cont")
            ->attr("data-x-mod","role-menu")
            ->add(div("row")
                ->add(div("col-12")
                    ->add(div("card")
                        ->add(div("card-header")
                            ->add(h3("float-left")->add("Role Menus"))
                        )
                        ->add(div("card-body")
                            ->add(div("row")
                                ->add(div("col-6")
                                    ->add(\Lib\BootSelect::init()
                                        ->set_model(["Role","Gs"])
                                        ->set_name("role")
                                        ->html()
                                    )
                                )    
                                ->add(div("col-6")
                                    ->add($this->components())
                                )    
                            )
                            ->add(div("row")
                                ->add(div("col-12 mt-2 menus"))
                            )
                        )
                    )
                )      
            );
    }

    private function components()
    {
        $select=select('form-control');
        $table=[
            "select"=>[
                "distinct(component)"
            ],
            "table"=>"links",
            "alias"=>"v"
        ];
        $filter=[
            "table"=>$table,
            "join"=>[
                "join"=>[
                    ["links l","v.component","l.component"]
                ]
            ],
            "where"=>[
               "l.link"=>["like%","gs/landing/links/"] 
            ],
			"_or"=>[
				"l.link"=>"gs/landing/index"
			],
            "select"=>[
              "distinct(concat(l.component,l.title,l.link)) as a", "l.component","l.title","l.link"
            ],
            "order"=>["component"]
        ];
        $mod=$this->model("Trail","Gs");
        $data=$mod->select($filter);//x(qd(),8);
        $d2=[];
        foreach($data as $row)
        {
            $link=$row["a"];
            $arr=explode("/",$link);
            $d2[]=[
                "group"=>ucfirst($row["component"]),
                "title"=>ucfirst($row["title"]),
                "id"=>array_pop($arr)
            ];
        }
        return \Lib\Combo::init()
            ->set_data($d2)
            ->set_name("component")
            ->html();
    }
    
    public function table($com,$role)
    {
        $table=table("table table-striped table-bordered text-left");
        $mod=$this->model("Trail","Gs");
        $rol=$this->model("Role","Gs");
        $rol->get($role);
        $table->add(thead()
            ->add(tr()
                ->add(th()->add('Role'))
                ->add(th()->add('Menu Link'))
                ->add(th()->add('Access'))
            )
        );
        $data=$mod->select([
            "table"=>"links",
            "join"=>[
                "left join"=>[
                    [
                        [
                            "alias"=>"rl",
                            "table"=>"rolelinks",
                            "where"=>[
                                "role"=>$role,
                                "active"=>1
                            ]
                        ],"rl.link","links.id"
                    ]
                ]
            ],
            "where"=>[
                "component"=>$com,"links.active"=>1
            ],
            "select"=>[
                "links.id as url","links.title","links.icon",
                "links.link","rl.id","links.active"
            ]
        ]);
        $body=tbody();
        foreach($data as $row)
        { 
            if($row["active"]==0)
			{
				continue;
			}
			$tr=tr();
            $tr->add(td()->add($rol->rep()));
            $tr->add(td()
                ->add(span()
                    ->add(i($row['icon']))
                    ->add(span()->add($row['title']))
                )
            );
            $tr->add($this->td($row));
            $body->add($tr);
        }
        return $table->add($body)->rep();
    }
    
    private function td($row)
    {
        return td()
            ->add(input()
               ->attr("type","hidden")
               ->attr("value",$row["url"])
               ->attr("name","link")
            )
            ->add(input()
               ->attr("type","hidden")
               ->attr("value",$row["id"])
               ->attr("name","id")
            )
            ->add(!$row["id"]?
                button("btn btn-success btn-action btn-sm")
                    ->attr("data-value","create")
                    ->add("Add Menu") : 
                button("btn btn-danger btn-action btn-sm")
                    ->attr("data-value","delete")
                    ->add("Remove Menu")    
            );	
    }
}