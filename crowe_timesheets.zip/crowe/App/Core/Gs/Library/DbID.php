<?php

namespace Core\Gs\Library;

use Lib\ID;
use Core\Gs\Library\Config;

class DbID{
    
    public static function id()
    {
        $config=Config::init();
        if(!$config->dbID)
        {
            $config->dbID=Char::gen();
        }
        return $config->dbID;
    }
    
    public static function check()
    {
       $config=Config::init();
       return $config->dbID==ID::server();
    }
    
    public static function update()
    {
       $config=Config::init();
       $config->dbID=ID::server();
    }
}