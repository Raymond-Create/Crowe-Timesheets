<?php

namespace Core\Gs\Library;

use Lib\Factory as Lf;
use Core\Gs\Library\Config;
use Core\Gs\Library\Rate;

class Ratedmodel extends \Core\Base\Library\RateModel
{
    
}