<?php

namespace Core\Gs\Library;

class ServerSyncReader
{
	use \Lib\Init;
		
	//public function 	
}