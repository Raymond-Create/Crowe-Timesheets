<?php

use Lib\Access as Ax;

Ax::models([
	["Role","Gs"],
	["User","Gs"],
	["Link","Gs"],
	["Base","Gs"],
	["Period","Gs"],
	["Location","Gs"],
	["Currency","Gs"],
	["Contact","Gs"],
	["Company","Gs"],
	["Sync","Gs"],
	["CSync","Gs"],
	["Trail","Gs"],
	["RoleLink","Gs"],
	["Setting","Gs"],
	["Rate","Gs"]
]);
