<?php

namespace Core\Gs\Controllers;

use  Core\Gs\Library\Crud;

class Bases extends Crud{
		
    use \Core\Gs\Library\Index;
		
    public 
        $show_form=1,
        $_model=["Base","Gs"],
        $_left=['Period Categories','settings'];
}