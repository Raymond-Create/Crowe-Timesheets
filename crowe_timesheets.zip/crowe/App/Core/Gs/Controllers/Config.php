<?php

namespace Core\Gs\Controllers;

use  Core\Gs\Library\Crud;
use Core\Gs\Library\Trail;
use Core\Gs\Library\SettingForm as Sf;

class Config extends Crud{
	
    use \Core\Gs\Library\Index;

    public $show_form=true,
        $_model=["Setting","Gs"],
        $_left=['Defaults','config'];
    
    public function index()
    {
        $splash=Sf::init();
        $this->ajax((div('row m-5 ')
                ->attr('data-x-mod','data-display')
                ->add($this->right($splash->html()))
            )
    	);
    }
	
    public function trail()
    {
        $trail= Trail::init();
        $this->ajax($trail->html($this->post()));
    }
    
    public function manage($module='Gs',$_lib="Manager")
    {
    	$data=$this->post();
    	$lib=\Lib\Factory::app($_lib,$module,$data);
    	$this->ajax($lib->html());
    }
	
    public function show($_lib="Manager",$module='Gs')
    {
    	$lib=\Lib\Factory::lib($_lib,$module);
    	$this->ajax((div('row m-5 ')
                ->attr('data-x-mod','data-display')
                ->add($this->right($lib->html()))
            )
    	);
    }
} 