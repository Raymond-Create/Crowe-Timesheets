<?php

namespace Core\Gs\Controllers;

use  Core\Gs\Library\Crud;
use  Core\Gs\Library\Cron as Crn;

class Crons extends Crud{
	
	public $_model = ["Cron","Gs"];
	
	
	public function index()
	{
	    //ini_set('max_execution_time', 120); // 120 (seconds) = 2 Minutes
	    ini_set('max_execution_time', 0); // 0 = Unlimited
	    $e=Crn::init()->run();
	    $this->json($e,$e);
	}
	
} 