<?php

namespace Core\Gs\Controllers;

//use Modules\Accounts\Library\Setup as BC;

use Lib\Lang as L;
use Lib\Password as P;
use Lib\Session as Ss;
use Lib\Factory as Lf;
use Core\Gs\Library\Login as LC;
use Core\Gs\Library\LoginForms as Lg;
use Core\Gs\Library\UserSignIn as Usi;
import("System");


class Login extends LC{
    
    public $_model=["User","Gs"];  
	
    public function index($idcode=null){
        x($idcode,8);
        if($idcode){
            Tracker::track($this->application->request);
        }
        $this->login_form();
    }
    public function finger()
    {
        Ss::set("finger",$this->post()["finger"]);
        $this->json(Ss::get("finger"));
    }
    public function request_login()
    {
        $div = div(["class"=>"row scripts","id"=>"request-login","data-value"=>"request-login"]);
        $col = div("col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3");
        $col->add(p()->add("Your are not signed in. ")->add(p()->add(
            button("btn btn-primary login")->add("Please login")
        )));
        $this->view->html = $div->add($col); 
    }
    
    public function login_form()
    {
        if($this->isLoggedIn())
        {
            redirect("gs/landing/index");			
        }
        //x(Ss::init()->state(),7);
        $user = new Usi($this->model);
        //$user->forget();
        $this->ajax(Lg::init()->signin());
    }
	
    public function check_login()
    {   
        if($this->isLoggedIn() && isAjax())
        {
            $this->json(L::get("already-logged-in"),0);		
        }
        if($this->post())
        {	
            $password=$this->post["password"];
            $email=$this->post['email'];
            $w=$this->model->fetch([
                "where"=>["email"=>$email],
                "_or"=>["username"=>$email]
            ]);//x($w,7);
            //$this->model->password=$password;x($this->model->save(),9);
            $pass=$this->model->is_valid($password);
            if($pass && !$this->model->blocked)
            {
                $user = new Usi($this->model);
                $user->store();
                $this->json("gs/landing/index");
            }	
            $this->json(L::get("login-not-successful"),0);	
        }
    }

    public function xst()
    {
        $xst = $this->isLoggedIn();
        $this->json($xst,$xst);
    }
    
    public function logout()
    {
        $user = new Usi($this->model);
        $user->forget();
        if(isAjax())
        {
            $this->login_form();
        }
        redirect("gs/login/index");
    }
    
    public function signup()
    {
        $form=Lf::lib('LoginForms','Gs');
        $this->ajax($form->signup());
    }
}