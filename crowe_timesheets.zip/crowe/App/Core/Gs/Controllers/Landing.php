<?php

namespace Core\Gs\Controllers;

use Lib\Lang;
use Core\Gs\Library\User;
use Core\Gs\Library\Crud;
use Core\Gs\Library\Link;
use Core\Gs\Library\Config;
use Core\Gs\Library\RateForm as Rf;

class Landing extends Crud{
    
    public $_model = ["Link","Gs"];
    
    public function p() {
        $periods=\Core\Gs\Library\Periods::init();
        $periods->update_periods();
    }
    public function set_rate($previous=false)
    {
        $ui=Rf::init($previous);
        if($this->post())
        {
            $a=$ui->save($this->post);
            $this->json($a,$a);
        }
        $o=$ui->html();
        if($o)
        {
            $this->ajax($o);
        }
        $this->json(0,0);
    }
    
    public function kv($key,$method='get'){
        $model= \Lib\Factory::app(['Setting',"Gs"]);
        $model->fetch([
            'where'=>[
                'name'=>$key
            ]
        ]);
        if($method=='set')
        {
            if($this->post()&&isset($this->post['value']))
            {;
            $model->name=$key;
            $model->value=$this->post['value'];
            $a=$model->save();
            $message=$a?Lang::get($model->id?"record-modified":"record-created"): Lang::get($model->id?"record-not-modified":"record-not-created");
            $this->json($message,$a);
            }
            else{
                $this->json("NO DATA",0);
            }
        }else{
            $this->json($model->value,1);
        }
    }
    
    public function index($order=false)
    {
        return $this->links('landing',$order);
    }
    
    public function books($order=false)
    {
        return $this->links('books',$order);
    }
    
    public function settings($order=false)
    {
        return $this->links('settings',$order);
    }
    
    public function reports($order=false)
    {
        return $this->links('reports',$order);
    }
    
    public function inventory($order=false)
    {
        return $this->links('inventory',$order);
    }
    
    public function load($order=false)
    {
        return $this->links('load',$order);
    }
    
    public function transporter($order=false)
    {
        return $this->links('transporter',$order);
    }
    
    public function links($componet,$order=false)
    {
        $sel=[
            'where'=>['component'=>$componet,"active"=>1],
            "table"=>"links",
            "alias"=>"links",
        ];
        if($componet!="landing")
        {
            $filter=[
                "table"=>"links",
                "alias"=>"x",
                "where"=>[
                    "title"=>".Home"
                ]
            ];
            
            $url="gs/landing/links/".$componet;
            $com=Link::find($url,"link","component");
            $url2="gs/landing/links/".$com;
            $tt=Link::find($url2);
            if($tt!=".Home")
            {
                $filter["_or"]=["title"=>$tt];
            }
            $sel['union']=[$filter];
        }
        $data=$this->model->select([
            "table"=>$sel,
            //"alias"=>"z",
            'order'=>['links.title',$order=="DESC"?:'ASC']
        ]);//x(qd(),7);
        if(Config::init()->landingStyle=="style2")
        {
            $html=$this->cont1($data);
        }
        else{
            $html=$this->cont($data);
        }
        $this->ajax($html);
    }
    
    private function cont($data)
    {
        $con=div("cont mt-5")
        ->attr('data-x-mod','app-landing');
        $row=div('row');
        foreach($data as $r)
        {
            if(!User::hasAccess($r["id"]))
            {
                continue;
            }
            $row->add(div('col-md-3 col-xs-6 col-sm-6')
                ->add($this->block(
                    $r['icon'],
                    $r['title'],
                    $r['link']
                    ))
                );
        }
        return $con->add($row);
    }
    private function cont1($data)
    {
        $con=div("cont mt-5")
        ->attr('data-x-mod','app-landing');
        $row=div("row");
        foreach ($data as $r)
        {
            if(!User::hasAccess($r["id"]))
            {
                continue;
            }
            $row->add(div("col-md-3 col-xs-6 col-sm-6 landing-link")
                ->add(div("row text-center")
                    ->add(span("fa-4x text-center ".$r["icon"]))
                    )
                ->add(div("row text-center")
                    ->add(h3("text-center")->add($r["title"]))
                    )
                ->add(span("l-k")->attr("data-value",$r['link']))
                ->attr("style","color:#207ab4")
                );
        }
        //0783850996
        return $con->add($row);
    }
    
    private function block($icon,$name,$url,$num=false){
        $num=is_numeric($num)?:i("fa fa-link");
        $d1=div("info-box landing-link");
        $d2= div("info-box-content")->attr("data-url",$url);
        $d1->add(span("info-box-icon bg-info elevation-1 l-k")
            ->attr("data-value",$url)
            ->attr("style",'color:#fff')
            ->add(i($icon))
            );
        $d2->add(span("info-box-text")
            ->add(h5()->add($name))
            )
            ->add(span("info-box-number")
                ->add($num)
                );
            return $d1->add($d2);
    }
    
    private function installation(){
        $inst=\Lib\Setup::perc();
    }
}