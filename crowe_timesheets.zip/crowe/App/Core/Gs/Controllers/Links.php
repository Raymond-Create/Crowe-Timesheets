<?php

namespace Core\Gs\Controllers;

class Links extends \Core\Gs\Library\Crud{
		
    use \Core\Gs\Library\Index;
		
    public 
    	$show_form=true,
        $_model=["Link","Gs"],
        $_left=['Links','advanced'];
    
    public function access()
    {
        $acc= \Core\Gs\Library\Access::init();
        if($this->post())
        {
            $acc= \Core\Gs\Library\Access::init();
            $a=$acc->update($this->post);
            $this->json($a,$a);
        }
        $this->ajax($acc->html());
    }
    
    public function get_perms()
    {
        if($this->post())
        {
            $acc= \Core\Gs\Library\Access::init();
            $this->ajax($acc->perms($this->post["role"]));
        }
        $this->json("Not Allowed",0);
    }
}