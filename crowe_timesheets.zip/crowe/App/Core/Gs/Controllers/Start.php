<?php

namespace Core\Gs\Controllers;

use  Core\Gs\Library\Crud;
import("System");
use Sys\Classes\Factory;

class Start extends Crud{
	
	use \Core\Gs\Library\Index;
	
	public
	    
	    $_model = ["User","Gs"],
	    $_left=["App Visitors","advanced"];
	
	public function index($a=10,$b=1,$c=0)
	{
		$this->model=Factory::init("Visitor");
		return $this->table($a,$b,$c);
	}
	
	public function  customize_table(\Lib\Grid $table)
    {
        $con=div('m-5')->attr('data-x-mod','data-display');
        $table->hide_form();
        return $con
            ->add(div('row')
                ->add($this->right($table->html()))
            );
    }
    
} 