<?php

namespace Core\Gs\Controllers;

use  Core\Gs\Library\Crud;

class Roles extends Crud{
    
    use \Core\Gs\Library\Index;

    public $show_form=true,
        $_model=["Role","Gs"],
        $_left=['Roles','advanced'];
   
    
}