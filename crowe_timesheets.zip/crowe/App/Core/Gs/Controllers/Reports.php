<?php

namespace Core\Gs\Controllers;

use Core\Gs\Library\Crud as Controller;
use Lib\Factory as Lf;
use Core\Gs\Library\Link;

class Reports extends Controller{   
    
    use \Core\Gs\Library\Index;
    
    public $_model=['Contact','Gs'];
    
    public function show_report($mod,$report){
        $report_lib= Lf::lib($report,$mod);
        if($this->post()){
            $this->json($report_lib->dsl($this->post));
        }
		$this->_left=[
			$report_lib->report,
			Link::find("gs/reports/show_report/$mod/$report","link","component")
		];
        $this->ajax((div('row m-5')
                ->attr('data-x-mod','data-display')
                ->add($this->right($report_lib->html()))
            )
    	);
    }
 	 
} 