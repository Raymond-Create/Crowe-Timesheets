<?php

namespace Core\Api\Controllers;

use  Core\Api\Library\Controller;

class Auth extends Crud{
	
    public $_model = ["Roleaccess","Gs"];
	
}