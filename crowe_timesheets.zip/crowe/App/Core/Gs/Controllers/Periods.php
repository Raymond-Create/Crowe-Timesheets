<?php

namespace Core\Gs\Controllers;

use  Core\Gs\Library\Crud;

class Periods extends Crud{
		
    use \Core\Gs\Library\Index;
		
    public 
        $_model=["Period","Gs"],
        $_left=['Periods','settings'];
		
}