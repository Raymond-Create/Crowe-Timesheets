<?php

namespace Core\Gs\Controllers;
use Core\Gs\Library\RolePrivileges as Rp;

class Roleprivileges extends \Core\Gs\Library\Crud{
		
    use \Core\Gs\Library\Index;
		
    public 
    	$show_form=true,
        $_model=["Privilege","Gs"],
        $_left=[
            'Role Links',
            'settings'
        ];
    
    public function create()
    {
        $html=Rp::init();
        if($this->post())
        {
            $a=$html->save($this->post);
            $this->json($a,$a);
        }
        $this->_left=['Role Privilege Alt','settings'];
        $left=div('col-md-4 col-lg-3 col-xs-12');
        $right=div('col-md-8 col-lg-9 col-xs-12');
        $this->ajax((div('row')
                ->add($left->add($this->left()))
                ->add($right->add($html->html()))
            )
    	);
    }
    
    public function get_perms()
    {
        if($this->post())
        {
            $acc= \Core\Gs\Library\Access::init();
            $this->ajax($acc->perms($this->post["role"]));
        }
        $this->json("Not Allowed",0);
    }
}