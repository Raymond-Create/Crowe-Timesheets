<?php

namespace Core\Gs\Controllers;

class Users extends \Core\Gs\Library\Crud{
		
    use \Core\Gs\Library\Index;
		
    public 
    	$show_form=true,
        $_model=["User","Gs"],
        $_left=[
            'Users',
            'config'
        ];
    
    public function password(){
        if($this->post()){
            $user = $this->model;
            $user->get(\Core\Gs\Library\User::id());
            if(!$user->isEmpty() && $user->is_valid($this->post["current"])){
                $user->password=$this->post["password"];
                $s = $user->save();
                $this->json($s?"Password changed":"Password NOT changed",$s);
            }
            $this->json("Password NOT changed",false);
        }
        $this->_left=['New Password','config'];
        $left=div('col-md-4 col-lg-3 col-xs-12');
        $right=div('col-md-8 col-lg-9 col-xs-12');
        $this->ajax((div('row m-5')
                ->attr('data-x-mod','data-display')
                ->add($left->add($this->left()))
                ->add($right->add(\Core\Gs\Library\Password::init()->html()))
            )
    	);
    }
}