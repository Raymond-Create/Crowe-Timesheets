<?php

namespace Core\Gs\Controllers;
use Core\Gs\Library\RoleLinks as Rl;
use Core\Gs\Library\RoleMenus as Rm;

class Rolelinks extends \Core\Gs\Library\Crud{
		
    use \Core\Gs\Library\Index;
		
    public 
    	$show_form=true,
        $_model=["RoleLink","Gs"],
        $_left=[
            'Role Links',
            'advanced'
        ];
    
    public function access()
    {
        $acc= \Core\Gs\Library\Access::init();
        if($this->post())
        {
            $acc= \Core\Gs\Library\Access::init();
            $a=$acc->update($this->post);
            $this->json($a,$a);
        }
        $this->ajax($acc->html());
    }
   
    
    public function menus($com=null,$role=null)
    {
        $lib=Rm::init();
        if($com&&is_numeric($role)){
            $this->json($lib->table($com,$role));
        }
        $this->_left=['Role Menus','advanced'];
        $this->ajax((div('row m-5')
                ->attr('data-x-mod','data-display')
                ->add($this->right($lib->html()))
            )
    	);
    }
    
    public function make()
    {
    		//if($this->post())
    		//{
    			$tr=$this->model("Trail","Gs");
    			$data=$tr->select([
    				"where"=>[
    					'role'=>5,'link'=>37
    				]
    			],'rolelinks');//x($data,8);
    			if(!empty($data)&&isset($data[0]['active'])&&!$data[0]['active'])
    			{
    				
    			}
    		//}
    }
}