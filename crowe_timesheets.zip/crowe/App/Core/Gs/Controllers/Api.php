<?php

namespace Core\Gs\Controllers;

use  Core\Gs\Library\Login as Controller;
use Core\Gs\Library\UserSignIn as Usi;
use Lib\Session as SS;
use Lib\Lang as L;

class Api extends Controller{
	
    public $_model = ["User","Gs"];
	
	public function index()
	{
		$this->view->html='';
	}
	
	public function check_login()
	{	
		/*
		if($this->isLoggedIn() && isAjax())
		{
			$this->json(L::get("already-logged-in"),0);		
		}*/
		if($this->post())
		{	
			$this->model->get($this->post["email"],"email");
			
			//$this->model->password=$this->post["password"];
			//$this->model->save();
			
			$pass = $this->model->is_valid($this->post["password"]);
			if($pass)
			{
				$user = new Usi($this->model);
				$token = $user->store($this->request());
				$this->json($token,$token);
			}	
			$this->json(L::get("login-not-successful"),0);	
		}
	}

	 public function xst()
    {
        $xst = $this->isLoggedIn();
        $this->json($xst,$xst);
    }
    
    public function logout()
    {
    	$user = new Usi($this->model);
		$user->forget();
		return $this->index();
    }
	
}