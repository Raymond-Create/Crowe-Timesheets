<?php

namespace Core\Gs\Controllers;

use Lib\Lang;
use Lib\Controller;
use Lib\Session as Ss;
use Lib\Factory as Lf;

class Server extends \Core\Gs\Library\Login{
	
    public $_model=["Setting","Gs"]; 

    public function on_init()
    {
        parent::on_init();
        //$this->model->createTable();
    }
    private function language(){
        $sess = Ss::get("language");
        if($sess && preg_match('/[a-z\-]{2,6}/',$sess)){
            return $sess;
        }
        try
        {
            $this->model->get("language","name");
            if($this->model->data()){
                return $this->model->value;
            }
        }catch(\Exception $Exception)
        {
            return config("language");
        }
        return config("language");
    }
    
    public function navigations(){
        $nav = $this->_lib('Nav');
        $this->resp($nav->html() . "");
    }
    
    public function javascript(){
        $var = [
            //"lang"=>\Huchi\Lang::getList(),
            "lang"=>Lang::all(),
            "activeLang"=>$this->language()
        ];
        $regx = [
            "email"=>EMAIL_RGX,
            "decimal"=>DECIMAL_RGX,
            "integer"=>INTEGER_RGX,
            "currency"=>CURRENCY_RGX,
            "datetime"=>DATETIME_RGX,
            "char"=>CHAR_RGX,
            "date"=>DATE_RGX,
            "time"=>TIME_RGX,
            "url"=>URL_RGX,
            "ip"=>IP_RGX
        ];
		$img = [
            "img_lg"=>IMG_LG,
            "img_md"=>IMG_MD,
            "img_sm"=>IMG_SM,
            "img_wt"=>IMG_WT
        ];
        header("Content-Type:application/x-javascript");
        $string = 'constants = '.json_encode($var ).";\n";
        $string .= "constants.langGet = function(key){return constants.lang[key]?constants.lang[key][constants.current]:''};\n";
        $string .= "constants.login = '".config("login") . "';\n"; 
        $string .= "constants.regx = ".json_encode($regx ).";\n";
        $string .= "constants.logos = ".json_encode($img ).";\n";
        $string .= "constants.logout = '".config("logout") . "';\n";
        $string .= "constants.URL = '".SERVER_URL . "';\n";
        $string .= "constants.call = '".PAGE_URL ."';\n";
        $string .= "constants.env = '".ENV ."';\n";
        $string .= "constants.pev = '".PEV ."';\n";
        $string .= "constants.dev = '".DEV ."';\n";
        //$string .= "constants.datetimeRegx = '". \Model\datetimeField()["pattern"] . "'.replace(/^\//,'').replace(/\/$/,'');\n";
        $string .= "constants.link = function(key){return constants.call+key};\n";
        $string .= "window.lang = name =>{if(constants.lang[name])return constants.lang[name][constants.current];return '';}\n";
       $string .= "var cons = constants;\n";
        echo $string;
        exit;
    }
}