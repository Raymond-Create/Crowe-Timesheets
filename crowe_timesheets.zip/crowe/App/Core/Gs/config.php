<?php

use Lib\Access as Ax;

if(!function_exists("curr"))
{
    function curr($name)
    {
        $model=\Lib\Factory::app("Currency","Gs");
        $model->fetch(["where"=>["name"=>$name]]);
        return $model->id;
    }
}//x('8',9);
/*
Ax::models([
	["Cron","Gs"],
	["Role","Gs"],
	["User","Gs"],
	["Link","Gs"],
	["Base","Gs"],
	["Period","Gs"],
	["Location","Gs"],
	["Currency","Gs"],
	["Contact","Gs"],
	["Company","Gs"],
	["Sync","Gs"],
	["CSync","Gs"],
	["Trail","Gs"],
	["RoleLink","Gs"],
	["Setting","Gs"],
	["Rate","Gs"]
]);

Ax::setup([
    [
        'link'=>'gs/landing/links/address',
        'title'=>'Address Book',
        'icon'=>'fa fa-address-book',
        'component'=>'landing',
        'active'=>1,
        'allowed'=>[
        		'Manager','Supervisor','Clerk'
        ]
    ],
    [
        'link'=>'gs/contacts',
        'title'=>'Contacts',
        'icon'=>'fa fa-address-card',
        'component'=>'address',
        'active'=>1,
        'allowed'=>[
            'Manager','Supervisor','Clerk'
        ]
    ],
    
    [
        'link'=>'gs/contacttypes',
        'title'=>'Contact Types',
        'icon'=>'fa fa-users-cog',
        'component'=>'address',
        'active'=>1,
        'allowed'=>[
            'Manager','Supervisor','Clerk'
        ]
    ],
    [
        'link'=>'gs/landing/links/sales',
        'title'=>'Documents',
        'icon'=>'fa fa-file-invoice',
        'component'=>'landing',
        'active'=>1,
        'allowed'=>[
            'Manager','Supervisor','Clerk'
        ]
    ],
    [
        'link'=>'doc/quotations',
        'title'=>'Quotations',
        'icon'=>'fa fa-file-invoice',
        'component'=>'sales',
        'active'=>1,
        'allowed'=>[
            'Manager','Supervisor','Clerk'
        ]
    ],
    [
        'link'=>'doc/documents',
        'title'=>'Mixed',
        'icon'=>'fa fa-file-invoice',
        'component'=>'sales',
        'active'=>1,
        'allowed'=>[
            'Manager','Supervisor','Clerk'
        ]
    ],
    [
        'link'=>'doc/receipts',
        'title'=>'Receipts.',
        'icon'=>'fa fa-receipt',
        'component'=>'sales',
        'active'=>1,
        'allowed'=>[
            'Manager','Supervisor','Clerk'
        ]
    ]
    
]);
*/