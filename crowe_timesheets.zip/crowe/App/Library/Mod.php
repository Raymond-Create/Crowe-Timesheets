<?php

//`_\|^´`%

namespace Lib;


class Mod
{
    use Init;
    
    public 
        $connections,$index=0;
    
    public function __construct($index=0){
        $file=SETTINGS .DS. 'connections.php';
        if(file_exists($file)){
            $this->connections=require($file);
        }
        $this->index=$index;
    }

    public function use($model,$module,$ignoreFix=false)
    {
        $factory=Factory::init();
        
        if($this->connections&&isset($this->connections[$this->index]))
        {
            $factory->set_config($this->connections[$this->index]);
            return $ignoreFix?$factory->get_model($model,$module)
                    :TableFixer::model($factory->get_model($model,$module));
        }
        return null;
    }
}