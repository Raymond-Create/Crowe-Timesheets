<?php


namespace Lib;

use Core\Gs\Library\Periods as P;

abstract class ReportHeader{


    public function __construct(){//x($this,8);
        P::init()->update_periods();
        $this->header();
    }

    public function add($tag){
        $this->row->add($tag);
    }

    public function html(){
        $this->header();
        $this->filters();
        $this->viewer();
        return $this->row;
    }
    
    protected function header(){
        $row = div("container mt-5")
            ->attr("data-x-mod","report-viewer");
        $this->row = $row->add(d1212()->add($this->_filters()));
    }
	
    protected function _filters(){
        $row=div("row");
        $col1=d124();
        $col2=d124();
        $col3=d124();
        $col4=d124();
        $col5=d124();
        $col1->add(select('form-control')
            ->attr('name','method')
            ->add(option(['value'=>'','text'=>'Select Date Method']))
            ->add(option(['value'=>'period','text'=>'Period']))
            ->add(option(['value'=>'range','text'=>'Range']))
        );
        $col2->add(\Lib\BootSelect::init()
            ->set_name('baseperiod')
            ->set_model(['Base','Gs'])
            ->set_placeholder('Select Period Base')
            ->html()
        );
        $col3->add(\Lib\BootSelect::init()
            ->set_name('period')
            ->set_model(['Period','Gs'])
            ->set_placeholder('Select Period')
            ->html()
        );
        $col4->add(div('input-group')
            ->add(div('input-group-addon input-group-prepend')
                ->add(div('input-group-text')
                    ->add("From")    
                )    
            )
            ->add(input('form-control')
                ->attr("name","from")  
                ->attr("data-addon","datepicker")  
                ->attr("placeholder","Report From")  
            )
        );
        $col5->add(div('input-group')
            ->add(div('input-group-addon input-group-prepend')
                ->add(div('input-group-text')
                    ->add("To")    
                )    
            )
            ->add(input('form-control')
                ->attr("name","to")  
                ->attr("data-addon","datepicker")  
                ->attr("placeholder","Report To")  
            )
        );
        return $row->add($col1)->add($col2)->add($col3)->add($col4)->add($col5);
    }
	
    private $row;

    private function viewer(){
        $row = div([
            "class"=>"row index mt-2",
            "data-url"=>$this->url
        ]);
        $col =div("col-md-8 col-lg-8 col-xs-8");
        $col_offset = div("col-md-2 col-lg-2 col-xs-2");
        $this->add($row->add($col_offset)->add($col->add(button([
            "text"=>"Generate Report",
            "class"=>"btn btn-primary  generate-btn form-control"
        ]))));
        $this->add(div("row mt-5")->add(div("col-xs-12 col-md-12 iframe")));
    }
    
    protected $url;

    abstract public function dsl($data);

    abstract protected function filters();

    protected function isDate($date){
        return preg_match(DATE_RGX,$date);
    }
	
    protected function nm($num){
        return number_format($num, 2);
    }
  
    protected function title(){
        $string = $this->report ." for ".$this->company." for period ".
            $this->period . ", beginning on (".$this->beginning.
            ") and ending on (".$this->ending.")";
        return ["columns"=>[[
            "text"=>$string,
            "alignment"=>"center",
            
        ]]];
    }
    protected function dates($crit,$data,$field){//x($data,9);
        $p=Factory::app("Period","Gs");
        if($p->struct()[$p->pk()]->isValid($data["period"])&&$data['date_method']!="range"){
            $p->get($data["period"]);
            if(!$p->isEmpty()){
                $data['from'] = $p->start;
                $data['to'] = $p->finish;
                $this->period = $p->name;
            }
        }
        $this->beginning = $data['from'];
        $this->ending = $data['to'];
        if(!$this->isDate($data["from"]) && !$this->isDate($data["to"])){
            return $crit;
        }
        $crit["where"] = isset($crit["where"])?$crit["where"]:[];
        if($this->isDate($data["from"]) && !$this->isDate($data["to"])){
            $crit["where"][$field]=[">=",$data["from"]];
        }
        if(!$this->isDate($data["from"]) && $this->isDate($data["to"])){
            $crit["where"][$field]=["<=",$data["to"]];
        }
        if($this->isDate($data["from"]) && $this->isDate($data["to"])){
                $crit["where"][$field]=["between"=>[$data["from"],$data["to"]]];
        }//x($crit,8);
        return $crit;
    }
	
    
}