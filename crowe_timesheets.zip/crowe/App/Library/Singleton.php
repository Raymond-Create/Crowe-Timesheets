<?php

namespace Lib;

trait Singleton
{
	use Init;
	
	public static $inst = null;
	
	public static function init($param=null)
	{
		if(!self::$inst)
		{
			self::$inst = Init::init($param);
		}	
		return self::$inst;
	}
} 