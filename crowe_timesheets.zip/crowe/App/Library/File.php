<?php


namespace Lib;

class File
{
	use Init;
	
	public function __construct($path)
	{
		$this->path = $path;
	}
	
	public function prepend($data,$glue='')
	{
		$this->write($data .$glue. $this->read());
	}
	
	public function append($data,$glue='')
	{
		$this->write($this->read() .$glue. $data);
	}
	
	public function read()
	{
		return file_get_contents($this->path);
	}
	
	public function write($data)
	{
		file_put_contents($this->path,$data);
	}
	
	public function exists()
	{
		return file_exists($this->path) && is_file($this->path);
	}
	
	public function getPath()
	{
		return $this->path;
	}
	
	public function readb()
	{
        if(!$this->exists())
		{
			return false;
		}
		$data = fopen($this->path, 'rb');
		$size = filesize($this->path);
		$contents = fread($data, $size);
		fclose($data);
		return base64_encode($contents);
	}
	
    public function mime(){
        // be careful that the path is correct
		if(!$this->exists())
		{
			return null;
        }
		return \mime_content_type($this->path);
    }
	public function writeb($base64_string) {
		// open the output file for writing
        $ifp = fopen($this->path, 'wb' ); 

        // split the string on commas
        // $data[ 0 ] == "data:image/png;base64"
        // $data[ 1 ] == <actual base64 string>
        $data = explode( ',', $base64_string );

        // we could add validation here with ensuring count( $data ) > 1
        fwrite( $ifp, base64_decode( $data[ 1 ] ) );

        // clean up the file resource
        fclose( $ifp ); 

        return $this->path;
	}
	private $path;
}