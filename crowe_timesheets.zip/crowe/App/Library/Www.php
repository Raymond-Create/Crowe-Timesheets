<?php 

namespace Lib;

class Www{
	public static function init($url){
        return new self($url);
    }
	
    private $url,$posts=[],$errors=[],$ch;
    public function __construct($url){
        $this->url = $url;
        $this->ch = curl_init();
    }
    public function __destruct(){
        curl_close($this->ch);
    }
    public function post(array $post){
        if(is_index($post)){
            $this->errors[] = 'Post data has index keys';
        }
        $this->posts = $post;
        return $this;
    }
    public function addPost($k,$v){
        $this->posts[$k] = $v;
        return $this;
    }
    public function error(){
        return $this->error();
    }
    public function setOption($k,$v){
        curl_setopt($this->ch,$k,$v);
    }
    public function setPostData($data){
        curl_setopt($this->ch,CURLOPT_POST,1);
        curl_setopt($this->ch,CURLOPT_POSTFIELDS,http_build_query($data));
    }
    function send(\Closure $callback = null){
        curl_setopt($this->ch,CURLOPT_URL,$this->url);
        curl_setopt($this->ch, CURLOPT_HTTPHEADER, ['Expect:']);
        if(!empty($this->posts)){
            $this->setPostData($this->posts);
        }
        curl_setopt($this->ch,CURLOPT_RETURNTRANSFER,true);//x($this->url,9);
        
        $response = curl_exec($this->ch);//x($response);
        return $callback?$callback($response):$response;
    }
}
		
	