<?php

namespace Lib;

class Db{
    
    public static $databases=[];
    
    public $index=null;
    
    
    public static function init()
    {
        return new self();
    }
    
    public static function set($database,$index)
    {
        return self::init()->set_db($database, $index);
    }
    
    public static function use($index=null)
    {
        return self::init()->use_db($index);
    }
    
    public function __construct(){
        $this->set_db(Session::get("user_selected_database"), "default");
    }
    
    public function set_db($database,$index){
        self::$database[$index]=$database;
        $this->index=$index;
        return $this;
    }
    
    public function use_db($index=null){
        if(is_null($index)){
            $index=$this->index;
        }
        if(isset(self::$database[$index])){
            Session::set(
                "user_selected_database",
                self::$database[$index]
            );
            return true;
        }
        return false;
    }
    
    
}
