<?php

namespace Lib;


#######################################################
#  box ################################################
#######################################################
#
#
class Box
{    
    private
	$__bod='panel',
	$__main='panel',
	$__foot='panel',
	$__head='panel',
    $__body='panel-body',
    $__type='panel-primary',
    $__header='panel-header',
    $__footer='panel-footer';
    
    public function __construct(array $config=[])
	{
        if(isset($config['type']))
		{
            $this->__type=$config['type'];
        }
		if(isset($config['main']))
		{
            $this->__main=$config['main'];
        }
		if(isset($config['body']))
		{
            $this->__body=$config['body'];
        }
		if(isset($config['header']))
		{
            $this->__header=$config['header'];
        }
		if(isset($config['footer']))
		{
            $this->__footer=$config['footer'];
        }
    }
	
    public function tag(){
        $bx=div($this->__main);
        if($this->__head)
		{
            $bx->add($this->__head);
        }
		if($this->__bod)
		{
            $bx->add($this->__bod);
		}
        if($this->__foot)
		{
            $bx->add($this->__foot);
		}
        return $bx;
	}
    #set custom classes
    public function main_class($klass)
	{
        $this->__main=$klass;
        return $this;
	}
    public function type_class($klass)
	{
        $this->__type=$klass;
        return $this;
	}
    public function body_class($klass){
        $this->__body=$klass;
        return $this;
    }
	public function header_class($klass){
        $this->__header=$klass;
        return $this;
    }
	public function footer_class($klass){
        $this->__footer=$klass;
        return $this;
    }
    public function body_inner($inner){
        if(!$inner instanceof \Huchi\Classes\Tag){
            $inner=div()->add($inner);
		}
        $this->__bod=div($this->__body)->add($inner);
        return $this;
	}		
    public function footer_inner($inner){
        if(!$inner instanceof \Huchi\Classes\Tag){
            $inner=div()->add(inner);
		}
        $this->__foot=div($this->__footer)->add($inner);
        return $this;
	}   
    public function header_inner($inner){
        if(!$inner instanceof \Huchi\Classes\Tag){
            $inner=h3()->add($inner);
		}
        $this->__head=div($this->__header)->add($inner);
        return $this;
    }
}