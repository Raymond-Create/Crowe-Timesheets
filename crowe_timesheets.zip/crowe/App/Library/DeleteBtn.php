<?php

namespace Lib;


class DeleteBtn{
	
	use Init;
	
	private 
		$model;
		
	public function __construct($model)
	{
		$this->model=$model;
	}
	
	public function html()
	{
		if($this->model->active==1)
		{
			if(Access::hasFull())
			{
				return $this->btn('delete');
			}
			else{
				return $this->btn('request');
			}
		}
		if($this->model->active==2)
		{
			if(Access::hasFull()||Access::hasUpdate())
			{
				return span()
					->add($this->btn('decline'))
					->add($this->btn('accept'));
			}
			else{
				return $this->btn('cancel');
			}
		}
	}
	
	private function btn($typ)
	{
		if($typ=="cancel")
		{
			$class="btn-cancel btn-secondary";
			$icon="fa fa-ban";
            $name="Cancel Request";
		}
		if($typ=="request")
		{
			$class="btn-request btn-warning";
			$icon="fa fa-trash";
            $name="Request Delete";
		}
		if($typ=="decline")
		{
			$class="btn-decline btn-secondary";
			$icon="fa fa-thumbs-down";
            $name="Decline Request";
		}
		if($typ=="delete")
		{
			$class="del-control btn-danger";
			$icon="fa fa-trash";
            $name="Delete";
		}
		if($typ=="accept")
		{
			$class="btn-accept btn-danger";
			$icon="fa fa-thumbs-up";
            $name="Accept";
            $typ="delete";
		}
		return button("btn btn-xs ".$class)
    			->attr("data-value",$this->model->{$this->model->pk()})
    			->attr("data-toggle","tooltip")
    			->attr("data-action",$typ)
    			->attr("title",$name)
    			->add(i($icon));
	}
}