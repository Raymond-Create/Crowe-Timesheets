<?php

namespace Lib;

class Captcha
{
	
	
	public function display()
	{
		$this->createImage();
		$this->draw();
	}
	
	public function setModerate()
	{
		$this->mode = 'moderate';
	}
	public function setComplex()
	{
		$this->mode = 'complex';
	}
	
	public function __destruct()
	{
		// clean up
	  imagedestroy($this->image);
	}
	private $image,$mode='simple';
	
	private function draw()
	{
		// display image 
  		header('Content-type: image/png');
  		imagepng($this->image);
	}
	
	private function createImageBorder()
	{
		try{
			$x = $this->mode == 'simple'?120:160;
			$y = $this->mode == 'simple'?30:45;
			return imagecreatetruecolor($x, $y);
		}
		catch(\Exception $i)
		{
			x($i,9);
		}
	}
	
	private function createImageBackground()
	{
		// set background
  		imagefill($this->image, 0, 0, imagecolorallocate($this->image, 0x66, 0xCC, 0xFF));
	}
	
	private function createImage()
	{		
  		$this->image = $this->createImageBorder();
		$this->createImageBackground();
  		//allocate drawing colours
  		$linecolor = imagecolorallocate($this->image, 0x33, 0x99, 0xCC);
  		$textcolor1 = imagecolorallocate($this->image, 0x00, 0x00, 0x00);
  		$textcolor2 = imagecolorallocate($this->image, 0xFF, 0xFF, 0xFF);
  		
  		$digit = $this->{$this->mode}($linecolor,$textcolor1,$textcolor2);
  		Session::set('digit',$digit);	
	}
	private function complex($linecolor,$textcolor1,$textcolor2)
	{
		// draw random lines on canvas
  		for($i=0; $i < 8; $i++) {
    		imagesetthickness($this->image, rand(1,3));
    		imageline($this->image, rand(0,160), 0, rand(0,160), 45, $linecolor);
  		}
		// using a mixture of TTF fonts
  		$fonts = [];
  		$fonts[] = "dejavu/DejaVuSerif-Bold.ttf";
  		$fonts[] = "dejavu/DejaVuSans-Bold.ttf";
  		$fonts[] = "dejavu/DejaVuSansMono-Bold.ttf";
  		// add random digits to canvas using random black/white colour
  		$digit = '';
  		for($x = 10; $x <= 130; $x += 30) {
    		$textcolor = (rand() % 2) ? $textcolor1 : $textcolor2;
    		$digit .= ($num = rand(0, 9));
    		imagettftext($this->image, 20, rand(-30,30), $x, rand(20, 42), $textcolor, $fonts[array_rand($fonts)], $num);
  		}
  		return $digit;
	}
	private function simple($linecolor,$textcolor1,$textcolor2)
	{
		
		// draw random lines on canvas
	  for($i=0; $i < 6; $i++) {
	    imagesetthickness($this->image, rand(1,3));
	    imageline($this->image, 0, rand(0,30), 120, rand(0,30) , $linecolor);
	  }
	  // add random digits to canvas using random black/white colour
	  $digit = '';
	  for($x = 15; $x <= 95; $x += 20) {
	    $textcolor = (rand() % 2) ? $textcolor1 : $textcolor2;
	    $digit .= ($num = $this->nextChar());
	    imagechar($this->image, rand(3, 5), $x, rand(2, 14), $num, $textcolor);
	  }
		return $digit;
	}
	
	private function moderate($linecolor,$textcolor1,$textcolor2)
	{
		// draw random lines on canvas
  		for($i=0; $i < 8; $i++) {
    		imagesetthickness($this->image, rand(1,3));
    		imageline($this->image, rand(0,160), 0, rand(0,160), 45, $linecolor);
  		}
	// using a mixture of system and GDF fonts
	  $fonts = array(3,4,5);
	  $fonts[] = imageloadfont("$fontdir/bmcorrode.gdf");
	  $fonts[] = imageloadfont("$fontdir/bmreceipt.gdf");
	  $fonts[] = imageloadfont("$fontdir/checkbook.gdf");
	  shuffle($fonts);
		
	  // add random digits to canvas using random black/white colour
	  $digit = '';
	  for($x = 15; $x <= 95; $x += 20) {
	    $textcolor = (rand() % 2) ? $textcolor1 : $textcolor2;
	    $digit .= ($num = $this->nextChar());
	    imagechar($this->image, array_pop($fonts), $x, rand(2, 14), $num, $textcolor);
	  }

  		return $digit;
	}
	private function nextChar()
	{
		$choices=[0,1,2];
		shuffle($choices);
		if($choices[0] == 0)
		{
			return rand(1,9);
		}
		if($choices[0] == 1)
		{
			return $this->upper();
		}
		return $this->upper(true);
	}
	
	private function upper($lower=false)
	{
		$no = ["o","v","x","w","c","z"];
		$letters = $this->letters;
		shuffle($letters);
		$char = array_pop($letters);
		$s = $lower?strtolower($char):$char;
		if(in_array($s,$no))
		{
			return $this->upper($lower);
		}
		return $s;
	}
	
	private $letters=[
		'A','B','C','D','E','F','G','H','I','J','K','L','M',
		'N','O','P','Q','R','S','T','U','V','W','X','Y','Z'	
	];
}