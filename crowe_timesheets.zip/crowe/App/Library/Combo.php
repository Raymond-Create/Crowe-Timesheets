<?php

namespace Lib;

use DB\Interfaces\ConnectionInterface;

class Combo{
	
    use \Lib\Init;

    public function __construct($data=null,$placeholder=null,$groups=null)
    {
        $this->def='';
        $this->meta=[];
        $this->filter=[];
        $this->data=$data;
        $this->model=null;
        $this->groups=$groups;
        $this->_placeholder=$placeholder;
    }
    private $big,$connection;
    
    public function set_connection(ConnectionInterface  $connection){
        $this->connection=$connection;
        return $this;
    }
    
    public function set_big(){
        $this->big=true;
        return $this;
    }
    public function set_default($val){
        $this->def=$val;
        return $this;
    }

    public function set_data($data)
    {
        $d=[];
        foreach($data as $k=>$v)
        {
            if(!is_array($v))
            {
                $d[]=['id'=>$k,"title"=>$v];
            }
            else{
                $d[$k]=$v;
            }
        }
        $this->data=$d;
        return $this;	
    }

    public function set_model($model)
    {
        $this->meta['data-model']=implode('/',$model);
        $this->model=Factory::app($model);
        if($this->connection){
            $this->model->setConnection($this->connection);
        }
        return $this;	
    }
    public function set_placeholder($placeholder)
    {
        $this->_placeholder=$placeholder;
        return $this;	
    }

    public function set_filter($filter)
    {
        $this->filter=$filter;
        return $this;	
    }
    
    public function set_meta($meta)
    {
        $this->meta= array_merge($this->meta,$meta);
        return $this;	
    }
    
    public function set_name($name)
    {
        $this->meta['name']=$name;
        return $this;
    }
    
    public function set_pattern($pattern)
    {
        $this->meta['data-pattern']=$pattern;
        return $this;
    }
    
    public function required()
    {
        $this->meta['required']='required';
        return $this;
    }
    
    public function get_data()
    {
        
	if(!is_array($this->data)&&$this->model)
        {
            $filter=$this->filter;
            if($this->model->_group_)
            {
                $filter['order']=[
                    implode(',',$this->model->_group_),"DESC"
                ];
            }
            if($this->model->_order_){
            	$o=$this->model->_order_;
            	$seq=$o[0];
            	$order=isset($o[1])?$o[1]:"DESC";
            	$filter['order']=[implode(',',$seq),$order];
            }
            if(isset($this->filter["order"]))
            {
                $filter['order']=$this->filter["order"];
            }
            $read=array_merge($filter,$this->filter);
            $data=$this->opts($this->model->select($read),$this->model);//x(qd(),9);
            $this->data=$data;
        }
        return $this;
    }
    
    public function html(){
        $grp=null;
        $optgp=null;
        $this->get_data();
        $com=!$this->big?select('form-control form-control-sm'):select('form-control');
        if($this->def){
            $com->attr("data-default-value",$this->def);
        }
        if($this->filter)
        {
            $this->meta["data-filter"]=str_replace('"','`',json_encode($this->filter));
        }
        if(isset($this->model)){
            $this->set_pattern($this->model->_struct_[$this->model->pk()]->getPattern());
        }
        if($this->meta&&!empty($this->meta))
        {
            foreach($this->meta as $key=>$value)
            {
                $com->attr($key,$value);
            }
        }
        $n=isset($this->meta['name'])?$this->meta['name']:'';
        $com->add(option()
            ->attr("text",$this->_placeholder?:"Select ".$n." ...")
            ->attr("value","")
        );
        foreach($this->data as $row)
        {//x($row,8);
            $opt=[
                "text"=>$row['title'],
                "value"=>$row['id']
            ];
            if($row['id']==$this->def)
            {
                $opt['selected']="selected";
            }
            if(isset($row['group'])&&!empty($row['group']))
            {
                if($grp&&$grp!=$row['group'])
                {
                    $com->add($optgp);
                }
                if(!$grp||$grp!=$row['group'])
                {
                    $grp=$row['group'];
                    $optgp=optgroup(["label"=>$grp]);
                }
                $optgp->add(option($opt));
            }
            else
            {
                $com->add(option($opt));
            }
        }
        if($optgp){
            $com->add($optgp);
        }
        return $com;
    }
	
    public static function opts($data,$model)
    {
        $do=[];
        foreach($data as $row){
            $v=[];
            $row=Set::init($row);
            $v['id']=$row->{$model->pk()};
            $v['title']=Set::init($row->extract($model->_rep_))->join(" ");
            $gp=self::group_value(Set::init($row->extract($model->_group_))->join(" "),$model);
            $v['group']=$gp;
            $do[]=$v;
        }
        return $do;
    }
    
    public static function group_value($grp,$model)
    {
        if(!$grp)
        {
            return $grp;
        }
        $_gp=$model->group();
        $gp=is_array($_gp)?$_gp[0]:$_gp;//x($gp,9);
        $field=$model->_struct_[$gp];
        if(!$field->getForeign()&&!$field->getExtra("model"))
        {
            return $grp;
        }
        $mod=Factory::app($field->getExtra("model"));
        $mod->setConnection($model->getConnection());
        $mod->get($grp);//x($mod->rep(),8);
        return $mod->rep();
    }
}









