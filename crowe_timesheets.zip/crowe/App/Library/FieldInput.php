<?php

namespace Lib;

import("DB");

use DB\Classes\Field;
use DB\Interfaces\ConnectionInterface;
use DB\Classes\Connection;

class FieldInput
{	 
    
    private $connection;
    
    public static function html(Field $field,$defaultValue=null,$bs=true,Connection $connection=null)
    {
        $self = new self($field,$defaultValue,$bs);
        $self->set_connection($connection);
        return $self->element();
    }

    public function __construct(Field $field,$defaultValue=null,$bs=true)
    {
        $this->bs = $bs;
        $this->field = $field;
        $this->defaultValue = $defaultValue;
    }
	
    public function set_connection(ConnectionInterface $connection){
        $this->connection=$connection;
        return $this;
    }
    public function addFilter($filter)
    {
        $this->filter = $filter;
    }

    private $field,$defaultValue,$filter=[],$bs=true;

    public function element()
    {
        $meta = [
            "value"=>"",
            "data-pattern"=>$this->field->getPattern(),
            "name"=>$this->field->getName(),
            "class"=>"form-control form-control-sm input-sm"			
        ];
        if(!$this->field->isNull())
        {
            $meta["required"] = "required";
        }
        if($this->field->getExtra("disabled"))
        {
            $meta["disabled"] = "disabled";
        }
        if($this->field->getExtra("data-add"))
        {
            $meta["data-add"] = $this->field->getExtra("data-add");
        }
        if($this->field->getExtra("data-search"))
        {
            $meta["data-search"] = $this->field->getExtra("data-search");
        }
        if($this->field->getExtra("data-input"))
        {
            $meta["data-input"] = $this->field->getExtra("data-input");
        }
        if($this->field->getExtra("data-placeholder"))
        {
            $meta["placeholder"] = $this->field->getExtra("data-placeholder");
        }
        return $this->wrap($meta);	
    }
    
	public static function buildPat($arr)
	{
	    $a=array_keys($arr);
	    $b=implode('|',$arr);
	    return '/^('.$b.')$/';
	}
	
    private function wrap($meta)
    {//if($this->field->getName()=="active")x($this->field->getOptions(),8);
        $meta["min-width"]="150px";
        if($this->field->getOptions())
        {
            $element=Combo::init()
                ->set_pattern(self::buildPat($this->field->getOptions()))
                ->set_data($this->field->getOptions())
                ->set_default($this->getValue())
                ->set_meta($meta)
                ->html();
        }
        elseif($this->field->getChoices())
        {
            $element=ChoiceInput::init()
                ->setOptions($this->field->getChoices())
                ->setDef($this->getValue())
                ->setMeta($meta)->html();
        }
        else if($this->field->getType()=="datetime")
        {
            $meta['data-addon'] = "datetimepicker";
            $element = $this->date_time($meta);
        }
        else if($this->field->getForeign()||$this->field->getExtra("model"))
        {
            $element = $this->foreign($meta);
            $element->attr("min-width","150px");
        }
        else if($this->field->getLength()>255 || $this->field->getType() == "text")
        {
            $element = textarea($meta);
            $element->add($this->getValue());
        }
        else
        {
            $meta['value'] = $this->getValue();
            if(in_array($this->field->getType(),["decimal","currency","integer"]))
            {
                $meta['type'] = "number";
                if($this->field->getType() != "integer")
                {
                    $meta['step'] = "any";
                }
            }
            else if($this->field->getType()=="date")
            {
                $meta['data-addon'] = "datepicker";
            }
            $element = input($meta);
                    //$element->add();
        }
        //if($this->field->getName()=="active")x($element,8);
        return $element;
    }

    private function getValue()
    {
        //if($this->field->getName()=="change")
        //	x($this->defaultValue!==null,8);
        if($this->defaultValue!==false&&$this->defaultValue!==null)
        {
            return $this->defaultValue;
        }
        if($this->field->getDefault()!==false||$this->field->getDefault()!==null)
        {
            return $this->field->getDefault();
        }
        return '';
    }

    private function foreign($meta)
    {
        $selector=$this->bs?BootSelect::init():Combo::init();//x( $this,9);
        $input=$selector
            ->set_meta($meta)
            ->set_connection($this->connection)
            ->set_model($this->field->getExtra("model"))
            ->set_default($this->getValue());
        if($this->field->getExtra("filter"))
        {
            $input->set_filter(
       		   $this->field->getExtra("filter")
            );
        }
       return $input->html();
    }
		
    private function date_time($meta)
    {
        $div=div("input-group input-append date d-p")
            ->attr("data-target-input","nearest");
        $meta["data-target"]=".dp";
        $meta["data-format"]="yyyy-MM-dd hh:mm:ss";
        $meta["type"]="text";
        $input=input("form-control form-control-sm datetimepicker-input")
            ->attr($meta);
        $span=span("add-on input-group-addon input-group-append")
            ->attr("data-target",".d-p")
            ->attr("data-toggle","datetimepicker")
            ->add(div("input-group-text")
                ->add(i("fa fa-calendar")) 
            );
        return $div->add($input)->add($span);
    }/*
    <div class="form-group">
                <div class="input-group date" id="datetimepicker1" data-target-input="nearest">
                    <input type="text" class="form-control datetimepicker-input" data-target="#datetimepicker1"/>
                    <div class="input-group-append" data-target="#datetimepicker1" data-toggle="datetimepicker">
                        <div class="input-group-text"><i class="fa fa-calendar"></i></div>
     * 
     */
    public static function datetime($meta,$def=null)
    {
        $object=new self(new Field(),$def);
        return $object->date_time($meta);
    }
    
    public static function foreigner($meta,$def=null)
    {
        $object=new self(new Field(),$def);
        return $object->foreign($meta);
    }
}