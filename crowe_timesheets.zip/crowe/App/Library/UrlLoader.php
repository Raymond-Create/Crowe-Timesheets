<?php

namespace Lib;

class UrlLoader{
	
	use Init;
	
	public function html()
	{
		return div("row")
			->attr("data-x-mod","url-loader")
			->add(div("col-md-12 col-xs-12 col-lg-12 x-12 inner"));
	}
	
}