<?php 

namespace Lib;


use DB\Interfaces\ConnectionInterface;

class Table
{
    
    use PageHtml;
    
    public
    $model;
    private
    $id,
    $cg,
    $url,
    $col,
    $st=[],
    $page=1,
    $rows=10,
    $hide=[],
    $order=[],
    $title="",
    $filter=[],
    $struct=[],
    $columns=[],
    $script=False,
    $widths=[],
    $blank_form=[],
    $form_config=[],
    $connection=null,
    $_form_config=[],
    $inactive=False,
    $form_hide=False,
    $ignore_key=True,
    $min_width='180px',
    $sort_filters=[],
    $search_forms=[],
    $search_filters=[],
    $column_filters=[],
    $transformation=[],
    $edit_with_create="",
    $action_min_width='100px',
    $table_class="table table-hover thead-light table-bordered table-sm",
    $th_style=["style"=>"font-size: 0.85rem !important"],
    $td_style=["style"=>"font-size: 0.8rem !important; padding:.5rem !important"],
    $action=[
        ["icon"=>"fa fa-eye mr-2","text"=>"View","act"=>"btn-view"],
        ["icon"=>"fa fa-edit mr-2","text"=>"Edit","act"=>"btn-edit"],
        ["icon"=>"fa far fa-trash-alt mr-2","text"=>"Delete","act"=>"btn-delete","action"=>1]
    ];
    
    
    public function __construct(array $config=[])
    {
        foreach($config as $key=>$val)
        {
            $this->$key = $val;//x(\Lib\Password::hash("manners@lines"),9);
        }
        if(isset($config["model"]))
        {
            $this->set_model($config["model"]);
        }
        $this->cg=$config;
    }
    
    public function set_seach_forms($array){
        $this->search_forms=$array;
        return $this;
    }
    
    public function set_seach_filters($json_string){
        $array=jsonToArray(json_decode($json_string));
        foreach($array as $field=>$value){
            $this->filter["where"][$field]=$value;
        }
        $this->search_filters=$array; 
        return $this;
    }
    
    public function set_sort($json_string)
    {
        $array=jsonToArray(json_decode($json_string));
        foreach($array as $field=>$data){
            $this->filter["where"][$field]=[$data["op"],$data["value"]];
        }
        $this->sort_filters=$array;
        return $this;
    }
    public function action_width($num)
    {
        $this->action_min_width=$num;
        return $this;
    }
    
    public function set_action($action)
    {
        $this->action=$action;
        return $this;
    }
    
    public function width($num)
    {
        $this->min_width=$num;
        return $this;
    }
    public function hide_form()
    {
        $this->form_hide=true;//x('hide',9);
        return $this;
    }
    public function edit_create()
    {
        $this->edit_with_create=1;//x('edit',9);
        return $this;
    }
    #set id
    public function set_id($val)
    {
        $this->id=$val;
        return $this;
    }
    
    public function set_connection(ConnectionInterface $connection)
    {
        $this->connection=$connection;
        return $this;
    }
    
    public function set_model($model)
    {
        if($this->model && ($this->model instanceof \Huchi\Classes\Model))
        {
            return;
        }
        if(!($model instanceof \Huchi\Classes\Model) )
        {
            $model=Factory::app($model);
        }
        $this->model=$model;
    }
    
    public function set_title($title)
    {
        $this->title=$title;
        return $this;
    }
    
    public function set_form_config($field,$config,$filter=null)
    {
        $this->form_config[$field]=$config;
        if($filter)
        {
            $this->_form_config[$field]=$filter;
        }
        return $this;
    }
    
    public function set_transform($title,\Closure $callback)
    {
        $this->transformation[$title]=$callback;
        return $this;
    }
    
    public function set_blank($title)
    {
        $this->blank_form[]=$title;
        return $this;
    }
    
    #Set url
    public function set_url($val)
    {
        $this->url=$val;
        return $this;
    }
    
    #set page
    public function set_page($val)
    {
        $this->page=$val;
        return $this;
    }
    #Set rows
    public function set_rows($val)
    {
        $this->rows=$val;
        return $this;
    }
    #Set inactive
    public function set_inactive($val)
    {
        $this->inactive=$val;
        return $this;
    }#Set th_style
    public function set_th_style($val)
    {
        $this->th_style=$val;
        return $this;
    }
    #Set inactive
    
    public function set_td_style($val)
    {
        $this->td_style=$val;
        return $this;
    }
    #Set url
    
    public function set_script($val)
    {
        $this->script=$val;
        return $this;
    }
    
    public function set_filter($filter)
    {
        $this->filter=array_merge($this->filter,$filter);
        return $this;
    }
    
    public function set_column($title,\Closure $callback)
    {
        $this->columns[$title]=$callback;
        return $this;
    }
    
    public function set_columns($val)
    {
        $this->columns=$val;
        return $this;
    }
    
    public function set_struct($val)
    {
        $this->struct=$val;
        return $this;
    }
    
    public function set_order($val)
    {
        $this->order=$val;
        return $this;
    }
    
    public function html()
    {
        // <div class="col-xl-6 col-md-12">
        $div=div("table-responsive m-0 p-0")
            ->attr("style","background-color:#FFEAA7;border-top:1px solid #DDDDDD")
            ->add($this->search())
            ->add($this->table());
            return div()
            ->attr("data-x-mod","data-grid-module")
            ->add(div("row mb-2")
                ->attr("style","display:none")
            ->add(div("col-xs-12 col-md-4")
                ->add(Combo::init()
                    ->set_data([
                        "off"=>'Search Mode Off',
                        "on"=>'Search Mode On'
                    ])
                    ->set_placeholder("SEARCH MODE")
                    ->set_name("search_mode")
                    ->set_default("off")
                    ->html()
                )
            )
        )->add($div);
        /*
        //<div class="ms-panel">
        div("ms-panel")
        ->attr("data-x-mod","data-grid-module")
            //<div class="ms-panel-header">
            ->add(div("ms-panel-header")
                //<h6>Recent Buyers</h6>
                ->add(h6()->add($this->title))
                //</div>
                )
            //<div class="ms-panel-body p-0">
            ->add(div("ms-panel-body p-0")
                //<div class="table-responsive">
                ->add(div("table-responsive p-1")
                    //<table class="table table-hover thead-light">
                    ->add($this->table())
                    //</div>
                )
            //</div>
        );
        */
    }
    
    public function search()
    {
        $row=div(ROW ." mt-2 mb-1");//x($this->search_forms,9);
        $arr=$this->search_forms;
        $len=count($arr);
        $size= floor(12/($len+1));
        if($len==6){$size=2;}
        $class="col-xs-6 col-lg-$size col-md-$size";
        $c2=$class;
        if($len==6){
            $c2="col-xs-12 col-lg-12 col-md-12";
        }
        foreach($this->get_order() as $field=>$b)
        {
            if(!in_array($field, $arr)){
                continue;
            }//x()
            $row->add(div($class)
                ->add($this->inp($field,true,$this->search_filters[$field]??null))
            );
        }
        $row->add(div($c2)
            ->add(button(BNDS . " m-0 btn-search btn-block")
                ->add("Search")
            )
        );
        return $row;
    }
    public function table()
    {
        $table=table($this->table_class);
        if($this->script)
        {
            $table->attr("data-x-mod",$this->script);
        }
        $table->add($this->table_head());//
        //x($this->model,9);
        $pages=new Page($this->model,$this->filter,$this->rows,$this->page);
        $this->result=$pages->read();//x(qd(),9);
        $table->add($this->body($this->result["data"]??[]));//
        
        $table->add(tfoot()
            ->add(tr()
                ->add(td(["colspan"=>$this->col])
                    ->add($this->pages())
                )
            )
        );
        return $table;
    }
    
    public function col_width($col,$width) {
        $this->widths[$col]=$width;
    }
    
    public function table_head()
    {
        $header=thead();
        $head_row=tr($this->th_style);#x($this->get_order(),9);
        foreach($this->get_order() as $field=>$title)
        { 
            if(isset($this->hide[$field])){
                continue;
            }//x($this->widths,8);
            $a=isset($this->widths[$field])?$this->widths[$field]:$this->min_width;
            $head_row->add(th([
                'style'=>'min-width:'.$a
            ])->add($title));
            $this->col++;
        }
        foreach($this->columns as $field=>$funct)
        {
            if(isset($this->hide[$field])){
                continue;
            }
            $a=isset($this->widths[$field])?$this->widths[$field]:$this->min_width;
            $head_row->add(th([
                'style'=>'min-width:'.$a
            ])->add(ucwords(str_replace("_"," ",$field))));
            $this->col++;
        }
        $header->add($head_row->add($this->add_action(False)));
        $this->col++;
        return $this->form($header);
    }
    
    private function get_struct()
    {
        if($this->struct && !empty($this->struct))
        {
            return $this->struct;
        }//x($this->struct,8);
        return $this->model->_struct_;
    }
    
    private function get_order()
    {
        if(empty($this->order))
        {
            foreach($this->get_struct() as $name=>$field)
            {
                if($field->isPrimary() && $this->ignore_key)
                {
                    continue;
                }
                if($field->getExtra('hide')||isset($this->hide[$name]))
                {
                    continue;
                }
                $this->order[$name]=ucwords(str_replace("_"," ",$field->getVerbose()));
            }
        }
        return $this->order;
    }
    
    private function body($data)
    {
        $tbody=tbody()->attr("data-url",$this->url);
        foreach($data as $row)
        {
            $tbody->add($this->row($row));
        }
        return $tbody;
    }
    
    public function set_sort_filters($data)
    {//x($data,8);
        $_data=[];
        $a=explode(";",$data);
        foreach($a as $b)
        {
            if($b==""){
                continue;
            }
            $c=explode(":",$b);
            if(count($c)<3)
            {
                $this->column_filters[$c[0]]=$c[1];
            }else{
                $this->column_filters[$c[0]]=$c[1].":".$c[2];
            }
            $_data=array_merge($_data,$this->op($this->fg($c,$a)));
        }
        $this->set_filter(["where"=>$_data]);
    }
    
    public function form($thead)
    {
        $row=tr($this->th_style)
            ->attr("data-row","form");
        foreach($this->get_order() as $f=>$x)
        {
            $td=td();
            $row->add($td->add($this->inp($f)));
        }
        foreach($this->columns as $name=>$func)
        {
            $row->add(td());
        }
        $td=td();
        $td->add(input()
            ->attr("data-pattern","/\d+/")
            ->attr("value",$this->id)
            ->attr("type","hidden")
            ->attr("name","id")
        );
        $td->add(button("btn btn-sm btn-block btn-send m-0 p-1 btn-outline-".SUBMIT)
            ->add(i("fas fa-paper-plane"))
            ->add(span()->add("SUBMIT")->attr("style","color:white"))
            //->attr("style","margin-top: 0 !important")
        );
        if(!$this->form_hide)
        {
          $thead->add($row->add($td));  
        }
        return $thead;
    }
    
    public function row($data)
    {
        $row=tr($this->td_style);
        $struct=$this->get_struct();
        foreach($this->get_order() as $f=>$x)
        {
            $td=td();
            if($struct[$f]->getExtra('hide')||isset($this->hide[$f]))
            {
                continue;
            }
            if(isset($this->transformation[$f]))
            {
                $td->add($this->transformation[$f]($data[$f],$data));
            }
            elseif($struct[$f]->getOptions())
            {
                $td->add($struct[$f]->getOptions()[(int)$data[$f]]);
            }
            elseif($struct[$f]->getForeign()|| is_array($struct[$f]->getExtra('model')))
            {
                $model=Factory::app($struct[$f]->getExtra('model'));
                $model->setConnection($this->connection);
                $model->get($data[$f]);
                $td->add($model->rep());
            }
            else
            { 
                $td->add($data[$f]);
            }
            $row->add($td);
        }
        foreach($this->columns as $name=>$func)
        {
            $td=td();
            $row->add($td->add($func($data)));
        }
        $row->add($this->action_btn($data));
        return $row;
    }
    
    private function action_btn($data)
    {
        $td=td();
        $div=div("dropdown dropdown-action");
        $div->add(a("action-icon dropdown-toggle")
            ->attr([
                "href"=>"#","data-toggle"=>"dropdown","aria-expanded"=>"false"
            ])
            ->add(i("fa fa-ellipsis-h"))
        );
        $menu=div("dropdown-menu dropdown-menu-right");
        foreach ($this->action as $row)
        {
            $menu->add(a("dropdown-item ".$row['act'])
                ->attr("data-action",strtolower($row['text']))
                ->add(i($row['icon']." mr-2"))
                ->add(span()->add($row['text']))
            );
        }
        $td
            ->add($div->add($menu))
            ->add(input()
                ->attr([
                    "name"=>"_key_",
                    "type"=>"hidden",
                    "value"=>$data[$this->model->pk()]
                ])
            );
        if($this->form_hide){
            $td->add(span(["data-edit"=>1]));
        }
        return $td;
    }
    
    private function add_action($buttons=True)
    {
        $td=td();
        if($buttons)
        {
            $td->add(input([
                "name"=>"id",
                "type"=>"hidden",
                "value"=>$this->id,
                "data-pk"=>1,
                "data-pattern"=>"/^\d{1,10}$/"
            ]));
            $td->add(input([
                "value"=>$this->inactive,
                "class"=>"inactive",
                "type"=>"hidden"
            ]));
            $td->add(button("btn btn-primary submit btn-sm")
                ->add(i("fa fa-paper-plane"))
                ->attr("title","Sumbit")
                ->attr("data-toggle","tooltip")
            );
            
        }
        else
        {
            $a=isset($this->widths["_action_"])?$this->widths["_action_"]:$this->action_min_width;
            $td=th([
                'style'=>'min-width:'.$a
            ])->add("Action");
        }
        return $td;
    }
    private function value_of($field)
    {
        if($this->id)
        {
            $val=$this->model->get($this->id);
            if($val and isset($val[0]) and isset($val[0][$field])){
                return $val[0][$field];
            }
        }
        return null;
    }
    
    private function inp($f,$search=false,$def=null)
    {
        $struct=$this->get_struct()[$f];//x(Char::gen(16),9);
        $default=$def??$this->value_of($f); 
        if(!$default&&isset($this->form_config[$f]))
        {
            $default=$this->get_default($f,$this->form_config[$f]);
        }
        if(!$default&&isset($this->sort_filters[$f]))
        {
            $default=$this->search_filters[$f]["value"];
        }
        if(isset($this->_form_config[$f]))
        {
            $struct->setExtra("filter",$this->_form_config[$f]);
        }
        
        $struct->setExtra(
            'data-placeholder',$this->get_order()[$f]
        );
        $struct->setExtra(
            $search?'data-search':'data-input','true'
        );
        $fi=new FieldInput($struct,$default);
        return $fi->set_connection($this->connection)->element();
    }
    private function get_default($f,$value)
    {
        $s=$this->get_struct();
        if(is_array($value)){
            if($s[$f]->getForeign())
            {
                $model=Factory::app($s[$f]->getExtra("model"));
                $model->fetch(["where"=>$value]);
                $value=$model->id;
            }
            else{
                $value=null;
            }
            return $value;
        }
    }
    private function title($title)
    {
        $spn = span("row");
        $spn->add(span("col-md-5 col-sm-5 col-xs-4")
            ->add(h4("title-heading")->add($title))
            );
        $spn->add(
            span("col-md-7 col-xs-8 col-sm-7 row pull-right")
            ->add(
                span("col-md-4 col-xs-4 col-sm-4  pull-right")
                ->add($this->filter_toggle())
                )
            ->add(
                span("col-md-4 col-xs-4 col-sm-4  pull-right")
                ->add($this->filter_select())
                )
            ->add(
                span("col-md-4 col-xs-4 col-sm-4  pull-right")
                ->add($this->filter_input())
                )
            );
        return div([
            "style"=>"left:auto;right:auto"
        ])->add($spn);
    }
    private function filter_toggle()
    {
        return Ig::init()
        ->set_prepend(div('input-group-text search')
            ->add(i("fa fa-filter"))
            )
            ->set_input(Combo::init()
                ->set_name("search-display-option")
                ->set_data(["Hide","Show"])
                //->set_data($data)
                ->html()
                )->tag();
    }
    private function filter_input()
    {
        return Ig::init()
        ->set_append(div('input-group-text search')
            ->add(i('fas fa fa-search'))
            )
            ->set_input(input([
                "name"=>"filter",
                "class"=>"form-control  form-control-sm",
                "placeholder"=>"operator:search"
            ]))->tag();
    }
    
    
    private function filter_select()
    {
        $sel = select([
            "class"=>"form-control  form-control-sm","name"=>"column"
        ]);
        $sel->add(option([
            "value"=>"","text"=>"Select Column"
        ]));
        foreach($this->get_order() as $name=>$title)
        {
            $sel->add(option([
                "value"=>$name,
                "data-value"=>$this->get_filter_value($name),
                "text"=>$title
            ]));
        }
        return $sel;
    }
    private function get_filter_value($name)
    {
        if(isset($this->column_filters[$name]))
        {
            return$this->column_filters[$name];
        }
        return "";
    }
    
    private function op($data)
    {
        return Filter::init($data, $this->get_struct());
    }
    
    private function fg($data)
    {
        return $data;
    }
    
    private function delete_btn($data)
    {
        $model=$this->db;
        $model->get($data[$model->pk()]);
        return DeleteBtn::init($model)->html();
    }
    
    private function update_btn($data)
    {
        if(!Access::hasUpdate())
        {
            return span();
        }
        return button("btn btn-xs btn-danger del-control")
        ->attr("data-value",$data[$this->db->pk()])
        ->attr("data-edit",$this->edit_with_create)
        ->add(i("fa fa-edit"))
        ->attr("data-toggle","tooltip")
        ->attr("title"," Edit");
    }
    
}

?>