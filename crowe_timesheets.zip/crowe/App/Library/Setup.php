<?php


namespace Lib;

class Setup{
	
	use Init;
	
	public function __construct()
	{
		$this->model=Factory::app('User','Gs');
	}
	
	public static function perc(){
		$inst=self::init();
		$tables=$inst->model->select([
			'table'=>'sqlite_master',
			'select'=>['*'],
			//'where'=>
		]);
		x($tables,8);
	}
	
}