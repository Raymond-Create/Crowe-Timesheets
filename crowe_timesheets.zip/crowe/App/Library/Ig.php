<?php

namespace Lib;

class Ig
{
    
    use Init;
    
    private
    $input=[],
    $append=null,
    $prepend=null;
    
    public function __construct($config=[])
    {
        if(is_array($config))
        {
            foreach($config as $key=>$val)
            {
                $method='set_'.$key;
                if(method_exists($this,$method))
                {
                    $this->$method($val);
                }
            }
        }	
    }	
    public function set_prepend($tag)
    {
        $this->is_tag($tag,'prepend');
        $this->prepend=$tag;
        return $this;
    }
		
    public function set_input($tag)
    {
        $this->is_tag($tag,'input');
        $this->input[]=$tag;
        return $this;
    }
		
    public function set_append($tag)
    {
        $this->is_tag($tag,'append');
        $this->append=$tag;
        return $this;
    }
		
    public function is_tag($tg,$name)
    {
        if(!$tg instanceof \Huchi\Classes\Tag)
        {
            throw new \Exception($name .' should be instance of tag');
        }
    }
    public function tag()
    {
        $tg=div('input-group input-group-sm');
        $app=div('input-group-addon input-group-append');
        $pre=div('input-group-addon input-group-prepend');
        if($this->prepend instanceof \Huchi\Classes\Tag)
        {
            $tg->add($pre->add($this->prepend));
        }
        if(count($this->input)>0)
        {
            foreach($this->input as $input)
            {
                $tg->add($input);
            }
        }
        else
        {
            throw new \Exception('At least one input is required');	
        }
        if($this->append instanceof \Huchi\Classes\Tag)
        {
           $tg->add($app->add($this->append));
        }
        return $tg;  
    }
}    