<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ID
 *
 * @author bchaumba
 */
namespace Lib;

use Lib\Session as S;

class ID {
    public static function get() {
        return (new self)->token();
    }
    public static function server($code=null)
    {
        $file=ROOT .DS. 'Files' .DS. '.thumb';
        if($code)
        {
            if(file_exists($file))
            {
                unlink($file);
            }
            file_put_contents($file, $code);
        }
        if(!file_exists($file))
        {
            return self::server(Char::gen(200));
        }
        return file_get_contents($file);
    }
    
    private function token(){
        if(S::get("HUCHI_USER_TOKEN_EXPIRY") && S::get("HUCHI_USER_TOKEN_EXPIRY") > time()){
            S::set("HUCHI_USER_TOKEN_EXPIRY",time() + config("lag"));
            return S::get("HUCHI_USER_TOKEN");
        }
        return $this->gen();
    }
    
    private function gen()
    {
       $id = '';
       $id.=self::server();
        $id .= "HUCHI".date('d');
        $token = md5($id); 
        S::set("HUCHI_USER_TOKEN_EXPIRY",time() + config("lag"));
        S::set("HUCHI_USER_TOKEN",$token);
        return $token; 
    }
}