<?php

namespace Lib;

class Templator
{
	
	private $components=[
		"panel"=>[
			"root"=>"panel panel-primary",
			"panel-body"=>"panel-body",
			"panel-header"=>"panel-header",
			"panel-heading"=>"panel-heading",
			"panel-footer"=>"panel-footer"
		],
		"inputGroup"=>[
			"root"=>"input-group",
			"text"=>"input-group-text",
			"append"=>"input-group-append",
			"prepend"=>"input-group-prepend",
		]
	],$indexed;
	
	public static function index($indexed)
	{
		$self = new self();
		$self->components["box"] = $self->components["panel"];
		$self->components["card"] = $self->components["panel"];
		if(!isset($self->components[$indexed]))
		{
			throw new Exception("Index $indexed not found");
		}
		$self->indexed = $indexed;
		
		$indexedFile = LIBRARY .DS. "Config" .DS. "$indexed.php";
		if(file_exists($indexedFile))
		{
			$self->components[$indexed] = require $indexedFile;
		}
		return $self;
	}
	
	public function get($index)
	{
		return isset($this->components[$this->indexed][$index])?$this->components[$this->indexed][$index]:'';
	}
}