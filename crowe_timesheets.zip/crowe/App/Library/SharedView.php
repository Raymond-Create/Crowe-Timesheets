<?php

namespace Lib;


class SharedView{
   
   use Fs;
   
   private 
    $view;
   public function __construct()
   {
       $this->view=div()->attr("data-x-mod","shared-view");
   }
   
   public function add($title,$content,$key=null){
       $div=div("row")
        ->attr("style","background-color:white;");
       if($key)
       {
           $div->attr("data-index",$key);
       }
       $this->view->add($div
           ->add(div("col-xs-12 col-md-12 col-sm-12")
                ->add($this->_set($title, $content))   
           )
       );
   }
	
   public function html()
   {
       return $this->view;
   }
}


								