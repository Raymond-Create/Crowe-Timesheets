<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Lib;

/**
 * Description of Connect
 *
 * @author blessing
 */

use DB\Classes\ModelFactory;

class Connect {
    
    public static function init():Connect
    {
        if(!self::$instance instanceof Connect){
            self::$instance=new self;
        }
        return self::$instance;
    }
    //put your code here
    public function mod($model,$module,$index=null)
    {
        if(is_array($model))
        {
            $module = $model[1];
            $model = $model[0];
        }
        if(is_string($model) && is_string($module))
        {
            $class='Mod'.NS.$module.NS.'Models'.NS.$model;
            if(!$this->exists($class))
            {
                $class='Core'.NS.$module.NS.'Models'.NS.$model;
                if(!$this->exists($class))
                {
                    throw new \Exception("Model with class '$class' does not exist");
                }
            }
        }
        else{
            $class=$model;
        }
        $object = new ModelFactory();
        $object->setClass($class);//
        //x()
        $object->setSetup($this->config[$index??$this->index]);
        return $object->createModelObject();
    }
    
    public function updatedConfig($db,$ignoreUser=false)
    {
        global $CONFIG;
        $copy=$CONFIG["app_db"];
        if($copy["type"]=="mysql_db"){
            $copy["settings"]["database"]=$db;
            $copy["settings"]["user"]=!config("update_user")?$copy["settings"]["user"]:$db;
        }else{
            $p = explode(DS,$copy['path']);
            $p[count($p)-1] = $db;
            $copy['path'] = implode(DS,$p);
        }//x($copy,7);
        return $this->addConfig($copy,$db);
    }
    
    public function addConfig($setup,$index=null){
        if($index){
            $this->config[$index]=$setup;
        }
        else{
            $this->config[]=$setup;
        }
        //x($setup,7);
    }
    
    private function exists($class)
    {
        $file=APP.DS.str_replace('Mod'.DS,'Modules'.DS,str_replace(NS,DS,$class)).'.php';
        return file_exists($file);
    }
    
    private $config,$index=0;
    public static $instance;
}