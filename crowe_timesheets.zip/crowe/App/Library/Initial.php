<?php

namespace Lib;

class Initial
{
	public function __construct($ui)
	{
		$this->row=div("row index")
			->attr('data-ui',$ui);
	}
}