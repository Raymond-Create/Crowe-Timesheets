<?php

namespace Lib;

trait DataLoader{
	
    public function adddata($data){
        try{
            $mod = Factory::app("Contact","Gs");
            $mod->begin();
            $this->apply_data($data);
            $mod->commit();
            return $this->count;
        }
        catch(\Exception $ex){
            $mod->rollback();
            x($ex,9);
            return false;
        }
    }
    
    private function data_entry($data,$table,$module){
        $mod = Factory::app($table,$module);
        foreach($data as $record){
            foreach($record as $field=>$value){
                if(is_array($value) && count($value)==3){
                    $value = $this->data_entry([$value[2]],$value[1],$value[0]);
                }
                $record[$field] = $value;
            }
            if(!$mod instanceof \Huchi\Classes\Model){
                x([$table,$module],9);
            }
            $mod->fetch(["where"=>$record]);
            if(!$mod->isEmpty()){
                $r = $mod->id;
                continue;
            }
            $mod->append($record);
            $is_saved = $mod->save();
            if($is_saved){
                $this->count++;
            }
            $r = $is_saved;
        }
        return $r;
    }
    
    private function apply_data($data){
        foreach($data as $module => $tables){
            foreach($tables as $table => $datum){//x($datum);
                $this->data_entry($datum,$table,$module);
            }	
        }
    }
    
    private $count=0;
}