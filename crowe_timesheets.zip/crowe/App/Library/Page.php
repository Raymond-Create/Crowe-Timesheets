<?php

namespace Lib;

use DB\Classes\Pagination;

class Page extends Pagination
{	
}