<?php

namespace Lib;


class TableFixer{
    
    public $model,$connection;
    
    public static function model($model,$connection=null) {
        $fixer=new TableFixer(null,null,$connection);
        $fixer->set_model($model);
        return $fixer->fix();
    }
    
    public static function init($model=null,$module=null,$connection=null): \Huchi\Classes\Model 
    {
        $fixer=new TableFixer($model,$module,$connection);//x($fixer->fix(),7);
        return $fixer->fix();
    }
    
    public function __construct($model=null,$module=null,$connection=null){
        
        if($connection)
        {
            $this->connection=$connection;
        }
        
        if($model)
        {
            $this->set_model(Factory::app($model, $module));
        }
    }
    
    public function set_model($model)
    {
        $this->model=$model;
        if($this->connection)
        {
            $this->model->setConnection($this->connection);
        }else{
           $this->connection=$this->model->getConnection();
        }
    }
    
    public function fix(): \Huchi\Classes\Model
    {
       
        if(ENV==DEV)
        {
            
            foreach($this->model->struct() as $field)
            { 
                $ext=$field->getExtra('model');
                //x($ext);
                if($field->getForeign()||$ext){//x($field->getExtra("model"));
                    //x([$this->model->table(),$field,$ext]);
                    TableFixer::init($field->getExtra("model"), $this->connection);
                }
            }
            $e=$this->model->tableExists();
          //  x([$this->model->table(),$e]);
        }
        return $this->model;
    }

}