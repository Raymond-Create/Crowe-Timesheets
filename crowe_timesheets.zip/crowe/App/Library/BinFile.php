<?php

namespace Lib;

class BinFile{
	
	public static function init($path,$root=false){
		return new self($path,$root);
	}
	public function __construct($path,$root=false){
		$this->path = $path;
		$this->root = $root?$root:ROOT;
	}
	public function read($path=false){
            $file = $this->root . DS . str_replace(ROOT . DS , "", $path?$path:$this->path); 
            $file = str_replace("/" , DS, str_replace("\\" , DS, $file)); 
            // be careful that the path is correct
            if(!file_exists($file)){
                return $file;
            }
            if(!is_file($file)){
                return $file;
            }
            $data = fopen($file, 'rb');
            $size = filesize($file);
            $contents = fread($data, $size);
            fclose($data);
            return base64_encode($contents);
	}
        public function mime($path=false){
            $file = $this->root . DS . str_replace(ROOT . DS , "",$path?$path:$this->path); 
            // be careful that the path is correct
            if(!file_exists($file)){
                    return null;
            }
            return \mime_content_type($file);
        }
	public function write($base64_string, $output_file=false) {
            $output_file = $output_file?$output_file:$this->path;
            // open the output file for writing
            $ifp = fopen( $this->root . DS . $output_file, 'wb' ); 

            // split the string on commas
            // $data[ 0 ] == "data:image/png;base64"
            // $data[ 1 ] == <actual base64 string>
            $data = explode( ',', $base64_string );

            // we could add validation here with ensuring count( $data ) > 1
            fwrite( $ifp, base64_decode( $data[ 1 ] ) );

            // clean up the file resource
            fclose( $ifp ); 

            return $output_file;
	}

	private $path,$root;
}