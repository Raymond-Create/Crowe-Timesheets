<?php

namespace Lib;
use DB\Classes\ModelFactory;
use Sys\Classes\MetaData;

class Factory{
	
    private $config;
    
    public static function init()
    {
        return new self();
    }
    
    public function __construct()
    {
        $this->reset();
    }
    
    public function reset()
    {
        global $CONFIG;
        $this->set_config($CONFIG["app_db"]);
    }
    
    public function set_config($config)
    {
        $this->config=$config;
    }
    
    public function get_config()
    {
        return $this->config;
    }
    
    public function update($database):void
    {
        if($this->config['type'] == 'sqlite_db')
        {
        		if(is_null($this->config['path']))
        		{
        			global $FALLBACK;
        			$this->config=$FALLBACK['app_db'];
        		}
        		//x($this->config,8);
            $p = explode(DS,$this->config['path']);
            $p[count($p)-1] = $database;
            $this->config['path'] = implode(DS,$p);
        }
        else{
            $this->config['settings']['database'] = $database;
            if(config("update_user")){
                $this->config['settings']['user'] = $database;
            }
        }
    }
    
    public function get_model($model,$module=null)
    {
        if(is_array($model))
        {
            $module = $model[1];
            $model = $model[0];
        }
        if(is_string($model) && is_string($module))
        {
            $class='Mod'.NS.$module.NS.'Models'.NS.$model;
            if(!$this->exists($class))
            {
                $class='Core'.NS.$module.NS.'Models'.NS.$model;
                if(!$this->exists($class))
                {
                    throw new \Exception("Model with class '$class' does not exist");
                }
            }
        }
        else{
            $class=$model;
        }
        if(isset($this->config["settings"])&&!$this->config["settings"]["user"]){
            global $FALLBACK;
            $this->set_config($FALLBACK["app_db"]);
        }
        $object = new ModelFactory();
        $object->setClass($class);//
        $object->setSetup($this->config);
        return $object->createModelObject();
        
    }
    
    private function exists($class)
    {
        $file=APP.DS.str_replace('Mod'.DS,'Modules'.DS,str_replace(NS,DS,$class)).'.php';
        return file_exists($file);
    }
    
    
    public static function lib($name,$module=null,$params=null)
    {
	if($module){
            $filename = APP .DS. 'Modules' .DS. $module .DS. 'Library' .DS. $name . '.php';
            $class = 'Mod' .NS. $module .NS. 'Library' .NS. $name;
         if(!file_exists($filename))
         {
            $filename = APP .DS. 'Core' .DS. $module .DS. 'Library' .DS. $name . '.php';
            $class = 'Core' .NS. $module .NS. 'Library' .NS. $name;
         }
        }
        else{
            $filename = APP .DS. 'Library' .DS. $name . '.php';
            $class = "Lib" .NS. $name;
        }
        $config = SETTINGS .DS. 'Libraries' .DS. $name . '.php';
        if(file_exists($config) && !$params && !$module){
            $params = require $config;
        }
        if(!file_exists($filename)){
            throw new \Exception("File $filename containing class $name does not exist");
        }
        return new $class($params);
        //MetaData::init($model);
        //return $model;
    }
    
    

    public static function app($model,$module=null):\Huchi\Classes\Model
    {
        $self=self::init();
        if(Session::get("user_selected_database"))
        {
            $self->update(Session::get("user_selected_database"));
        }
        return $self->get_model($model, $module);	
    }

    public static function db($model,$module=null,$config=[])
    {
        $self=self::init();
        if(!empty($config)&&is_array($config)){
            $self->set_config($config);
        }
        return $self->get_model($model, $module);
    }

    public static function sys($model,$module=null)
    {
        $self=self::init();
        global $CONFIG;
        $self->set_config($CONFIG["sys_db"]);
        return $self->get_model($model, $module);
    }
    
    public static function myserver($config=false)
    {
		return ModelFactory::myserver($config);
	}
}