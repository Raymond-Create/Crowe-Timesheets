<?php

namespace Lib;

class Data{
	
	public $model,$config,$tree=[],$file,$filter=[];
	
	public function set_model($model,$module=null)
	{
			$this->model=$this->_model($model,$module);
	}
	
	public function set_config($cnf)
	{
			$this->config=$cnf;
	}
	
	public function set_filter($filter)
	{
	    $this->filter=$filter;
	}
	
	public function set_file($fullpath)
	{
			$this->file=$fullpath;
	}
	
	
	public function _model($model,$module=null)
	{
			$factory=Factory::init();
			if($this->config)
				$factory->set_config($this->config);
			return $factory->get_model($model,$module);
	}
	
	public function output($type=null)
	{
			if(!is_null($type)&&$type!=0&&$type!=1)
			{
				$type=null;
			}
			return file_put_contents(
				$this->file,
				json_encode(is_null($type)?$this->tree:$this->tree[$type])
			);
	}
	
	public function input($type)
	{
			if(!is_null($type)&&$type!=0&&$type!=1)
			{
				$type=null;
			}
			$data=json_encode(file_get_contents($this->file));
			if(is_null($type))
			    $this->tree=$data;
		    $this->tree=$data[$type];
	}
	
	public function read($limit=null,$offset=null)
	{
	    
	    if($limit){
	        $this->filter["limit"]=[];
	        $this->filter["limit"][0]=$limit;
            if($offset)
                $this->filter["limit"][0]=$offset;
	    }
        //x($this,8);
	    $data=$this->model->select($this->filter);
	    x($data,8);
	}
}