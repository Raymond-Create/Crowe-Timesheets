<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Lib;

use Huchi\Classes\Tag as T;
/**
 * Description of Scripts
 *
 * @author bchaumba
 */
class Scripts {
    //put your code here
    public static function get($type = 'css'){
    		$s = new self;   
    		$s->pop();    
       return $s->links($type);
    }
    public function find($type){
        $u = '';
        foreach(['Modules'] as $dir){
           $u .= $this->over($dir,$type);
        }//x($u,7);
        return $u;
    }
    private function over($folder,$type){
        $u = '';//x($folder,8);
        $dir = APP . DS . $folder . DS;
        $modules = [];
        if(is_dir($dir))
        {
        	 $modules = ls($dir);
        }//x(ls("/sdcard/htdocs/project/App/Modules"),7);
        foreach($modules as $module){
           $u .= $this->files($module,$dir,$type,$folder);
        }//x(ls($dir),9);
        return $u;
    }
    public function files($module,$dir,$type,$folder){      
        $path = SERVER_URL . '/App/' . $folder . '/' . $module . '/static/' . $type . '/' ;//x($path,9);
        $folder = $dir .  $module . DS . 'static' . DS . $type . DS;  
        $group = '';
        if(!is_dir($folder)){//x($folder,8);
            return $group;
        }
        foreach(ls($folder) as $file){   
            if(!preg_match('/[a-zA-Z0-9\-\.]+\.'.$type.'$/', $file)){
                continue;
            }
            if(ENV == "development"){
                $file .= "?" . md5(time());
            }
            
            if($type == 'css'){
                $group .= '<LINK href="'. $path . $file .'" rel="stylesheet">';
            } 
            else{
                $group .= '<script src="'. $path . $file .'"></script>';
            }
            
            //x([$file,$group,$path],8);
        }
        
       // if($module == "settings"){
        		//x($group,9);
      //  }
        return $group;
    }
    
    private 
    		$script_array=[];
    		
    	public function pop()
    	{
    		$this->make_list('js','Modules');
    		$this->make_list('js','Core');
    		$this->make_list('css','Modules');
    		$this->make_list('css','Core');
    		//x($this->script_array,9);
    	}
    	
    	private function links($type)
    	{
    		$links='';
    		foreach($this->script_array[$type] as $url)
    		{
    		    if(ENV == "development"){
    		        $url .= "?" . md5(time());
    		    }
    		    if($type == 'css'){
                    $links .= '<LINK href="'. $url .'" rel="stylesheet">';
                } 
                else{
                    $links .= '<script src="'. $url .'"></script>';
                }
    		}//x(html_escape($links),8);
    		return $links;
    	}
    	private function make_list($folder,$root)
    	{
    		foreach(ls(APP . DS . $root) as $module)
    		{
    			$dir=APP . DS . $root . DS . $module . DS .  'static' . DS . $folder; 
    			if(is_dir($dir))
    			{
    				$this->add(ls($dir),$folder,$module,$root);
    			}
    		}
    	}
    	
    	private function add($array,$folder,$module,$root)
    	{
    		if(!isset($this->script_array[$folder]))
    		{
    			$this->script_array[$folder]=[];
    		}
    		foreach($array as $file)
    		{
    			$file2=$root . DS . $module . DS .  'static' . DS . $folder . DS . $file;
    			$url=SERVER_URL ."/App/$root/$module/static/$folder/$file";
    			$test='Modules' . DS . $module . DS .  'static' . DS . $folder . DS . $file;
    			if($root=='Core' && isset($this->script_array[$folder][$test]))
	    		{
	    			continue;
	    		}
	    		$this->script_array[$folder][$file2]=$url;
    		}
    	}
}