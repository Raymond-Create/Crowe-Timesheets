<?php
namespace Lib;

abstract class AbViewPlain
{
	public $mainView,$view,$_title,$open_title="Open";
    
    public function __construct($mainView)
    {
        $this->mainView=$mainView;
        $this->view = new SharedViewPlain();
    }
    
    public function title($title)
    {
        $this->_title=$title;
    }
    
    public function html()
    {
        //$this->view->add($this->_title,$this->splash());
        $this->url_loader();
        $this->body();
        return div("ms-panel")
        ->attr("data-x-mod","shared-view")
        //<div class="ms-panel-header">
        ->add(div("ms-panel-header")
            //<h6>Recent Buyers</h6>
            ->add($this->splash())
            //</div>
        )
            //<div class="ms-panel-body p-0">
        ->add($this->view->html());
    }
    
    public function url_loader()
    {
    		$this->view->add(
    			$this->open_title,
    			\Lib\UrlLoader::init()->html(),
    			"url_loader"
    		);
    }
    
    abstract public function body();
    
    public function splash()
    {
        return div("row")
            ->add(div("col-xs-6 col-lg-6")
                ->add(h5()->add($this->_title))
            );
            
    }

}
