<?php

namespace Lib;

use Lib\Factory as Lf;

trait Loader
{
	public function model($model,$module=null)
    {
        return Lf::app($model, $module);
    }
    
    public function library($name,$module=null,$param=null)
    {
    	return Lf::lib($name,$module,$param);
    }   
    
    //public function cm($model,$)
}