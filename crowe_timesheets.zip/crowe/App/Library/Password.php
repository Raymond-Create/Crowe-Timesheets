<?php

namespace Lib;

class Password{
	
	public static function hash($password){
		if(phpversion() < 5.6){
			return create_hash($password);
		}
		return password_hash($password, PASSWORD_DEFAULT, ['cost' => 11]);
	}
	
	public static function rehash($password,$hash){
		if(self::verify($password,$hash)){
			if(password_needs_rehash($password, PASSWORD_DEFAULT, ['cost' => 11])){
				return self::hash($password);
			}
		}
		return false;
	}
	
	public static function verify($password,$hash,$oldWay=false){
		if(phpversion() < 5.6 || $oldWay){
			return validate_password($password, $hash);
		}
		return password_verify($password, $hash);
	}
}