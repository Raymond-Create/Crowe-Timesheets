<?php

namespace Lib;

trait Init
{
    public static function init($param=null)
    {
        return new self($param);
    }
    
    public function card($body,$title=null,$footer=null)
    {
        $card=div("card");
        if($title)
        {
            $card->add(div("card-header")
               ->add($title)     
            );
        }
        $card->add(div("card-body")
           ->add($body)     
        );
        if($footer)
        {
            $card->add(div("card-footer")
               ->add($footer)     
            );
        }
        return $card;
    }
} 