<?php

namespace Lib;

class Style
{
	
	public static $inst;
	
	public static function get($type)
	{
		if(!self::$inst)
		{
			return false;
		}
		self::$inst->setType($type);
		return self::$inst;
	}
	
	public static function init($type)
	{
		if(!self::$inst)
		{
			self::$inst = new self($type);
		}
	}
	
	public function __construct($theme)
	{	$theme_file = APP .DS. 'Layouts' .DS. $theme . '.php';
		if(!file_exists($theme_file))
		{
			throw new \Exception("Theme $theme does not exists");
		}
		$this->styles = require $theme_file;
	}
	
	public function setType($type){
		$this->type = $type;
	}
	
	public function __set($name,$value)
	{
		$this->styles[$this->type] = isset($this->styles[$this->type])?$this->styles[$this->type]:[];
		$this->styles[$this->type][$name] = $value;
	}
	
	public function __get($name)
	{
		return isset($this->styles[$this->type]) && isset($this->styles[$this->type][$name])?$this->styles[$this->type][$name]:false;
	}

	private $type,$styles=[];
}