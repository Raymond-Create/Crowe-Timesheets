<?php

namespace Lib;

class SuggestInput extends ChoiceInput
{
	use Init;
	
	protected 
	$model,
	$filter=[],
	$modelString;
	
	public function setModel($model)
	{
		$this->model = Factory::app($model);
		$this->modelString = is_array($model)?implode(",",$model):$model;
		$this->model->tableExists();
		$this->meta["data-pattern"] = $this->model->_struct_[$this->model->pk()]->getPattern();
		return $this;
	}
	
	public function setFilter(array $filter)
	{
		$this->filter = $filter;
		return $this;
	}
	
	public function html()
	{
            $drop = div([
                "class"=>"dropdown","style"=>"width:100%!important"
            ]);
            $menu = div("dropdown-menu");
            $a = a([
                "class"=>"dropdown-toggle",
                "data-toggle"=>"dropdown",
                "aria-expanded"=>"false",
                "aria-expanded"=>"display:none",
                "href"=>"#"
            ]);
            return $drop->add($a)->add($this->inputs())->add($menu);
	}
	
	
	private function inputs()
	{
		$this->presets();
		//create input group
		$inputgroup = div("input-group");
		//create toggle  button
		$toggle = span("input-group-prepend input-group-addon prep")
			->add(span("input-group-text")
				->add(i("fas fa fa-retweet"))
		);
		//create select combo
		$select = select($this->meta);
		$select->add(option([
			"value"=>"",
			"text"=>"Select from ".$this->model->table()
		]));
		foreach($this->model->select($this->filter) as $row)
		{
			$this->model->clear();
			$this->model->append($row);
			$opt = [
				"value"=>$this->model->pk(1),
				"text"=>$this->model->rep()
			];
			if($this->def == $this->model->pk(1))
			{
				$opt["selected"]="selected";
			}
			$select->add(option($opt));
		}
		$this->model->clear();
		$this->model->get($this->def);
		$value = $this->model->isEmpty()?"":$this->model->rep();
		//create type in input
		$input = input([
			"value"=>$value,
			"data-addon"=>"suggest",
			"class"=>"form-control",
			"style"=>"display:none",
			"data-provide"=>$this->name,
			"data-mode"=>$this->modelString,
			"placeholder"=>"Type to select ".$this->model->table()
		]);
		return $inputgroup
			->add($toggle)
			->add($select)
			->add($input);
	}
	
}