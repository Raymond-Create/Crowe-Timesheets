<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */
namespace Lib;

use Lib\Factory as Fa;
use Lib\TableFixer as Tf;

abstract class SideMenu{
    
    public function html()
    {
        return $this->generate_menus();
    }
    
    public function generate_menus()
    {
        $root=$this->menu_root_tag();
        $roots=$this->list_menu_roots();
        foreach($roots as $rt)
        {
            $link=$this->add_menu_group($rt);
            if($link)
            {
                $root->add($link);
            }
        }
        return $root;
    }
    
    public function list_menu_roots()
    {
        $mod=Fa::app("Menu","Authentication");
        return $mod->read([
            "where"=>[
               "cluster"=>"root" 
            ]
        ]);
    }
    
    public function add_menu_group($root)
    {
        //create html tag
        $group=$this->add_group($root);
        if($group)
        {
            return $this->add_links($group, $root["url"]);
        }
        return false;
    }
    abstract public function menu_root_tag();
    abstract public function add_group($root);
    abstract public function add_links($li,$cluster,$parent="");
}