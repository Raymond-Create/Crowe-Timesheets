<?php

namespace Lib;

class Filter
{
    private 
        $struct,
        $data;
    public static function init($data,$struct)
    {
        $ob=new self($data,$struct);
        return $ob->get();
    }
    public function __construct($data,$struct)
    {
        $this->data=$data;
        $this->struct=$struct;
    }
    public function get()
    {
        $filter=[];
        $data=$this->data;
        $key= array_shift($data);
        $type=$this->struct[$key];
        if($type->getOptions())
        {
            $filter[$key]=$this->operator($data,$type->getOptions(),"option");
        }
        elseif($type->getForeign())
        {
            $filter[$key]=$this->operator($data,$type->getExtra("model"),"foreign");
        }
        else
        {
            $filter[$key]=$this->operator($data);
        }
        return $filter;
    }
    
    public function operator($data,$transform=null,$type=null)
    {
        if(count($data)==1){
            return $this->transform($data[0],$transform,$type);
        }
        if($data[0]=='.match'){
            return ['%like',$this->transform($data[1],$transform,$type)];
        }
        if($data[0]=='not'||$data[0]=='<>'){
            return ['<>',$this->transform($data[1],$transform,$type)];
        }
        if($data[0]=='.match.'){
            return ['%like%',$this->transform($data[1],$transform,$type)];
        }
        if($data[0]=='match.'){
            return ['like%',$this->transform($data[1],$transform,$type)];
        }
        if($data[0]=='>='||$data[0]=='greaterOrEqual'){
            return ['>=',$this->transform($data[1],$transform,$type)];
        }
        if($data[0]=='<='||$data[0]=='lessOrEqual'){
            return ['<=',$this->transform($data[1],$transform,$type)];
        }
        if($data[0]=='>'||$data[0]=='greater'){
            return ['>',$this->transform($data[1],$transform,$type)];
        }
        if($data[0]=='<'||$data[0]=='less'){
            return ['<',$this->transform($data[1],$transform,$type)];
        }
        if($data[0]=='='||$data[0]=='equal'){
            return $this->transform($data[1],$transform,$type);
        }
        if($data[0]=='&'||$data[0]=='between'){
            return ['between'=>explode('|',$this->transform($data[1],$transform,$type))];
        }
        if($data[0]=='#'||$data[0]=='in'){
            return ['in'=>explode('|',$this->transform($data[1],$transform,$type))];
        }
    }

    private function transform($data,$transform,$type)
    {
        if($type=="option")
        {
            return $this->option($transform,$data);
        }
        if($type=="foreign")
        {
            return $this->foreign($transform,$data);
        }
        return $data;
    }
    
    
    private function option($options,$data)
    {
    	if(is_array($data))
        {
            $d=[];
            foreach ($data as $value) {
                $d[]=$this->option($options,$value);
            }
            return $d;
        }
        return indexOf($options, $data);
    }
    
    
    private function foreign($model,$data)
    {
    	if(is_array($data))
        {
            $d=[];
            foreach ($data as $value) {
                $d[]=$this->foreign($model,$value);
            }
            return $d;
        }
        $mod=Factory::app($model);
        $dat=explode(" ",$data);
        $where=[];
        foreach($dat as $key=>$d)
        {
            $where[$mod->_rep_[$key]]=$d;
        }
        $mod->fetch(["where"=>$where]);
        return $mod->id?:null;
    }
    
}