<?php
namespace Lib;

abstract class AbView
{
	public $mainView,$view,$_title,$open_title="Open";
    
    public function __construct($mainView)
    {
        $this->mainView=$mainView;
        $this->view = new SharedView();
    }
    
    public function title($title)
    {
        $this->_title=$title;
    }
    
    public function html()
    {
        $this->view->add($this->_title,$this->splash());
        $this->url_loader();
        $this->body();
        return $this->view->html();
    }
    
    public function url_loader()
    {
        $this->view->add(
            $this->open_title,
            \Lib\UrlLoader::init()->html(),
            "url_loader"
        );
    }
    
    abstract public function body();
    
    public function splash()
    {
        return div("row")
            ->add(div("col-xs-6 col-lg-6")
                ->add(h5()->add($this->_title))
            );
            
    }

}
