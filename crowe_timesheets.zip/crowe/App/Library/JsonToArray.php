<?php

namespace Lib;

trait JsonToArray{
	
	public function convert($s){
    	if($s instanceof \stdClass){
    		$s = (array)$s;
    	}
    	foreach($s as $key => $value){
    		if($value instanceof \stdClass){
    			$s[$key] = $this->convert($value);
    		}
    	}
    	return $s;
  }
  
}