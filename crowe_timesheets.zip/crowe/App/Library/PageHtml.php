<?php

namespace Lib;

trait PageHtml
{
	public $result;
	
	public function pages()
    {
        $row=div("row mt-1");
        $pgs=$this->result["info"];
        $showing=[
            10=>10,
            25=>25,
            50=>50,
            100=>100,
            250=>250,
            500=>500
        ];
        
        $pages=[];
        if(is_array($pgs)&&isset($pgs["totPages"]))
        {
            
            $num=(int)$pgs["totPages"];
            $i=1;
            while($i<=$num)
            {
                $pages[$i]=$i;
                $i++;
            }
        }
        $row->add(div("col-xs-6 col-sm-6 col-md-3 col-lg-3 mt-1")
            ->add(label("control-label")->add("Number of all records"))
            ->add(input("form-control form-control-sm")
                ->attr([
                    "value"=>is_array($pgs)&&isset($pgs["totRecs"])?$pgs["totRecs"]:0,
                    "disabled"=>"disabled","name"=>"records"
                ])    
            )
        );
        
        $row->add(div("col-xs-6 col-sm-6 col-md-3 col-lg-3 mt-1")
            ->add(label("control-label")->add("Records per page"))
            ->add(\Lib\Combo::init()
                ->set_data($showing)
                ->set_default(is_array($pgs)&&isset($pgs["showing"])?$pgs["showing"]:NULL)
                ->set_name("showing")
                ->html()
            )
        );
      
        $row->add(div("col-xs-6 col-sm-6 col-md-3 col-lg-3 mt-1")
            ->add(label("control-label")->add("Number of all pages"))
            ->add(input("form-control form-control-sm")
                ->attr([
                    "value"=>is_array($pgs)&&isset($pgs["totPages"])?$pgs["totPages"]:0,
                    "disabled"=>"disabled","name"=>"pages"
                ])
            )
        );
        
          
        
        return $row->add(div("col-xs-6 col-sm-6 col-md-3 col-lg-3 mt-1")
            ->add(label("control-label")->add("Showing page"))
            ->add(\Lib\Combo::init()
                ->set_data($pages)
                ->set_default(is_array($pgs)&&isset($pgs["page"])?$pgs["page"]:NULL)
                ->set_name("page")
                ->html()
            )
        );
    
	}
}