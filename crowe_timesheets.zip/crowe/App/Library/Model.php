<?php

namespace Lib;

abstract class Model extends BaseModel
{

}