<?php

namespace Lib;


class Set{
	
    use \Lib\Init;

    private $data;

    public function __construct($data=null)	
    {
        $this->data=is_array($data)?$data:[];
    }
	
    public function __get($key)
    {
        return isset($this->data[$key])?$this->data[$key]:false;
    }

    public function __set($key,$val)
    {
        $this->data[$key]=$val;
    }
    public function extract($fields)
    {
        $fields=is_array($fields)?$fields:[$fields];
        $w=[];
        foreach($fields as $field) 
        {
            if(isset($this->data[$field]))
            {
                $w[$field]=$this->data[$field];
            }
        }
        return $w;
    }
	
    public function join($del)
    {
        return implode($del,$this->data);
    }

    public function each(\Closure $fn){
        foreach($this->data as $key=>$value) 
        {
            $fn($key,$value);
        }
    }
}
