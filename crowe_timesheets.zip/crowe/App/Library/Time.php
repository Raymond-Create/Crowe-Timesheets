<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Lib;

/**
 * Description of Time
 *
 * @author C Mapurisa
 */
class Time {
    
    private $time;
    
    public static $muted;
    
    public static function display(){
        $inst = new self;
        if(!Time::$muted)
        {
            x($inst->time,7);
        }
    }
    public static function grab($point){
        $time = time();
        $inst = new self;
        $inst ->time[] = [
            'point'=>$point,
            'time'=> $time,
            'delay' => $inst -> delay($time)
        ];
        Session::set('perfomance_timer', json_encode($inst -> time));		
    }
    public static function clean(){
        Session::set('perfomance_timer', json_encode([]));		
    }
    public static function mute(){
        Time::$muted=true;		
    }
    private function delay($time){
        $this->time = (array)$this->time;
        if(isset($this->time[count($this->time)-1]))
        {
            $tm = (array)$this->time[count($this->time)-1];
        }
        else{
            $tm=['time'=>time()];
        }
        return $time - $tm['time'];
    }
    public function __construct(){
        $this->time = json_decode(Session::get('perfomance_timer'));
    }
}
