<?php

namespace Lib;

trait Recid
{
	
   

    //Table auto installer	
    public function idOf($data, \DB\Interfaces\ConnectionInterface $connection=null)
    {//x($data[0],8);
        $model=Factory::app($data[0]);
        if($connection){
            $model->setConnection($connection);
        }
        foreach($data[1] as $key=>$value)
        {
            if(is_array($value)){
                $data[1][$key]=$this->idOf($value,$connection);
            }
        }
        $model->fetch([
            "where"=>$data[1]
        ]);//x($data[1]);x($model->data());
        foreach($data[1] as $key=>$value)
        {
            $model->$key=$value;
        }
        $id=$model->save();
        return $model->id?:$id;
    }
}