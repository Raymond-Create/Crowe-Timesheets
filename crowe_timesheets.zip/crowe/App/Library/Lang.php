<?php

namespace Lib;

use Huchi\Classes\Language as L;

class Lang extends L
{
	public static function all()
	{
		$arr = [
			"saved"=>[
				"sh"=>"Zvachengeteka zvakanaka",
				"en"=>"Succesifully saved"
			],
			"not-saved"=>[
				"sh"=>"Hazvina kuchengeteka zvakanaka",
				"en"=>"NOT saved"
			],
			"record-created"=>[
				"sh"=>"Rhekodhi ragadzirwa zvakanaka",
				"en"=>"Record succesifully created"
			],
			"record-not-created"=>[
				"sh"=>"Rhekodhi harina kugadzirwa zvakanaka",
				"en"=>"Record NOT created"
			],
			"record-modified"=>[
				"sh"=>"Rhekodhi rashandurwa zvakanaka",
				"en"=>"Record succesifully modified"
			],
			"record-not-modified"=>[
				"sh"=>"Rhekodhi harina kushandurwa zvakanaka",
				"en"=>"Record NOT modified"
			],
			"record-deleted"=>[
				"sh"=>"Rhekodhi radzimwa zvakanaka",
				"en"=>"Record succesifully deleted"
			],
			"record-not-deleted"=>[
				"sh"=>"Rhekodhi harina kudzimwa zvakanaka",
				"en"=>"Record NOT deleted"
			]
		];
		global $APPLICATION;
		if($APPLICATION === 'WebApplication')
		{
			foreach(ls(APP .DS. "Modules") as $module)
			{
				$file = APP .DS. "Modules" .DS. $module .DS. "lang.php";
				if(file_exists($file))
				{
					$arr = array_merge($arr,require $file);
				}
			}
		}
		return $arr;		
	}
	
	public static function get($index,$lang=false)
	{
		$object = L::init();
		$lang = $lang?:config("language");
		$object->languages = array_merge($object->languages,self::all());
		return isset($object->languages[$index]) && isset($object->languages[$index][$lang])?$object->languages[$index][$lang]:null;
	}
}  