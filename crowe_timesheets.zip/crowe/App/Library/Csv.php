<?php

namespace Lib;

class Csv
{
    
    use Init;
    
    private 
    $content="",$col=0,$row=0,$dim,$_dim,$name,
    
    $colSep=";",$qutSep="",$rowSep="\r\n";
    
    public function __construct($name)
    {
        $this->name=$name;
    }
    
    public function setColSep($delim)
    {
        $this->colSep=$delim;
        return $this;
    }
    
    public function setRowSep($delim)
    {
        $this->rowSep=$delim;
        return $this;
    }
    
    public function setQuote($delim)
    {
        $this->qutSep=$delim;
        return $this;
    }
    
    public function add($value)
    {
        if($this->col>0)
        {
            $this->content.=$this->colSep;
        }
        $this->content.=$this->qutSep;
        $this->content.=str_replace(',','\,' ,str_replace('"','\"' ,$value));
        $this->content.=$this->qutSep;
        if(is_null($this->_dim))
        {
            $this->_dim=1;
        }
        else{
            $this->_dim++;
        }
        $this->col++;
        return $this;
    }
    
    public function line()
    {
        if($this->col==0)
        {
            return;
        }
        if(is_null($this->dim))
        {
            $this->dim=$this->_dim;
        }
        else{
            if($this->col!=$this->dim)
            {
                throw new \Exception("Dimensional error on line ".$this->row." ending on col ".$this->col." instead of ".$this->dim);
            }
            $this->_dim=0;
        }
        $this->content.=$this->rowSep;
        $this->col=0;
        $this->row++;//x($this->content,9);
        return $this;
    }
    
    public function getCsv()
    {
        return $this->content;
    }
    
    public function download()
    {
        header('Content-Disposition: attachment; filename="'.$this->name.'.csv"');
        header('Content-Type: text/csv'); 
        header("Content-Length: " . strlen($this->content));
        header('Connection: close');
        echo $this->content;
        exit();
    }
}

