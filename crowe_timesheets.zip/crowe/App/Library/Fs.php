<?php
namespace Lib;

trait Fs
{
    public function _set($title,$content)
    {
        return  fieldset("scheduler-border")
        ->add(legend("scheduler-border")->add($title))
        ->add($content);
    }
}

