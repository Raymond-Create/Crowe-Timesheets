<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Lib;
use Huchi\Classes\Controller as HuchiController;
use Huchi\Classes\Tag as t;
use Huchi\Classes\Layout;
use Core\Gs\Library\ModelData;
/**
 * Description of Controller
 *
 * @author bchaumba
 */
class Controller extends HuchiController
{
    
    use Loader;
    
	
    public function on_init() 
    {  
        if(isset($this->_model))
        {
            $this->set_model();
        }
    }
    
    public function set_model() 
    {  
        if(isset($this->_model))
        {
            $this->model = TableFixer::model(
                isset($this->root_db)?
                    Factory::init()->get_model($this->_model):
                Factory::app($this->_model)    
            );
        }
    }

    public function tracking($visitor)
    {
        $visitor->processed=implode("/",$this->page);
        if(!\Lib\Access::linkAllowed($visitor,$this->page))
        {
            if(isAjax())
            {
                $this->json("Error insufficient permissions",0);
            }
            redirect("gs/landing");
        }
    }
	
    public function respond() 
    {
        $this->set("scripts", Scripts::get("js"));
        $this->set("links", Scripts::get("css"));
        if(isAjax())
        {
            $this->view->noHeader();
        }
        parent::respond();
    }
	
	//public $lay
    protected function layout(
        $module=null,
        $controller=null,
        $method=null
    )
    {
        if(!$module)
        {
            $module = $this->page[0];
        }
        if(!$controller)
        {
            $controller = $this->page[1];
        }
        if(!$method)
        {
            $method = $this->page[2];
        }
        return Layout::set($module,$controller,$method);
    }
    
    public function ajax($html)
    {
    	if(\isAjax())
    	{
            $this->json(
                $html instanceof t?$html->as_list():$html,
                1,$html instanceof t?'htmlObject':"text"
            );
    	}
    	$this->set('html',$html);
    }
    
    public function options()
    {
        $filter=[];
        if($this->post() && isset($this->post['filter']))
        {
            $filter=jsonToArray(json_decode($this->post['filter']));//x($filter)
        }
        $opt=[["id"=>"","title"=>"Select ".$this->model->table()]];
        $selexn=$this->model->select($filter);
        $combo=Combo::opts($selexn,$this->model);
        $return=array_merge($opt,$combo);//x($return,9);
        $this->json($return);
    }
    
    public function combo_data($model,$module)
    {
        $this->model=Factory::app($model,$module);
        $this->options();
    }
    
    public function confirm_box()
    {
        $lib=\Core\Gs\Library\Confirm::init();
        $this->ajax($lib->html($this->post()));
    }
    
    public function remove()
    {
        if($this->post())
        {
            if($this->post["type"]=="delete")
            {
                $state=$this->model->delete($this->post['id']);
                $message=$state?"Delete successiful":"Delete NOT successiful";
            }
            if($this->post["type"]=="decline")
            {
                $state=$this->model->decline_request($this->post['id']);
                $message=$state?"Decline request delete successiful":"Decline request delete NOT successiful";
            }
            if($this->post["type"]=="request")
            {
                $state=$this->model->delete_request($this->post['id']);
                $message=$state?"Request for delete successiful":"Request for delete NOT successiful";
            }
            if($this->post["type"]=="cancel")
            {
                $state=$this->model->cancel_request($this->post['id']);
                $message=$state?"Cancellation of delete request successiful":"Cancellation of delete request NOT successiful";
            }
            $this->json($message,$state);
        }
        $this->json("No data supplied",0);
    }
    
    public function table($a=10,$b=1,$inactive=0)
    {
        $this->view->noHeader();
        $lib = new \Lib\Grid($this->model);
        $lib->set_rows(is_numeric($a)?$a:10);
        $lib->set_page(is_numeric($b)?$b:1);
        //x($this->post(),9);
        $lib->set_url(implode("/",$this->page));
        if($this->post() && isset($this->post['sort_filter']))
        {
            $lib->set_sort_filters($this->post['sort_filter']);
        }
        $struct = $this->model->_setup();
        if(isset($struct["is_active"])){
            $lib->set_filter([
                "where"=>["is_active"=>$inactive?0:1]
            ]);
            if($inactive)
            {
                $lib->set_inactivate(1);
            }
        }
        if(isset($this->form_config))
        {
            $lib->set_form_config($this->form_config);
        }
        $oBj=new \Core\Home\Library\Window($this->customize_table($lib),"Window");
        $this->ajax($oBj->html());
        $this->view->pageTitle =  "Table of Records";
    }
    
    public function inactive($a=10,$b=1)
    {
        $this->table($a,$b,1);
    }
    
    public function head($id=null){
        $lib = new \Lib\Table();
        $lib->set_connection($this->model->getConnection());
        $lib->set_model($this->model);
        if(isset($this->form_config))
        {
            $lib->set_form_config($this->form_config);
        }
        if($id)
        {
            $lib->set_id($id);
        }
        $this->ajax($lib->table_head());
    }
    
    public function put($id=null){
        if($this->post())
        {
            $this->_put($id);
        }//x($this->post,9);
        $this->json("No data supplied",0);
    }
    
    
    
    public function customize_table(\Lib\Grid $table)
    {
        return section("ftco-section ftco-degree-bg")
        ->add(div("container")
            ->add(div("row justify-content-center mb-5 pb-5")
                ->add($table->html())
                )
            );
    }
    
    public function read()
    {
        $filter=[];
        if($this->post() && isset($this->post['filter']))
        {
            $filter=jsonToArray(json_decode($this->post['filter']));
        }
        $data=$this->model->select($filter);
        //x(qd(),9);
        $this->json($data);
    }
    
    public function vertical_form($id=0,$bare=0){
        $this->model_form($this->_model[1], $this->_model[0], $id, $bare);
    }
    
    public function model_form($module,$model=0,$id=0,$bare=0)
    {
        $mod=Factory::app($module,$model);
        $mod->set_connection($this->model->getConnection());
        if($mod->table())
        {
            $this->model=$mod;
        }
        if(!$this->model->_struct_[$this->model->pk()]->is_valid($id))
        {
            $id=0;
        }
        $form= VerticalModelForm::init($this->model);
        $form->set_id($id);
        $form->set_model_name($model?[$module,$model]:str_replace("+",NS,$module));
        if($this->post()){
            $this->_put($id,$form->get_model());
        }
        $this->ajax($bare?$form->form():$form->html());
    }
    private function _table($a=10,$b=1)
    {
        $lib = new \Lib\Table($this->model);
        $lib->addRecordNum($a);
        $lib->addPageNum($b);
        $lib->addUrl(implode("/",$this->page));
        if($this->post() && isset($this->post['filter']))
        {
            $lib->addClientFilter($this->post['filter']);
        }
        return $this->customize_table($lib);
    }
    
    private function _put($id,$model=null)
    {
        $lib=ModelData::init($this->model);
        $lib->set_data($this->post);
        $lib->set_id($id);
        $resp=$lib->save();
        $this->json($resp[0],$resp[1]);
    }
    
    
}



