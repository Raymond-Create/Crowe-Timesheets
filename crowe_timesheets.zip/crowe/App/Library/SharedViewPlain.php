<?php

namespace Lib;


class SharedViewPlain{
   
   
   private 
    $view;
   public function __construct()
   {
       $this->view=div("ms-panel-body");
   }
   
   public function add($title,$content,$key=null){
       $div=div("row");
        //->attr("style","background-color:white;");
       if($key)
       {
           $div->attr("data-index",$key);
       }
       $this->view->add($div
           ->add(div("col-xs-12 col-md-12 col-sm-12")
                ->add($content)   
           )
       );
   }
	
   public function html()
   {
       return $this->view;
   }
}


								