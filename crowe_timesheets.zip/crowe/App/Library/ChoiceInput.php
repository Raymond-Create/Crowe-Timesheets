<?php

namespace Lib;

class ChoiceInput
{
	use Init;
	
	public function setField($field)
	{
		return $this->setName($field->getName())
			->setDef($field->getDefault())
			->setOptions($field->getChoices());
		return $this;
	}
	
	public function setOptions(array $options)
	{
		$opts=[];
		foreach($options as $option)
		{
			$opts[$option] = ucwords($option);
		}
		return $this->setChoices($opts);
	}
	public function setChoices(array $choices)
	{
		$this->meta["data-pattern"] = "/^(".implode("|",array_keys($choices)).")$/";
		$this->choices = $choices;
		return $this;
	}
	public function setDef($def)
	{	
		$this->def = $def;		
		return $this;
	}
	
	public function setName($name)
	{
		$this->name = $name;
		return $this;
	}
	public function setMeta($meta)
	{
		$this->meta = !empty($this->meta)?array_merge($this->meta,$meta):$meta;
		return $this;
	}
	
	public function html()
	{
		return $this->input();
	}
	
	
	protected $def=0,$name,$meta=[];
	
	protected function presets()
	{
		//is form-control in classes
		if(!isset($this->meta["class"]) || !preg_match('/form\-control/',$this->meta["class"])){
			$this->meta["class"] = isset($this->meta["class"])?$this->meta["class"] . " form-control form-control-sm":"form-control form-control-sm";
		}
		if(!isset($this->meta["name"]) && $this->name){
			$this->meta["name"] = $this->name;
		}
	}
	
	private $field,$choices;
	
	private function input()
	{
		
		$this->presets();
		//create select combo
		$select = select($this->meta);
		$select->add(option([
			"value"=>"",
			"text"=>"Select ".$this->name
		]));
		foreach($this->choices as $key=>$value)
		{
			$opt = [
				"value"=>$key,
				"text"=>$value
			];
			if($this->def == $key)
			{
				$opt["selected"]="selected";
			}
			$select->add(option($opt));
		}
		return $select;
	}
	
}