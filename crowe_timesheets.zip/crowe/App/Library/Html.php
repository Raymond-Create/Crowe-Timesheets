<?php

namespace Lib;

class Html
{
	use Init;
	
	private
		$input;
	
	public static 
            //class
            $clRgx='/\.([^\.\:\#\@\?\&\+]+)/',
            //name
            $nmRgx='/\:([^\.\:\#\@\?\&\+]+)/',
            //id
            $idRgx='/\#([^\.\:\#\@\?\&\+]+)/',
            //data-value
            $dvRgx='/\@([^\.\:\#\@\?\&\+]+)/',
            //data-x-mod
            $xmRgx='/\?([^\.\:\#\@\?\&\+]+)/',
            //data-addon
            $aoRgx='/\&([^\.\:\#\@\?\&\+]+)/',
            //data-add
            $adRgx='/\+([^\.\:\#\@\?\&\+]+)/';
	
	public function __construct($data)
	{
		$this->input=$data;
	}
	
	public function tag()
	{
		return $this->node($this->input);	
	}
	
	private function node(array $array)
	{
		$dic=[];
		if(isset($array[1])&&is_string($array[1]))
		{
			$dic=$this->string_digest($array[1]);
		}
		if(isset($array[1])&&is_array($array[1]))
            {
			$dic=$array[1];
		}
		$elem=$array[0];
            if($elem=='row')
            {
                $elem='div';
                $dic=$this->row($dic);
            }
            if($elem=='col')
            {
                $elem='div';
                $dic=$this->col($dic);
            }
            if($elem=='btn')
            {
                $elem='button';
                $dic=$this->btn($dic);
            }
            $tag=_e_($dic,$elem);
            if(isset($array[2])&&is_array($array[2]))
            {
                foreach($array[2] as $node)
                {
                    $tag->add(is_array($node)?$this->node($node):$node);
                }
            }
            if(isset($array[2])&&(is_string($array[2])||$array[2] instanceof \Huchi\Classes\Tag))
            {
                    $tag->add($array[2]);
            }
            return $tag;
	}
	
	private function row(array $dic)
	{
		$dic['class']=isset($dic['class'])?$dic['class']:'';
		if(empty($data['class']))
		{
			$dic['class'].="row";
		}
		else{
			$dic['class'].=" row";
		}
		return $dic;
	}
	
	private function col(array $dic)
	{
		$dic['class']=isset($dic['class'])?$dic['class']:'';
		if(preg_match('/(\*(\d\d?\*?)+)/',$dic['class'],$mat))
		{
			$dic['class']=str_replace($mat[0],'',$dic['class']);
			$str=explode('*',$mat[0]);
			$a=array_shift($str);
			if(!empty($str))
			{
				$n=array_shift($str);
				$dic['class'].=' col-lg-'.$n;
			}
			if(!empty($str))
			{
				$n=array_shift($str);
				$dic['class'].=' col-md-'.$n;
			}
			if(!empty($str))
			{
				$n=array_shift($str);
				$dic['class'].=' col-xs-'.$n;
			}
			if(!empty($str))
			{
				$n=array_shift($str);
				$dic['class'].=' col-sm-'.$n;
			}
		}else{
			$dic['class'].=' col-md-12';
		}
		return $dic;
	}
	
	private function btn(array $dic)
	{
		$dic['class']=isset($dic['class'])?$dic['class']:'';
		$pat='/(danger|warning|success|secondary|primary|info)/';
		if(preg_match($pat,$dic['class'],$mat))
		{
			$dic['class']=str_replace($mat[0],'',$dic['class']);
			$dic['class'].=' btn btn-'.$mat[0];
		}else{
			$dic['class'].=' btn btn-default';
		}return $dic;
	}
	
	private function string_digest($str) 
	{
		$dic=[];
		$this->match(self::$dvRgx,'data-value',$str,$dic);
		$this->match(self::$xmRgx,'data-x-mod',$str,$dic);
		$this->match(self::$aoRgx,'data-addon',$str,$dic);
		$this->match(self::$adRgx,'data-add',$str,$dic);
		$this->match(self::$clRgx,'class',$str,$dic);
		$this->match(self::$nmRgx,'name',$str,$dic);
		$this->match(self::$idRgx,'id',$str,$dic);
		return $dic;
	}
	
	private function match($pattern,$type,$string,&$array)
	{
		if(preg_match($pattern,$string,$match))
		{
			$array[$type]=$match[1];
		}
	}
}