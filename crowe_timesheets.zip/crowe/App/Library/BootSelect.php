<?php

namespace Lib;
use Core\Gs\Library\User;

class BootSelect extends Combo{

    use Init;
    
    public function html($addonInModule=false)
    {
        $ig=Ig::init();
        $this->placeholder=$this->model?"Select from ".$this->model->table():"Select...";
        $icon=$this->is_privileged()?"fa fa-plus-square":"fa fa-ban";
	    $ig->set_prepend(span("input-group-text")->add(i($icon)));
	    $this->meta['data-addon']=$addonInModule?'xcreator':'creator';
    	$ig->set_input(parent::html());
    	return $ig->tag();
    }
		
    public function is_privileged()
    {
        return true;		
    }
		
}


								