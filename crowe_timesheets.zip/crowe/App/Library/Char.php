<?php

namespace Lib;

class Char
{

	
    public static function gen($len=10) 
    {
        $self=new self();
        $char='';
        while($len)
        {
            $char.=$self->nextChar();
            $len--;
        }
        return $char;
    }

    protected function nextChar()
    {
        $choices=[0,1,2];
        shuffle($choices);
        if($choices[0] == 0)
        {
            return rand(1,9);
        }
        if($choices[0] == 1)
        {
            return $this->upper();
        }
        return $this->upper(true);
    }
	
	private function upper($lower=false)
	{
		$no = ["o","v","x","w","c","z"];
		$letters = $this->letters;
		shuffle($letters);
		$char = array_pop($letters);
		$s = $lower?strtolower($char):$char;
		if(in_array($s,$no))
		{
			return $this->upper($lower);
		}
		return $s;
	}
	
	private $letters=[
		'A','B','C','D','E','F','G','H','I','J','K','L','M',
		'N','O','P','Q','R','S','T','U','V','W','X','Y','Z'	
	];
}