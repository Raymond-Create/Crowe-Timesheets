<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Lib;

/**
 * Description of VerticalModelForm
 *
 * @author C Mapurisa
 */
class VerticalModelForm {
    //put your code here
    use Init;
    
    private 
        $id=null,
        $db=null,
        $hide=[],
        $url=null,
        $struct=null,
        $show_pk=false,
        $model_name='';
    
    public function __construct(\Huchi\Classes\Model $model) {
        $this->db=$model;
        $this->set_struct();
    }
    public function show_id()
    {
        $this->show_pk=true;
        return $this;
    } 
    public function add_hide($field)
    {
        $this->hide[]=$field;
        return $this;
    }
    public function pop_hide()
    {
        array_pop($this->hide);
        return $this;
    }
    public function reset_hide()
    {
        $this->hide=[];
        return $this;
    }
    public function shift_hide()
    {
        array_shift($this->hide);
        return $this;
    }
    public function set_struct($struct=null)
    {
        $this->struct=$struct?:$this->db->struct();
        return $this;
    } 
    public function set_url($url)
    {
        $this->url=$url;
        return $this;
    }
    public function get_model()
    {
        return $this->db;
    }
    public function set_id($id)
    {
        if($this->struct[$this->db->pk()]->is_valid($id))
        {
            $this->id=$id;
            $this->db->get($id);
        }
        return $this;
    }
    public function set_model_name($name)
    {
        if(is_array($name))
        {
            $this->db=Factory::app($name);
            $this->set_struct();
            if($this->id)
            {
                $this->set_id($this->id);
            }
            $name=implode(",",$name);
        }
        $this->model_name=$name;//x($this->model,9);
        return $this;
    }
    public function form()
    {
        $form=form('form form-vertical')
            ->attr('data-x-mod','vertical-form')
            ->attr('data-url',$this->url)
            ->attr('data-model',$this->model_name);
        foreach($this->struct as $field=>$def)
        {
            if(in_array($field,$this->hide)||$def->getExtra('hide')||(!$this->show_pk&&$def->isPrimary()))
            {
                continue;
            }
            $form->add(div('form-row')
                ->add(div('col-md-12 mb-2')
                    ->add(label('control-label pull-right')
                        ->add($def->getVerbose())
                    )
                    ->add(FieldInput::html($def, $this->value($field),false,$this->db->getConnection()))
                )
            ); 
        }
        $form->add(div('form-row')
            ->add(div('col-md-12')
                ->add(hr())
            )
        );
        $form->add(div('form-row')
            ->add(div('col-md-12')
                ->add(input()
                    ->attr('data-pattern',$this->struct[$this->db->pk()]->getPattern())
                    ->attr('name',$this->db->pk())
                    ->attr('value',$this->id)
                    ->attr('class','pri-key')
                    ->attr('type','hidden')
                )
                ->add(button("btn btn-primary m-0 btn-sm btn-block btn-add")->add("Save Record"))
            )
        );
        return $form;
    }
    
    public function html()
    {
        return $this->form();
        $conatiner = div('container mt-2')
            ->attr('data-x-mod','vertical-model-form')
            ->add(div('card')
                ->add(div('card-header')
                    ->add(h5()->add(ucfirst($this->db->table()) . " Record Form"))    
                )
                ->add(div('card-body')
                    ->add($this->form())  
                )
                ->add(div('card-footer')
                    ->add(div('row')
                        ->add(div('col-xs-12 col-md-6')
                            ->add(input()
                                ->attr('data-pattern',$this->struct[$this->db->pk()]->getPattern())
                                ->attr('name',$this->db->pk())
                                ->attr('value',$this->id)
                                ->attr('class','pri-key')
                                ->attr('type','hidden')
                            )
                            ->add(button('btn btn-info btn-new btn-block')
                                ->add(i('fa fa-plus-circle'))
                                ->add(span()->add(" New Record"))
                            )
                        )
                        ->add(div('col-xs-12 col-md-6')
                            ->add(button('btn btn-success btn-edit pull-right btn-block')
                                ->add(i('fa fa-pencil'))
                                ->add(span()->add(" Edit Record"))
                            )
                        )
                        ->add(div('col-xs-12 col-md-12 mt-1')
                            ->add(button('btn btn-primary btn-add btn-block')
                                ->add(i('fa fa-plus'))
                                ->add(span()->add(" Add Record"))
                            )
                        ) 
                    )
                )
            ); 
        return div('row')->add(div('col-md-12 col-xs-12')->add($conatiner));
    }
    private function value($field){
        return $this->db->{$field}?:'';
    }
}
