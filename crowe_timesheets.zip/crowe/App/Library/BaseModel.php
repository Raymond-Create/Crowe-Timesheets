<?php

namespace Lib;

use DB\Interfaces\ConnectionInterface;
use DB\Interfaces\SqlBuilderInterface;

abstract class BaseModel extends \Huchi\Classes\Model
{
	//
}