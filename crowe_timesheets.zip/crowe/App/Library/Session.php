<?php

namespace Lib;

import("System");

class Session extends \Sys\Classes\Sess{
		
}