<?php

namespace Lib;


class SelectPlus extends Combo{

    use Init;
    
    public function html()
    {
	$ig=Ig::init();//x($this->model,9);
	$this->placeholder=$this->model?"Select from ".$this->model->table():"Select...";
	$ig->set_prepend(span("input-group-text")->add(i("fas fa fa-retweet")));
        $this->meta['data-addon']='suggest';
	$ig->set_input(parent::html());//x($ig,9);
	return $ig->tag();
    }
	
}


								