<?php

namespace Lib;

class Access
{
	
    use Recid;
    
    private 
            $array=[];

    //Table auto installer	
    public static function models(array $array)
    {
        if(ENV!=DEV)
        {
            return;
        }
        //x(config("install"),7);
        if(config("install")||Session::get("install"))
        {
            foreach($array as $m)
            {
                Factory::app($m[0],$m[1])->tableExists();
            }
        }
    }
	
    //link and 	link permmisions installer
    public static function hasRole($role)
    {
        $obj=Factory::app("Role","Gs");
        $obj->fetch([
            "join"=>[
                "join"=>[
                    ["users u","roles.id","u.role"]
                ]
            ],
            "where"=>[
                "u.id"=>Session::get(ID::get()),
                "roles.name"=>$role
            ],
            "select"=>["roles.*"]
        ]);
        return !$obj->isEmpty();
    }
    
    //link and 	link permmisions installer
    public static function setup(array $array)
    {
        if(config("install")||Session::get("install"))
        {
            $obj=new self();
            $obj->array=$array;
            $obj->install();
        }
        
    }

    //Check if user has write permmision
    public static function userLevel()
    {
        return (new self())->level();
    }

    

    //Check if user has write permmision
    public static function linkAllowed($TRACK,$linkArray)
    {
        //x($TRACK->data(),9);
        if(self::userLevel()==1)
        {
            $TRACK->access=1;
            $TRACK->save();
            return true;
        }
        if(self::open(implode("/",$linkArray)))
        {//x();
            $TRACK->access=1;
            $TRACK->save();
            return true;
        }
        $pat=str_replace("/","\/",strtolower($TRACK->processed));
        if(preg_match("/".$pat.".*$/",$TRACK->url))
        {
        		$_la=str_replace("url=","",$TRACK->url);
        		$la=explode("/",$_la);
        }
        else{
        	$la=$linkArray;
        }
        $link=self::linkID($la);//x($link,8);
        if(!$link)
        {
            $TRACK->access=1;
            $TRACK->save();
            return true; 
        }
        $rl=Factory::app("RoleLink","Gs");
        $rl->fetch([
            "where"=>[
                "role"=>Session::get("role"),
                "link"=>$link
            ]
        ]);//x($rl->data(),9);
        if(!$rl->isEmpty())
        {
            $TRACK->access=1;
            $TRACK->save();
            return true;
        }
        $TRACK->access=0;
        $TRACK->save();
        return false;
    }
	
    public static function linkID(array $url)
    {
        if(empty($url))
        {
            return false;
        }
        $link=Factory::app("Link","Gs");
        $link->fetch([
            "where"=>[
                "link"=>strtolower(implode("/",$url)),
                //"link"=>["like%",strtolower(implode("/",$url))]
            ]
        ]);
        if($link->isEmpty())
        {
            array_pop($url);
            return self::linkID($url);
        }
        return $link->id;
    }
    
    public static function open($url)
    {
        return in_array(strtolower($url),[
            "gs/landing",
            "gs/landing/index",
            "gs/login",
            "gs/login/index",
            "gs/login/check_login",
            "gs/login/logout",
            "gs/server/javascript"
        ]);
    }
		
		private function isAdmin()
    {
        $usr=Factory::app(MAUTH,LAUTH);
        $usr->fetch(Session::get(ID::get()));
        return $usr->admin;
		}
    private function level()
    {
        $usr=Factory::app("User","Authentication");
        $data=$usr->read([
            "join"=>[
                "join"=>[
                    ["roles r","users.role","r.id"]
                ]
            ],
            "where"=>[
                "users.id"=>Session::get(ID::get())
            ],
            "select"=>["r.priority"]
        ]);
        return !empty($data)&&isset($data[0])&&isset($data[0]["priority"])?$data[0]["priority"]:null;
    }
	
    private function install()
    {
        if(ENV!=DEV||!Session::get(ID::get()))
        {
            return;
        }
        foreach($this->array as $link)
        {
            $model=Factory::app("Menu","Base");
            //$model->modify(["active"=>1],["title"=>$link["title"]]);x(qd(),8);
            $model->fetch([
                "where"=>["title"=>$link["title"]]
            ]);
            //x($model,9);
            $model->url=$link['url'];
            $model->icon=$link['icon'];
            $model->title=$link['title'];
            $model->active=$link['active'];
            $model->cluster=$link['cluster'];
            $model->module=$link['module'];
            $model->category=$this->idOf($link['category']);
            $id=$model->save();
            $this->perm($model->id?:$id,$link);
        }
    }
	
    private function perm($link,$setup)
    {
        $model=Factory::app("MenuAccess","Authentication");
        $model->tableExists();
        foreach($setup['allowed'] as $role)
        {
            $model->fetch([
                "where"=>[
                    "role"=>$this->role($role),
                    "menu"=>$link
                ]
            ]);
            $model->role=$this->role($role);
            $model->menu=$link;
            $model->save();
        }
    }

    private function role($name)
    {
        $model=Factory::app("Role","Authentication");
        $model->fetch([
            "where"=>["name"=>$name]
        ]);
        $model->name=$name;
        $id=$model->save();
        return $model->id?:$id;
    }
	
	
}